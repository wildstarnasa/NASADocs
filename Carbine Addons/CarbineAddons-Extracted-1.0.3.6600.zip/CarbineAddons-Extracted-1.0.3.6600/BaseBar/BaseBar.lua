-----------------------------------------------------------------------------------------------
-- Client Lua Script for BaseBar
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------
require "Window"
require "Money"
require "ChallengesLib"
require "Unit"
require "GameLib"
require "Apollo"
require "PathMission"
require "Quest"
require "Episode"
require "math"
require "string"
require "DialogSys"
require "PublicEvent"
require "PublicEventObjective"
require "CommunicatorLib"
require "Tooltip"
require "GroupLib"
require "PlayerPathLib"
require "MatchingGame"

local kcrLevelNormal = CColor.new(50/255, 252/255, 246/255, 1)
local kcrLevelFlagged = CColor.new(1, 83/255, 83/255, 1)
local kcrLevelCombat = CColor.new(0.75, 0.75, 0.75, 1)
--------------------------------------------------------------------------------------------------
-- BaseBar module definition
---------------------------------------------------------------------------------------------------
local BaseBar = {}

function BaseBar:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	return o
end

function BaseBar:Init()
	Apollo.RegisterAddon(self)
end

function BaseBar:OnLoad()
	--[[ TODO: REMOVE: DEPRECATED: Raplced with \UI\BaseBarCorner
	Apollo.RegisterEventHandler("ResolutionChanged", 		"GetXP", self)
	Apollo.RegisterEventHandler("UnitEnteredCombat", 		"OnEnteredCombat", self)
	Apollo.RegisterEventHandler("UnitNameChanged", 			"UpdateUnitName", self)
	Apollo.RegisterEventHandler("ChangeWorld", 				"OnChangeWorld", self)
	Apollo.RegisterEventHandler("PersonaUpdateCharacterStats", "OnPlayerLevelChange", self)
	Apollo.RegisterEventHandler("ShowResurrectDialog", 		"OnDeath", self)
	Apollo.RegisterEventHandler("UI_XPChanged", 			"GetXP", self)
	Apollo.RegisterEventHandler("CharacterCreated", 		"OnCharacterCreated", self)
	Apollo.RegisterEventHandler("PlayerLevelChange", 		"OnPlayerLevelChange", self)
	--Apollo.RegisterEventHandler("UI_LevelChange", 			"OnLevelChange", self)
	--Apollo.RegisterEventHandler("UI_EffectiveLevelChanged", "OnEffectiveLevelChange", self)
	Apollo.RegisterEventHandler("UnitPvpFlagsChanged", 		"HelperPickLevelColor", self)


	self.wndBaseBar = Apollo.LoadForm("BaseBarForms.xml", "BaseBarForm", "FixedHudStratum", self)
	self.wndBaseBar:Show(true)
	self.unitPlayer = nil
	self.nCurrentXP = nil
	self.nNeededXP = nil
	self.nRestedXP = nil
	self.nRestedXPPool = nil

	self.bInCombat = false
	self.wndBaseBar:FindChild("PlayerName"):SetText("")

	if GameLib.GetPlayerUnit() then
		self:OnCharacterCreated()
	end
	]]--
end

function BaseBar:OnCharacterCreated()
	local unitPlayer = GameLib.GetPlayerUnit()
	local strUnitName = unitPlayer:GetName()

	if unitPlayer then
		self:UpdateUnitName(unitPlayer, strUnitName)
		self:OnPlayerLevelChange()
	end

	if self.wndBaseBar:FindChild("PlayerName"):GetText() == nil or self.wndBaseBar:FindChild("PlayerName"):GetText() == "" then
		if unitPlayer ~= nil then
			self:UpdateUnitName(unitPlayer, strUnitName)
		end
	end

	if unitPlayer ~= nil then
		self:GetXP()
	end

	self:HelperPickLevelColor()
end

function BaseBar:OnPlayerLevelChange()
	local unitPlayer = GameLib.GetPlayerUnit()
	local tStats = unitPlayer:GetBasicStats()
	if not tStats then
		return
	end
	
	self:DisplayLevel(tStats.level, tStats.effectiveLevel)
end

function BaseBar:OnLevelChange(nLevel)
	local unitPlayer = GameLib.GetPlayerUnit()
	local tStats = unitPlayer:GetBasicStats()
	if not tStats then
		return
	end
	
	self:DisplayLevel(nLevel, tStats.effectiveLevel)
end

function BaseBar:OnEffectiveLevelChange(nEffectiveLevel)
	local unitPlayer = GameLib.GetPlayerUnit()
	local tStats = unitPlayer:GetBasicStats()
	if not tStats then
		return
	end
	self:DisplayLevel(tStats.level, nEffectiveLevel)
end

function BaseBar:DisplayLevel(nLevel, nEffectiveLevel)
	local strDisplayText = ""
	local strTooltip = ""
	
	if nEffectiveLevel > 0 then
		strDisplayText = String_GetWeaselString(Apollo.GetString("CRB_Parenthese"), tostring(nEffectiveLevel))
		strTooltip = string.format("<T Font=\"CRB_InterfaceSmall_O\">%s</T>", String_GetWeaselString(Apollo.GetString("Base_EffectiveLevel"), nLevel, nEffectiveLevel))
	else
		strDisplayText = nLevel
		strTooltip = string.format("<T Font=\"CRB_InterfaceSmall_O\">%s</T>", String_GetWeaselString(Apollo.GetString("Base_Level"), nLevel))
	end
	if self.wndBaseBar:FindChild("PvPFlag"):IsShown() then
		strTooltip = string.format("<T Font=\"CRB_InterfaceSmall_O\">%s</T>", String_GetWeaselString(Apollo.GetString("Base_PvPFlagged"), strTooltip))
	end
	
	self.wndBaseBar:FindChild("LevelNumber"):SetText(strDisplayText)
	self.wndBaseBar:FindChild("LevelNumber"):SetTooltip(strTooltip)
end


function BaseBar:UpdateUnitName(unit, strUnitName)
	local unitPlayer = GameLib.GetPlayerUnit()
	if unitPlayer and unit == unitPlayer then
		self.wndBaseBar:FindChild("PlayerName"):SetText(strUnitName)
	end
end

function BaseBar:SetXP(nNewXP, nPrevLevelXP, nNeededXP, nNewRestBonusXP)
	self.nCurrentXP = nNewXP - nPrevLevelXP
	self.nNeededXP = nNeededXP
	self.nRestedXP = nNewRestBonusXP + 300
	self:UpdateXPWithLocalValues()
end

function BaseBar:GetXP()
	local nXpToCurrentLevel = GetXpToCurrentLevel()
	local nXpToNextLevel = GetXpToNextLevel()

	self.nCurrentXP = GetXp() - nXpToCurrentLevel -- current amount of xp into the current level
	self.nNeededXP = nXpToNextLevel -- total amount needed to move through current level
	self.nRemainingXP = nXpToNextLevel - self.nCurrentXP -- amount remaining to reach next level
	self.nRestedXP = GetRestXp() -- amount of rested xp
	self.nRestedXPPool = GetRestXpKillCreaturePool() -- amount of rested xp remaining from creature kills

	if self.nCurrentXP == nil or self.nRemainingXP == nil or self.nNeededXP == nil or self.nRestedXP == nil then
		return
	end

	self:UpdateXPWithLocalValues()
end

function BaseBar:UpdateXPWithLocalValues()
	-- This relies on SetXP setting local values before it will do anything
	if self.nCurrentXP == nil or self.nNeededXP == nil then
		return
	end

	self.wndBaseBar:FindChild("XPBarFill"):Show(true)
	self.wndBaseBar:FindChild("XPBarFill"):SetMax(self.nNeededXP)
	self.wndBaseBar:FindChild("XPBarFill"):SetFloor(0)
	self.wndBaseBar:FindChild("XPBarFill"):SetProgress(self.nCurrentXP)

	if self.nRestedXP then
		self.wndBaseBar:FindChild("RestXPBarFill"):Show(true)
		self.wndBaseBar:FindChild("RestXPBarGoal"):Show(true)
		
		nCurrentRest = self.nCurrentXP + self.nRestedXP
		nTotalRest = self.nCurrentXP + self.nRestedXPPool
		
		if nTotalRest <= self.nCurrentXP then
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetStyleEx("EdgeGlow", false)
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetMax(self.nNeededXP)
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetFloor(0)
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetProgress(self.nCurrentXP)
		elseif nTotalRest > self.nNeededXP then
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetStyleEx("EdgeGlow", true)
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetMax(self.nNeededXP)
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetFloor(0)
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetProgress(self.nNeededXP)
		else
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetStyleEx("EdgeGlow", true)
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetMax(self.nNeededXP)
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetFloor(0)
			self.wndBaseBar:FindChild("RestXPBarGoal"):SetProgress(nTotalRest)
		end
		
		if nCurrentRest <= self.nCurrentXP then
			self.wndBaseBar:FindChild("RestXPBarFill"):SetMax(self.nNeededXP)
			self.wndBaseBar:FindChild("RestXPBarFill"):SetFloor(0)
			self.wndBaseBar:FindChild("RestXPBarFill"):SetProgress(self.nCurrentXP)
		elseif nCurrentRest > self.nNeededXP then
			self.wndBaseBar:FindChild("RestXPBarFill"):SetMax(self.nNeededXP)
			self.wndBaseBar:FindChild("RestXPBarFill"):SetFloor(0)
			self.wndBaseBar:FindChild("RestXPBarFill"):SetProgress(self.nNeededXP)
		else
			self.wndBaseBar:FindChild("RestXPBarFill"):SetMax(self.nNeededXP)
			self.wndBaseBar:FindChild("RestXPBarFill"):SetFloor(0)
			self.wndBaseBar:FindChild("RestXPBarFill"):SetProgress(nCurrentRest)
		end
		
	else
		self.wndBaseBar:FindChild("RestXPBarFill"):Show(false)
		self.wndBaseBar:FindChild("RestXPBarGoal"):Show(false)
	end
	
	local strXP = self.nCurrentXP / self.nNeededXP * 100
	if strXP == "100" then
		strXP = "99.9"
	end

	strXP = String_GetWeaselString(Apollo.GetString("Base_XPPercentString"), strXP)
	self.wndBaseBar:FindChild("XPText"):SetText(strXP)
	self:ConfigureTooltip(self.nCurrentXP, self.nNeededXP, self.nRestedXP, self.nRestedXPPool)
end

function BaseBar:ConfigureTooltip(nXp, nMax, nRested, nRestedPool)
	local strTooltip = ""
	strTooltip = string.format("<P Font=\"CRB_InterfaceMedium_B\">%s</P>", String_GetWeaselString(Apollo.GetString("Base_XPValue"), nXp, nMax, nXp / nMax * 100))

	if nRested > 0 then
		local strRested = ""
		local strEndofRested = ""
		strRested = string.format("<P Font=\"CRB_InterfaceMedium_B\" TextColor=\"ffda69ff\">%s</P>", String_GetWeaselString(Apollo.GetString("Base_XPRested"), nRested, nRested / nMax * 100))
		if nXp + nRestedPool > nMax then
			strEndofRested = string.format("<P Font=\"CRB_InterfaceMedium_B\">%s</P>", Apollo.GetString("Base_XPRestedEndsAfterLevelTooltip"))
		else
			strEndofRested = string.format("<P Font=\"CRB_InterfaceMedium_B\">%s</P>", String_GetWeaselString(Apollo.GetString("Base_XPRestedPoolTooltip"), nRestedPool, ((nRestedPool + nXp)  / nMax) * 100))
		end
		strTooltip = strTooltip .. strRested .. strEndofRested 
	end
	
	self.wndBaseBar:FindChild("XPText"):SetTooltip(strTooltip)
	self.wndBaseBar:FindChild("XPBarFill"):SetTooltip(strTooltip)
	self.wndBaseBar:FindChild("RestXPBarFill"):SetTooltip(strTooltip)
	self.wndBaseBar:FindChild("RestXPBarGoal"):SetTooltip(strTooltip)
	
end

function BaseBar:OnEnteredCombat(unit, bInCombat)
	if unit == GameLib.GetPlayerUnit() then
		self.wndBaseBar:FindChild("CombatIndicatorFrameBtn"):Show(bInCombat)
		self.wndBaseBar:FindChild("CombatIndicatorCircleBtn"):Show(bInCombat)

		self.bInCombat = bInCombat
		self:HelperPickLevelColor()
	end
end

function BaseBar:OnChangeWorld()
	self.wndBaseBar:FindChild("CombatIndicatorFrameBtn"):Show(false)
	self.wndBaseBar:FindChild("CombatIndicatorCircleBtn"):Show(false)
	self:HelperPickLevelColor()
end

function BaseBar:HelperPickLevelColor()
	local crColorToUse = kcrLevelNormal
	local tPvpFlagInfo = GameLib.GetPvpFlagInfo()

	if self.bInCombat == true then
		crColorToUse = kcrLevelCombat
	elseif tPvpFlagInfo.bIsFlagged then
		crColorToUse = kcrLevelFlagged
	end

	self.wndBaseBar:FindChild("PvPFlag"):Show(tPvpFlagInfo.bIsFlagged)
	self.wndBaseBar:FindChild("LevelNumber"):SetTextColor(crColorToUse)
end

function BaseBar:OnDeath()
	self.wndBaseBar:FindChild("CombatIndicatorFrameBtn"):Show(false)
	self.wndBaseBar:FindChild("CombatIndicatorCircleBtn"):Show(false)
end

---------------------------------------------------------------------------------------------------
-- BaseBar instance
---------------------------------------------------------------------------------------------------
local BaseBarInst = BaseBar:new()
BaseBarInst:Init()
