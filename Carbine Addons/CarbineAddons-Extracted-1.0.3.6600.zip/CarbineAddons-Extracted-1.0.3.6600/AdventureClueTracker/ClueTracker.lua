-----------------------------------------------------------------------------------------------
-- Client Lua Script for ClueTracker
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "GameLib"

local ClueTracker = {}

function ClueTracker:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function ClueTracker:Init()
    Apollo.RegisterAddon(self)
end

function ClueTracker:OnLoad()
    Apollo.RegisterSlashCommand("cluetracker", "Initialize", self)
    --Apollo.RegisterEventHandler("ShowClueUI", "Initialize", self) -- Disabled for now, wait for PopulateClueUI to show
	Apollo.RegisterEventHandler("HideClueUI", "OnHide", self)
	Apollo.RegisterEventHandler("PopulateClueUI", "OnPopulate", self)
end

function ClueTracker:Initialize()
    if not self.wndMain then -- To save memory, don't load until needed
		self.wndMain = Apollo.LoadForm("ClueTracker.xml", "ClueTrackerForm", nil, self)
	end
	self.wndMain:Show(true)
end

function ClueTracker:OnHide()
	if self.wndMain then
		self.wndMain:Destroy()
	end
end

function ClueTracker:OnPopulate(nWhich, strText)
	if not self.wndMain then
		self:Initialize()
	end

	local wndCurr = Apollo.LoadForm("ClueTracker.xml", "ClueFrame", self.wndMain:FindChild("ClueFrameScroll"), self)
	wndCurr:FindChild("ClueNumber"):SetText("#"..nWhich)
	wndCurr:FindChild("ClueText"):SetAML("<P Font=\"CRB_InterfaceMedium_O\">"..Apollo.GetString(strText).."</P>")
	local nTextWidth, nTextHeight = wndCurr:FindChild("ClueText"):SetHeightToContentHeight()
	local l,t,r,b = wndCurr:GetAnchorOffsets()
	nTextHeight = math.max(27, nTextHeight) -- Minimum height for the text
	wndCurr:SetAnchorOffsets(l,t,r,t + nTextHeight + 16) -- +2 is for lower g height and padding

	self.wndMain:FindChild("ClueFrameScroll"):ArrangeChildrenVert(0)
end

-----------------------------------------------------------------------------------------------
-- ClueTracker Instance
-----------------------------------------------------------------------------------------------
local ClueTrackerInst = ClueTracker:new()
ClueTrackerInst:Init()
