-----------------------------------------------------------------------------------------------
-- Client Lua Script for EscapeMenu
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Apollo"
require "Sound"
require "Window"

local EscapeMenu = {}

function EscapeMenu:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	return o
end

function EscapeMenu:OnLoad()
	Apollo.RegisterSlashCommand("camp", "OnCampSlashCommand", self) -- TODO: Extract this to a relevant add-on before deprecating this file
--	Apollo.RegisterEventHandler("InvokeEscapeMenu", "OnEscapeMenu", self)

	self.wndMenu = Apollo.LoadForm("EscapeMenuForms.xml", "EscapeMenu", nil, self)
	self.wndMenu:Show(false)
end

function EscapeMenu:OnEscapeMenu()
	Apollo.CloseEscapableWindows()
	self.wndMenu:Show(true)
	self.wndMenu:ToFront()
	Sound.Play(Sound.PlayUIWindowOpen)
end

function EscapeMenu:OnEscapeMenu_Return()				--close main menu with X button
	Sound.Play(Sound.PlayUIWindowClose)
	self.wndMenu:Show(false)
end

function EscapeMenu:OnEscapeMenu_Options()
	InvokeOptionsScreen()
	self.wndMenu:Show(false)
end

function EscapeMenu:OnEscapeMenu_KeyBindings()
	Sound.Play(Sound.PlayUIWindowClose)
	self.wndMenu:Show(false)
	Apollo.ParseInput(Apollo.GetString("EscapeMenu_KeybindCommand"))
end

function EscapeMenu:OnEscapeMenu_Macros()
	Sound.Play(Sound.PlayUIWindowClose)
	self.wndMenu:Show(false)
	Apollo.ParseInput(Apollo.GetString("EscapeMenu_MacrosCommand"))
end

function EscapeMenu:OnEscapeMenu_Camp()
	Sound.Play(Sound.PlayUIWindowClose)
	self.wndMenu:Show(false)
	Event_FireGenericEvent("GenericEvent_PlayerCampStart")
	Camp()
end

function EscapeMenu:OnEscapeMenu_BugReport ()
	ReportError ()
	self.wndMenu:Show(false)
end

function EscapeMenu:OnEscapeMenu_Exit()
	self.wndMenu:Show(false)
	Event_FireGenericEvent("GenericEvent_PlayerExitStart")
	ExitGame()
end

function EscapeMenu:OnCampSlashCommand()
	self:OnEscapeMenu_Exit()
end

function EscapeMenu:OnEscapeMenu_Tutorials()
	self.wndMenu:Show(false)
	Apollo.ParseInput(Apollo.GetString("EscapeMenu_TutorialsCommand"))
end

local Instance = EscapeMenu:new()
Apollo.RegisterAddon(Instance)
