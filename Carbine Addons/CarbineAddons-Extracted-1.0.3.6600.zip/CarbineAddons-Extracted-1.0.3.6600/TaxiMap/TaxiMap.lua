-----------------------------------------------------------------------------------------------
-- Client Lua Script for TaxiMap
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------
 
require "Window"
require "Unit"
require "GameLib"
require "Tooltip"
require "XmlDoc"
require "PlayerPathLib"
require "HexGroups"
 
-----------------------------------------------------------------------------------------------
-- TaxiMap Module Definition
-----------------------------------------------------------------------------------------------
local TaxiMap = {} 
 
-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
function TaxiMap:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self 

    -- initialize variables here
	o.unitTaxi = nil
	o.nTaxiUnderCursor = 0
	o.tTaxiObjects = {}
	o.tTaxiNodes = {}
	o.tTaxiRoutes = {}

    return o
end

function TaxiMap:Init()
    Apollo.RegisterAddon(self)
end
 

-----------------------------------------------------------------------------------------------
-- TaxiMap OnLoad
-----------------------------------------------------------------------------------------------
function TaxiMap:OnLoad()
	Apollo.RegisterEventHandler("FlightPathUpdate", 	"OnFlightPathUpdate", self)
	Apollo.RegisterEventHandler("InvokeTaxiWindow", 	"OnInvokeTaxiWindow", self)
	Apollo.RegisterEventHandler("InvokeShuttlePrompt", 	"OnInvokeShuttlePrompt", self)		
	Apollo.RegisterEventHandler("CloseVendorWindow", 	"OnCloseVendorWindow", self)
	Apollo.RegisterEventHandler("TaxiWindowClose",		"OnCloseVendorWindow", self)
	Apollo.RegisterTimerHandler("MessageDisplayTimer",	"OnMessageDisplayTimer", self)
    
    -- load our forms
    self.wndMain 	= Apollo.LoadForm("TaxiMap.xml", "TaxiMapForm", nil, self)
	self.wndPrompt	= Apollo.LoadForm("TaxiMap.xml", "ShuttlePrompt", nil, self)
	self.wndMap 	= self.wndMain:FindChild("WorldMap")
	self.wndTitle 	= self.wndMain:FindChild("Title")
	self.wndTaxiMap = self.wndMain:FindChild("WorldMap")
	self.wndMessage	= self.wndMain:FindChild("UpdateMessage")
	
	self.tZoneInfo = nil
	
	self.wndMain:Show(false)
	self.wndPrompt:Show(false)
	self.wndMessage:Show(false, true)
end


-----------------------------------------------------------------------------------------------
-- TaxiMap Functions
-----------------------------------------------------------------------------------------------

function TaxiMap:OnInvokeTaxiWindow(unitTaxi, bSettlerTaxi)
	if self.wndMain:IsShown() then
		return
	end

	if unitTaxi == nil then
		return
	end

	self.unitTaxi = unitTaxi
	self.bSettlerTaxi = bSettlerTaxi
	
	local tZoneInfo = GameLib.GetCurrentZoneMap()
	if tZoneInfo ~= nil then 
		self.tZoneInfo = tZoneInfo
	else	
		return
	end	
	
	self:PopulateTaxiMap()
	self.wndMain:Show(true)
end

-----------------------------------------------------------------------------------------------

function TaxiMap:OnInvokeShuttlePrompt(unitTaxi)
	if self.wndPrompt:IsShown() then
		return
	end

	if unitTaxi == nil then
		return
	end

	self.unitTaxi = unitTaxi
	
	local strPrompt = String_GetWeaselString(Apollo.GetString("TaxiMap_ShuttleConfirmation"), unitTaxi:GetTransferDestination())
	self.wndPrompt:FindChild("Title"):SetText(strPrompt)
	
	self.wndPrompt:Show(true)
end

-----------------------------------------------------------------------------------------------
function TaxiMap:OnFlightPathUpdate()
	if not self.wndMain:IsShown() then
		return
	end

	if self.unitTaxi == nil then
		return
	end

	self:PopulateTaxiMap()
end

-----------------------------------------------------------------------------------------------
function TaxiMap:PopulateTaxiMap()
	self.wndTaxiMap:RemoveAllLines()
	self.wndTaxiMap:RemoveAllObjects()

	local tNodes = self.unitTaxi:GetFlightPaths()

	if tNodes == nil or self.tZoneInfo == nil then
		return
	end
	
	self.tTaxiObjects = {}
	self.tTaxiRoutes = {}
	self.tTaxiNodes = {}
	self.nTaxiUnderCursor = 0
	
	self.wndMap:SetZone(self.tZoneInfo.id)
	local nCurrentContinent = self.wndMap:GetContinentInfo(self.tZoneInfo.continentId)	
	
	if self.bSettlerTaxi == false and nCurrentContinent ~= nil and nCurrentContinent.bCanDisplay == true then
		self.wndMap:SetDisplayMode(self.wndMap.CodeEnumDisplayMode.Continent)
		self.wndMap:SetMinDisplayMode(self.wndMap.CodeEnumDisplayMode.Continent)
		self.wndMap:SetMaxDisplayMode(self.wndMap.CodeEnumDisplayMode.Continent)
	else
		self.wndMap:SetDisplayMode(self.wndMap.CodeEnumDisplayMode.Scaled)
		self.wndMap:SetMinDisplayMode(self.wndMap.CodeEnumDisplayMode.Scaled)
		self.wndMap:SetMaxDisplayMode(self.wndMap.CodeEnumDisplayMode.Scaled)
	end
	
	local tInfo = 
	{
		strIcon = "sprMM_VendorFlight",
		crObject = CColor.new(1, 1, 1, 1),
		strIconEdge = "sprMM_VendorFlight",
		crEdge = CColor.new(1, 1, 1, 1),
	}

	if not self.eOverlayType then
		self.eOverlayType = self.wndTaxiMap:CreateOverlayType()
	end

	for idx, tTaxi in ipairs(tNodes) do
		if tTaxi.eType == Unit.CodeEnumFlightPathType.Local then
			local idObject = self.wndTaxiMap:AddObject(self.eOverlayType, tTaxi.tLocation, tTaxi.strName, tInfo, {bNeverShowOnEdge = true, bFixedSizeLarge = true})
			self.tTaxiObjects[idObject] = tTaxi
			self.tTaxiNodes[tTaxi.idNode] = tTaxi
		end
	end
	
	self.wndTaxiMap:SetDisplayMode(3)
end

-----------------------------------------------------------------------------------------------
-- TaxiMapForm Functions
-----------------------------------------------------------------------------------------------

function TaxiMap:OnWindowClosed()
	self.tTaxiObjects = {}
	self.tTaxiNodes = {}
	self.tTaxiRoutes = {}
	self.nTaxiUnderCursor = 0
	Event_CancelTaxiVendor()
end

-----------------------------------------------------------------------------------------------
function TaxiMap:OnPromptWindowClosed()
	Event_CancelTaxiVendor()
end

-----------------------------------------------------------------------------------------------
-- when the Cancel button is clicked
function TaxiMap:OnCancel(wndHandler, wndControl)
	if wndHandler:GetId() ~= wndControl:GetId() then
		return
	end

	-- just close the window which will trigger OnWindowClosed
	self.wndMain:Close()
end

-----------------------------------------------------------------------------------------------
-- when the No button is clicked
function TaxiMap:OnNo(wndHandler, wndControl)
	if wndHandler:GetId() ~= wndControl:GetId() then
		return
	end

	-- just close the window which will trigger OnWindowClosed
	self.wndPrompt:Close()
end

-----------------------------------------------------------------------------------------------
-- when the Yes button is clicked
function TaxiMap:OnYes(wndHandler, wndControl)
	if wndHandler:GetId() ~= wndControl:GetId() then
		return
	end
	
	self.unitTaxi:TakeShuttle()

	-- just close the window which will trigger OnWindowClosed
	self.wndPrompt:Close()
end

-----------------------------------------------------------------------------------------------
function TaxiMap:OnCloseVendorWindow()
	if self.wndMain:IsShown() then
		self.wndMain:Close()
	end
	
	if self.wndPrompt:IsShown() then
		self.wndPrompt:Close()
	end
end

-----------------------------------------------------------------------------------------------
function TaxiMap:OnTaxiMapButtonDown(wndHandler, wndControl, eButton, nX, nY, bDoubleClick)
	local tPos = self.wndTaxiMap:WindowPointToClientPoint(nX, nY)
	
	local tObjects = self.wndTaxiMap:GetObjectsAt(tPos.x, tPos.y)
	for key, tObject in pairs(tObjects) do
		local tTaxi = self.tTaxiObjects[tObject.id]
		if self.unitTaxi:GetFlightPathToPoint(tTaxi.idNode) then
			self.unitTaxi:PurchaseFlightPath(tTaxi.idNode)
		else
			self.wndMessage:FindChild("MessageText"):SetText(Apollo.GetString("TaxiMap_CantRoute"))
			self.wndMessage:Show(true)
			Apollo.StopTimer("MessageDisplayTimer")
			Apollo.CreateTimer("MessageDisplayTimer", 4.000, false)
		end
	end
		
	return true
end

-----------------------------------------------------------------------------------------------
function TaxiMap:OnMouseMove(wndHandler, wndControl, nX, nY)
	self:OnGenerateTooltip(wndHandler, wndControl, Tooltip.TooltipGenerateType_Default, nX, nY)
end

-----------------------------------------------------------------------------------------------
function TaxiMap:OnGenerateTooltip(wndHandler, wndControl, eType, nX, nY)
	local strTooltipString = ""
	local strBlankLine = string.format("<P Font=\"%s\" TextColor=\"%s\">" .. ":" .. "</P>", "CRB_Pixel", "00ffffff")

	if eType == Tooltip.TooltipGenerateType_Default then
		local tPos = self.wndTaxiMap:WindowPointToClientPoint(nX, nY)
		
		local tObjects = self.wndTaxiMap:GetObjectsAt(tPos.x, tPos.y)

		for key, tObject in pairs(tObjects) do
			local tTaxi = self.tTaxiObjects[tObject.id]
			local tPath = self.tTaxiRoutes[tTaxi.idNode]
			if tPath == nil then
				tPath = self.unitTaxi:GetFlightPathToPoint(tTaxi.idNode)
				if tPath ~= nil then
					self.tTaxiRoutes[tTaxi.idNode] = tPath
				end
			end
			
			strTooltipString = string.format("<P Font=\"%s\" TextColor=\"%s\">" .. tObject.strName .. "</P>", "CRB_InterfaceMedium", "ffffffff")
			
			if tPath ~= nil then
				if self.nTaxiUnderCursor ~= tTaxi.idNode then
					self.nTaxiUnderCursor = tTaxi.idNode
					self.wndTaxiMap:RemoveAllLines()
					local nPrev = 0
					for idx, tNode in ipairs(tPath.tRoute) do
						if nPrev ~= 0 then
							self.wndTaxiMap:AddLine(self.tTaxiNodes[nPrev].tLocation, self.tTaxiNodes[tNode.id].tLocation, 5.0, CColor.new(1, 1, 1, 1), "", "")
						end
						nPrev = tNode.id
					end
				end
				
				local nPlatinum = math.floor(tPath.tPriceInfo.nAmount1 / (1000000))
				local nRemainder = tPath.tPriceInfo.nAmount1 % (1000000)
				local nGold = math.floor(nRemainder / (10000))
				nRemainder = nRemainder % (10000)
				local nSilver = math.floor(nRemainder / 100)
				local nCopper = math.floor(nRemainder % 100)		
				
				if nPlatinum >= 1 then
					local strPlatinumLine = string.format("<P Font=\"%s\" TextColor=\"%s\">%s</P>", "CRB_InterfaceSmall", "dbd7d2", String_GetWeaselString(Apollo.GetString("CRB_Platinum"), nPlatinum))
					strTooltipString = strTooltipString .. strPlatinumLine
				end
				
				if nGold >= 1 then
					local strGoldLine = string.format("<P Font=\"%s\" TextColor=\"%s\">%s</P>", "CRB_InterfaceSmall", "ffd700", String_GetWeaselString(Apollo.GetString("CRB_Gold"), nGold))
					strTooltipString = strTooltipString .. strGoldLine
				end
				
				if nSilver >= 1 then
					local strSilverLine = string.format("<P Font=\"%s\" TextColor=\"%s\">%s</P>", "CRB_InterfaceSmall", "ffc0c0c0", String_GetWeaselString(Apollo.GetString("CRB_Silver"), nSilver))
					strTooltipString = strTooltipString .. strSilverLine
				end
				
				if nCopper >= 1 then
					local strCopperLine = string.format("<P Font=\"%s\" TextColor=\"%s\">%s</P>", "CRB_InterfaceSmall", "ffcd7f32", String_GetWeaselString(Apollo.GetString("CRB_Copper"), nCopper))
					strTooltipString = strTooltipString .. strCopperLine
				end
			end				
		end
	end

	wndControl:SetTooltipType(Window.TPT_OnCursor)
	wndControl:SetTooltip(strTooltipString)
end

-----------------------------------------------------------------------------------------------
function TaxiMap:OnMessageDisplayTimer()
	self.wndMessage:Show(false)
end

-----------------------------------------------------------------------------------------------
-- TaxiMap Instance
-----------------------------------------------------------------------------------------------
local TaxiMapInst = TaxiMap:new()
TaxiMapInst:Init()
