require "Window"
require "Unit"


---------------------------------------------------------------------------------------------------
-- Debug module definition

local Debug = {}

---------------------------------------------------------------------------------------------------
-- local constants
---------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------
-- Debug initialization
---------------------------------------------------------------------------------------------------
function Debug:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	
	-- initialize our variables

	-- return our object
	return o
end

---------------------------------------------------------------------------------------------------
function Debug:Init()

	Apollo.RegisterAddon(self)
end

---------------------------------------------------------------------------------------------------
-- Debug EventHandlers
---------------------------------------------------------------------------------------------------


function Debug:OnLoad()
	Apollo.RegisterSlashCommand("debugon", "OnDebugOn", self)
	Apollo.RegisterEventHandler("RealmBroadcastTierHigh", "OnServerMessage", self)

	-- load our forms
	self.GroupHud = Apollo.LoadForm("Debug.xml", "DebugGroupHud", nil, self)
	self.GroupHud:Show(false)
	
	self.ServerMessageDlg = Apollo.LoadForm("Debug.xml", "ServerMessage", nil, self)
	self.ServerMessageDlg:Show(false)
	self.arServerMessages = {}
end
	
---------------------------------------------------------------------------------------------------
-- Functions
---------------------------------------------------------------------------------------------------

function Debug:OnDebugOn()
	self.GroupHud:Show(true)
end

function Debug:OnYes()
	Print("Yes!")
end

function Debug:OnNo()
	Print("No!")
	self.GroupHud:Show(false)
end

function Debug:OnServerMessage(strMsg)
	table.insert(self.arServerMessages, 1, strMsg)
	self.ServerMessageDlg:FindChild("Message"):SetText(self.arServerMessages[#self.arServerMessages])
	self.ServerMessageDlg:Show(true)
end

function Debug:OnServerMessageAck()
	table.remove(self.arServerMessages)
	if #self.arServerMessages > 0 then
		self.ServerMessageDlg:FindChild("Message"):SetText(self.arServerMessages[#self.arServerMessages])
		self.ServerMessageDlg:Show(true)
	else
		self.ServerMessageDlg:Show(false)
	end
end

---------------------------------------------------------------------------------------------------
-- Debug instance
---------------------------------------------------------------------------------------------------
local DebugInst = Debug:new()
Debug:Init()



