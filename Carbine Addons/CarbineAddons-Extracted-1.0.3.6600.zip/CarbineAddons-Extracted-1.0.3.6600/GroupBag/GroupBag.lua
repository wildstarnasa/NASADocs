-----------------------------------------------------------------------------------------------
-- Client Lua Script for GroupDisplayOptions
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "Apollo"
require "GroupLib"

local GroupBag = {}

function GroupBag:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self

	return o
end

local LuaEnumRollType =
{
	Greed 		= 0,
	Need 		= 1,
	Pass 		= 2,
	Salvage 	= 3,
	Undecided 	= 4,
	LeftGroup 	= 5,
}

local ktLootTypeStrings =
{
	[LuaEnumRollType.Greed] 	= Apollo.GetString("CRB_Greed"),
	[LuaEnumRollType.Need] 		= Apollo.GetString("CRB_Need"),
	[LuaEnumRollType.Pass] 		= Apollo.GetString("CRB_Pass"),
	[LuaEnumRollType.Salvage] 	= Apollo.GetString("CRB_Salvage"),
	[LuaEnumRollType.Undecided] = Apollo.GetString("CRB_Undecided"),
}

local kMaxSharedColumns = 5
local kMaxSharedRows = 5

function GroupBag:Init()
	Apollo.RegisterAddon(self)
end

function GroupBag:OnLoad()
	Apollo.RegisterEventHandler("ToggleGroupBag", 			"ToggleWindow", self)
	Apollo.RegisterEventHandler("GroupBagItemAdded", 		"AddItem", self)
	Apollo.RegisterEventHandler("GroupBagItemUpdated", 		"UpdateItem", self)
	Apollo.RegisterEventHandler("GroupBagItemRemoved", 		"RemoveItem", self)
	Apollo.RegisterEventHandler("GroupBag_ItemDistributed", "OnItemDistributed", self)
	Apollo.RegisterEventHandler("GroupBag_Changed", 		"OnGroupBagChanged", self)
	Apollo.RegisterSlashCommand("groupbag", 				"ToggleWindow", self)
	Apollo.RegisterEventHandler("LootRollUpdate", 			"OnGroupBagChanged", self)
	Apollo.RegisterEventHandler("MasterLootUpdate", 		"OnGroupBagChanged", self)
	Apollo.RegisterEventHandler("Vacuum", 					"OnVacuum", self)
	Apollo.RegisterEventHandler("PendingLootInteract", 		"OnPendingLootInteract", self)

	self.wndGroupBag		= Apollo.LoadForm("GroupBagForms.xml", "GroupBag", nil, self)
	self.wndGroupBagLootTab = Apollo.LoadForm("GroupBagForms.xml", "GroupBagLoot", self.wndGroupBag, self)
	self.wndGroupBag:SetRadioSel("GroupBagTab", 2)

	self.wndLootItemsGrid = self.wndGroupBagLootTab:FindChild("LootItemsList")
	self.wndLootItemsTree = self.wndGroupBagLootTab:FindChild("LootItemsTree")
	self.wndLootItemsTree:SetColumnWidth(1, 160)
	self.wndLootItemsTree:SetColumnWidth(2, 116)

	self.wndMasterLooterGrid 	= self.wndGroupBagLootTab:FindChild("MasterLooterGrid")
	self.nMasterLootRecipient 	= nil

	self.wndGroupBag:Show(false)
	self.wndItemHistoryGrid = self.wndGroupBagLootTab:FindChild("LootItemsHistory")

	self.tSelectedItem = nil
	self:EnableVoteButtons()
end

--------------------//-----------------------------
function GroupBag:ToggleWindow()
	if self.wndGroupBag:IsVisible() then
		self.wndGroupBag:Show(false)
		Sound.Play(Sound.PlayUI38CloseRemoteWindowDigital)
	else
		-- TEMP HACK: Only show for Master Loot
		self.wndGroupBag:Show(true and #GameLib.GetMasterLoot() > 0)
		self:PopulateGroupLoot()
		Sound.Play(Sound.PlayUI37OpenRemoteWindowDigital)
	end
end

--------------------//-----------------------------

function GroupBag:OnVacuum()
	if self.wndGroupBag:IsVisible() then
		return
	end

	if self.wndLootItemsTree:GetFirstVisibleNode() == nil then
		return
	end

	-- TEMP HACK: Only show for Master Loot
	self.wndGroupBag:Show(true and #GameLib.GetMasterLoot() > 0)
	self:PopulateGroupLoot()
	Sound.Play(Sound.PlayUI37OpenRemoteWindowDigital)
end

--------------------//-----------------------------

function GroupBag:OnPendingLootInteract(idLoot)
	if self.wndGroupBag:IsVisible() then
		return
	end

	self.wndGroupBag:Show(true and #GameLib.GetMasterLoot() > 0)
	self:PopulateGroupLoot()
	Sound.Play(Sound.PlayUI37OpenRemoteWindowDigital)
	local tCurrNode = self.wndLootItemsTree:GetFirstVisibleNode()
	while tCurrNode do
		local tCurrData = self.wndLootItemsTree:GetNodeData(tCurrNode)
		if tCurrData and tCurrData.lootId == idLoot then
			self.wndLootItemsTree:SelectNode(tCurrNode)
			break
		end
		tCurrNode = self.wndLootItemsTree:GetNextVisibleNode(tCurrNode)
	end
end

--------------------//-----------------------------

function GroupBag:PopulateGroupLoot()
	self.wndLootItemsGrid:DeleteAll()
	self.wndItemHistoryGrid:DeleteAll()
	self.wndLootItemsTree:DeleteAll()

	self.tSelectedItem = nil

	local tLootRolls = GameLib.GetLootRolls()
	if tLootRolls ~= nil then
		for idx, tCurrentElement in ipairs(tLootRolls) do
			self:AddItemToLootList(tCurrentElement)
		end
	end

	local tMasterLoot = GameLib.GetMasterLoot()
	if tMasterLoot ~= nil then
		for idx, tCurrentElement in ipairs(tMasterLoot) do
			self:AddItemToLootList(tCurrentElement)
		end
	end
	self:EnableVoteButtons()
end


--------------------//-----------------------------

function GroupBag:OnLootTreeSelChanged(wndHandler, wndControl, tNewNode, tOldNode)
	self.tSelectedItem = wndControl:GetNodeData(tNewNode)
	self:EnableVoteButtons()
end

--------------------//-----------------------------

function GroupBag:AddItemToLootList(tItemData)
	local tNode = self.wndLootItemsTree:AddNode(0, tItemData.itemDrop:GetName(), tItemData.itemDrop:GetIcon(), tItemData)
	self.wndLootItemsTree:SetMinimumNodeHeight(tNode, 32)

	self.wndLootItemsTree:CollapseNode(tNode)
end

function GroupBag:AddItemToHistoryList(tItemData)
	local nRow = self.wndItemHistoryGrid:AddRow(tItemData.strName, tItemData.strIcon, tItemData)
	self.wndItemHistoryGrid:SetCellData(nRow, 2, tItemData.winnerName)
end

--------------------//-----------------------------

function GroupBag:AddItem(nItemGuid)
	local tItemGrid = GroupLib.Bag_GetItemByGuid(nItemGuid)

	self:AddItemToGrid(nItemGuid)
end

--------------------//-----------------------------

function GroupBag:UpdateItem(idLoot)
	local nRows = self.wndLootItemsGrid:GetRowCount ()

	for iRow = 0, nRows do
		local tGuidAndId = self.wndLootItemsGrid:GetCellData (iRow, 1)

		if tGuidAndId ~= nil and tGuidAndId.lootId == idLoot then
			break
		end
	end
	self:EnableVoteButtons()
end

--------------------//-----------------------------

function GroupBag:RemoveItem(idLoot)
	local tRows = self.wndLootItemsGrid:GetRowCount ()

	for iRow = 1, tRows do
		local tGuidAndId = self.wndLootItemsGrid:GetCellData(iRow, 1)

		if tGuidAndId ~= nil and tGuidAndId.lootId == idLoot then
			self.wndLootItemsGrid:DeleteRow(iRow)
			break
		end
	end
	self.tSelectedItem = nil
	self:EnableVoteButtons()
end

--------------------//-----------------------------

function GroupBag:EnableVoteButtons()
	local bIsMasterLoot = self.tSelectedItem ~= nil and self.tSelectedItem.tLooters ~= nil
	self.wndGroupBag:FindChild("Salvage"):Enable(false and self.tSelectedItem ~= nil)
	self.wndGroupBag:FindChild("Need"):Enable(self.tSelectedItem ~= nil and not bIsMasterLoot)
	self.wndGroupBag:FindChild("Greed"):Enable(self.tSelectedItem ~= nil and not bIsMasterLoot)
	self.wndGroupBag:FindChild("Pass"):Enable(self.tSelectedItem ~= nil and not bIsMasterLoot)
	self.wndGroupBag:FindChild("MasterLootSelect"):Show(bIsMasterLoot)

	if bIsMasterLoot then
		self.wndMasterLooterGrid:DeleteAll()
		for idx, unitLooter in ipairs(self.tSelectedItem.tLooters) do
			local nRow = self.wndMasterLooterGrid:AddRow(unitLooter:GetName(), "", unitLooter)
			self.wndMasterLooterGrid:SetCellLuaData(nRow, 1, unitLooter)
		end
		self.wndGroupBag:FindChild("MasterLootSelect"):FindChild("Assign"):Enable(false)
	end
end

--------------------//-----------------------------

function GroupBag:OnLootItemChange(wndControl, wndHandler, nRow)
	self.tSelectedItem = self.wndLootItemsGrid:GetCellData(nRow, 1)
	self:EnableVoteButtons()
	self.nMasterLootRecipient = nil
end

--------------------//-----------------------------

function GroupBag:OnMasterLooterChange(wndControl, wndHandler, nRow)
	local unitSelectedLooter = self.wndMasterLooterGrid:GetCellData (nRow, 1)
	self.wndGroupBag:FindChild("MasterLootSelect"):FindChild("Assign"):Enable(unitSelectedLooter ~= nil)

	self.nMasterLootRecipient = self.wndMasterLooterGrid:GetFocusRow()
end

--------------------//-----------------------------

function GroupBag:OnItemDistributed(nItemGuid, nMember)
	local tItemGrid = GroupLib.Bag_GetItemByGuid(nItemGuid)
	self:PopulateGroupLoot()
	self:EnableVoteButtons()
end

function GroupBag:OnGroupBagChanged()
	self:PopulateGroupLoot()
end

--------------------//-----------------------------
--------------------//-----------------------------
function GroupBag:Need()
	if self.tSelectedItem ~= nil then
		GameLib.RollOnLoot(self.tSelectedItem.lootId, true)
	end
end
--------------------//-----------------------------
function GroupBag:Greed()
	if self.tSelectedItem ~= nil then
		GameLib.RollOnLoot(self.tSelectedItem.lootId, false)
	end
end
--------------------//-----------------------------
function GroupBag:Pass()
	if self.tSelectedItem ~= nil then
		GameLib.PassOnLoot(self.tSelectedItem.lootId)
	end
end
--------------------//-----------------------------
function GroupBag:Salvage()
	if self.tSelectedItem ~= nil then
		GroupLib.Bag_VoteForItem(self.tSelectedItem.guid, LuaEnumRollType.Salvage)
		self:UpdateItem(self.tSelectedItem.guid)
	end
end
--------------------//-----------------------------
function GroupBag:MasterAssign()
	if self.tSelectedItem ~= nil and self.nMasterLootRecipient ~= nil then
		local unitSelectedLooter = self.wndMasterLooterGrid:GetCellLuaData(self.nMasterLootRecipient, 1)
		if unitSelectedLooter ~= nil then
			GameLib.AssignMasterLoot(self.tSelectedItem.nLootId, unitSelectedLooter)
		end
	end
end

function GroupBag:OnCloseBtn()
	self.wndGroupBag:Show(false)
end

function GroupBag:OnLootTreeMouseMove(wndHandler, wndControl, nX, nY)
	wndControl:SetTooltipDoc(nil)
	return false
end

local GroupBag_Singleton = GroupBag:new()
GroupBag_Singleton:Init()
