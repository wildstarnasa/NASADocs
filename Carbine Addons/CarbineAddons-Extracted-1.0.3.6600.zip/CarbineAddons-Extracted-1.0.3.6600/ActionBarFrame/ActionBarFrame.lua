-----------------------------------------------------------------------------------------------
-- Client Lua Script for ActionBarFrame
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "Apollo"
require "GameLib"
require "Spell"
require "Unit"
require "Item"
require "PlayerPathLib"
require "ActionSetLib"
require "AttributeMilestonesLib"

local ActionBarFrame = {}

function ActionBarFrame:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function ActionBarFrame:Init()
    Apollo.RegisterAddon(self)
end

function ActionBarFrame:OnSave(eType)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Character then
		return
	end

	local tSavedData = {}
	tSavedData.nDefaultSize = self.nDefaultSize
	return tSavedData
end

function ActionBarFrame:OnRestore(eType, tSavedData)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Character then
		return
	end
	self.nDefaultSize = tSavedData.nDefaultSize or 1
end

function ActionBarFrame:OnLoad()
	Apollo.RegisterEventHandler("PlayerChanged", 							"InitializeBars", self)
	Apollo.RegisterEventHandler("CharacterCreated", 						"InitializeBars", self)
	Apollo.RegisterEventHandler("PlayerLevelChange", 						"ReinitializeBars", self)

	Apollo.RegisterEventHandler("StanceChanged", 							"RedrawStances", self)
	Apollo.RegisterEventHandler("ShowActionBarShortcut", 					"OnShowActionBarShortcut", self)
	Apollo.RegisterEventHandler("ToggleBlockBarsVisibility", 				"ToggleBlockBarsVisibility", self) -- TODO! From Ability Builder
	Apollo.RegisterEventHandler("ActionBarDescriptionSpell", 				"ActionBarDescriptionSpell", self) -- TODO OLD: Deprecated?
	Apollo.RegisterEventHandler("Tutorial_RequestUIAnchor", 				"OnTutorial_RequestUIAnchor", self)
	Apollo.RegisterEventHandler("Options_UpdateActionBarTooltipLocation", 	"OnUpdateActionBarTooltipLocation", self)
	Apollo.RegisterEventHandler("ActionBarNonSpellShortcutAddFailed", 		"OnActionBarNonSpellShortcutAddFailed", self)

    self.wndMain = Apollo.LoadForm("ActionBarFrame.xml", "ActionBarFrameForm", "FixedHudStratum", self)
	self.wndMain:FindChild("StancePopoutBtn"):AttachWindow(self.wndMain:FindChild("StancePopoutFrame"))

	-- Saved Preferences
	self.nDefaultSize = 1
	Apollo.RegisterTimerHandler("ActionBarFrameTimer_DelayedInit", "OnCharacterCreated", self)
	Apollo.CreateTimer("ActionBarFrameTimer_DelayedInit", 1, false)

	if GameLib.GetPlayerUnit() then
		self:InitializeBars()
	end
end

function ActionBarFrame:ReinitializeBars()
	self:InitializeBars()

	-- Stances
	self:RedrawStances()
end

function ActionBarFrame:InitializeBars()
	self.wndMain:FindChild("Bar1ButtonContainer"):DestroyChildren()
	self.wndMain:FindChild("Bar2ButtonContainer"):DestroyChildren()
	self.wndMain:FindChild("Bar3ButtonContainer"):DestroyChildren()

	-- All the buttons
	self.arBarButtons = {}
	self.arBarButtons[0] = self.wndMain:FindChild("ActionBarInnate")

	local nLockSpriteCount = 0

	for idx = 1, 34 do
		local wndCurr = nil
		local strParent = "Bar3ButtonContainer"
		if idx < 9 then
			wndCurr = Apollo.LoadForm("ActionBarFrame.xml", "ActionBarItemBig", self.wndMain:FindChild("Bar1ButtonContainer"), self)
			wndCurr:FindChild("ActionBarBtn"):SetContentId(idx - 1)
			if ActionSetLib.IsSlotUnlocked(idx - 1) ~= ActionSetLib.CodeEnumLimitedActionSetResult.Ok then
				nLockSpriteCount = nLockSpriteCount + 1
				wndCurr:FindChild("LockSprite"):Show(true)
				wndCurr:FindChild("LockSprite"):SetSprite("sprActionBarFrame_Lock"..math.min(5, nLockSpriteCount))
			else
				wndCurr:FindChild("LockSprite"):Show(false)
			end
		elseif idx == 9 or idx == 10 then
			wndCurr = Apollo.LoadForm("ActionBarFrame.xml", "ActionBarItemSmallSide", self.wndMain:FindChild("Bar1ButtonSmallContainer"), self)
			wndCurr:FindChild("ActionBarBtn"):SetContentId(idx - 1)
			if ActionSetLib.IsSlotUnlocked(idx - 1) ~= ActionSetLib.CodeEnumLimitedActionSetResult.Ok then
				wndCurr:FindChild("LockSprite"):Show(true)
				wndCurr:SetTooltip(idx == 9 and Apollo.GetString("ActionBarFrame_LockedGadgetSlot") or Apollo.GetString("AbilityBuilder_SlotLockedTooltip"))
			else
				wndCurr:FindChild("LockSprite"):Show(false)
			end
		elseif idx < 23 then -- 11 to 22
			wndCurr = Apollo.LoadForm("ActionBarFrame.xml", "ActionBarItemSmall", self.wndMain:FindChild("Bar2ButtonContainer"), self)
			wndCurr:FindChild("ActionBarBtn"):SetContentId(idx + 1)
		else -- 23 to 34
			wndCurr = Apollo.LoadForm("ActionBarFrame.xml", "ActionBarItemSmall", self.wndMain:FindChild("Bar3ButtonContainer"), self)
			wndCurr:FindChild("ActionBarBtn"):SetContentId(idx + 1)
		end
		self.arBarButtons[idx] = wndCurr:FindChild("ActionBarBtn")
	end

	self.wndMain:FindChild("Bar1ButtonContainer"):ArrangeChildrenHorz(0)
	self.wndMain:FindChild("Bar1ButtonSmallContainer"):ArrangeChildrenHorz(0)
	self.wndMain:FindChild("Bar2ButtonContainer"):ArrangeChildrenHorz(0)
	self.wndMain:FindChild("Bar3ButtonContainer"):ArrangeChildrenHorz(0)
	self:OnUpdateActionBarTooltipLocation()
end

function ActionBarFrame:OnCharacterCreated()
	self.wndMain:ToFront() -- For the stance picker button vs the endurance bar

	-- Saved Defaults
	local nLocalDefaultSize = self.nDefaultSize
	local wndPlus = self.wndMain:FindChild("PlusBtn")
	if nLocalDefaultSize == 1 then
		self:OnPlusBtn(wndPlus, wndPlus)
	elseif nLocalDefaultSize == 2 then
		self:OnPlusBtn(wndPlus, wndPlus)
		self:OnPlusBtn(wndPlus, wndPlus)
	end
	self.nDefaultSize = nLocalDefaultSize -- HACK: Since Plus may overwrite this

	-- Default open vehicle if reloading ui
	self:ShowVehicleBar(0, IsActionBarSetVisible(0))

	-- Stances
	self:RedrawStances()
end

-----------------------------------------------------------------------------------------------
-- Main Redraw
-----------------------------------------------------------------------------------------------
function ActionBarFrame:RedrawStances()
	local wndPopoutFrame = self.wndMain:FindChild("StancePopoutFrame")
	local wndStancePopout = wndPopoutFrame:FindChild("StancePopoutList")
	wndStancePopout:DestroyChildren()

	local nCountSkippingTwo = 0
	for idx, spellObject in pairs(GameLib.GetClassInnateAbilitySpells().tSpells) do
		if idx % 2 == 1 then
			nCountSkippingTwo = nCountSkippingTwo + 1
			local strKeyBinding = GameLib.GetKeyBinding("SetStance"..nCountSkippingTwo) -- hardcoded formatting
			local wndCurr = Apollo.LoadForm("ActionBarFrame.xml", "StanceBtn", wndStancePopout, self)
			wndCurr:FindChild("StanceBtnKeyBind"):SetText(strKeyBinding == "<Unbound>" and "" or strKeyBinding)
			wndCurr:FindChild("StanceBtnIcon"):SetSprite(spellObject:GetIcon())
			wndCurr:SetData(nCountSkippingTwo)

			if Tooltip then
				wndCurr:SetTooltipDoc(nil)
				Tooltip.GetSpellTooltipForm(self, wndCurr, spellObject)
			end
		end
	end

	-- Hide the current stance (optional)
	local wndCurrInDropdown = wndStancePopout:FindChildByUserData(GameLib.GetCurrentClassInnateAbilityIndex())
	if wndCurrInDropdown and wndCurrInDropdown:IsValid() then
		wndCurrInDropdown:Destroy()
	end

	local nHeight = wndStancePopout:ArrangeChildrenVert(0)
	local nLeft, nTop, nRight, nBottom = wndPopoutFrame:GetAnchorOffsets()
	wndPopoutFrame:SetAnchorOffsets(nLeft, nBottom - nHeight - 20, nRight, nBottom)
	self.wndMain:FindChild("StancePopoutBtn"):Show(#wndStancePopout:GetChildren() > 0)
	self.wndMain:FindChild("StanceNoStanceFrame"):Show(#wndStancePopout:GetChildren() <= 0)
end

function ActionBarFrame:OnStanceBtn(wndHandler, wndControl)
	self.wndMain:FindChild("StancePopoutFrame"):Show(false)
	GameLib.SetCurrentClassInnateAbilityIndex(wndHandler:GetData())
end

function ActionBarFrame:OnPlusBtn(wndHandler, wndControl)
	local nLeft, nTop, nRight, nBottom = self.wndMain:GetAnchorOffsets()
	if self.wndMain:FindChild("Bar3ButtonContainer"):IsShown() then
		return
	elseif self.wndMain:FindChild("Bar2ButtonContainer"):IsShown() then -- Expand from 2 to 3
		self.wndMain:SetAnchorOffsets(nLeft, nTop - 44, nRight, nBottom)
		self.wndMain:FindChild("Bar3ButtonContainer"):Show(true)
		self.wndMain:FindChild("PlusBtn"):Enable(false)
		self.wndMain:FindChild("MinusBtn"):Enable(true)
	else -- Expand from 1 to 2
		self.wndMain:SetAnchorOffsets(nLeft, nTop - 42, nRight, nBottom)
		self.wndMain:FindChild("Bar2ButtonContainer"):Show(true)
		self.wndMain:FindChild("PlusBtn"):Enable(true)
		self.wndMain:FindChild("MinusBtn"):Enable(true)
	end

	self:ToggleBlockBarsVisibility(self.wndMain:FindChild("Blockers"):GetData())
	self.nDefaultSize = self.nDefaultSize and math.min(2, self.nDefaultSize + 1)
end

function ActionBarFrame:OnMinusBtn(wndHandler, wndControl)
	local nLeft, nTop, nRight, nBottom = self.wndMain:GetAnchorOffsets()
	if self.wndMain:FindChild("Bar3ButtonContainer"):IsShown() then -- Collapse from 3 to 2
		self.wndMain:SetAnchorOffsets(nLeft, nTop + 44, nRight, nBottom)
		self.wndMain:FindChild("Bar3ButtonContainer"):Show(false)
		self.wndMain:FindChild("PlusBtn"):Enable(true)
		self.wndMain:FindChild("MinusBtn"):Enable(true)
	elseif self.wndMain:FindChild("Bar2ButtonContainer"):IsShown() then -- Collapse from 2 to 1
		self.wndMain:SetAnchorOffsets(nLeft, nTop + 42, nRight, nBottom)
		self.wndMain:FindChild("Bar2ButtonContainer"):Show(false)
		self.wndMain:FindChild("PlusBtn"):Enable(true)
		self.wndMain:FindChild("MinusBtn"):Enable(false)
	end

	self:ToggleBlockBarsVisibility(self.wndMain:FindChild("Blockers"):GetData())
	self.nDefaultSize = self.nDefaultSize and math.max(0, self.nDefaultSize - 1)
end

function ActionBarFrame:ToggleBlockBarsVisibility(bVisible)
	local wndBlockers = self.wndMain:FindChild("Blockers")
	wndBlockers:Show(bVisible)
	wndBlockers:SetData(bVisible)
	wndBlockers:FindChild("ActionBar1Blocker"):Show(true)
	wndBlockers:FindChild("ActionBar2Blocker"):Show(self.wndMain:FindChild("Bar2ButtonContainer"):IsShown() and not self.wndMain:FindChild("Bar3ButtonContainer"):IsShown())
	wndBlockers:FindChild("ActionBar2and3Blocker"):Show(self.wndMain:FindChild("Bar3ButtonContainer"):IsShown())
end

function ActionBarFrame:OnShowActionBarShortcut(nWhichBar, bIsVisible, nNumShortcuts)
	if nWhichBar == 0 and self.wndMain and self.wndMain:IsValid() then
		for idx, wndBtn in pairs(self.arBarButtons) do
			wndBtn:Enable(not bIsVisible) -- Turn on or off all buttons
		end
		self:ShowVehicleBar(nWhichBar, bIsVisible, nNumShortcuts) -- show/hide vehicle bar if nWhichBar matches
	end
end

function ActionBarFrame:ShowVehicleBar(nWhichBar, bIsVisible, nNumShortcuts)
	if nWhichBar ~= 0 or not self.wndMain or not self.wndMain:IsValid() then
		return
	end

	local wndVehicleBar = self.wndMain:FindChild("VehicleBarMain")
	wndVehicleBar:Show(bIsVisible)
	
	self.wndMain:FindChild("Bar1ButtonContainer"):Show(not bIsVisible)

	if bIsVisible then
		for idx = 1, 6 do -- TODO hardcoded formatting
			wndVehicleBar:FindChild("ActionBarShortcutContainer" .. idx):Show(false)
		end

		if nNumShortcuts then
			for idx = 1, math.max(2, nNumShortcuts) do -- Art width does not support just 1
				wndVehicleBar:FindChild("ActionBarShortcutContainer" .. idx):Show(true)
				wndVehicleBar:FindChild("ActionBarShortcutContainer" .. idx):FindChild("ActionBarShortcut." .. idx):Enable(true)
			end

			local nLeft, nTop ,nRight, nBottom = wndVehicleBar:FindChild("VehicleBarFrame"):GetAnchorOffsets() -- TODO SUPER HARDCODED FORMATTING
			wndVehicleBar:FindChild("VehicleBarFrame"):SetAnchorOffsets(nLeft, nTop, nLeft + (35 * nNumShortcuts) + 66, nBottom)
		end

		wndVehicleBar:ArrangeChildrenHorz(1)
		wndVehicleBar:FindChild("ActionBarShortcut.Dismount"):Show(GameLib:CanDisembarkVehicle())
	end
end

function ActionBarFrame:ActionBarDescriptionSpell(spell, strDesc, tReasons)
	strDesc.textColor = CColor.new(0.8, 0.0, 0.0, 1.0)

	if tReasons[Spell.CodeEnumCastResult.ItemCharges] then
		strDesc.saturation = 0.0
	elseif tReasons[Spell.CodeEnumCastResult.SpellGlobalCooldown] or tReasons[Spell.CodeEnumCastResult.SpellCooldown] or tReasons[Spell.CodeEnumCastResult.SpellGroupCooldown] then

		if tReasons[Spell.CodeEnumCastResult.CasterVitalCostResource0]
			or tReasons[Spell.CodeEnumCastResult.CasterVitalCostResource1]
			or tReasons[Spell.CodeEnumCastResult.CasterVitalCostResource2]
			or tReasons[Spell.CodeEnumCastResult.CasterVitalCostResource3]
			or tReasons[Spell.CodeEnumCastResult.CasterVitalCostResource4]
			or tReasons[Spell.CodeEnumCastResult.CasterVitalCostResource5]
			or tReasons[Spell.CodeEnumCastResult.CasterVitalCostResource6]
			or tReasons[Spell.CodeEnumCastResult.CasterVitalCostResource7] then

			strDesc.diffused = true
			strDesc.diffuse = CColor.new(0.4, 0.4, 0.4, 1.0)
		end

		strDesc.saturation = 0.4
	else
		strDesc.diffused = true
		strDesc.diffuse = CColor.new(0.4, 0.4, 0.4, 1.0)
	end

	if tReasons[Spell.CodeEnumCastResult.Caster_CannotBe_Moving] then
		strDesc.blur = true
		strDesc.diffuse = CColor.new(0.4, 0.4, 0.4, 1.0)
	end
end

function ActionBarFrame:OnUpdateActionBarTooltipLocation()
	for idx = 0, 10 do
		self:HelperSetTooltipType(self.arBarButtons[idx])
	end
end

function ActionBarFrame:HelperSetTooltipType(wnd)
	if Apollo.GetConsoleVariable("ui.actionBarTooltipsOnCursor") then
		wnd:SetTooltipType(Window.TPT_OnCursor)
	else
		wnd:SetTooltipType(Window.TPT_DynamicFloater)
	end
end

function ActionBarFrame:OnTutorial_RequestUIAnchor(eAnchor, idTutorial, strPopupText)
	if eAnchor == GameLib.CodeEnumTutorialAnchor.AbilityBar or eAnchor == GameLib.CodeEnumTutorialAnchor.InnateAbility then
		local tRect = {}
		tRect.l, tRect.t, tRect.r, tRect.b = self.wndMain:GetRect()
		Event_FireGenericEvent("Tutorial_RequestUIAnchorResponse", eAnchor, idTutorial, strPopupText, tRect)
	end
end

function ActionBarFrame:OnGenerateTooltip(wndControl, wndHandler, eType, arg1, arg2)
	local xml = nil
	if eType == Tooltip.TooltipGenerateType_ItemInstance then -- Doesn't need to compare to item equipped
		Tooltip.GetItemTooltipForm(self, wndControl, arg1, {})
	elseif eType == Tooltip.TooltipGenerateType_ItemData then -- Doesn't need to compare to item equipped
		Tooltip.GetItemTooltipForm(self, wndControl, arg1, {})
	elseif eType == Tooltip.TooltipGenerateType_GameCommand then
		xml = XmlDoc.new()
		xml:AddLine(arg2)
		wndControl:SetTooltipDoc(xml)
	elseif eType == Tooltip.TooltipGenerateType_Macro then
		xml = XmlDoc.new()
		xml:AddLine(arg1)
		wndControl:SetTooltipDoc(xml)
	elseif eType == Tooltip.TooltipGenerateType_Spell then
		Tooltip.GetSpellTooltipForm(self, wndControl, arg1)
	elseif eType == Tooltip.TooltipGenerateType_PetCommand then
		xml = XmlDoc.new()
		xml:AddLine(arg2)
		wndControl:SetTooltipDoc(xml)
	end
end

function ActionBarFrame:OnActionBarNonSpellShortcutAddFailed()
	Print("You can not add that to your Limited Action Set bar.")
end

local ActionBarFrameInst = ActionBarFrame:new()
ActionBarFrameInst:Init()
