-----------------------------------------------------------------------------------------------
-- Client Lua Script for ZoneHopperDev
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "GameLib"

local ZoneHopperDev = {}
local changeFaction = 0
local goLoc = 0
local lastMapId = 0			-- Stores the last map entered

local toggleCheck = 0		-- Queries the user to make sure they're set up correct for the Malgrave Adventure
local zones = {}

function ZoneHopperDev:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self

    return o
end

function ZoneHopperDev:Init()
    Apollo.RegisterAddon(self)
end

-----------------------------------------------------------------------------------------------
-- ZoneHopperDev OnLoad
-----------------------------------------------------------------------------------------------
function ZoneHopperDev:OnLoad()
    Apollo.RegisterSlashCommand("zhdev", "OnZHOn", self)
	Apollo.RegisterEventHandler("SubZoneChanged", "ChangedZones", self)
	Apollo.RegisterEventHandler("Change_World", "ChangedMaps", self)
	Apollo.RegisterTimerHandler("AutoSalvageHeirloomKitTimer", "OnAutoSalvageHeirloomKitTimer", self)
	Apollo.RegisterTimerHandler("OneSecTimer", "OnOneSecTimer", self)
	Apollo.RegisterEventHandler("ToggleZoneHopperDevWindow", "OnToggleZoneHopperDevWnd", self)
	
	self.bInitialShow = false

    self.wndMain = Apollo.LoadForm("ZoneHopperDev.xml", "ZoneHopperForm", nil, self)

	self.wndMain:FindChild("bExiles"):SetData("Exiles");
	self.wndMain:FindChild("bDominion"):SetData("Dominion");
	self.wndMain:FindChild("bAdventure"):SetData("Adventure");
	self.wndMain:FindChild("bDungeon"):SetData("Dungeon");

	--self.wndMain:FindChild("bTogEm"):SetCheck(true)
	--self.wndMain:FindChild("bTogQuest"):SetCheck(true)

	self.wndMain:FindChild("TabsContainer"):ArrangeChildrenHorz(1)

	self:SetUpList()
	self.bNeedToSalvage = false
	self.wndMain:FindChild("TutorialText"):SetText(
		"1. Click a button to teleport to a zone. \n\n"..
		"2. Zone Hopper will also auto-level and give quests for each zone. This can be turned off with the toggle buttons. \n\n"..
		"3. You can also receive items for your level. Right click to equip these in your inventory (\'i\' key). \n\n"..
		"4. Use \'/zh\' to open Zone Hopper again. Note you'll receive different options as a Dominion or Exile character.")
		
end

function ZoneHopperDev:OnOneSecTimer()
	if self.bInitialShow == true then
		return 
	end

	if GameLib.GetPlayerUnit() == nil then
		return
	end
	
	local tInfo = GameLib.GetAccountRealmCharacter()
	if string.sub(tInfo.strAccount, 1, 3) == "zh_" then
		self:OnZHOn()
	else
		self.bInitialShow = true
	end
	
end

function ZoneHopperDev:OnZHOn()
	self.wndMain:Show(true)
	self.bInitialShow = true

	self.bInAZoneChange = false

	local nFaction = GameLib.GetPlayerUnit():GetFaction()
	if nFaction then
		self.wndMain:FindChild("bExiles"):Show(nFaction == Unit.CodeEnumFaction.ExilesPlayer)
		self.wndMain:FindChild("bDominion"):Show(nFaction == Unit.CodeEnumFaction.DominionPlayer)
		self.wndMain:FindChild("wndExiles"):Show(nFaction == Unit.CodeEnumFaction.ExilesPlayer)
		self.wndMain:FindChild("wndDominion"):Show(nFaction == Unit.CodeEnumFaction.DominionPlayer)
		self.wndMain:FindChild("TabsContainer"):ArrangeChildrenHorz(1)
	end
end

function ZoneHopperDev:OnCancel()	-- Minimize the addon
	self.wndMain:Show(false)
end

function ZoneHopperDev:OnToggleZoneHopperDevWnd()	-- Toggles the display of ZHDev so that other addons can interact with this
	if self.wndMain:IsShown() then
		self.wndMain:Show(false)
	else
		self.wndMain:Show(true)
	end
end

-----------------------------------------------------------------------------------------------
-- ZoneHopperDevForm Functions
-----------------------------------------------------------------------------------------------

function ZoneHopperDev:OnHeirloomBtn()
	Apollo.ParseInput("/c ci 13415")

--	self.bNeedToSalvage = true
--	Apollo.CreateTimer("AutoSalvageHeirloomKitTimer", 0.100, false)
--	Apollo.StartTimer("AutoSalvageHeirloomKitTimer")
end

function ZoneHopperDev:OnAbilityBtn( wndHandler, wndControl, eMouseButton )
	Apollo.ParseInput("/c cm 35494")
--	Apollo.ParseInput("/c uas")
end
--[[
function ZoneHopperDev:OnAutoSalvageHeirloomKitTimer()
	Apollo.StopTimer("AutoSalvageHeirloomKitTimer")

	if self.bNeedToSalvage then
		for _, tCurr in pairs(GameLib.GetPlayerUnit():GetInventoryItems()) do
			if tCurr.item:GetItemId() and tCurr.item:GetItemId() == 13415 then
				self.wndMain:FindChild("HiddenBagWindow"):SalvageItem(tCurr.item:GetInventoryId())

				self.bNeedToSalvage = false
				return
			end
		end

		Apollo.CreateTimer("AutoSalvageHeirloomKitTimer", 1.000, false)
		Apollo.StartTimer("AutoSalvageHeirloomKitTimer")
	end
end
]]--
function ZoneHopperDev:changeLevels(lvl)
	if self.wndMain:FindChild("bTogEm"):IsChecked() then
		Apollo.ParseInput("/c lvl "..lvl)
	end
end

function ZoneHopperDev:getQuest(qId, nPhase)
	if self.wndMain:FindChild("bTogQuest"):IsChecked() then
		Apollo.ParseInput("/c qg "..qId)
		if nPhase then
			Apollo.ParseInput("/c setphase "..nPhase)
		end
	end
end

function ZoneHopperDev:displayZones(wndHandler, wndControl)	--Displays each of the four main windows depending on which button is clicked at the bottom of the UI
	local strData = wndControl:GetData()
	self.wndMain:FindChild("wndExiles"):Show(strData =="Exiles")
	self.wndMain:FindChild("wndDominion"):Show(strData =="Dominion")
	self.wndMain:FindChild("wndDungeon"):Show(strData =="Dungeon")
	self.wndMain:FindChild("wndAdventure"):Show(strData =="Adventure")
end

function ZoneHopperDev:goMap(mapId)
	if not (mapId == lastMapId) or (mapId == lastMapId and goLoc == 0) then		-- If you are going to a place in the same map, don't use the gomap cheat, just port to the loc
		lastMapId = mapId
		Apollo.ParseInput("/c gm "..mapId)	
	else
		Apollo.ParseInput("/c port "..goLoc)
		goLoc = 0
	end
end

function ZoneHopperDev:goHub(locId)
	if locId then
		Apollo.ParseInput("/c goloc "..locId)
	end
end

function ZoneHopperDev:ChangedZones(idZone, pszZoneName)	-- Automatically triggered when the player changes zones or maps
	if not (goLoc==0) then		-- If a port location was recorded from a button press then port there now
		Apollo.ParseInput("/c port "..goLoc)
		--Apollo.ParseInput("/c go "..goLoc)
		goLoc = 0
	end
	--Print("Changed Zones to "..idZone)
	self.bInAZoneChange = false
end

---------------------------------------------------------------------------------------------------
-- wndZone Functions
---------------------------------------------------------------------------------------------------

function ZoneHopperDev:SetUpList()
	--When adding a new zone, update the i for loop, increment by one and add a new section to handle each tract
	for i=0, 13 do		-- EXILE ZONES
		table.insert(zones, Apollo.LoadForm("ZoneHopperDev.xml", "wndZone", self.wndMain:FindChild("wndExiles"), self))
		if i==0 then	-- Arc Ship
			zones[# zones]:FindChild("wndZone"):SetText("Arkship")
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Exile Arc")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 1: Exile Arkship")

		elseif i==1 then	-- Northern Wilds
			zones[# zones]:FindChild("wndZone"):SetText("Northern Wilds")
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("NWT1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 3: The start of Northern Wilds.")

			zones[# zones]:FindChild("bZoneT2"):SetData("NWT2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 4: Coldburrow Camp.")

			zones[# zones]:FindChild("bZoneT3"):SetData("NWT3")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level 5: Camp Icefury.")
		elseif i==2 then	-- Everstar Grove
			zones[# zones]:FindChild("wndZone"):SetText("Everstar Grove")
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Everstar 1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 3: The start of Everstar.")
		elseif i==3 then	-- Algoroc
			zones[# zones]:FindChild("wndZone"):SetText("Algoroc")
			zones[# zones]:FindChild("bZoneT4"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):SetData("AlgorocT1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 6: This will take you to Tremor Ridge")

			zones[# zones]:FindChild("bZoneT2"):SetData("AlgorocT2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 9: Takes you to the town of Gallow")

			zones[# zones]:FindChild("bZoneT3"):SetData("AlgorocT3")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level 12: This takes you to the Digsite south of Gallow.")
		elseif i==4 then	-- Celestion
			zones[# zones]:FindChild("wndZone"):SetText("Celestion")
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("CelestionT1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 6: Celestion Tract 1")

			zones[# zones]:FindChild("bZoneT2"):SetData("CelestionT2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 9: Celestion Tract 2")

			zones[# zones]:FindChild("bZoneT3"):SetData("CelestionT3")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level 12: Celestion Tract 3")
		elseif i==5 then	-- Galeras
			zones[# zones]:FindChild("wndZone"):SetText("Galeras")
			zones[# zones]:FindChild("bZoneT1"):SetData("GalerasT1A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 14: Takes you to Thayd, the start of Galeras.")

			zones[# zones]:FindChild("bZoneT2"):SetData("GalerasT2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 16: Galeras tract 2.")

			zones[# zones]:FindChild("bZoneT3"):SetData("GalerasT3B")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level 18: Galeras tract 3, XAS Forward Camp.")

			zones[# zones]:FindChild("bZoneT4"):SetData("GalerasT4A")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Level 20: Galeras tract 4, Skywatch.")
		elseif i==6 then	-- Whitevale
			zones[# zones]:FindChild("wndZone"):SetText("Whitevale")
			zones[# zones]:FindChild("bZoneT2"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("WhitevaleT1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 23: Whitevale tract 1, Thermock Hold.")

			zones[# zones]:FindChild("bZoneT3"):SetData("WhitevaleT3")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level 24: Whitevale tract 3, Wigwalli Village.")

			zones[# zones]:FindChild("bZoneT4"):SetData("WhitevaleT4")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Level 27: Whitevale tract 4, Prosperity Junction.")
		elseif i==7 then	-- Farside
			zones[# zones]:FindChild("wndZone"):SetText("Farside")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Farside Exiles T1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 29: Farside Tract 1")

			zones[# zones]:FindChild("bZoneT2"):SetData("Farside Exiles T2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 32: Farside Tract 2")		
		elseif i==8 then	-- Wilderrun
			zones[# zones]:FindChild("wndZone"):SetText("Wilderrun")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Wilderrun T1 Exiles")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 35: Takes you to tract 1 of Wilderrun")

			zones[# zones]:FindChild("bZoneT2"):SetData("Wilderrun T2 Both")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 38: Takes you to tract 2 of Wilderrun")
		elseif i==9 then	-- Murkmire
			zones[# zones]:FindChild("wndZone"):SetText("Murkmire")
			zones[# zones]:FindChild("bZoneT1"):SetData("Murkmire T1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level X: NYI")

			zones[# zones]:FindChild("bZoneT2"):SetData("Murkmire T2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level X: NYI")

			zones[# zones]:FindChild("bZoneT3"):SetData("Mukrmire T3")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level X: NYI")

			zones[# zones]:FindChild("bZoneT4"):SetData("Mukrmire T4")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Level X: NYI")
		elseif i==10 then	-- Malgrave
			zones[# zones]:FindChild("wndZone"):SetText("Malgrave")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Malgrave T1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 40: Malgrave Tract 1")

			zones[# zones]:FindChild("bZoneT2"):SetData("Malgrave T2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 45: Malgrave Tract 2")
		elseif i==11 then	-- Dreadmoor
			zones[# zones]:FindChild("wndZone"):SetText("Dreadmoor")
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT2"):SetData("Dreadmoor T2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 22: Dreadmoor Tract 2")

			zones[# zones]:FindChild("bZoneT3"):SetData("Dreadmoor T3 Exile")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level 25: Dreadmoor Tract 3")
		elseif i==12 then	-- Halon Ring
			zones[# zones]:FindChild("wndZone"):SetText("Halon Ring")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Halon Ring T1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 41: Halon Ring Tract 1")

			zones[# zones]:FindChild("bZoneT2"):SetData("Halon Ring T2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 44: Halon Ring Tract 2")
		elseif i==13 then	-- Grimvault
			zones[# zones]:FindChild("wndZone"):SetText("Grimvault")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Grimvault T1 Exile")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 45: Grimvault Tract 1")

			zones[# zones]:FindChild("bZoneT2"):SetData("Grimvault T2 Exile")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 48: Grimvault Tract 2")			
		end
	end
	for i=0, 11 do		-- DOMINION ZONES
		table.insert(zones, Apollo.LoadForm("ZoneHopperDev.xml", "wndZone", self.wndMain:FindChild("wndDominion"), self))
		if i==0 then	-- Crimson Isle
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("wndZone"):SetText("Crimson Isle")
			zones[# zones]:FindChild("bZoneT1"):SetData("CrimsonT1A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This will take you to the start of Crimson Isle and level you to 3")
--[[
			zones[# zones]:FindChild("bZoneT2"):SetData("CrimsonT1B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This will take you to Megatech, the last half of Crimson Isle. Also levels you to 5")
--]]			
		elseif i==1 then	-- Levian Bay
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("wndZone"):SetText("Levian Bay")
			zones[# zones]:FindChild("bZoneT1"):SetData("LevianT1A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This takes you to the start of Levian Bay and levels you to 3")

			zones[# zones]:FindChild("bZoneT2"):SetData("LevianT1B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This will port you to Star-Comm Station, the exo-lab area of Levian Bay. "
				.. "The fog here is pretty thick. You may want to turn the fog off in the console if you want to be able to see the entire station. Also levels you to 3")
		elseif i==2 then	-- Deradune
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("wndZone"):SetText("Deradune")
			zones[# zones]:FindChild("bZoneT1"):SetData("DeraduneT1A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 6: Tract 1 of Deradune, Bloodfire Village.")

			zones[# zones]:FindChild("bZoneT2"):SetData("DeraduneT2A")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 8: Tract 2 of Deradune, Outreach Post.")

			zones[# zones]:FindChild("bZoneT3"):SetData("DeraduneT3")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level 10: Tract 3 of Deradune, Owanee Research Station.")
		elseif i==3 then	-- Ellevar
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("wndZone"):SetText("Ellevar")
			zones[# zones]:FindChild("bZoneT1"):SetData("EllevarT1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 6: Tract 1 of Ellevar, Lightreach Mission.")

			zones[# zones]:FindChild("bZoneT2"):SetData("EllevarT2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 9: Tract 2 of Ellevar, Mistymurk Camp.")

			zones[# zones]:FindChild("bZoneT3"):SetData("EllevarT3")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level 12: Tract 3 of Ellevar, Lightreach Mission.")
		elseif i==4 then	-- Auroria
			zones[# zones]:FindChild("wndZone"):SetText("Auroria")
			zones[# zones]:FindChild("bZoneT1"):SetData("AuroriaT1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 14: Takes you to tract 1 of Auroria")

			zones[# zones]:FindChild("bZoneT2"):SetData("AuroriaT2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 16: Takes you to tract 2 of Auroria")

			zones[# zones]:FindChild("bZoneT3"):SetData("AuroriaT3")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level 18: Takes you to tract 3 of Auroria")

			zones[# zones]:FindChild("bZoneT4"):SetData("AuroriaT4")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Level 20: Takes you to tract 4 of Auroria")
		elseif i==5 then	-- Whitevale
			zones[# zones]:FindChild("wndZone"):SetText("Whitevale")
			zones[# zones]:FindChild("bZoneT1"):Show(false)

			zones[# zones]:FindChild("bZoneT2"):SetData("WhitevaleT2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 23: Whitevale tract 2, Palerock Post.")

			zones[# zones]:FindChild("bZoneT3"):SetData("WhitevaleT3")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level 24: Whitevale tract 3, Wigwalli Village.")

			zones[# zones]:FindChild("bZoneT4"):SetData("WhitevaleT4")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Level 27: Whitevale tract 4, Prosperity Junction.")
		elseif i==6 then	-- Dreadmoor
			zones[# zones]:FindChild("wndZone"):SetText("Dreadmoor")
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Dreadmoor T1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 22: Dreadmoor Tract 1")

			zones[# zones]:FindChild("bZoneT3"):SetData("Dreadmoor T3 Dom")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("Level 25: Dreadmoor Tract 3")
		elseif i==7 then	-- Farside
			zones[# zones]:FindChild("wndZone"):SetText("Farside")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Farside Dom T1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 29: Farside Tract 1")

			zones[# zones]:FindChild("bZoneT2"):SetData("Farside Dom T2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 32: Farside Tract 2")				
		elseif i==8 then	-- Wilderrun
			zones[# zones]:FindChild("wndZone"):SetText("Wilderrun")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Wilderrun T1 Dom")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 35: Takes you to tract 1 of Wilderrun")

			zones[# zones]:FindChild("bZoneT2"):SetData("Wilderrun T2 Both")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 38: Takes you to tract 2 of Wilderrun")
		elseif i==9 then	-- Malgrave
			zones[# zones]:FindChild("wndZone"):SetText("Malgrave")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Malgrave T1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 40: Malgrave Tract 1")

			zones[# zones]:FindChild("bZoneT2"):SetData("Malgrave T2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 45: Malgrave Tract 2")			
		elseif i==10 then	-- Halon Ring
			zones[# zones]:FindChild("wndZone"):SetText("Halon Ring")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Halon Ring T1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 41: Halon Ring Tract 1")

			zones[# zones]:FindChild("bZoneT2"):SetData("Halon Ring T2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 44: Halon Ring Tract 2")
		elseif i==11 then	-- Grimvault
			zones[# zones]:FindChild("wndZone"):SetText("Grimvault")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("Grimvault T1 Dom")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Level 45: Grimvault Tract 1")

			zones[# zones]:FindChild("bZoneT2"):SetData("Grimvault T2 Dom")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("Level 48: Grimvault Tract 2")
		end
	end
	for i=0, 4 do		-- DUNGEONS
		table.insert(zones, Apollo.LoadForm("ZoneHopperDev.xml", "wndZone", self.wndMain:FindChild("wndDungeon"), self))
		if i==0 then
			zones[# zones]:FindChild("wndZone"):SetText("Stormtalon's Lair")
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
			zones[# zones]:FindChild("bZoneT4"):SetData("Stormtalon")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Level 20: Stormtalon's Lair is tuned for 5 people.")
		elseif i==1 then
			zones[# zones]:FindChild("wndZone"):SetText("Ruins of Kel Voreth")
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
			zones[# zones]:FindChild("bZoneT4"):SetData("Kelvoreth")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Level 20: Kel Voreth is tuned for 5 people.")
		elseif i==2 then
			zones[# zones]:FindChild("wndZone"):SetText("Skullcano Island")
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
			zones[# zones]:FindChild("bZoneT4"):SetData("Skullcano")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Level 35: Skullcano is tuned for 5 people.")
		elseif i==3 then
			zones[# zones]:FindChild("wndZone"):SetText("Sanctuary of the Sword Maiden")
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
			zones[# zones]:FindChild("bZoneT4"):SetData("Sanctuary")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Level 50: Sanctuary of the Sword Maiden is tuned for 5 people.")
		elseif i==4 then
			zones[# zones]:FindChild("wndZone"):SetText("Datascape Island")
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
			zones[# zones]:FindChild("bZoneT4"):SetData("Datascape")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Level 50: Datascape is tuned for 40 people.")
		end
	end
	for i=0, 7 do		-- ADVENTURES
		table.insert(zones, Apollo.LoadForm("ZoneHopperDev.xml", "wndZone", self.wndMain:FindChild("wndAdventure"), self))
		if i==0 then
			zones[# zones]:FindChild("wndZone"):SetText("Hycrest")				-- Level 15
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetData("AdvHycrest")
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
--			zones[# zones]:FindChild("bZoneT4"):SetData("StartAdvHycrest")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Hycrest Adventure is a 5-man instance for level 15 Exiles")
		elseif i==1 then
			zones[# zones]:FindChild("wndZone"):SetText("Astrovoid")			-- Level 15
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetData("AdvAstrovoid")
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
--			zones[# zones]:FindChild("bZoneT4"):SetData("StartAdvAstrovoid")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Astrovoid Adventure is a 5-man instance for level 15 Dominion")
		elseif i==2 then
			zones[# zones]:FindChild("wndZone"):SetText("Northern Wilds")		-- Level 25
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetData("AdvNW")
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
--			zones[# zones]:FindChild("bZoneT4"):SetData("StartAdvNW")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Northern Wilds Adventure is a 5-man instance for level 25 characters")
		elseif i==3 then
			zones[# zones]:FindChild("wndZone"):SetText("Galeras")				-- Level 30
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetData("AdvGaleras")
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
--			zones[# zones]:FindChild("bZoneT4"):SetData("StartAdvGaleras")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Galeras Adventure is a 5-man instance for level 30 characters")
		elseif i==4 then
			zones[# zones]:FindChild("wndZone"):SetText("Whitevale")			-- Level 40
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetData("AdvWhitevale")
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
--			zones[# zones]:FindChild("bZoneT4"):SetData("StartAdvWhitevale")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Whitevale Adventure is a 5-man instance for level 40 characters")
		elseif i==5 then
			zones[# zones]:FindChild("wndZone"):SetText("Malgrave")				-- Level 45
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetData("AdvMalgrave")
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
--			zones[# zones]:FindChild("bZoneT4"):SetData("StartAdvMalgrave")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Malgrave Adventure is a 5-man instance for level 45 characters")
		elseif i==6 then
			zones[# zones]:FindChild("wndZone"):SetText("Farside")				-- Level 50
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetData("AdvFarside")
			zones[# zones]:FindChild("bZoneT4"):SetText("Go")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Farside Adventure is a 5-man instance for level 50 characters")
		elseif i==7 then
			zones[# zones]:FindChild("wndZone"):SetText("Spawn the Adventure Vendor")			-- Spawn the adventure vendor!
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):SetText("OK")
			zones[# zones]:FindChild("bZoneT4"):SetData("Adv Vendor")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("Spawns the adventure vendor. Get all that special edition phat l00tz!")
		end
	end
	self.wndMain:FindChild("wndExiles"):ArrangeChildrenVert(0)
	self.wndMain:FindChild("wndDominion"):ArrangeChildrenVert(0)
	self.wndMain:FindChild("wndDungeon"):ArrangeChildrenVert(0)
	self.wndMain:FindChild("wndAdventure"):ArrangeChildrenVert(0)
end

function ZoneHopperDev:goZone( wndHandler, wndControl, eMouseButton )
	--if self.bInAZoneChange then return end -- TEMP disabled

															-- EXILES *********************************
	if wndControl:GetData()=="Exile Arc" then				-- Arc Ship
		self:changeLevels(1)
		self:goMap(1537)
	elseif wndControl:GetData()=="AlgorocT1" then			-- Algoroc T1
		self:changeLevels(6)
		goLoc = "3828.85 -996.68 -4483.92 -17.16"
		self:goMap(51)
	elseif wndControl:GetData()=="AlgorocT2" then			-- Algoroc T2
		self:changeLevels(9)
		goLoc = "4093.23 -1056.04 -3999.60 -105.62"
		self:goMap(51)
	elseif wndControl:GetData()=="AlgorocT3" then			-- Algoroc T3
		self:changeLevels(12)
		goLoc = "4422.04 -1105.13 -3936.69 -156.00"
		self:goMap(51)
	elseif wndControl:GetData()=="CelestionT1" then			-- Celestion T1
		self:changeLevels(6)
		goLoc = "1028.07 -906.74 -3073.66 -104.33"
		self:goMap(51)
	elseif wndControl:GetData()=="CelestionT2" then			-- Celestion T2
		self:changeLevels(9)
		goLoc = "2116.16 -919.85 -1912.82 0.59"
		self:goMap(51)
	elseif wndControl:GetData()=="CelestionT3" then			-- Celestion T3
		self:changeLevels(12)
		goLoc = "2413.62 -919.73 -2494.11 -106.81"
		self:goMap(51)
	elseif wndControl:GetData()=="Dreadmoor T1" then		-- Dreadmoor T1 	(Dominion)
		self:changeLevels(22)
		goLoc = "-2835.84 -983.92 -88.80 22.44"
		self:goMap(22)
	elseif wndControl:GetData()=="Dreadmoor T2" then		-- Dreadmoor T2
		self:changeLevels(22)
		goLoc = "-3626.45 -985.83 2498.96 100.41"
		self:goMap(22)
	elseif wndControl:GetData()=="Dreadmoor T3 Exile" then	-- Dreadmoor T3
		self:changeLevels(25)
		goLoc = "-1430.43 -956.41 926.45 -34.35"
		self:goMap(22)
	elseif wndControl:GetData()=="Dreadmoor T3 Dom" then	-- Dreadmoor T3		(Dominion)
		self:changeLevels(25)
		goLoc = "-1423.16 -970.34 712.04 -49.98"
		self:goMap(22)
	elseif wndControl:GetData()=="Everstar 1" then			-- Everstar Grove - Start
		self:changeLevels(3)
		goLoc = "-773.25 -904.22 -2269.52 -43.89"
		self:goMap(990)
	elseif wndControl:GetData()=="Farside Exiles T1" then	-- Farside T1 Exiles
		self:changeLevels(29)
		goLoc = "5903.19 -496.46 -4925.91 168.60"
		self:goMap(1421)
	elseif wndControl:GetData()=="Farside Exiles T2" then	-- Farside T2 Exiles
		self:changeLevels(32)
		goLoc = "4385.05 -714.45 -5663.95 57.11"
		self:goMap(1421)
	elseif wndControl:GetData()=="GalerasT1A" then			-- Galeras T1
		self:changeLevels(14)
		goLoc = "4101.77 -803.21 -2349.14 -126.32"
		self:goMap(51)
	elseif wndControl:GetData()=="GalerasT2" then			-- Galeras T2
		self:changeLevels(16)
		goLoc = "5084.08 -874.95 -2917.66 -39.39"
		self:goMap(51)
	elseif wndControl:GetData()=="GalerasT3B" then			-- Galeras T3
		self:changeLevels(18)
		goLoc = "5612.59 -1012.67 -2430.34 -0.72"
		self:goMap(51)
	elseif wndControl:GetData()=="GalerasT4A" then			-- Galeras T4
		self:changeLevels(20)
		goLoc = "5753.92 -868.84 -2536.53 -154.69"
		self:goMap(51)
	elseif wndControl:GetData()=="Grimvault T1 Exile" then	-- Grimvault T1 Exile
		self:changeLevels(45)
		goLoc = "834.15 -946.83 773.69 25.67"
		self:goMap(1061)
	elseif wndControl:GetData()=="Grimvault T2 Exile" then	-- Grimvault T2 Exile
		self:changeLevels(48)
		goLoc = "814.44 -1042.12 -4143.49 93.43"
		self:goMap(1061)
	elseif wndControl:GetData()=="Grimvault T1 Dom" then	-- Grimvault T1 Dominion
		self:changeLevels(45)
		goLoc = "2654.37 -874.91 863.85 -62.55"
		self:goMap(1061)
	elseif wndControl:GetData()=="Grimvault T2 Dom" then	-- Grimvault T2 Dominion
		self:changeLevels(48)
		goLoc = "671.67 -1013.65 -4107.32 -47.25"
		self:goMap(1061)
	elseif wndControl:GetData()=="Halon Ring T1" then		-- Halon Ring T1		(Both)
		self:changeLevels(41)
		goLoc = "-11894.04 55.71 -4013.62 -42.27"
		self:goMap(1068)
	elseif wndControl:GetData()=="Halon Ring T2" then		-- Halong Ring T2		(Both)
		self:changeLevels(44)
		goLoc = "-10549.97 169.57 -8366.75 164.91"
		self:goMap(1068)
	elseif wndControl:GetData()=="Malgrave T1" then			-- Malgrave T1			(Both)
		self:changeLevels(40)
		goLoc = "1587.28 -978.08 4213.55 30.83"
		self:goMap(1061)
	elseif wndControl:GetData()=="Malgrave T2" then			-- Malgrave T2			(Both)
		self:changeLevels(45)
		goLoc = "1650.23 -819.84 2880.66 128.60"
		self:goMap(1061)
	elseif wndControl:GetData()=="NWT1" then				-- Northern Wilds T1
		self:changeLevels(3)
		goLoc = "3911.21 -699.89 -5330.62 -24.95"
		self:goMap(426)
	elseif wndControl:GetData()=="NWT2" then				-- Northern Wilds T2
		self:changeLevels(4)
		goLoc = "4614.40 -719.23 -5644.10 -75.14"
		Apollo.ParseInput("/c qc 3486")
		Apollo.ParseInput("/c setphase 2")
		self:getQuest(3668)
		self:goMap(426)
	elseif wndControl:GetData()=="NWT3" then				-- Northern Wilds T3
		self:changeLevels(5)
		goLoc = "4484.15 -720.89 -5348.95 -158.38"
		Apollo.ParseInput("/c qc 3486")
		Apollo.ParseInput("/c qc 3673")
		self:goMap(426)
	elseif wndControl:GetData()=="WhitevaleT1" then			-- Whitevale T1
		self:changeLevels(23)
		goLoc = "4496.42 -936.95 -575.72 -51.24"
		self:goMap(51)
	elseif wndControl:GetData()=="WhitevaleT2" then			-- Whitevale T2			(Dominion)
		self:changeLevels(23)
		goLoc = "1762.69 -992.59 -734.20 -93.79"
		self:goMap(51)
	elseif wndControl:GetData()=="WhitevaleT3" then			-- Whitevale T3			(Both)	
		self:changeLevels(24)
		goLoc = "3472.37 -943.62 -434.92 43.64"
		self:goMap(51)
	elseif wndControl:GetData()=="WhitevaleT4" then			-- Whitevale T4			(Both)
		self:changeLevels(27)
		goLoc = "3090.42 -1031.10 772.00 -124.58"
		self:goMap(51)
	elseif wndControl:GetData()=="Wilderrun T1 Exiles" then	-- Wilderrun T1 Exiles
		self:changeLevels(35)
		goLoc = "2160.78 -850.59 -1769.63 6.75"
		self:goMap(22)
	elseif wndControl:GetData()=="Wilderrun T1 Dom" then	-- Wilderrun T1 Dominion
		self:changeLevels(35)
		goLoc = "1240.03 -723.70 -2055.06 -131.96"
		self:goMap(22)
	elseif wndControl:GetData()=="Wilderrun T2 Both" then	-- Wilderrun T2 Both
		self:changeLevels(38)
		goLoc = "2682.85 -746.39 -3868.58 137.02"
		self:goMap(22)
																-- DOMINION **********************************
	elseif wndControl:GetData()=="CrimsonT1A" then				-- Crimson Isle - Start
		self:changeLevels(3)
		goLoc = "-7667.77 -992.96 36.20 -11.40"
		self:getQuest(5595)
		--self:goMap(870)
--[[	elseif wndControl:GetData()=="CrimsonT1B" then				-- Crimson Isle - Megatech
		self:changeLevels(5)
		goLoc = "-7249.89 -985.45 -1100.07 61.85"
		self:getQuest(5604)
		self:goMap(870)
	--]]
	elseif wndControl:GetData()=="LevianT1A" then				-- Levian Bay - Start
		self:changeLevels(3)
		self:goMap(1387)
	elseif wndControl:GetData()=="LevianT1B" then				-- Levian Bay - Star-Comm Station
		self:changeLevels(3)
		goLoc = "-3019.90 -959.10 -6073.39 -121.47"
		self:goMap(1387)
	elseif wndControl:GetData()=="DeraduneT1A" then				-- Deradune T1
		self:changeLevels(6)
		self:goMap(22)
	elseif wndControl:GetData()=="DeraduneT2A" then				-- Deradune T2
		self:changeLevels(8)
		goLoc = "-5089.52 -944.55 -1551.12 53.49"
		self:goMap(22)
	elseif wndControl:GetData()=="DeraduneT3" then				-- Deradune T3
		self:changeLevels(10)
		goLoc = "-4688.60 -969.74 -429.04 -95.73"
		self:goMap(22)
	elseif wndControl:GetData()=="EllevarT1" then				-- Ellevar T1
		self:changeLevels(6)
		goLoc = "-2542.90 -770.79 -3467.97 -46.68"
		self:goMap(22)
	elseif wndControl:GetData()=="EllevarT2" then				-- Ellevar T2
		self:changeLevels(9)
		goLoc = "-2514.75 -763.90 -2935.87 -170.44"
		self:goMap(22)
	elseif wndControl:GetData()=="EllevarT3" then				-- Ellevar T3
		self:changeLevels(12)
		goLoc = "-2450.22 -785.95 -3569.29 -54.17"
		self:goMap(22)
	elseif wndControl:GetData()=="Farside Dom T1" then			-- Farside T1 Dominion
		self:changeLevels(29)
		goLoc = "5362.36 -496.95 -4528.93 175.01"
		self:goMap(1421)
	elseif wndControl:GetData()=="Farside Dom T2" then			-- Farside T2 Dominion
		self:changeLevels(32)
		goLoc = "4063.84 -722.36 -5242.14 3.71"
		self:goMap(1421)	
	elseif wndControl:GetData()=="AuroriaT1" then				-- Auroria T1
		self:changeLevels(14)
		goLoc = "-2469.52 -874.94 -1958.03 -148.11"
		self:goMap(22)
	elseif wndControl:GetData()=="AuroriaT2" then				-- Auroria T2
		self:changeLevels(16)
		goLoc = "-2096.28 -876.09 -2049.89 -134.59"
		self:goMap(22)
	elseif wndControl:GetData()=="AuroriaT3" then				-- Auroria T3
		self:changeLevels(18)
		goLoc = "-2183.83 -904.72 -808.15 -142.38"
		self:goMap(22)
	elseif wndControl:GetData()=="AuroriaT4" then				-- Auroria T4
		self:changeLevels(20)
		goLoc = "-1254.25 -892.46 -1172.70 -0.34"
		self:goMap(22)
	elseif wndControl:GetData()=="Stormtalon" then				-- DUNGEONS ***********************************
		self:changeLevels(20)
		self:goMap(382)
	elseif wndControl:GetData()=="Kelvoreth" then
		self:changeLevels(20)
		self:goMap(1336)
	elseif wndControl:GetData()=="Skullcano" then
		self:changeLevels(35)
		self:goMap(1263)
	elseif wndControl:GetData()=="Sanctuary" then
		self:changeLevels(50)
		self:goMap(1271)
	elseif wndControl:GetData()=="Datascape" then
		self:changeLevels(20)
		self:goMap(1333)
																		-- ADVENTURES *************************
	elseif wndControl:GetData()=="AdvHycrest" then						-- Hycrest Adventure
		self:changeLevels(15)											
--		self:goMap(1149)
		self:goHub(41727)
	elseif wndControl:GetData()=="AdvAstrovoid" then					-- Astrovoid Adventure
		self:changeLevels(15)
--		self:goMap(1437)
		self:goHub(42020)
	elseif wndControl:GetData()=="AdvNW" then							-- Northern Wilds Adventure
		self:changeLevels(25)
		self:goHub(41445)
--		self:goMap(1393)
	elseif wndControl:GetData()=="AdvGaleras" then						-- Galeras Adventure
		self:changeLevels(30)
--		self:goMap(1233)
		self:goHub(40952)
	elseif wndControl:GetData()=="AdvWhitevale" then					-- Whitevale Adventure
		self:changeLevels(40)
--		self:goMap(1323)
		self:goHub(41156)
	elseif wndControl:GetData()=="AdvMalgrave" then						-- Malgrave Adventure
		self:changeLevels(45)
--		self:goMap(1181)
		self:goHub(41719)
	elseif wndControl:GetData()=="AdvFarside" then						-- Farside Adventure
		self:changeLevels(50)
		self:goMap(3010)
--		self:goHub()
	elseif wndControl:GetData()=="AdvGuy" then							-- Spawn the Adventure Guy
		Apollo.ParseInput("/c cm 18343")
	elseif wndControl:GetData()=="Adv Vendor" then						-- Spawns the Adventure Vending Machine
		Apollo.ParseInput("/c cm 31126")
	else
		self.bInAZoneChange = false
		return
	end

	self.bInAZoneChange = true
end

---------------------------------------------------------------------------------------------------
-- ZoneHopperForm Functions
---------------------------------------------------------------------------------------------------

function ZoneHopperDev:OnMoneyBtn( wndHandler, wndControl, eMouseButton )
	Apollo.ParseInput("/c money 99999999")
end

function ZoneHopperDev:OnBagBtn( wndHandler, wndControl, eMouseButton )
	Apollo.ParseInput("/c ci 12050")
end

function ZoneHopperDev:OnGearBtn( wndHandler, wndControl, eMouseButton )	-- Gets the newer dungeon gear to test in
	myGuy = GameLib.GetPlayerUnit()
	myClass = GameLib.GetClassName(myGuy:GetClassId())
	myLevel = myGuy:GetLevel()
--	Print("My Class = "..myClass)
--	Print("My Level = "..myLevel)
	if (myClass == "Warrior") then
		if (myLevel < 50) then 					-- Grants the Warrior weapon
			Apollo.ParseInput("/c ci 38753")
		else 
			Apollo.ParseInput("/c ci 38759")
		end
		if (myLevel < 20) then					-- Grants the Warrior armor
			Apollo.ParseInput("/c ci 38321")
			Apollo.ParseInput("/c ci 38322")
		elseif (myLevel < 25) then
			Apollo.ParseInput("/c ci 36555")
			Apollo.ParseInput("/c ci 36556")
		elseif (myLevel < 30) then
			Apollo.ParseInput("/c ci 38333")
			Apollo.ParseInput("/c ci 38334")
		elseif (myLevel < 35) then
			Apollo.ParseInput("/c ci 38345")
			Apollo.ParseInput("/c ci 38346")
		elseif (myLevel < 40) then
			Apollo.ParseInput("/c ci 38369")
			Apollo.ParseInput("/c ci 38370")
		elseif (myLevel < 45) then
			Apollo.ParseInput("/c ci 38381")
			Apollo.ParseInput("/c ci 38382")
		elseif (myLevel < 50) then
			Apollo.ParseInput("/c ci 38393")
			Apollo.ParseInput("/c ci 38394")
		else
			Apollo.ParseInput("/c ci 38357")
			Apollo.ParseInput("/c ci 38358")
		end
	end
	if (myClass == "Engineer") then
		if (myLevel < 50) then 					-- Grants the Engineer weapon
			Apollo.ParseInput("/c ci 38754")
		else 
			Apollo.ParseInput("/c ci 38760")
		end
		if (myLevel < 20) then					-- Grants the Engineer armor
			Apollo.ParseInput("/c ci 38323")
			Apollo.ParseInput("/c ci 38324")
		elseif (myLevel < 25) then
			Apollo.ParseInput("/c ci 36557")
			Apollo.ParseInput("/c ci 36558")
		elseif (myLevel < 30) then
			Apollo.ParseInput("/c ci 38335")
			Apollo.ParseInput("/c ci 38336")
		elseif (myLevel < 35) then
			Apollo.ParseInput("/c ci 38347")
			Apollo.ParseInput("/c ci 38348")
		elseif (myLevel < 40) then
			Apollo.ParseInput("/c ci 38371")
			Apollo.ParseInput("/c ci 38372")
		elseif (myLevel < 45) then
			Apollo.ParseInput("/c ci 38383")
			Apollo.ParseInput("/c ci 38384")
		elseif (myLevel < 50) then
			Apollo.ParseInput("/c ci 38395")
			Apollo.ParseInput("/c ci 38396")
		else
			Apollo.ParseInput("/c ci 38359")
			Apollo.ParseInput("/c ci 38360")
		end
	end
	if (myClass == "Stalker") then
		if (myLevel < 50) then 					-- Grants the Stalker weapon
			Apollo.ParseInput("/c ci 38755")
		else 
			Apollo.ParseInput("/c ci 38761")
		end
		if (myLevel < 20) then					-- Grants the Stalker armor
			Apollo.ParseInput("/c ci 38325")
			Apollo.ParseInput("/c ci 38326")
		elseif (myLevel < 25) then
			Apollo.ParseInput("/c ci 36559")
			Apollo.ParseInput("/c ci 36560")
		elseif (myLevel < 30) then
			Apollo.ParseInput("/c ci 38337")
			Apollo.ParseInput("/c ci 38338")
		elseif (myLevel < 35) then
			Apollo.ParseInput("/c ci 38349")
			Apollo.ParseInput("/c ci 38350")
		elseif (myLevel < 40) then
			Apollo.ParseInput("/c ci 38373")
			Apollo.ParseInput("/c ci 38374")
		elseif (myLevel < 45) then
			Apollo.ParseInput("/c ci 38385")
			Apollo.ParseInput("/c ci 38386")
		elseif (myLevel < 50) then
			Apollo.ParseInput("/c ci 38397")
			Apollo.ParseInput("/c ci 38398")
		else
			Apollo.ParseInput("/c ci 38361")
			Apollo.ParseInput("/c ci 38362")
		end
	end
	if (myClass == "Esper") then
		if (myLevel < 50) then 					-- Grants the Esper weapon
			Apollo.ParseInput("/c ci 38756")
		else 
			Apollo.ParseInput("/c ci 38762")
		end
		if (myLevel < 20) then					-- Grants the Esper armor
			Apollo.ParseInput("/c ci 38327")
			Apollo.ParseInput("/c ci 38328")
		elseif (myLevel < 25) then
			Apollo.ParseInput("/c ci 36561")
			Apollo.ParseInput("/c ci 36562")
		elseif (myLevel < 30) then
			Apollo.ParseInput("/c ci 38339")
			Apollo.ParseInput("/c ci 38340")
		elseif (myLevel < 35) then
			Apollo.ParseInput("/c ci 38351")
			Apollo.ParseInput("/c ci 38352")
		elseif (myLevel < 40) then
			Apollo.ParseInput("/c ci 38375")
			Apollo.ParseInput("/c ci 38376")
		elseif (myLevel < 45) then
			Apollo.ParseInput("/c ci 38387")
			Apollo.ParseInput("/c ci 38388")
		elseif (myLevel < 50) then
			Apollo.ParseInput("/c ci 38399")
			Apollo.ParseInput("/c ci 38400")
		else
			Apollo.ParseInput("/c ci 38363")
			Apollo.ParseInput("/c ci 38364")
		end
	end
	if (myClass == "Spellslinger") then
		if (myLevel < 50) then 					-- Grants the Spellslinger weapon
			Apollo.ParseInput("/c ci 38757")
		else 
			Apollo.ParseInput("/c ci 38763")
		end
		if (myLevel < 20) then					-- Grants the Spellslinger armor
			Apollo.ParseInput("/c ci 38329")
			Apollo.ParseInput("/c ci 38330")
		elseif (myLevel < 25) then
			Apollo.ParseInput("/c ci 36563")
			Apollo.ParseInput("/c ci 36564")
		elseif (myLevel < 30) then
			Apollo.ParseInput("/c ci 38341")
			Apollo.ParseInput("/c ci 38342")
		elseif (myLevel < 35) then
			Apollo.ParseInput("/c ci 38353")
			Apollo.ParseInput("/c ci 38354")
		elseif (myLevel < 40) then
			Apollo.ParseInput("/c ci 38377")
			Apollo.ParseInput("/c ci 38378")
		elseif (myLevel < 45) then
			Apollo.ParseInput("/c ci 38389")
			Apollo.ParseInput("/c ci 38390")
		elseif (myLevel < 50) then
			Apollo.ParseInput("/c ci 38401")
			Apollo.ParseInput("/c ci 38402")
		else
			Apollo.ParseInput("/c ci 38365")
			Apollo.ParseInput("/c ci 38366")
		end
	end
	if (myClass == "Medic") then
		if (myLevel < 50) then 					-- Grants the Medic weapon
			Apollo.ParseInput("/c ci 38758")
		else 
			Apollo.ParseInput("/c ci 38764")
		end
		if (myLevel < 20) then					-- Grants the Medic armor
			Apollo.ParseInput("/c ci 38331")
			Apollo.ParseInput("/c ci 38332")
		elseif (myLevel < 25) then
			Apollo.ParseInput("/c ci 36565")
			Apollo.ParseInput("/c ci 36566")
		elseif (myLevel < 30) then
			Apollo.ParseInput("/c ci 38343")
			Apollo.ParseInput("/c ci 38344")
		elseif (myLevel < 35) then
			Apollo.ParseInput("/c ci 38355")
			Apollo.ParseInput("/c ci 38356")
		elseif (myLevel < 40) then
			Apollo.ParseInput("/c ci 38379")
			Apollo.ParseInput("/c ci 38380")
		elseif (myLevel < 45) then
			Apollo.ParseInput("/c ci 38391")
			Apollo.ParseInput("/c ci 38392")
		elseif (myLevel < 50) then
			Apollo.ParseInput("/c ci 38403")
			Apollo.ParseInput("/c ci 38404")
		else
			Apollo.ParseInput("/c ci 38367")
			Apollo.ParseInput("/c ci 38368")
		end
	end	
end

-----------------------------------------------------------------------------------------------
-- ZoneHopperDev Instance
-----------------------------------------------------------------------------------------------
local ZoneHopperDevInst = ZoneHopperDev:new()
ZoneHopperDevInst:Init()
