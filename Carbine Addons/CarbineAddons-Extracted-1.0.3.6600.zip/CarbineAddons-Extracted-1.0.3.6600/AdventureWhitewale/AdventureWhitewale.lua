-----------------------------------------------------------------------------------------------
-- Client Lua Script for AdventureWhitewale
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------
 
require "Window"
 
-----------------------------------------------------------------------------------------------
-- AdventureWhitewale Module Definition
-----------------------------------------------------------------------------------------------
local AdventureWhitewale = {} 
 
-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
-- e.g. local kiExampleVariableMax = 999
 
-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
function AdventureWhitewale:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self 

    -- initialize variables here

    return o
end

function AdventureWhitewale:Init()
    Apollo.RegisterAddon(self)
end
 

-----------------------------------------------------------------------------------------------
-- AdventureWhitewale OnLoad
-----------------------------------------------------------------------------------------------
function AdventureWhitewale:OnLoad()
    -- Register handlers for events, slash commands and timer, etc.
    -- e.g. Apollo.RegisterEventHandler("KeyDown", "OnKeyDown", self)
    Apollo.RegisterSlashCommand("whitevaleadv", "OnWhitevaleAdventureOn", self)
    Apollo.RegisterEventHandler("WhitevaleAdvResource", "OnUpdateResource", self)
	Apollo.RegisterEventHandler("WhitevaleAdvShow", "OnShow", self)
	Apollo.RegisterEventHandler("ChangeWorld", "OnHide", self)
	
	self.tSons = {}
	self.tRollers = {}
	self.tGrinders = {}
	
    -- load our forms
    self.wnd = Apollo.LoadForm("WhitevaleAdventure.xml", "WhitevaleAdventureForm", nil, self)
	self.wndMain = self.wnd:FindChild("Main")
	self.wndRepBar = self.wndMain:FindChild("Rep")
	self.wndSonsLoyalty = self.wndMain:FindChild("SonsLoyalty")
	self.wndRollersLoyalty = self.wndMain:FindChild("RollersLoyalty")
	self.wndGrindersLoyalty = self.wndMain:FindChild("GrindersLoyalty")
	self.wndSonsLoyalty:SetText(Apollo.GetString("WhitevaleAdv_SonsOfRavok"))
	self.wndRollersLoyalty:SetText(Apollo.GetString("WhitevaleAdv_RocktownRollers"))
	self.wndGrindersLoyalty:SetText(Apollo.GetString("WhitevaleAdv_Geargrinders"))
	self.wndSonsLoyalty:Show(false)
	self.wndRollersLoyalty:Show(false)
	self.wndGrindersLoyalty:Show(false)
	
	for i = 1, 3 do 
		self.tSons[i] = self.wndSonsLoyalty:FindChild("Sons" .. i)
		self.tRollers[i] = self.wndRollersLoyalty:FindChild("Rollers" .. i)
		self.tGrinders[i] = self.wndGrindersLoyalty:FindChild("Grinders" .. i)
	end
	
	self.wndRepBar:SetMax(100)
	self.wndRepBar:SetFloor(0)
	self.wndRepBar:SetProgress(0)
	self.wndRepBar:Show(false)
	self.wndRepBar:SetText(Apollo.GetString("WhitevaleAdv_Notoriety"))
    self.wnd:Show(false)
    
end


-----------------------------------------------------------------------------------------------
-- AdventureWhitewale Functions
-----------------------------------------------------------------------------------------------
-- Define general functions here

-- on SlashCommand "/whitevaleadv"
function AdventureWhitewale:OnWhitevaleAdventureOn()
	self.wnd:Show(true) -- show the window
end


function AdventureWhitewale:OnUpdateResource(iRep, iSons, iRollers, iGrinders)
	self.wnd:Show(true)
	self.wndRepBar:Show(true)
	self.wndRepBar:SetProgress(iRep)
	
	self.wndSonsLoyalty:Show(true)
	self.wndRollersLoyalty:Show(true)
	self.wndGrindersLoyalty:Show(true)
	self:HideAll()
	
	if iSons > 0 then
		for i = 1, iSons do
			self.tSons[i]:Show(true)
		end
	end
	
	if iRollers > 0 then
		for i = 1, iRollers do
			self.tRollers[i]:Show(true)
		end
	end
	
	if iGrinders > 0 then
		for i = 1, iGrinders do
			self.tGrinders[i]:Show(true)
		end
	end
end


function AdventureWhitewale:HideAll()
	for i = 1, 3 do
		self.tSons[i]:Show(false)
		self.tRollers[i]:Show(false)
		self.tGrinders[i]:Show(false)
	end
end
	
	
function AdventureWhitewale:OnShow(bShow)
	if bShow == true then
		self.wnd:Show(true)
	elseif bShow == false then
		self.wndMain:Show(false)
	end
end

function AdventureWhitewale:OnHide()
	self.wnd:Show(false)
end
-----------------------------------------------------------------------------------------------
-- WhitevaleAdventureForm Functions
-----------------------------------------------------------------------------------------------
-- when the OK button is clicked
function AdventureWhitewale:OnOK()
	self.wnd:Show(false) -- hide the window
end

-- when the Cancel button is clicked
function AdventureWhitewale:OnCancel()
	self.wnd:Show(false) -- hide the window
end


-----------------------------------------------------------------------------------------------
-- AdventureWhitewale Instance
-----------------------------------------------------------------------------------------------
local AdventureWhitewaleInst = AdventureWhitewale:new()
AdventureWhitewaleInst:Init()
