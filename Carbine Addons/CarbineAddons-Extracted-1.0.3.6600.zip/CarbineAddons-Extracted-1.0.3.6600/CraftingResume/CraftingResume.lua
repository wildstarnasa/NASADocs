-----------------------------------------------------------------------------------------------
-- Client Lua Script for CraftingResume
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"

local CraftingResume = {}

function CraftingResume:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function CraftingResume:Init()
    Apollo.RegisterAddon(self)
end

function CraftingResume:OnLoad()
	Apollo.RegisterEventHandler("GenericEvent_CraftFromPL", "OnGenericEvent_CraftFromPL", self)
end

function CraftingResume:OnGenericEvent_CraftFromPL(idQueuedSchematic)
	if GameLib.GetPlayerUnit():IsCasting() then
		return
	end

	if self.wndMain and self.wndMain:IsValid() then
		self.wndMain:Destroy()
	end

	local tCurrentCraft = CraftingLib.GetCurrentCraft()
	if tCurrentCraft and tCurrentCraft.nSchematicId ~= 0 then
		self.wndMain = Apollo.LoadForm("CraftingResume.xml", "CraftingResumeForm", nil, self)
		self.wndMain:FindChild("CoordPrevAbandonBtn"):SetData(idQueuedSchematic)
		self.wndMain:FindChild("CoordPrevFinishOldBtn"):SetData(tCurrentCraft.nSchematicId)
		self.wndMain:FindChild("CoordPrevWindowPopupOldName"):SetText(CraftingLib.GetSchematicInfo(tCurrentCraft.nSchematicId).strName)
	else
		self:HelperStartCraft(idQueuedSchematic)
	end
end

function CraftingResume:OnCoordPrevFinishOldBtn(wndHandler, wndControl) -- CoordPrevFinishOldBtn, data is idQueuedSchematic
	self:HelperStartCraft(wndHandler:GetData())
	self.wndMain:Destroy()
end

function CraftingResume:OnCoordPrevAbandonBtn(wndHandler, wndControl) -- CoordPrevAbandonBtn
	Event_FireGenericEvent("GenericEvent_LootChannelMessage", Apollo.GetString("CraftingResume_Abandon"))
	Event_FireGenericEvent("GenericEvent_BotchCraft")
	Event_FireGenericEvent("AlwaysShowTradeskills")
	CraftingLib.BotchCraft()
	self.wndMain:Destroy()
end

function CraftingResume:HelperStartCraft(idSchematic)
	if not idSchematic then
		return
	end

	local tSchematicInfo = CraftingLib.GetSchematicInfo(idSchematic)
	if not tSchematicInfo then
		return
	end

	local tTradeskillInfo = CraftingLib.GetTradeskillInfo(tSchematicInfo.eTradeskillId)
	if tTradeskillInfo.bIsCoordinateCrafting then
		Event_FireGenericEvent("GenericEvent_StartCraftingGrid", idSchematic)
	elseif tTradeskillInfo.bIsCircuitBoardCrafting then
		Event_FireGenericEvent("GenericEvent_StartCircuitCraft", idSchematic)
	end
end

function CraftingResume:OnWindowClosed()
	self.wndMain:Destroy()
end

local CraftingResumeInst = CraftingResume:new()
CraftingResumeInst:Init()
