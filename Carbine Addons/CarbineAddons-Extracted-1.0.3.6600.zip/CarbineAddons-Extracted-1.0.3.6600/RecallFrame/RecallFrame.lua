-----------------------------------------------------------------------------------------------
-- Client Lua Script for RecallFrame
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------
 
require "Window"
require "GameLib"
require "HousingLib"
require "HousingLib"
require "Unit"
 
-----------------------------------------------------------------------------------------------
-- RecallFrame Module Definition
-----------------------------------------------------------------------------------------------
local RecallFrame = {} 
 
-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
-- e.g. local kiExampleVariableMax = 999
local knBottomPadding = 12 -- MUST MATCH XML
local knTopPadding = 8 -- MUST MATCH XML
 
-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
function RecallFrame:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self 

    -- initialize variables here

    return o
end

function RecallFrame:Init()
    Apollo.RegisterAddon(self)
end
 

-----------------------------------------------------------------------------------------------
-- RecallFrame OnLoad
-----------------------------------------------------------------------------------------------
function RecallFrame:OnLoad()
    -- Register handlers for events, slash commands and timer, etc.
    -- e.g. Apollo.RegisterEventHandler("KeyDown", "OnKeyDown", self)

	Apollo.RegisterEventHandler("ChangeWorld", 					"OnChangeWorld", self)
	Apollo.RegisterEventHandler("HousingNeighborhoodRecieved", 	"OnNeighborhoodsUpdated", self)
	Apollo.RegisterEventHandler("GuildResult", 					"OnGuildResult", self)
	
	Apollo.RegisterEventHandler("CharacterCreated", 			"RefreshDefaultCommand", self)
	Apollo.RegisterEventHandler("PersonaUpdateCharacterStats", 	"RefreshDefaultCommand", self)

	Apollo.RegisterTimerHandler("RefreshRecallTimer", 			"RefreshDefaultCommand", self)
	Apollo.RegisterEventHandler("Tutorial_RequestUIAnchor", 	"OnTutorial_RequestUIAnchor", self)
	
	-- load our forms
    self.wndMain = Apollo.LoadForm("RecallFrame.xml", "RecallFrameForm", "InWorldHudStratum", self)
    self.wndMain:Show(false)
	
	self.wndMenu = Apollo.LoadForm("RecallFrame.xml", "RecallSelectionMenu", "FixedHudStratum", self)
	self.wndMain:FindChild("RecallOptionToggle"):AttachWindow(self.wndMenu)
	self.wndMenu:Show(false)
    
	self:RefreshDefaultCommand()
end

-----------------------------------------------------------------------------------------------
-- RecallFrame Functions
-----------------------------------------------------------------------------------------------
-- Define general functions here

	
function RecallFrame:RefreshDefaultCommand()
	if GameLib.GetDefaultRecallCommand() == nil then
		self:ResetDefaultCommand()
	elseif GameLib.GetDefaultRecallCommand() == GameLib.CodeEnumRecallCommand.BindPoint then
		if GameLib.HasBindPoint() == false then 	
			self:ResetDefaultCommand()
		end
	elseif GameLib.GetDefaultRecallCommand() == GameLib.CodeEnumRecallCommand.House then
		if HousingLib.IsResidenceOwner() == false then 	
			self:ResetDefaultCommand()
		end
	elseif GameLib.GetDefaultRecallCommand() == GameLib.CodeEnumRecallCommand.Warplot then
		local bNeedsReset = true
		-- Determine if this player is in a WarParty
		for key, guildCurr in pairs(GuildLib.GetGuilds()) do
			if guildCurr:GetType() == GuildLib.GuildType_WarParty then
				bNeedsReset = false
				break
			end
		end
		if bNeedsReset then
			self:ResetDefaultCommand()
		end
	end

	if GameLib.GetDefaultRecallCommand() ~= nil then
		if GameLib.GetDefaultRecallCommand() == GameLib.CodeEnumRecallCommand.BindPoint then
			if GameLib.HasBindPoint() then
				self.wndMain:Show(true)
				self.wndMain:FindChild("RecallActionBtn"):SetContentId(GameLib.CodeEnumRecallCommand.BindPoint)
			else
				self.wndMain:Show(false)
			end
		elseif GameLib.GetDefaultRecallCommand() == GameLib.CodeEnumRecallCommand.House then
			self.wndMain:Show(true)
			self.wndMain:FindChild("RecallActionBtn"):SetContentId(GameLib.CodeEnumRecallCommand.House)
		elseif GameLib.GetDefaultRecallCommand() == GameLib.CodeEnumRecallCommand.Warplot then
			self.wndMain:Show(true)
			self.wndMain:FindChild("RecallActionBtn"):SetContentId(GameLib.CodeEnumRecallCommand.Warplot)
		end
	else
		self.wndMain:Show(false)
	end
end

function RecallFrame:ResetDefaultCommand()
	local bHasWarplot = false
	-- Determine if this player is in a WarParty
	for key, guildCurr in pairs(GuildLib.GetGuilds()) do
		if guildCurr:GetType() == GuildLib.GuildType_WarParty then
			bHasWarplot = true
			break
		end
	end

	if GameLib.HasBindPoint() then 	
		GameLib.SetDefaultRecallCommand(GameLib.CodeEnumRecallCommand.BindPoint)
	elseif HousingLib.IsResidenceOwner() == true then
		GameLib.SetDefaultRecallCommand(GameLib.CodeEnumRecallCommand.House)	
	elseif bHasWarplot then
		GameLib.SetDefaultRecallCommand(GameLib.CodeEnumRecallCommand.Warplot)
	else
		GameLib.SetDefaultRecallCommand(GameLib.CodeEnumRecallCommand.BindPoint)
	end
end

function RecallFrame:OnGenerateTooltip(wndControl, wndHandler, tType, arg1, arg2)
	Tooltip.GetSpellTooltipForm(self, wndControl, arg1)
end

-----------------------------------------------------------------------------------------------
-- RecallFrameForm Functions
-----------------------------------------------------------------------------------------------

function RecallFrame:OnRecallOptionToggle(wndHandler, wndControl, eMouseButton)
	if wndControl:IsChecked() then
		self:GenerateBindList()
	else
		self.wndMenu:Show(false)
	end
end

function RecallFrame:GenerateBindList()
	self.wndMenu:FindChild("Content"):DestroyChildren() -- todo: selectively destroy the list
	local nWndLeft, nWndTop, nWndRight, nWndBottom = self.wndMenu:GetAnchorOffsets()
	local nEntryHeight = 0
	local bHasBinds = false
	local bHasWarplot = false
	local guildCurr = nil
	
	-- todo: condense this 
	if GameLib.HasBindPoint() == true then
		--load recall
		local wndBind = Apollo.LoadForm("RecallFrame.xml", "RecallEntry", self.wndMenu:FindChild("Content"), self)
		wndBind:FindChild("RecallActionBtn"):SetContentId(GameLib.CodeEnumRecallCommand.BindPoint)
		wndBind:FindChild("SetDefault"):SetData(GameLib.CodeEnumRecallCommand.BindPoint)
		wndBind:FindChild("BindLabel"):SetText("Transmat Terminal")
		
		if GameLib.GetDefaultRecallCommand() ~= nil and GameLib.GetDefaultRecallCommand() == GameLib.CodeEnumRecallCommand.BindPoint then
			wndBind:FindChild("SetDefault"):Enable(false)
			wndBind:FindChild("SetDefault"):Show(false)
			wndBind:FindChild("DefaultLabel"):Show(true)
		end
		
		bHasBinds = true
		local nLeft, nTop, nRight, nBottom = wndBind:GetAnchorOffsets()
		nEntryHeight = nEntryHeight + (nBottom - nTop)
	end
	
	if HousingLib.IsResidenceOwner() == true then
		local wndSpace = Apollo.LoadForm("RecallFrame.xml", "EmptySpace", self.wndMenu:FindChild("Content"), self)
		local nSpaceLeft, nSpaceTop, nSpaceRight, nSpaceBottom = wndSpace:GetAnchorOffsets()
		nEntryHeight = nEntryHeight + (nSpaceBottom - nSpaceTop)
		
		-- load house
		local wndHouse = Apollo.LoadForm("RecallFrame.xml", "RecallEntry", self.wndMenu:FindChild("Content"), self)
		wndHouse:FindChild("RecallActionBtn"):SetContentId(GameLib.CodeEnumRecallCommand.House)
		wndHouse:FindChild("SetDefault"):SetData(GameLib.CodeEnumRecallCommand.House)
		wndHouse:FindChild("BindLabel"):SetText("Housing")

		if GameLib.GetDefaultRecallCommand() ~= nil and GameLib.GetDefaultRecallCommand() == GameLib.CodeEnumRecallCommand.House then
			wndHouse:FindChild("SetDefault"):Enable(false)
			wndHouse:FindChild("SetDefault"):Show(false)
			wndHouse:FindChild("DefaultLabel"):Show(true)
		end
		
		bHasBinds = true
		local nLeft, nTop, nRight, nBottom = wndHouse:GetAnchorOffsets()
		nEntryHeight = nEntryHeight + (nBottom - nTop)		
	end

	-- Determine if this player is in a WarParty
	for key, guildCurr in pairs(GuildLib.GetGuilds()) do
		if guildCurr:GetType() == GuildLib.GuildType_WarParty then
			bHasWarplot = true
			break
		end	
	end
	
	if bHasWarplot == true then
		local wndSpace = Apollo.LoadForm("RecallFrame.xml", "EmptySpace", self.wndMenu:FindChild("Content"), self)
		local nSpaceLeft, nSpaceTop, nSpaceRight, nSpaceBottom = wndSpace:GetAnchorOffsets()
		nEntryHeight = nEntryHeight + (nSpaceBottom - nSpaceTop)
		
		-- load warplot
		local wndWarplot = Apollo.LoadForm("RecallFrame.xml", "RecallEntry", self.wndMenu:FindChild("Content"), self)
		wndWarplot:FindChild("RecallActionBtn"):SetContentId(GameLib.CodeEnumRecallCommand.Warplot)
		wndWarplot:FindChild("SetDefault"):SetData(GameLib.CodeEnumRecallCommand.Warplot)
		wndWarplot:FindChild("BindLabel"):SetText(Apollo.GetString("CRB_Warplot"))

		if GameLib.GetDefaultRecallCommand() ~= nil and GameLib.GetDefaultRecallCommand() == GameLib.CodeEnumRecallCommand.Warplot then
			wndWarplot:FindChild("SetDefault"):Enable(false)
			wndWarplot:FindChild("SetDefault"):Show(false)
			wndWarplot:FindChild("DefaultLabel"):Show(true)
		end
		
		bHasBinds = true
		local nLeft, nTop, nRight, nBottom = wndWarplot:GetAnchorOffsets()
		nEntryHeight = nEntryHeight + (nBottom - nTop)	
	end
	
	if bHasBinds == true then
		self.wndMenu:FindChild("Content"):SetText("")
		self.wndMenu:SetAnchorOffsets(nWndLeft, nWndBottom -(nEntryHeight + knBottomPadding+knTopPadding), nWndRight, nWndBottom)

		self.wndMenu:FindChild("Content"):ArrangeChildrenVert()
	end

	self.wndMenu:Show(true)
	self.wndMenu:ToFront()	
end		

function RecallFrame:OnSetDefault(wndHandler, wndControl)
	self.wndMain:FindChild("RecallActionBtn"):SetContentId(wndControl:GetData())
	self.wndMenu:Show(false)
	GameLib.SetDefaultRecallCommand(wndControl:GetData())
end

function RecallFrame:OnCloseBtn()
	self.wndMenu:Show(false)
end

function RecallFrame:OnChangeWorld()
	self.bHaveNeighborhoods = false
	self.wndMenu:Show(false)
end

function RecallFrame:OnGuildResult(guildCurr, strName, nRank, eResult) -- guild object, name string, Rank, result enum

	local bRefresh = false

	if eResult == GuildLib.GuildResult_GuildDisbanded then
		bRefresh = true
	elseif eResult == GuildLib.GuildResult_KickedYou then
		bRefresh = true
	elseif eResult == GuildLib.GuildResult_YouQuit then
		bRefresh = true
	elseif eResult == GuildLib.GuildResult_YouJoined then
		bRefresh = true
	elseif eResult == GuildLib.GuildResult_YouCreated then
		bRefresh = true
	end
				
	if bRefresh then
		self.wndMenu:Show(false)
		-- Process on the next frame.
		Apollo.CreateTimer("RefreshRecallTimer", 0.001, false)
	end
end

function RecallFrame:OnTutorial_RequestUIAnchor(eAnchor, idTutorial, strPopupText)
	if eAnchor == GameLib.CodeEnumTutorialAnchor.Recall then
		local tRect = {}
		tRect.l, tRect.t, tRect.r, tRect.b = self.wndMain:GetRect()
		Event_FireGenericEvent("Tutorial_RequestUIAnchorResponse", eAnchor, idTutorial, strPopupText, tRect)
	end
end

-----------------------------------------------------------------------------------------------
-- RecallFrame Instance
-----------------------------------------------------------------------------------------------
local RecallFrameInst = RecallFrame:new()
RecallFrameInst:Init()
