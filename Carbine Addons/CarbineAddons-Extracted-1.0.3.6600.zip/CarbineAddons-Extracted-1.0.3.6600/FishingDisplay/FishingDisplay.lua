-- Client lua script
require "Window"
require "DialogSys"
require "DialogResponse"
require "GameLib"

---------------------------------------------------------------------------------------------------
-- FishingDisplay module definition
---------------------------------------------------------------------------------------------------
local FishingDisplay = {}

---------------------------------------------------------------------------------------------------
-- local constants
---------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------
-- FishingDisplay initialization
---------------------------------------------------------------------------------------------------
function FishingDisplay:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	
	-- initialize our variables
	o.fishingWnd = nil
	o.valueWnd = nil
	o.timeWnd = nil
	o.fishTotal = 0
	o.timeRemaining = 0
	o.updateTime = 0
	
	-- return our object
	return o
end

---------------------------------------------------------------------------------------------------
function FishingDisplay:Init()
	Apollo.RegisterAddon(self)
end

---------------------------------------------------------------------------------------------------
-- FishingDisplay EventHandlers
---------------------------------------------------------------------------------------------------
function FishingDisplay:OnLoad()
	--[[ Deprecating FishingDisplay. No longer used or edited since 2011.
	Apollo.RegisterEventHandler("AlertSpacehandStartFishing", "OnStart", self)
	Apollo.RegisterEventHandler("AlertSpacehandUpdateFishing", "OnUpdate", self)
	Apollo.RegisterEventHandler("AlertSpacehandSucceedFishing", "OnSucceed", self)
	Apollo.RegisterEventHandler("AlertSpacehandFailFishing", "OnFail", self)
	Apollo.RegisterEventHandler("VarChange_FrameCount", "OnFrame", self)
	-- load up our sprites
	Apollo.LoadSprites("UI\\SpriteDocs\\StoryPanelSprites.xml")

	-- load our forms
	self.fishingWnd = Apollo.LoadForm("ui\\FishingDisplay\\FishingDisplay.xml", "FishingDisplay", nil, self)

	self.fishingWnd:Show(false)	
	
	self.valueWnd = self.fishingWnd:FindChild("FishValue")	
	self.timeWnd = self.fishingWnd:FindChild("FishTime")
	]]--	
end

---------------------------------------------------------------------------------------------------
function FishingDisplay:OnStart(timeRemaining)

	self.updateTime = GameLib.GetGameTime()
	
	self.timeRemaining = timeRemaining
	self.fishValue = 0

	self.fishingWnd:Show(true)

	self.valueWnd:SetText(tostring(self.fishValue))
	self.timeWnd:SetText(tostring(self.timeRemaining))
	--Apollo.DPF("text" .. text)
	
	self.fishingWnd:ToFront()
	
end


---------------------------------------------------------------------------------------------------
function FishingDisplay:OnUpdate(fishValue)
 
	self.fishValue = fishValue

	self.valueWnd:SetText(tostring(self.fishValue))

end


---------------------------------------------------------------------------------------------------
function FishingDisplay:OnSucceed()

	self.fishingWnd:Show(false)

end


---------------------------------------------------------------------------------------------------
function FishingDisplay:OnFail()

	self.fishingWnd:Show(false)

end


---------------------------------------------------------------------------------------------------
function FishingDisplay:OnFrame(varName, cnt)

	if self.timeRemaining > 0 then
		local currentTime = GameLib.GetGameTime()
		self.timeRemaining = self.timeRemaining - (currentTime - self.updateTime)
		self.updateTime = currentTime
		if (self.timeRemaining < 0) then self.timeRemaining = 0 end

		self.timeWnd:SetText(tostring(math.ceil(self.timeRemaining)))
	end

end

---------------------------------------------------------------------------------------------------
-- FishingDisplay instance
---------------------------------------------------------------------------------------------------
local FishingDisplayInst = FishingDisplay:new()
FishingDisplayInst:Init()
