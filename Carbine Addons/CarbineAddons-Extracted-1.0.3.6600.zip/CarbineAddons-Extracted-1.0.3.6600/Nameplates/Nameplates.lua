-----------------------------------------------------------------------------------------------
-- Client Lua Script for Nameplates
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "ChallengesLib"
require "Unit"
require "GameLib"
require "Apollo"
require "PathMission"
require "Quest"
require "Episode"
require "math"
require "string"
require "DialogSys"
require "PublicEvent"
require "PublicEventObjective"
require "CommunicatorLib"
require "Tooltip"
require "GroupLib"
require "PlayerPathLib"
require "GuildLib"
require "GuildTypeLib"

local Nameplates = {}

-- TODO Delete strings:
-- Nameplates_GuildDisplay

-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
local karDisposition = 
{
	tTextColors =
	{
		[Unit.CodeEnumDisposition.Hostile] 	= ApolloColor.new("DispositionHostile"),
		[Unit.CodeEnumDisposition.Neutral] 	= ApolloColor.new("DispositionNeutral"),
		[Unit.CodeEnumDisposition.Friendly] = ApolloColor.new("DispositionFriendly"),
	},

	tTargetPrimary =
	{
		[Unit.CodeEnumDisposition.Hostile] 	= "CRB_Nameplates:sprNP_BaseSelectedRed",
		[Unit.CodeEnumDisposition.Neutral] 	= "CRB_Nameplates:sprNP_BaseSelectedYellow",
		[Unit.CodeEnumDisposition.Friendly] = "CRB_Nameplates:sprNP_BaseSelectedGreen",
	},

	tTargetSecondary =
	{
		[Unit.CodeEnumDisposition.Hostile] 	= "sprNp_Target_HostileSecondary",
		[Unit.CodeEnumDisposition.Neutral] 	= "sprNp_Target_NeutralSecondary",
		[Unit.CodeEnumDisposition.Friendly] = "sprNp_Target_FriendlySecondary",
	},

	tHealthBar =
	{
		[Unit.CodeEnumDisposition.Hostile] 	= "CRB_Nameplates:sprNP_RedProg",
		[Unit.CodeEnumDisposition.Neutral] 	= "CRB_Nameplates:sprNP_YellowProg",
		[Unit.CodeEnumDisposition.Friendly] = "CRB_Nameplates:sprNP_GreenProg",
	},

	tHealthTextColor =
	{
		[Unit.CodeEnumDisposition.Hostile] 	= "ffff8585",
		[Unit.CodeEnumDisposition.Neutral] 	= "ffffdb57",
		[Unit.CodeEnumDisposition.Friendly] = "ff9bff80",
	},
}

local ktHealthBarSprites =
{
	"sprNp_Health_FillGreen",
	"sprNp_Health_FillOrange",
	"sprNp_Health_FillRed"
}

local karConColors =  -- differential value, color
{
	{-4, ApolloColor.new("ConTrivial")},
	{-3, ApolloColor.new("ConInferior")},
	{-2, ApolloColor.new("ConMinor")},
	{-1, ApolloColor.new("ConEasy")},
	{0, ApolloColor.new("ConAverage")},
	{1, ApolloColor.new("ConModerate")},
	{2, ApolloColor.new("ConTough")},
	{3, ApolloColor.new("ConHard")},
	{4, ApolloColor.new("ConImpossible")}
}

local kcrScalingHex 	= "ffffbf80"
local kcrScalingCColor 	= CColor.new(1.0, 191/255, 128/255, 0.7)

local karPathSprite =
{
	[PlayerPathLib.PlayerPathType_Soldier] 		= "CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathSol",
	[PlayerPathLib.PlayerPathType_Settler] 		= "CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathSet",
	[PlayerPathLib.PlayerPathType_Scientist] 	= "CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathSci",
	[PlayerPathLib.PlayerPathType_Explorer] 	= "CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathExp",
}

local knCharacterWidth 		= 8 -- the average width of a character in the font used. TODO: Not this.
local knRewardWidth 		= 23 -- the width of a reward icon + padding
local knTextHeight 			= 15 -- text window height
local knNameRewardWidth 	= 400 -- the width of the name/reward container
local knNameRewardHeight 	= 20 -- the width of the name/reward container
local knTargetRange 		= 40000 -- the distance^2 that normal nameplates should draw within (max targeting range)

-- Todo: break these out onto options
local kcrWarPartyTextColor 				= ApolloColor.new("crayBlizzardBlue")
local kcrFlaggedFriendlyTextColor 		= ApolloColor.new("DispositionFriendly")
local kcrDefaultGuildmemberTextColor 	= ApolloColor.new("crayPurple")
local kcrAggressiveEnemyTextColor 		= ApolloColor.new("DispositionNeutral")
local kcrNeutralEnemyTextColor 			= ApolloColor.new("crayDenim")
local kcrDefaultUnflaggedAllyTextColor 	= ApolloColor.new("DispositionFriendly")

local kcrDefaultTaggedColor = ApolloColor.new("crayGray")

-- Control types
-- 0 - custom
-- 1 - single check

local karSavedProperties =
{
	--General nameplate drawing
	["bShowMainObjectiveOnly"] = { default=true, nControlType=1, strControlName="MainShowObjectives" },
	["bShowMainGroupOnly"] = { default=false, nControlType=1, strControlName="MainShowGroup" },
	["bShowMyNameplate"] = { default=false, nControlType=1, strControlName="MainShowMine" },
	["bShowOrganization"] = { default=false, nControlType=1, strControlName="MainShowOrganization" },
	["bShowVendor"] = { default=true, nControlType=1, strControlName="MainShowVendors" },
	["bShowTaxi"] = { default=true, nControlType=1, strControlName="MainShowTaxis" },
	["bShowDispositionHostile"] = { default=true, nControlType=1, strControlName="MainShowDisposition_1" },
	["bShowDispositionNeutral"] = { default=false, nControlType=1, strControlName="MainShowDisposition_2" },
	["bShowDispositionFriendly"] = { default=true, nControlType=1, strControlName="MainShowDisposition_3" },
	["bShowDispositionFriendlyPlayer"] = { default=true, nControlType=1, strControlName="MainShowDisposition_FriendlyPlayer" },
	--Draw distance
	["nMaxRange"] = { default=70.0, nControlType=0 },
	--Individual
	["bShowNameMain"] = { default=true, nControlType=1, strControlName="IndividualShowName" },
	["bShowTitle"] = { default=true, nControlType=1, strControlName="IndividualShowAffiliation" },
	["bShowCertainDeathMain"] = { default=true, nControlType=1, strControlName="IndividualShowCertainDeath" },
	["bShowCastBarMain"] = { default=false, nControlType=1, strControlName="IndividualShowCastBar" },
	["bShowRewardsMain"] = { default=true, nControlType=1, strControlName="IndividualShowRewardIcons" },
	--Reward icons
	["bShowRewardTypeQuest"] = { default=true, nControlType=1, strControlName="ShowRewardTypeQuest" },
	["bShowRewardTypeMission"] = { default=true, nControlType=1, strControlName="ShowRewardTypeMission" },
	["bShowRewardTypeAchievement"] = { default=false, nControlType=1, strControlName="ShowRewardTypeAchievement" },
	["bShowRewardTypeChallenge"] = { default=true, nControlType=1, strControlName="ShowRewardTypeChallenge" },
	["bShowRewardTypeReputation"] = { default=false, nControlType=1, strControlName="ShowRewardTypeReputation" },
	["bShowRewardTypePublicEvent"] = { default=true, nControlType=1, strControlName="ShowRewardTypePublicEvent" },
	["bShowRivals"] = { default=true, nControlType=1, strControlName="ShowRewardTypeFriend" },
	["bShowFriends"] = { default=true, nControlType=1, strControlName="ShowRewardTypeRival" },
	--Info panel
	["bShowHealthMain"] = { default=false, nControlType=0 },
	["bShowHealthMainDamaged"] = { default=true, nControlType=0 },	
	--target components
	["bShowMarkerTarget"] = { default=true, nControlType=0 },
	["bShowNameTarget"] = { default=true, nControlType=0 },
	["bShowRewardsTarget"] = { default=true, nControlType=0 },
	["bShowGuildNameTarget"] = { default=true, nControlType=0 },
	["bShowHealthTarget"] = { default=true, nControlType=0 },
	["bShowRangeTarget"] = { default=false, nControlType=0 },
	["bShowCastBarTarget"] = { default=true, nControlType=0 },
	--Non-targeted nameplates in combat
	["bHideInCombat"] = { default=false, nControlType=0 }
}

function Nameplates:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function Nameplates:Init()
    Apollo.RegisterAddon(self, true)
end

-----------------------------------------------------------------------------------------------
-- Nameplates OnLoad
-----------------------------------------------------------------------------------------------

function Nameplates:OnLoad()
    -- Register handlers for events, slash commands and timer, etc.
    -- e.g. Apollo.RegisterEventHandler("KeyDown", "OnKeyDown", self)
	Apollo.RegisterSlashCommand("Nameplates", 					"OnNameplatesOn", self)
	Apollo.RegisterSlashCommand("nameplates", 					"OnNameplatesOn", self)
	Apollo.RegisterSlashCommand("Nameplates_OpenMenu", 			"OnNameplatesOn", self)

	Apollo.RegisterEventHandler("UnitCreated", 					"OnUnitCreated", self)
	Apollo.RegisterEventHandler("UnitDestroyed", 				"OnUnitDestroyed", self)
	Apollo.RegisterEventHandler("UnitTextBubbleCreate", 		"OnUnitTextBubbleToggled", self)
	Apollo.RegisterEventHandler("UnitTextBubblesDestroyed", 	"OnUnitTextBubbleToggled", self)
	Apollo.RegisterEventHandler("TargetUnitChanged", 			"OnTargetUnitChanged", self)
	Apollo.RegisterEventHandler("UnitEnteredCombat", 			"OnEnteredCombat", self)
	Apollo.RegisterEventHandler("VarChange_FrameCount", 		"OnFrame", self)
	Apollo.RegisterEventHandler("UnitNameChanged", 				"OnUnitNameChanged", self)
	Apollo.RegisterEventHandler("KeyBindingKeyChanged", 		"OnKeyBindingUpdated", self)
	Apollo.RegisterEventHandler("UnitPvpFlagsChanged", 			"OnUnitPvpFlagsChanged", self)
	Apollo.RegisterEventHandler("UnitTitleChanged", 			"OnUnitTitleChanged", self)
	Apollo.RegisterEventHandler("PlayerTitleChange", 			"OnPlayerTitleChanged", self)
	Apollo.RegisterEventHandler("UnitGuildNameplateChanged", 	"OnUnitGuildNameplateChanged",self)
	Apollo.RegisterEventHandler("ApplyCCState", 				"OnApplyCCState", self)
	Apollo.RegisterEventHandler("RemoveCCState", 				"OnRemoveCCState", self)
	Apollo.RegisterEventHandler("UnitLevelChanged", 			"OnUnitLevelChanged", self)

	Apollo.RegisterEventHandler("UnitMemberOfGuildChange", 		"OnUnitMemberOfGuildChange", self)
	Apollo.RegisterEventHandler("GuildChange", 					"OnGuildChange", self)  -- notification that a guild was added / removed.
	Apollo.RegisterEventHandler("ChangeWorld", 					"OptionsChanged", self)

	Apollo.RegisterEventHandler("CharacterCreated", 			"OptionsChanged", self)

	-- These events update the reward icons/quest framing
	Apollo.RegisterEventHandler("QuestInit", 					"OnQuestInit", self)
	Apollo.RegisterEventHandler("QuestStateChanged", 			"OnQuestStateChanged", self)
	Apollo.RegisterEventHandler("UnitActivationTypeChanged", 	"OnUnitActivationTypeChanged", self)
	Apollo.RegisterEventHandler("QuestObjectiveUpdated", 		"OnQuestObjectiveUpdated", self)
	Apollo.RegisterEventHandler("PublicEventStart", 			"OnPublicEventStart", self)
	Apollo.RegisterEventHandler("PublicEventObjectiveUpdate", 	"OnPublicEventObjectiveUpdate", self)
	Apollo.RegisterEventHandler("PublicEventEnd", 				"OnPublicEventEnd", self)
	Apollo.RegisterEventHandler("PublicEventLeave",				"OnPublicEventEnd", self)
	Apollo.RegisterEventHandler("ChallengeUnlocked", 			"OnChallengeUnlocked", self)
	Apollo.RegisterEventHandler("ChallengeFailArea", 			"OnChallengeFailArea", self)
    Apollo.RegisterEventHandler("ChallengeFailTime", 			"OnChallengeFailTime", self)
	Apollo.RegisterEventHandler("ChallengeActivate",			"OnChallengeActivate", self)
	Apollo.RegisterEventHandler("ChallengeCompleted", 			"OnChallengeCompleted", self)
	Apollo.RegisterEventHandler("ChallengeAbandon", 			"OnChallengeCompleted", self)
	Apollo.RegisterEventHandler("PlayerPathMissionUnlocked", 	"OnPlayerPathMissionChange", self)
	Apollo.RegisterEventHandler("PlayerPathMissionUpdate", 		"OnPlayerPathMissionChange", self)
	Apollo.RegisterEventHandler("PlayerPathMissionComplete", 	"OnPlayerPathMissionChange", self)
	Apollo.RegisterEventHandler("PlayerPathMissionDeactivate", 	"OnPlayerPathMissionChange", self)
	Apollo.RegisterEventHandler("PlayerPathMissionActivate", 	"OnPlayerPathMissionChange", self)

	Apollo.RegisterTimerHandler("InitialParseTimer", 			"OptionsChanged", self)

	Apollo.CreateTimer("InitialParseTimer", 1.0, false)
	Apollo.StopTimer("InitialParseTimer")

	-------form setup starts below----------
	self.xmlDoc = XmlDoc.CreateFromFile("Nameplates.xml")

    self.wndMain 				= Apollo.LoadForm(self.xmlDoc, "NameplatesForm", nil, self)
	self.wndOptionsMain 		= Apollo.LoadForm(self.xmlDoc, "StandardModule", self.wndMain:FindChild("ContentMain"), self)
	self.wndOptionsTargeted 	= Apollo.LoadForm(self.xmlDoc, "TargetedModule", self.wndMain:FindChild("ContentTarget"), self)
	self.wndMain:Show(false)
	self.wndMain:FindChild("ContentMain"):Show(true)
	self.wndMain:FindChild("ContentTarget"):Show(false)
	self.wndMain:FindChild("ContentToggleContainer:NormalViewCheck"):SetCheck(true)

	self.unitPlayerDisposComparisonTEMP 	= nil
	self.bInitialLoadAllClear 				= false -- delays drawing until everything's come in
	self.arDisplayedNameplates 				= {}
	self.arUnit2Nameplate 					= {}
	self.arFreeWindows 						= {}
	self.arHiddenUnits						= {}

	self.bPlayerInCombat 					= false
	self.bRewardInfoDirty 					= false

	for property,tData in pairs(karSavedProperties) do
		self[property] = tData.default
		if tData.nControlType == 1 then
			local wndControl = self.wndMain:FindChild(tData.strControlName)
			if wndControl ~= nil then
				wndControl:SetData(property)
			end
		end
	end

	self:RefreshNameplatesConfigure()
	
	self.bBlinded = false

	self.strPathActionKeybind = GameLib.GetKeyBinding("PathAction")
	self.bPathActionUsesIcon = false
	if self.strPathActionKeybind == Apollo.GetString("HUDAlert_Unbound") or #self.strPathActionKeybind > 1 then -- Don't show interact
		self.bPathActionUsesIcon = true
	end

	self.strQuestActionKeybind = GameLib.GetKeyBinding("CastObjectiveAbility")
	self.bQuestActionUsesIcon = false
	if self.strQuestActionKeybind == Apollo.GetString("HUDAlert_Unbound") or #self.strQuestActionKeybind > 1 then -- Don't show interact
		self.bQuestActionUsesIcon = true
	end

	--Apollo.CreateTimer("InitialParseTimer", 10.0, false) -- gives everything a chance to load, then updates nameplates
	Apollo.CreateTimer("SecondaryParseTimer", 60.0, true) -- failsafe load; updates if things weren't. runs every minute to keep things clean

	local wndTemp = Apollo.LoadForm(self.xmlDoc, "NameplateNew", nil, self)
	self.nFrameLeft, self.nFrameTop, self.nFrameRight, self.nFrameBottom = wndTemp:FindChild("Container:Health:HealthBars:MaxHealth"):GetAnchorOffsets()
	self.nHealthWidth = self.nFrameRight - self.nFrameLeft
	wndTemp:Destroy()

	if GameLib.GetPlayerUnit() then
		self:OptionsChanged()
	end
end

function Nameplates:OnSave(eType)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Character then
		return
	end

	local tSave = {}
	for property,tData in pairs(karSavedProperties) do
		tSave[property] = self[property]
	end

	return tSave
end

function Nameplates:OnRestore(eType, t)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Character then
		return
	end

	for property,tData in pairs(karSavedProperties) do
		if t[property] ~= nil then
			self[property] = t[property]
		end
	end

	self:OptionsChanged()
end

function Nameplates:OnConfigure()
	self:OnNameplatesOn()
end

-----------------------------------------------------------------------------------------------
-- Nameplates Functions
-----------------------------------------------------------------------------------------------
function Nameplates:CreateNameplateObject(unit)

	local tNameplate =
	{
		unitOwner 		= unit,
		idUnit 			= unit:GetId(),
		bOnScreen 		= false,
		bOccluded 		= false,
		bSpeechBubble 	= false,
		bIsTarget 		= false,
		bIsCluster 		= false,
		bIsCasting 		= false,
		nVulnerableTime = 0
	}

	self.arUnit2Nameplate[tNameplate.idUnit] = tNameplate
	self:ParseRewards(tNameplate)

	return tNameplate
end

function Nameplates:CreateNameplateWindow(tNameplate)
	if tNameplate.wndNameplate ~= nil then
		return
	end

	if tNameplate.unitOwner == nil then
		return
	end

	tNameplate.wndNameplate = table.remove(self.arFreeWindows)
	if tNameplate.wndNameplate == nil then
		tNameplate.wndNameplate = Apollo.LoadForm(self.xmlDoc, "NameplateNew", "InWorldHudStratum", self)
	end

	tNameplate.wndNameplate:SetData(tNameplate.unitOwner)
	tNameplate.wndNameplate:FindChild("Name"):SetData(tNameplate.unitOwner)
	tNameplate.wndNameplate:SetUnit(tNameplate.unitOwner, 1)

	tNameplate.bOnScreen = tNameplate.wndNameplate:IsOnScreen()
	tNameplate.bOccluded = tNameplate.wndNameplate:IsOccluded()
	tNameplate.wndNameplate:Show(false,true)

	self.arDisplayedNameplates[tNameplate.wndNameplate:GetId()] = tNameplate

	self:SetNormalNameplate(tNameplate)

	return tNameplate.wndNameplate
end

function Nameplates:OnUnitCreated(unitNew) -- build main options here
	if not unitNew then
		return
	end

	local idUnit = unitNew:GetId()
	-- don't create unit if we already know about it
	local tNameplate = self.arUnit2Nameplate[idUnit]
	if tNameplate ~= nil then
		return
	end

	tNameplate = self:CreateNameplateObject(unitNew)
	tNameplate.bBrandNew = true
	if not self:HelperVerifyVisibilityOptions(tNameplate) then
		self.arUnit2Nameplate[idUnit] = nil
		self.arHiddenUnits[idUnit] = unitNew
	else
		self.arHiddenUnits[idUnit] = nil
	end
end

function Nameplates:UnattachNameplateWindow(tNameplate)
	if tNameplate.wndNameplate ~= nil then
		local idWnd = tNameplate.wndNameplate:GetId()
		tNameplate.wndNameplate:SetNowhere()
		tNameplate.wndNameplate:Show(false)
		table.insert(self.arFreeWindows, tNameplate.wndNameplate)
		tNameplate.wndNameplate = nil
		self.arDisplayedNameplates[idWnd] = nil
	end
end

function Nameplates:OnUnitDestroyed(unitDead)
	local idUnit = unitDead:GetId()

	local tNameplate = self.arUnit2Nameplate[idUnit]
	if tNameplate == nil then
		return
	end

	self:UnattachNameplateWindow(tNameplate)
	self.arUnit2Nameplate[idUnit] = nil
	self.arHiddenUnits[idUnit] = nil

end

function Nameplates:OnUnitTextBubbleToggled(tUnitArg, strText)
	local idUnit = tUnitArg:GetId()

	if not self.arUnit2Nameplate or not self.arUnit2Nameplate[idUnit] then
		return
	end

	if strText and strText ~= "" then
		self.arUnit2Nameplate[idUnit].bSpeechBubble = true
	else
		self.arUnit2Nameplate[idUnit].bSpeechBubble = false
	end
end

function Nameplates:OnWorldLocationOnScreen(wndHandler, wndControl, bOnScreen)
	if self.arDisplayedNameplates[wndHandler:GetId()] ~= nil then
		self.arDisplayedNameplates[wndHandler:GetId()].bOnScreen = bOnScreen
	end
end

function Nameplates:OnUnitOcclusionChanged(wndHandler, wndControl, bOccluded)
	if self.arDisplayedNameplates[wndHandler:GetId()] ~= nil then
		self.arDisplayedNameplates[wndHandler:GetId()].bOccluded = bOccluded
	end
end

function Nameplates:OnEnteredCombat(unitChecked, bInCombat)
	if unitChecked == GameLib.GetPlayerUnit() then
		self.bPlayerInCombat = bInCombat
	end
end

function Nameplates:OnApplyCCState(nState, unitChecking)
	self.bBlinded = (unitChecking == GameLib.GetPlayerUnit() and nState == Unit.CodeEnumCCState.Blind)
end

function Nameplates:OnRemoveCCState(nState, unitChecking)
	if unitChecking == GameLib.GetPlayerUnit() and nState == Unit.CodeEnumCCState.Blind then
		self.bBlinded = false
	end
end

function Nameplates:OnUnitLevelChanged(unitUpdating)
	local tNameplate = self.arUnit2Nameplate[unitUpdating:GetId()]
	if tNameplate == nil then
		return
	end
	local bHideMine = unitUpdating:IsThePlayer() and not self.bShowMyNameplate
	if bHideMine or unitUpdating:IsDead() or not unitUpdating:ShouldShowNamePlate() then
		self:UnattachNameplateWindow(tNameplate)
	elseif tNameplate.bIsTarget == true or tNameplate.bIsCluster == true then
		self:SetTargetedNameplate(tNameplate)
	else
		self:SetNormalNameplate(tNameplate)
	end
end

function Nameplates:OnNameplateNameClick(wndHandler, wndCtrl, eMouseButton)
	local unitOwner = wndCtrl:GetData()

	if unitOwner ~= nil and GameLib.GetTargetUnit() ~= unitOwner and eMouseButton == GameLib.CodeEnumInputMouse.Left then
		GameLib.SetTargetUnit(unitOwner)
		return true
	end
end

function Nameplates:OnTargetUnitChanged(unitOwner) -- build targeted options here; we get this event when a creature attacks, too
	local tNameplate = nil
	if unitOwner ~= nil then
		tNameplate = self.arUnit2Nameplate[unitOwner:GetId()]
	end
	if tNameplate ~= nil then
		if tNameplate.bIsTarget then
			return
		end
	elseif unitOwner ~= nil then
		self:CreateNameplateObject(unitOwner)
	end

	for idx, tNameplate in pairs(self.arUnit2Nameplate) do
		if tNameplate.bIsTarget == true or tNameplate.bIsCluster == true then
			tNameplate.bIsTarget = false
			tNameplate.bIsCluster = false
			self:ParseRewards(tNameplate)
			local unitCurr = tNameplate.unitOwner
			local bHideMine = unitCurr:IsThePlayer() and not self.bShowMyNameplate

			if bHideMine or unitCurr:IsDead() or not unitCurr:ShouldShowNamePlate() then
				self:UnattachNameplateWindow(tNameplate)
			else
				self:SetNormalNameplate(tNameplate)
			end
		end
	end

	if unitOwner == nil then
		return
	end

	local tCluster = unitOwner:GetClusterUnits()
	local tAdjustedNameplates = {} -- built a temp table for the nameplates that need adjustment

	for idx, tNameplate in pairs(self.arUnit2Nameplate) do  -- identify targets and cluster members
		local unitCurr = tNameplate.unitOwner
		if unitOwner == unitCurr then
			tNameplate.bIsTarget = true -- set target
			table.insert(tAdjustedNameplates, tNameplate) -- add that unit's nameplate
		end

		if tCluster then
			for idx = 1, #tCluster do
				if tCluster[idx] == unitCurr and not tNameplate.bIsTarget then
					tNameplate.bIsCluster = true -- set cluster
					table.insert(tAdjustedNameplates, tNameplate) -- add that nameplate
				end
			end
		end
	end

	for idx = 1, #tAdjustedNameplates do -- format the nameplates that need adjusting
		local unitCurr = tAdjustedNameplates[idx].unitOwner
		self:ParseRewards(tAdjustedNameplates[idx])
		local bHideMine = unitCurr:IsThePlayer() and not self.bShowMyNameplate
		if bHideMine or unitCurr:IsDead() or not unitCurr:ShouldShowNamePlate() then
			if tAdjustedNameplates[idx].bIsTarget then
				self:UnattachNameplateWindow(tAdjustedNameplates[idx])
				tAdjustedNameplates[idx].bIsTarget = true -- reset (clearing the nameplate makes this false)
			else -- has to be the cluster to get on the table
				self:UnattachNameplateWindow(tAdjustedNameplates[idx])
				tAdjustedNameplates[idx].bIsCluster = true -- reset (clearing the nameplate makes this false)
			end
		else
			if tAdjustedNameplates[idx].wndNameplate == nil then
				self:CreateNameplateWindow(tAdjustedNameplates[idx])
			end
			self:SetTargetedNameplate(tAdjustedNameplates[idx])
		end
	end

	tAdjustedNameplates = nil
end

-- TODO: Refactor: The OnFrame can just deal with repositioning and health.
-- TODO: Refactor: Calculating visibility and etc. can be event driven either from code or from the options Window.
function Nameplates:OnFrame() -- on frame, toggle visibility, set health, set disposition, etc
	if Apollo.GetConsoleVariable("unit.nameplateShowCPPNameplates") then
		return
	end

	if self.bRewardInfoDirty then
		self:UpdateRewardInfo()
	end

	if not self.bInitialLoadAllClear then
		for idx, tNameplate in pairs(self.arDisplayedNameplates) do
			if tNameplate.wndNameplate ~= nil then
				tNameplate.wndNameplate:Show(false)
			end
		end

		return
	end

	for idx, tNameplate in pairs(self.arUnit2Nameplate) do
		self:DrawNameplate(tNameplate)
	end
end

function Nameplates:DrawNameplate(tNameplate)
	local bShowNameplate = self:HelperVerifyVisibilityOptions(tNameplate) and self:CheckDrawDistance(tNameplate)

	if not bShowNameplate then
		self:UnattachNameplateWindow(tNameplate)
		return false
	end

	self:CreateNameplateWindow(tNameplate)

	local unitOwner = tNameplate.unitOwner

	if unitOwner == nil then
		return false
	end

	bShowNameplate = bShowNameplate
						and not self.bBlinded
						and tNameplate.bOnScreen
						and (not tNameplate.bOccluded or unitOwner:IsMounted())
						and not tNameplate.bSpeechBubble

	if not bShowNameplate then
		if tNameplate.wndNameplate ~= nil then
			tNameplate.wndNameplate:Show(false)
		end
		return false
	end

	if unitOwner:IsMounted() and tNameplate.wndNameplate:GetUnit() == unitOwner then
		tNameplate.wndNameplate:SetUnit(tNameplate.unitOwner:GetUnitMount(), 1)
	elseif not unitOwner:IsMounted() and tNameplate.wndNameplate:GetUnit() ~= unitOwner then
		tNameplate.wndNameplate:SetUnit(unitOwner, 1) -- Good catch by Garet Jax
	end

	if not self.unitPlayerDisposComparisonTEMP then
		self.unitPlayerDisposComparisonTEMP = GameLib.GetPlayerUnit()
	end

	local bWndMain = not tNameplate.bIsTarget and not tNameplate.bIsCluster
	local eDisposition = unitOwner:GetDispositionTo(self.unitPlayerDisposComparisonTEMP)
	local bHiddenUnit = not unitOwner:ShouldShowNamePlate() or unitOwner:GetHealth() == nil or unitOwner:GetType() == "Collectible"
		or unitOwner:GetType() == "PinataLoot" or unitOwner:IsDead()

	self:OnUnitPvpFlagsChanged(unitOwner, tNameplate)

	local wndHealth = tNameplate.wndNameplate:FindChild("Health")

	if bHiddenUnit then
		wndHealth:Show(false)
	elseif bWndMain and self.bShowHealthMainDamaged then -- check for health on non-targets, only want to see the nameplates of damaged creatures
		local nHealthCurrent = unitOwner:GetHealth()
		local nHealthMax = unitOwner:GetMaxHealth()

		if wndHealth:IsShown() and nHealthCurrent == nHealthMax or bHiddenUnit then
			wndHealth:Show(false)
		elseif not wndHealth:IsShown() and nHealthCurrent ~= nHealthMax and not bHiddenUnit then
			wndHealth:Show(true)
		end
	end

	local nCon = self:HelperCalculateConValue(unitOwner)
	if wndHealth:IsShown() then
		self:HelperDoHealthShieldBar(wndHealth, unitOwner, eDisposition)
		if tNameplate.wndNameplate:FindChild("TargetScalingMark"):IsShown() then
			tNameplate.wndNameplate:FindChild("Level"):SetTextColor(kcrScalingCColor)
		elseif unitOwner:GetLevel() == nil then
			tNameplate.wndNameplate:FindChild("Level"):SetTextColor(karConColors[1][2])
		else
			tNameplate.wndNameplate:FindChild("Level"):SetTextColor(karConColors[nCon][2])
		end
	end

	tNameplate.wndNameplate:FindChild("CertainDeath"):Show(self.bShowCertainDeathMain and nCon == #karConColors and eDisposition ~= Unit.CodeEnumDisposition.Friendly
		and unitOwner:GetHealth() and unitOwner:ShouldShowNamePlate() and not unitOwner:IsDead())

	-- Vulnerable; shown/hidden once but updated on frame
	local bIsVulnerable = false
	local wndVulnerable = tNameplate.wndNameplate:FindChild("Vulnerable")
	if (bWndMain and self.bShowHealthMain or self.bShowHealthMainDamaged) or (not bWndMain and self.bShowHealthTarget) then
		local nVulnerable = unitOwner:GetCCStateTimeRemaining(Unit.CodeEnumCCState.Vulnerability)
		if nVulnerable == nil then
			-- Do nothing
		elseif nVulnerable == 0 and nVulnerable ~= tNameplate.nVulnerableTime then
			tNameplate.nVulnerableTime = 0 -- casting done, set back to 0
			wndVulnerable:Show(false)
		elseif nVulnerable ~= 0 and nVulnerable > tNameplate.nVulnerableTime then
			tNameplate.nVulnerableTime = nVulnerable
			wndVulnerable:Show(true)
			bIsVulnerable = true
		elseif nVulnerable ~= 0 and nVulnerable < tNameplate.nVulnerableTime then
			wndVulnerable:FindChild("VulnFill"):SetMax(tNameplate.nVulnerableTime)
			wndVulnerable:FindChild("VulnFill"):SetProgress(nVulnerable)
			bIsVulnerable = true
		end
	end

	-- Casting; has some onDraw parameters we need to check
	if (bWndMain and self.bShowCastBarMain) or (not bWndMain and self.bShowCastBarTarget) then
		local bIsCasting = unitOwner:ShouldShowCastBar() and not bHiddenUnit
		if bIsCasting ~= tNameplate.bIsCasting then
			tNameplate.bIsCasting = bIsCasting
			tNameplate.wndNameplate:FindChild("CastBar"):Show(bIsCasting)
		end
	end

	local wndCastBar = tNameplate.wndNameplate:FindChild("CastBar")
	if wndCastBar:IsShown() then
		wndCastBar:FindChild("Label"):SetText(unitOwner:GetCastName())
		wndCastBar:FindChild("CastFill"):SetMax(unitOwner:GetCastDuration())
		wndCastBar:FindChild("CastFill"):SetProgress(unitOwner:GetCastElapsed())
	end

	-- Targeted set -------------------------------------------------------------
	local bShowTargetMarkerArrow = tNameplate.bIsTarget and self.bShowMarkerTarget and not wndHealth:IsVisible()
	tNameplate.wndNameplate:FindChild("TargetMarkerArrow"):SetSprite(karDisposition.tTargetSecondary[eDisposition])
	tNameplate.wndNameplate:FindChild("TargetMarker"):SetSprite(karDisposition.tTargetPrimary[eDisposition])

	if bIsVulnerable then -- Override if vulnerable
		tNameplate.wndNameplate:FindChild("TargetMarker"):SetSprite("sprNP_BaseSelectedPurple")
	end

	tNameplate.wndNameplate:FindChild("TargetMarker"):Show(tNameplate.bIsTarget and self.bShowMarkerTarget and wndHealth:IsVisible())
	tNameplate.wndNameplate:FindChild("TargetMarkerArrow"):Show(bShowTargetMarkerArrow, not bShowTargetMarkerArrow)

	if tNameplate.bIsTarget and unitOwner:IsDead() then
		tNameplate.wndNameplate:FindChild("TargetMarker"):Show(false)
		tNameplate.wndNameplate:FindChild("TargetMarkerArrow"):Show(false)
	end

	if tNameplate.bIsCluster and unitOwner:IsDead() then
		tNameplate.wndNameplate:FindChild("TargetMarker"):Show(false)
		tNameplate.wndNameplate:FindChild("TargetMarkerArrow"):Show(false)
	end

	tNameplate.wndNameplate:Show(unitOwner:ShouldShowNamePlate())

	return bShowNameplate
end

function Nameplates:HelperVerifyVisibilityOptions(tNameplate)
	if not self.unitPlayerDisposComparisonTEMP then
		self.unitPlayerDisposComparisonTEMP = GameLib.GetPlayerUnit()
	end

	local bShowNameplate = false
	local unitOwner = tNameplate.unitOwner
	local bWndMain = not tNameplate.bIsTarget and not tNameplate.bIsCluster
	local eDisposition = unitOwner:GetDispositionTo(self.unitPlayerDisposComparisonTEMP)

	local bHiddenUnit = not unitOwner:ShouldShowNamePlate() or unitOwner:GetHealth() == nil or unitOwner:GetType() == "Collectible" or unitOwner:GetType() == "PinataLoot" or unitOwner:IsDead()
	if bHiddenUnit and not tNameplate.bIsTarget then
		tNameplate.bBrandNew = false
		return false
	end

	if self.bShowMainObjectiveOnly and tNameplate.bIsObjective then
		bShowNameplate = true
	end

	if self.bShowMainGroupOnly and unitOwner:IsInYourGroup() then
		bShowNameplate = true
	end

	if self.bShowDispositionHostile and eDisposition == Unit.CodeEnumDisposition.Hostile then
		bShowNameplate = true
	end
	
	if self.bShowDispositionNeutral and eDisposition == Unit.CodeEnumDisposition.Neutral then
		bShowNameplate = true
	end
	
	if self.bShowDispositionFriendly and eDisposition == Unit.CodeEnumDisposition.Friendly then
		bShowNameplate = true
	end
	
	if self.bShowDispositionFriendlyPlayer and eDisposition == Unit.CodeEnumDisposition.Friendly and unitOwner:GetType() == "Player" then
		bShowNameplate = true
	end

	local tActivation = unitOwner:GetActivationState()
	
	if self.bShowVendor and tActivation.Vendor ~= nil then
		bShowNameplate = true
	end
	
	if self.bShowTaxi and (tActivation.FlightPathSettler ~= nil or tActivation.FlightPath ~= nil or tActivation.FlightPathNew) then
		bShowNameplate = true
	end
	
	if self.bShowOrganization and tNameplate.bIsGuildMember then
		bShowNameplate = true
	end

	if self.bShowMainObjectiveOnly then
		-- QuestGivers too
		if tActivation.QuestReward ~= nil then
			bShowNameplate = true
		end
		
		if tActivation.QuestNew ~= nil or tActivation.QuestNewMain ~= nil then
			bShowNameplate = true
		end
		
		if tActivation.QuestReceiving ~= nil then
			bShowNameplate = true
		end
		
		if tActivation.TalkTo ~= nil then
			bShowNameplate = true
		end
	end

	if bShowNameplate then
		bShowNameplate = not (self.bPlayerInCombat and self.bHideInCombat)
	end

	if bShowNameplate then
		bShowNameplate = not self.bBlinded
	end
	
	if unitOwner:IsThePlayer() then
		if self.bShowMyNameplate and not unitOwner:IsDead() then
			bShowNameplate = true
		else
			bShowNameplate = false
		end
	end

	tNameplate.bBrandNew = false
	return bShowNameplate
end

function Nameplates:OnUnitPvpFlagsChanged(unitUpdated, tNameplate)
	if tNameplate == nil then
		tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
		if tNameplate == nil then
			return
		end
	end

	if not self.unitPlayerDisposComparisonTEMP then
		self.unitPlayerDisposComparisonTEMP = GameLib.GetPlayerUnit()
	end

	unitController = unitUpdated:GetUnitOwner() or unitUpdated

	local eDisposition = unitController:GetDispositionTo(self.unitPlayerDisposComparisonTEMP)
	local crColorToUse = karDisposition.tTextColors[eDisposition]

	local strUnitType = unitUpdated:GetType()

	if strUnitType == "Player" or strUnitType == "Pet" or strUnitType == "Esper Pet" then
		if eDisposition == Unit.CodeEnumDisposition.Friendly or unitUpdated:IsThePlayer() then
			if unitController:IsPvpFlagged() then
				crColorToUse = kcrFlaggedFriendlyTextColor
			elseif unitController:IsInYourGroup() then
				crColorToUse = kcrWarPartyTextColor
			else
				crColorToUse = kcrDefaultUnflaggedAllyTextColor
				if tNameplate.bIsGuildMember then
					crColorToUse = kcrDefaultGuildmemberTextColor
				end
			end
		else
			local bIsUnitFlagged = unitController:IsPvpFlagged()
			local bAmIFlagged = GameLib.IsPvpFlagged()
			if not bAmIFlagged and not bIsUnitFlagged then
				crColorToUse = kcrNeutralEnemyTextColor
			elseif (bAmIFlagged and not bIsUnitFlagged) or (not bAmIFlagged and bIsUnitFlagged) then
				crColorToUse = kcrAggressiveEnemyTextColor
			end
		end
	end

	if unitUpdated:GetType() ~= "Player" and unitUpdated:IsTagged() and not unitUpdated:IsTaggedByMe() and not unitUpdated:IsSoftKill() then
		crColorToUse = kcrDefaultTaggedColor
	end

	if tNameplate.wndNameplate == nil then
		return
	end

	tNameplate.wndNameplate:FindChild("Name"):SetTextColor(crColorToUse)
	tNameplate.wndNameplate:FindChild("Guild"):SetTextColor(crColorToUse)
end

function Nameplates:OnUnitNameChanged(unitUpdated, strNewName)
	local tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
	if tNameplate and tNameplate.wndNameplate then
		self:RedrawName(tNameplate.wndNameplate, strNewName)
	end
end

function Nameplates:RedrawName(wndNameplate, strNewName)
	local wndNameRewardContainer = wndNameplate:FindChild("NameRewardContainer")
	local wndName = wndNameplate:FindChild("Name")
	local nNameWidth = Apollo.GetTextWidth("CRB_InterfaceMedium", strNewName)
	local nHalfNameWidth = math.ceil(nNameWidth / 2)
	
	-- Rewards also depend on name
	local nLeft, nTop, nRight, nBottom = wndNameRewardContainer:GetAnchorOffsets()
	wndNameRewardContainer:SetAnchorOffsets(nHalfNameWidth, nTop, nHalfNameWidth + wndNameRewardContainer:ArrangeChildrenHorz(0), nBottom)
	
	-- Resize Name
	nLeft, nTop, nRight, nBottom = wndName:GetAnchorOffsets()
	wndName:SetAnchorOffsets(-nHalfNameWidth, nTop, nHalfNameWidth, nBottom)
	wndName:SetText(strNewName)
end

function Nameplates:RedrawGuild(wndNameplate, strNewGuild)
	local wndGuild = wndNameplate:FindChild("Guild")
	local nGuildWidth = Apollo.GetTextWidth("CRB_InterfaceMedium", strNewGuild)
	local nHalfGuildWidth = math.ceil(nGuildWidth / 2)
	
	local nLeft, nTop, nRight, nBottom = wndGuild:GetAnchorOffsets()
	wndGuild:SetAnchorOffsets(-nHalfGuildWidth, nTop, nHalfGuildWidth, nBottom)
	wndGuild:SetText(strNewGuild)
end

function Nameplates:HelperAdjustNameAndGuildStack(wndNameplate)
	local wndName = wndNameplate:FindChild("Name")
	local wndGuild = wndNameplate:FindChild("Guild")
	
	local nGuildLeft, nGuildTop, nGuildRight, nGuildBottom = wndGuild:GetAnchorOffsets()
	local nNameLeft, nNameTop, nNameRight, nNameBottom = wndName:GetAnchorOffsets()
	
	local strGuildText = wndGuild:GetText()
	
	if wndGuild:IsShown() and strGuildText ~= nil and strGuildText ~= "" then
		wndName:SetAnchorOffsets(nNameLeft, nGuildTop-wndGuild:GetHeight(), nNameRight, nGuildTop)
	else
		wndName:SetAnchorOffsets(nNameLeft, nGuildTop, nNameRight, nGuildBottom)
	end
end

function Nameplates:OnUnitTitleChanged(unitUpdated)
	local tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
	if tNameplate == nil or tNameplate.wndNameplate == nil then
		return
	end
	local bHideMine = unitUpdated:IsThePlayer() and not self.bShowMyNameplate
	if bHideMine or unitUpdated:IsDead() or not unitUpdated:ShouldShowNamePlate() then
		self:UnattachNameplateWindow(tNameplate)
	elseif tNameplate.bIsTarget == true or tNameplate.bIsCluster == true then
		self:SetTargetedNameplate(tNameplate)
	else
		self:SetNormalNameplate(tNameplate)
	end
end

function Nameplates:OnPlayerTitleChanged()
	local unitUpdated = GameLib.GetPlayerUnit()
	local tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
	if tNameplate == nil or tNameplate.wndNameplate == nil then
		return
	end
	local bHideMine = unitUpdated:IsThePlayer() and not self.bShowMyNameplate
	if bHideMine or unitUpdated:IsDead() or not unitUpdated:ShouldShowNamePlate() then
		self:UnattachNameplateWindow(tNameplate)
	elseif tNameplate.bIsTarget == true or tNameplate.bIsCluster == true then
		self:SetTargetedNameplate(tNameplate)
	else
		self:SetNormalNameplate(tNameplate)
	end
end

function Nameplates:OnUnitGuildNameplateChanged(unitUpdated)
	local tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
	if tNameplate == nil or tNameplate.wndNameplate == nil then
		return
	end
	local bHideMine = unitUpdated:IsThePlayer() and not self.bShowMyNameplate
	if bHideMine or unitUpdated:IsDead() or not unitUpdated:ShouldShowNamePlate() then
		self:UnattachNameplateWindow(tNameplate)
	elseif tNameplate.bIsTarget == true or tNameplate.bIsCluster == true then
		self:SetTargetedNameplate(tNameplate)
	else
		self:SetNormalNameplate(tNameplate)
	end
end

function Nameplates:OnGuildDirty(unitOwner, tNameplate)
	if self.guildDisplayed then
		tNameplate.bIsGuildMember = self.guildDisplayed:IsUnitMember(unitOwner)
	else
		tNameplate.bIsGuildMember = false
	end

	if self.guildWarParty then
		tNameplate.bIsWarPartyMember = self.guildWarParty:IsUnitMember(unitOwner)
	else
		tNameplate.bIsWarPartyMember = false
	end
end

function Nameplates:OnUnitMemberOfGuildChange(unitOwner)
	if unitOwner == nil then
		return
	end

	local tNameplate = self.arUnit2Nameplate[unitOwner:GetId()]
	if tNameplate == nil or tNameplate.wndNameplate == nil then
		return
	end

	self:OnGuildDirty(unitOwner, tNameplate)

	self:OnUnitPvpFlagsChanged(unitOwner, tNameplate)
end

function Nameplates:OnGuildChange()
	self.guildDisplayed = nil
	self.guildWarParty = nil
	for key, guildCurr in pairs(GuildLib.GetGuilds()) do
		if guildCurr:GetType() == GuildLib.GuildType_Guild then
			self.guildDisplayed = guildCurr
		end
		if guildCurr:GetType() == GuildLib.GuildType_WarParty then
			self.guildWarParty = guildCurr
		end
	end

	for key, tNameplate in pairs(self.arUnit2Nameplate) do
		local unitOwner = tNameplate.unitOwner
		self:OnGuildDirty(unitOwner, tNameplate)
		self:OnUnitPvpFlagsChanged(unitOwner, tNameplate)
	end
end

function Nameplates:OnKeyBindingUpdated(strKeybind)
	if strKeybind ~= "Path Action" and strKeybind ~= "Cast Objective Ability" then
		return
	end

	self.strPathActionKeybind = GameLib.GetKeyBinding("PathAction")
	self.bPathActionUsesIcon = false
	if self.strPathActionKeybind == Apollo.GetString("HUDAlert_Unbound") or #self.strPathActionKeybind > 1 then -- Don't show interact
		self.bPathActionUsesIcon = true
	end

	self.strQuestActionKeybind = GameLib.GetKeyBinding("CastObjectiveAbility")
	self.bQuestActionUsesIcon = false
	if self.strQuestActionKeybind == Apollo.GetString("HUDAlert_Unbound") or #self.strQuestActionKeybind > 1 then -- Don't show interact
		self.bQuestActionUsesIcon = true
	end

	self:OptionsChanged()
end

function Nameplates:CheckDrawDistance(tNameplate)
	local unitOwner = tNameplate.unitOwner

	if not unitOwner then
	    return
	end

	local unitPlayer = GameLib.GetPlayerUnit()

	tPosTarget = unitOwner:GetPosition()
	tPosPlayer = unitPlayer:GetPosition()

	if tPosTarget == nil then
		return
	end

	local nDeltaX = tPosTarget.x - tPosPlayer.x
	local nDeltaY = tPosTarget.y - tPosPlayer.y
	local nDeltaZ = tPosTarget.z - tPosPlayer.z

	local nDistance = (nDeltaX * nDeltaX) + (nDeltaY * nDeltaY) + (nDeltaZ * nDeltaZ)

	if tNameplate.bIsTarget or tNameplate.bIsCluster == true then
		bInRange = nDistance < knTargetRange
		return bInRange
	else
		bInRange = nDistance < (self.nMaxRange * self.nMaxRange) -- squaring for quick maths
		return bInRange
	end
end

-----------------------------------------------------------------------------------------------
-- Nameplate Helper Functions
-----------------------------------------------------------------------------------------------
function Nameplates:OnNameplatesOn()
	local ePath = PlayerPathLib.GetPlayerPathType()
	self.wndOptionsMain:FindChild("ShowRewardTypeMission"):FindChild("Icon"):SetSprite(karPathSprite[ePath])
	self.wndMain:Show(true)
	self:RefreshNameplatesConfigure()
end

function Nameplates:RefreshNameplatesConfigure()
	-- Generic maanged controls
	for property,tData in pairs(karSavedProperties) do
		if tData.nControlType == 1 and self[property] ~= nil then
			local wndControl = self.wndMain:FindChild(tData.strControlName)
			if wndControl ~= nil then
				wndControl:SetCheck(self[property])
			end
		end
	end

	--Draw distance
	if self.nMaxRange ~= nil then
		self.wndOptionsMain:FindChild("ShowOptionsBacker:DrawDistanceSlider"):SetValue(self.nMaxRange)
		self.wndOptionsMain:FindChild("ShowOptionsBacker:DrawDistanceLabel"):SetText(String_GetWeaselString(Apollo.GetString("Nameplates_DrawDistance"), self.nMaxRange))
	end
	--Info panel
	if self.bShowHealthMain ~= nil and self.bShowHealthMainDamaged ~= nil then self.wndMain:FindChild("MainShowHealthBarAlways"):SetCheck(self.bShowHealthMain and not self.bShowHealthMainDamaged) end
	if self.bShowHealthMain ~= nil and self.bShowHealthMainDamaged ~= nil then self.wndMain:FindChild("MainShowHealthBarDamaged"):SetCheck(not self.bShowHealthMain and self.bShowHealthMainDamaged) end
	if self.bShowHealthMain ~= nil and self.bShowHealthMainDamaged ~= nil then self.wndMain:FindChild("MainShowHealthBarNever"):SetCheck(not self.bShowHealthMain and not self.bShowHealthMainDamaged) end
	--target components
	if self.bShowMarkerTarget ~= nil then self.wndMain:FindChild("TargetedShowMarker"):SetCheck(self.bShowMarkerTarget) end
	if self.bShowMarkerTarget ~= nil then self.wndMain:FindChild("TargetedShowMarkerOff"):SetCheck(not self.bShowMarkerTarget) end
	if self.bShowNameTarget ~= nil then self.wndMain:FindChild("TargetedShowName"):SetCheck(self.bShowNameTarget) end
	if self.bShowNameTarget ~= nil then self.wndMain:FindChild("TargetedShowNameOff"):SetCheck(not self.bShowNameTarget) end
	if self.bShowRewardsTarget ~= nil then self.wndMain:FindChild("TargetedShowRewards"):SetCheck(self.bShowRewardsTarget) end
	if self.bShowRewardsTarget ~= nil then self.wndMain:FindChild("TargetedShowRewardsOff"):SetCheck(not self.bShowRewardsTarget) end
	if self.bShowGuildNameTarget ~= nil then self.wndMain:FindChild("TargetedShowGuild"):SetCheck(self.bShowGuildNameTarget) end
	if self.bShowGuildNameTarget ~= nil then self.wndMain:FindChild("TargetedShowGuildOff"):SetCheck(not self.bShowGuildNameTarget) end
	if self.bShowHealthTarget ~= nil then self.wndMain:FindChild("TargetedShowHealthBar"):SetCheck(self.bShowHealthTarget) end
	if self.bShowHealthTarget ~= nil then self.wndMain:FindChild("TargetedShowHealthBarOff"):SetCheck(not self.bShowHealthTarget) end
	if self.bShowCastBarTarget ~= nil then self.wndMain:FindChild("TargetedShowCastBar"):SetCheck(self.bShowCastBarTarget) end
	if self.bShowCastBarTarget ~= nil then self.wndMain:FindChild("TargetedShowCastBarOff"):SetCheck(not self.bShowCastBarTarget) end
	if self.bHideInCombat ~= nil then self.wndMain:FindChild("MainHideInCombat"):SetCheck(self.bHideInCombat) end
	if self.bShowMarkerTarget ~= nil then self.wndMain:FindChild("MainHideInCombatOff"):SetCheck(not self.bHideInCombat) end
end

function Nameplates:SetClearedNameplate(tNameplate)
	local wndNameplate = tNameplate.wndNameplate

	if wndNameplate == nil then
		return
	end

	wndNameplate:Show(false, true)
	wndNameplate:FindChild("TargetMarker"):Show(false)
	wndNameplate:FindChild("TargetMarkerArrow"):Show(false)
	wndNameplate:FindChild("Name"):Show(false)
	wndNameplate:FindChild("Guild"):Show(false)
	wndNameplate:FindChild("Health"):Show(false)
	wndNameplate:FindChild("QuestRewards"):Show(false)
	wndNameplate:FindChild("Vulnerable"):Show(false)
	wndNameplate:FindChild("CastBar"):Show(false)
	wndNameplate:FindChild("TargetScalingMark"):Show(false)

	tNameplate.bIsTarget = false
	tNameplate.bIsCluster = false
	tNameplate.bIsCasting = false
	tNameplate.nVulnerableTime = 0
end

function Nameplates:SetNormalNameplate(tNameplate) -- happens when built and the creature is untargeted
	local wndNameplate = tNameplate.wndNameplate
	if wndNameplate == nil then
		return
	end
	local unitOwner = tNameplate.unitOwner
	local bHiddenUnit = not unitOwner:ShouldShowNamePlate() or unitOwner:GetHealth() == nil or unitOwner:GetType() == "Collectible"
				or unitOwner:GetType() == "PinataLoot" or unitOwner:IsDead()

	local strName = unitOwner:GetName()
	if self.bShowTitle == true then
		strName = unitOwner:GetTitleOrName()
	end

	-- Name
	self:RedrawName(wndNameplate, strName)
	
	--Guild
	self:RedrawGuild(wndNameplate, unitOwner:GetAffiliationName())

	wndNameplate:Show(false)
	wndNameplate:FindChild("NameRewardContainer"):Show(true)
	wndNameplate:FindChild("TargetMarker"):Show(false)
	wndNameplate:FindChild("TargetMarkerArrow"):Show(false)
	wndNameplate:FindChild("Name"):Show(self.bShowNameMain)
	wndNameplate:FindChild("Guild"):Show(self.bShowTitle)
	wndNameplate:FindChild("Health"):Show(not bHiddenUnit and self.bShowHealthMain)

	self:HelperAdjustNameAndGuildStack(wndNameplate)
	
	local nLevel = unitOwner:GetLevel()
	if nLevel == nil then
		wndNameplate:FindChild("Level"):SetText("-")
	else
		wndNameplate:FindChild("Level"):SetText(unitOwner:GetLevel())
	end

	wndNameplate:FindChild("TargetScalingMark"):Show(unitOwner:IsScaled())

	if wndNameplate:FindChild("CastBar"):IsShown() then -- check to see if this option is set for non-targets
		wndNameplate:FindChild("CastBar"):Show(self.bShowCastBarMain)
		if self.bShowCastBarMain == false then
			tNameplate.bIsCasting = false
		end
	end

	if wndNameplate:FindChild("Vulnerable"):IsShown() then -- check to see if this option is set for non-targets
		wndNameplate:FindChild("Vulnerable"):Show(wndNameplate:FindChild("Health"):IsShown())
		if not wndNameplate:FindChild("Health"):IsShown() then
			tNameplate.nVulnerableTime = 0
			wndNameplate:FindChild("Vulnerable"):FindChild("VulnFill"):SetProgress(0)
		end
	end

	if self.bShowRewardsMain then
		local tFlags =
		{
			bVert = false,
			bHideQuests = not self.bShowRewardTypeQuest,
			bHideChallenges = not self.bShowRewardTypeChallenge,
			bHideMissions = not self.bShowRewardTypeMission,
			bHidePublicEvents = not self.bShowRewardTypePublicEvent,
			bHideRivals = not self.bShowRivals,
			bHideFriends = not self.bShowFriends
		}
		RewardIcons.GetUnitRewardIconsForm(wndNameplate:FindChild("QuestRewards"), unitOwner, tFlags)
	end

	local nNameWidth = Apollo.GetTextWidth("CRB_InterfaceMedium", strName)
	local nHalfNameWidth = nNameWidth / 2
	local nLeft, nTop, nRight, nBottom = tNameplate.wndNameplate:FindChild("NameRewardContainer"):GetAnchorOffsets()
	wndNameplate:FindChild("NameRewardContainer"):SetAnchorOffsets(nHalfNameWidth, nTop, nHalfNameWidth + wndNameplate:FindChild("NameRewardContainer"):ArrangeChildrenHorz(0), nBottom)
end

function Nameplates:SetTargetedNameplate(tNameplate) -- happens when the creature is targeted
	local wndNameplate = tNameplate.wndNameplate
	if wndNameplate == nil then
		return
	end
	local unitOwner = tNameplate.unitOwner
	local bHiddenUnit = not unitOwner:ShouldShowNamePlate() or unitOwner:GetHealth() == nil or unitOwner:GetType() == "Collectible"
				or unitOwner:GetType() == "PinataLoot" or unitOwner:IsDead()

	local strName = unitOwner:GetName()
	if self.bShowTitle == true then
		strName = unitOwner:GetTitleOrName()
	end

	wndNameplate:Show(false)

	wndNameplate:FindChild("Name"):Show(self.bShowNameTarget)
	wndNameplate:FindChild("Guild"):Show(self.bShowTitle)
	wndNameplate:FindChild("TargetScalingMark"):Show(unitOwner:IsScaled())
	wndNameplate:FindChild("QuestRewards"):Show(self.bShowRewardsTarget)
	wndNameplate:FindChild("NameRewardContainer"):Show(false)

	self:HelperAdjustNameAndGuildStack(wndNameplate)
	
	local nLevel = unitOwner:GetLevel()
	if nLevel == nil then
		wndNameplate:FindChild("Level"):SetText("-")
	else
		wndNameplate:FindChild("Level"):SetText(unitOwner:GetLevel())
	end
	wndNameplate:FindChild("Health"):Show(self.bShowHealthTarget and not bHiddenUnit)

	if self.bShowNameTarget then
		wndNameplate:FindChild("NameRewardContainer"):Show(true)
	end

	if wndNameplate:FindChild("CastBar"):IsShown() then -- check to see if this option is set for non-targets
		wndNameplate:FindChild("CastBar"):Show(self.bShowCastBarTarget)
		if self.bShowCastBarTarget == false then
			tNameplate.bIsCasting = false
		end
	end

	if wndNameplate:FindChild("Vulnerable"):IsShown() then -- check to see if this option is set for non-targets
		wndNameplate:FindChild("Vulnerable"):Show(wndNameplate:FindChild("Health"):IsShown())
		if not wndNameplate:FindChild("Health"):IsShown() then
			tNameplate.nVulnerableTime = 0
			wndNameplate:FindChild("Vulnerable"):FindChild("VulnFill"):SetProgress(0)
		end
	end

	if self.bShowRewardsTarget then
		local tFlags =
		{
			bVert = false,
			bHideQuests = not self.bShowRewardTypeQuest,
			bHideChallenges = not self.bShowRewardTypeChallenge,
			bHideMissions = not self.bShowRewardTypeMission,
			bHidePublicEvents = not self.bShowRewardTypePublicEvent,
			bHideRivals = not self.bShowRivals,
			bHideFriends = not self.bShowFriends
		}
		RewardIcons.GetUnitRewardIconsForm(wndNameplate:FindChild("QuestRewards"), unitOwner, tFlags)
	end

	local nNameWidth = Apollo.GetTextWidth("CRB_InterfaceMedium", strName)
	local nHalfNameWidth = nNameWidth / 2
	local nLeft, nTop, nRight, nBottom = tNameplate.wndNameplate:FindChild("NameRewardContainer"):GetAnchorOffsets()
	wndNameplate:FindChild("NameRewardContainer"):SetAnchorOffsets(nHalfNameWidth, nTop, nHalfNameWidth + wndNameplate:FindChild("NameRewardContainer"):ArrangeChildrenHorz(0), nBottom)
end

function Nameplates:HelperDoHealthShieldBar(wndHealth, unitOwner, eDisposition)
	local nVulnerabilityTime = unitOwner:GetCCStateTimeRemaining(Unit.CodeEnumCCState.Vulnerability)

	if unitOwner:GetType() == "Simple" or unitOwner:GetHealth() == nil then
		wndHealth:FindChild("MaxHealth"):SetAnchorOffsets(self.nFrameLeft, self.nFrameTop, self.nFrameRight, self.nFrameBottom)
		wndHealth:FindChild("HealthLabel"):SetText("")
		return
	end

	local nHealthCurr 	= unitOwner:GetHealth()
	local nHealthMax 	= unitOwner:GetMaxHealth()
	local nShieldCurr 	= unitOwner:GetShieldCapacity()
	local nShieldMax 	= unitOwner:GetShieldCapacityMax()
	local nAbsorbCurr 	= 0
	local nAbsorbMax 	= unitOwner:GetAbsorptionMax()
	if nAbsorbMax > 0 then
		nAbsorbCurr = unitOwner:GetAbsorptionValue() -- Since it doesn't clear when the buff drops off
	end
	local nTotalMax = nHealthMax + nShieldMax + nAbsorbMax

	-- Scaling
	--[[local nPointHealthRight = self.nFrameR * (nHealthCurr / nTotalMax) -
	local nPointShieldRight = self.nFrameR * ((nHealthCurr + nShieldMax) / nTotalMax)
	local nPointAbsorbRight = self.nFrameR * ((nHealthCurr + nShieldMax + nAbsorbMax) / nTotalMax)--]]

	local nPointHealthRight = self.nFrameLeft + (self.nHealthWidth * (nHealthCurr / nTotalMax)) -- applied to the difference between L and R
	local nPointShieldRight = self.nFrameLeft + (self.nHealthWidth * ((nHealthCurr + nShieldMax) / nTotalMax))
	local nPointAbsorbRight = self.nFrameLeft + (self.nHealthWidth * ((nHealthCurr + nShieldMax + nAbsorbMax) / nTotalMax))


	if nShieldMax > 0 and nShieldMax / nTotalMax < 0.2 then
		local nMinShieldSize = 0.2 -- HARDCODE: Minimum shield bar length is 20% of total for formatting
		--nPointHealthRight = self.nFrameR * math.min(1-nMinShieldSize, nHealthCurr / nTotalMax) -- Health is normal, but caps at 80%
		--nPointShieldRight = self.nFrameR * math.min(1, (nHealthCurr / nTotalMax) + nMinShieldSize) -- If not 1, the size is thus healthbar + hard minimum

		nPointHealthRight = self.nFrameLeft + (self.nHealthWidth*(math.min(1 - nMinShieldSize, nHealthCurr / nTotalMax)))
		nPointShieldRight = self.nFrameLeft + (self.nHealthWidth*(math.min(1, (nHealthCurr / nTotalMax) + nMinShieldSize)))
	end

	-- Resize
	wndHealth:FindChild("ShieldFill"):EnableGlow(nShieldCurr > 0 and nShieldCurr ~= nShieldMax)
	self:SetBarValue(wndHealth:FindChild("ShieldFill"), 0, nShieldCurr, nShieldMax) -- Only the Curr Shield really progress fills
	self:SetBarValue(wndHealth:FindChild("AbsorbFill"), 0, nAbsorbCurr, nAbsorbMax)
	wndHealth:FindChild("MaxHealth"):SetAnchorOffsets(self.nFrameLeft, self.nFrameTop, nPointHealthRight, self.nFrameBottom)
	wndHealth:FindChild("MaxShield"):SetAnchorOffsets(nPointHealthRight - 1, self.nFrameTop, nPointShieldRight, self.nFrameBottom)
	wndHealth:FindChild("MaxAbsorb"):SetAnchorOffsets(nPointShieldRight - 1, self.nFrameTop, nPointAbsorbRight, self.nFrameBottom)

	-- Bars
	wndHealth:FindChild("ShieldFill"):Show(nHealthCurr > 0)
	wndHealth:FindChild("MaxHealth"):Show(nHealthCurr > 0)
	wndHealth:FindChild("MaxShield"):Show(nHealthCurr > 0 and nShieldMax > 0)
	wndHealth:FindChild("MaxAbsorb"):Show(nHealthCurr > 0 and nAbsorbMax > 0)

	-- Text
	local strHealthMax = self:HelperFormatBigNumber(nHealthMax)
	local strHealthCurr = self:HelperFormatBigNumber(nHealthCurr)
	local strShieldCurr = self:HelperFormatBigNumber(nShieldCurr)

	local strText = nHealthMax == nHealthCurr and strHealthMax or String_GetWeaselString(Apollo.GetString("TargetFrame_HealthText"), strHealthCurr, strHealthMax)
	if nShieldMax > 0 and nShieldCurr > 0 then
		strText = String_GetWeaselString(Apollo.GetString("TargetFrame_HealthShieldText"), strText, strShieldCurr)
	end
	wndHealth:FindChild("HealthLabel"):SetText(strText)

	-- Sprite
	if nVulnerabilityTime and nVulnerabilityTime > 0 then
		wndHealth:FindChild("MaxHealth"):SetSprite("CRB_Nameplates:sprNP_PurpleProg")
	else
		wndHealth:FindChild("MaxHealth"):SetSprite(karDisposition.tHealthBar[eDisposition])
	end

	--[[
	elseif nHealthCurr / nHealthMax < .3 then
		wndHealth:FindChild("MaxHealth"):SetSprite(ktHealthBarSprites[3])
	elseif 	nHealthCurr / nHealthMax < .5 then
		wndHealth:FindChild("MaxHealth"):SetSprite(ktHealthBarSprites[2])
	else
		wndHealth:FindChild("MaxHealth"):SetSprite(ktHealthBarSprites[1])
	end]]--
end

function Nameplates:HelperFormatBigNumber(nArg)
	-- Turns 99999 into 99.9k and 90000 into 90k
	local strResult
	if nArg < 1000 then
		strResult = tostring(nArg)
	elseif math.floor(nArg%1000/100) == 0 then
		strResult = String_GetWeaselString(Apollo.GetString("TargetFrame_ShortNumberWhole"), math.floor(nArg / 1000))
	else
		strResult = String_GetWeaselString(Apollo.GetString("TargetFrame_ShortNumberFloat"), nArg / 1000)
	end
	return strResult
end

function Nameplates:SetBarValue(wndBar, fMin, fValue, fMax)
	wndBar:SetMax(fMax)
	wndBar:SetFloor(fMin)
	wndBar:SetProgress(fValue)
end

function Nameplates:HelperCalculateConValue(unitTarget)
	if unitTarget == nil or GameLib.GetPlayerUnit() == nil then
		return 1
	end

	local nUnitCon = GameLib.GetPlayerUnit():GetLevelDifferential(unitTarget)

	local nCon = 1 --default setting

	if nUnitCon <= karConColors[1][1] then -- lower bound
		nCon = 1
	elseif nUnitCon >= karConColors[#karConColors][1] then -- upper bound
		nCon = #karConColors
	else
		for idx = 2, (#karConColors - 1) do -- everything in between
			if nUnitCon == karConColors[idx][1] then
				nCon = idx
			end
		end
	end

	return nCon
end

-----------------------------------------------------------------------------------------------
-- Reward update functions (in case you need to do something specific depending on the signal)
-----------------------------------------------------------------------------------------------
function Nameplates:OnQuestInit()
	if self.bShowRewardTypeQuest then
		self:OnRewardInfoUpdated()
	end
end

function Nameplates:OnQuestStateChanged()
	self:OnRewardInfoUpdated()
end

function Nameplates:OnQuestObjectiveUpdated()
	self:OnRewardInfoUpdated()
end

function Nameplates:OnUnitActivationTypeChanged()
	self:OnRewardInfoUpdated()
end

function Nameplates:OnPublicEventStart()
	if self.bShowRewardTypePublicEvent then
		self:OnRewardInfoUpdated()
	end
end

function Nameplates:OnPublicEventObjectiveUpdate()
	if self.bShowRewardTypePublicEvent then
		self:OnRewardInfoUpdated()
	end
end

function Nameplates:OnPublicEventEnd()
	if self.bShowRewardTypePublicEvent then
		self:OnRewardInfoUpdated()
	end
end

function Nameplates:OnChallengeUnlocked()
	if self.bShowRewardTypeChallenge then
		self:OnRewardInfoUpdated()
	end
end

function Nameplates:OnChallengeFailArea()
	if self.bShowRewardTypeChallenge then
		self:OnRewardInfoUpdated()
	end
end

function Nameplates:OnChallengeFailTime()
	if self.bShowRewardTypeChallenge then
		self:OnRewardInfoUpdated()
	end
end

function Nameplates:OnChallengeActivate()
	if self.bShowRewardTypeChallenge then
		self:OnRewardInfoUpdated()
	end
end

function Nameplates:OnChallengeCompleted() -- TODO: Hack because network traffic seems to delay the update to "completed"
	if self.bShowRewardTypeChallenge then
		Apollo.RegisterTimerHandler("ChallengeCompletedTimer", "OnRewardInfoUpdated", self)
		Apollo.CreateTimer("ChallengeCompletedTimer", 0.2, false)
		--self:OnRewardInfoUpdated()
	end
end

function Nameplates:OnPlayerPathMissionChange()
	if self.bShowRewardTypeMission then
		self:OnRewardInfoUpdated()
	end
end

-----------------------------------------------------------------------------------------------
function Nameplates:OnRewardInfoUpdated() -- we've recieved an external signal that reward stuff has been changed
	self.bRewardInfoDirty = true
end

function Nameplates:UpdateRewardInfo()
	if self.bInitialLoadAllClear == false then
		return
	end

	self.bRewardInfoDirty = false

	-- Quest backers first
	local tAdjustObjectives = {}
	for idx, tNameplate in pairs(self.arUnit2Nameplate) do
		local bObjective = self:ParseRewards(tNameplate) -- get the new value
		if tNameplate.bIsObjective ~= bObjective then -- compare to old
			table.insert(tAdjustObjectives, tNameplate) -- add to list if they're not the same
		end
	end

	if not tAdjustObjectives then
		for idx, tNameplate in pairs(tAdjustObjectives) do
			local unitOwner = tNameplate.unitOwner
			local bHideMine = unitOwner:IsThePlayer() and not self.bShowMyNameplate
			if bHideMine or unitOwner:IsDead() or not unitOwner:ShouldShowNamePlate() then
				self:UnattachNameplateWindow(tNameplate)
			elseif tNameplate.bIsTarget == true or tNameplate.bIsCluster == true then
				self:SetTargetedNameplate(tNameplate)
			else
				self:SetNormalNameplate(tNameplate)
			end
		end
	end

	if not self.bShowRewardsMain and not self.bShowRewardsTarget then -- don't process rewards if they're not shown
		return
	end

	--There's no real efficient way to do this since the target may have the same number of rewards but have different info for them
	for idx, tNameplate in pairs(self.arUnit2Nameplate) do -- run the list
		local unitOwner = tNameplate.unitOwner
		local bHideMine = unitOwner:IsThePlayer() and not self.bShowMyNameplate
		if bHideMine or unitOwner:IsDead() or not unitOwner:ShouldShowNamePlate() then -- the format functions update reward icons
			self:UnattachNameplateWindow(tNameplate)
		elseif tNameplate.bIsTarget == true or tNameplate.bIsCluster == true then
			self:SetTargetedNameplate(tNameplate)
		else
			self:SetNormalNameplate(tNameplate)
		end
	end
end

function Nameplates:ParseRewards(tNameplate)
	local unitOwner = tNameplate.unitOwner
	if unitOwner == nil then
		return
	end

	local tRewardInfo = {}
	tRewardInfo = unitOwner:GetRewardInfo()
	if tRewardInfo == nil or type(tRewardInfo) ~= "table" then
		tNameplate.bIsObjective = false
		return
	end

	local iRewards = 0
	local nRewardCount = #tRewardInfo
	if nRewardCount > 0 then
		for idx = 1, nRewardCount do
			local ePathId = PlayerPathLib.GetPlayerPathType()
			local strType = tRewardInfo[idx].strType
			if strType == "Quest" then
				iRewards = iRewards + 1
			--elseif strType == "Challenge" then -- NOTE: Challenges read as true even if you're not on the challenge
			--	iRewardCount = iRewardCount+1
			elseif strType == "Explorer" and ePathId == PlayerPathLib.PlayerPathType_Explorer then
				iRewards = iRewards + 1
			elseif strType == "Scientist" and ePathId == PlayerPathLib.PlayerPathType_Scientist then
				iRewards = iRewards + 1
			elseif strType == "Soldier" and ePathId == PlayerPathLib.PlayerPathType_Soldier then
				iRewards = iRewards + 1
			elseif strType == "Settler" and ePathId == PlayerPathLib.PlayerPathType_Settler then
				iRewards = iRewards + 1
			end
		end
	end

	--now do questgivers, etc

	local tActivation = unitOwner:GetActivationState()
	if tActivation.QuestTarget ~= nil then
		iRewards = iRewards + 1
	end
	if tActivation.QuestReward ~= nil then
		iRewards = iRewards + 1
	end
	if tActivation.QuestNew ~= nil or tActivation.QuestNewMain ~= nil then
		iRewards = iRewards + 1
	end
	if tActivation.QuestReceiving ~= nil then
		iRewards = iRewards + 1
	end
	if tActivation.TalkTo ~= nil then
		iRewards = iRewards + 1
	end

	tNameplate.bIsObjective = iRewards > 0
end

-----------------------------------------------------------------------------------------------
-- NameplatesForm Functions
-----------------------------------------------------------------------------------------------

function Nameplates:OnNormalViewCheck(wndHandler, wndCtrl)
	self.wndMain:FindChild("ContentMain"):Show(true)
	self.wndMain:FindChild("ContentTarget"):Show(false)
end

function Nameplates:OnTargetViewCheck(wndHandler, wndCtrl)
	self.wndMain:FindChild("ContentMain"):Show(false)
	self.wndMain:FindChild("ContentTarget"):Show(true)
end

-- when the OK button is clicked
function Nameplates:OnOK()
	self.wndMain:Show(false) -- hide the window
end

-- when the Cancel button is clicked
function Nameplates:OnCancel()
	self.wndMain:Show(false) -- hide the window
end

function Nameplates:OnDrawDistanceSlider(wndNameplate, wndHandler, nValue, nOldvalue)
	self.wndOptionsMain:FindChild("DrawDistanceLabel"):SetText(String_GetWeaselString(Apollo.GetString("Nameplates_DrawDistance"), nValue))
	self.nMaxRange = nValue-- set new constant, apply math
end

function Nameplates:OnMainShowHealthBarAlways(wndHandler, wndCtrl)
	self:HelperOnMainShowHealthSettingChanged(true, false)
end

function Nameplates:OnMainShowHealthBarDamaged(wndHandler, wndCtrl)
	self:HelperOnMainShowHealthSettingChanged(false, true)
end

function Nameplates:OnMainShowHealthBarNever(wndHandler, wndCtrl)
	self:HelperOnMainShowHealthSettingChanged(false, false)
end

function Nameplates:HelperOnMainShowHealthSettingChanged(bShowHealthMain, bShowHealthMainDamaged)
	self.bShowHealthMain = bShowHealthMain
	self.bShowHealthMainDamaged = bShowHealthMainDamaged
	self:OptionsChanged()
end

---------------------------------------------------------------
---------------------------------------------------------------

function Nameplates:OnTargetedShowGuildNameToggle(wndHandler, wndControl)
	self.bShowGuildNameTarget = self.wndOptionsTargeted:FindChild("TargetedShowGuild"):IsChecked()
	self:OptionsChanged()
end

function Nameplates:OnMainHideInCombat(wndHandler, wndCtrl)
	self.bHideInCombat = wndCtrl:IsChecked() -- onDraw
end

function Nameplates:OnMainHideInCombatOff(wndHandler, wndCtrl)
	self.bHideInCombat = not wndCtrl:IsChecked() -- onDraw
end

function Nameplates:OnTargetedShowName(wndHandler, wndCtrl)
	local bDrawNameTargeted = wndCtrl:IsChecked()
	self.bShowNameTarget = bDrawNameTargeted	 -- tabled
	self:OptionsChanged()
end

function Nameplates:OnTargetedShowNameOff(wndHandler, wndCtrl)
	local bDrawNameTargeted = not wndCtrl:IsChecked()
	self.bShowNameTarget = bDrawNameTargeted	 -- tabled
	self:OptionsChanged()
end

function Nameplates:OnTargetedShowHealthBar(wndHandler, wndCtrl)
	self.bShowHealthTarget = true  -- tabled
	self:OptionsChanged()
end

function Nameplates:OnTargetedShowHealthBarOff(wndHandler, wndCtrl)
	self.bShowHealthTarget = false  -- tabled
	self:OptionsChanged()
end

function Nameplates:OnTargetedShowRewards(wndHandler, wndCtrl)
	local bDrawRewardsTargeted = wndCtrl:IsChecked()
	self.bShowRewardsTarget = bDrawRewardsTargeted	 -- tabled
	self:OptionsChanged()
end

function Nameplates:OnTargetedShowRewardsOff(wndHandler, wndCtrl)
	local bDrawRewardsTargeted = not wndCtrl:IsChecked()
	self.bShowRewardsTarget = bDrawRewardsTargeted	 -- tabled
	self:OptionsChanged()
end

function Nameplates:OnTargetedShowCastBar(wndHandler, wndCtrl)
	self.bShowCastBarTarget = wndCtrl:IsChecked()	 -- onDraw
	self:OptionsChanged()
end

function Nameplates:OnTargetedShowCastBarOff(wndHandler, wndCtrl)
	self.bShowCastBarTarget = not wndCtrl:IsChecked()	 -- onDraw
	self:OptionsChanged()
end

function Nameplates:OnTargetedShowRange(wndHandler, wndCtrl)
	local bDrawRangeTargeted = wndCtrl:IsChecked()
	self.bShowRangeTarget = bDrawRangeTargeted -- tabled
	self:OptionsChanged()
end

function Nameplates:OnTargetedShowRangeOff(wndHandler, wndCtrl)
	local bDrawRangeTargeted = not wndCtrl:IsChecked()
	self.bShowRangeTarget = bDrawRangeTargeted -- tabled
	self:OptionsChanged()
end

function Nameplates:OnTargetedShowMarker(wndHandler, wndCtrl)
	local bDrawMarkerTargeted = wndCtrl:IsChecked()
	self.bShowMarkerTarget = bDrawMarkerTargeted -- tabled
	self:OptionsChanged()
end

function Nameplates:OnTargetedShowMarkerOff(wndHandler, wndCtrl)
	local bDrawMarkerTargeted = not wndCtrl:IsChecked()
	self.bShowMarkerTarget = bDrawMarkerTargeted -- tabled
	self:OptionsChanged()
end

function Nameplates:OptionsChanged()
	local unitPlayer = GameLib.GetPlayerUnit()
	if unitPlayer == nil then
		Apollo.StartTimer("InitialParseTimer", 1.0, false) -- ensures the player is fully loaded
		return
	end

	self.bInitialLoadAllClear = true
	self.unitPlayerDisposComparisonTEMP = unitPlayer
	self.bBlinded = unitPlayer:IsInCCState(Unit.CodeEnumCCState.Blind)

	for idx, tNameplate in pairs(self.arDisplayedNameplates) do
		local unitOwner = tNameplate.unitOwner
		self:ParseRewards(tNameplate)

		-- reward icons get updated in the formatting functions below
		local bHideMine = unitOwner:IsThePlayer() and not self.bShowMyNameplate
		if bHideMine or unitOwner:IsDead() or not unitOwner:ShouldShowNamePlate() then
			self:UnattachNameplateWindow(tNameplate)
		elseif tNameplate.bIsTarget or tNameplate.bIsCluster then
			self:SetTargetedNameplate(tNameplate) -- no need to set target since it should be shown already
		else
			self:SetNormalNameplate(tNameplate)
		end
	end
	
	for idx, unitHidden in pairs(self.arHiddenUnits) do
		if unitHidden:IsValid() then
			self:OnUnitCreated(unitHidden)
		end
	end
	
	self:OnSecondaryParseTimer()
end

function Nameplates:OnSecondaryParseTimer() -- keeps everything clean
	if self.bInitialLoadAllClear == false then
		return
	end

	local nCount = 0
	local nWindows = 0
	local nVisible = 0
	for idx, tNameplate in pairs(self.arUnit2Nameplate) do
		nCount = nCount + 1
		local unitOwner = tNameplate.unitOwner
		if tNameplate.wndNameplate ~= nil then
			nWindows = nWindows + 1
			self:ParseRewards(tNameplate)
			if tNameplate.wndNameplate:IsVisible() then
				nVisible = nVisible + 1

				-- reward icons get updated in the formatting functions below
				local bHideMine = unitOwner:IsThePlayer() and not self.bShowMyNameplate
				if bHideMine or unitOwner:IsDead() or not unitOwner:ShouldShowNamePlate() then
					self:UnattachNameplateWindow(tNameplate)
				elseif tNameplate.bIsTarget == true or tNameplate.bIsCluster == true then
					self:SetTargetedNameplate(tNameplate) -- no need to set target since it should be shown already
				else
					self:SetNormalNameplate(tNameplate)
				end
			end
		end
	end
end

---------------------------------------------------------------------------------------------------
-- StandardModule Functions
---------------------------------------------------------------------------------------------------

function Nameplates:OnGenericSingleCheck(wndHandler, wndControl, eMouseButton)
	local strSettingName = wndControl:GetData()
	if strSettingName ~= nil then
		self[strSettingName] = wndControl:IsChecked()
		self:OptionsChanged()
	end
end

-----------------------------------------------------------------------------------------------
-- Nameplates Instance
-----------------------------------------------------------------------------------------------
local NameplatesInst = Nameplates:new()
NameplatesInst:Init()
