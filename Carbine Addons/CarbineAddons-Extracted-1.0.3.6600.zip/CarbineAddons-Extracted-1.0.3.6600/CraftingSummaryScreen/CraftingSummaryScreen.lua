-----------------------------------------------------------------------------------------------
-- Client Lua Script for CraftingSummaryScreen
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "CraftingLib"

local CraftingSummaryScreen = {}

local karHotColdToString =
{
	[CraftingLib.CodeEnumCraftingDiscoveryHotCold.Hot] 		= Apollo.GetString("Crafting_DiscoveryHot"),
	[CraftingLib.CodeEnumCraftingDiscoveryHotCold.Cold] 	= Apollo.GetString("Crafting_DiscoveryCold"),
	[CraftingLib.CodeEnumCraftingDiscoveryHotCold.Warm] 	= Apollo.GetString("Crafting_DiscoveryWarm"),
	[CraftingLib.CodeEnumCraftingDiscoveryHotCold.Success] 	= Apollo.GetString("Crafting_DiscoverySuccess"),
}

local ktDirectionsNorth =
{
	[CraftingLib.CodeEnumCraftingDirection.N]	= true,
	[CraftingLib.CodeEnumCraftingDirection.NE]	= true,
	[CraftingLib.CodeEnumCraftingDirection.NW]	= true,
}

local ktDirectionsSouth =
{
	[CraftingLib.CodeEnumCraftingDirection.S]	= true,
	[CraftingLib.CodeEnumCraftingDirection.SE]	= true,
	[CraftingLib.CodeEnumCraftingDirection.SW]	= true,
}

local ktDirectionsEast =
{
	[CraftingLib.CodeEnumCraftingDirection.E]	= true,
	[CraftingLib.CodeEnumCraftingDirection.NE]	= true,
	[CraftingLib.CodeEnumCraftingDirection.SE]	= true,
}

local ktDirectionsWest =
{
	[CraftingLib.CodeEnumCraftingDirection.W]	= true,
	[CraftingLib.CodeEnumCraftingDirection.NW]	= true,
	[CraftingLib.CodeEnumCraftingDirection.SW]	= true,
}

function CraftingSummaryScreen:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function CraftingSummaryScreen:Init()
    Apollo.RegisterAddon(self)
end

function CraftingSummaryScreen:OnLoad()
	Apollo.RegisterEventHandler("GenericEvent_BotchCraft", 		"OnBotchCraft", self)
	Apollo.RegisterEventHandler("GenericEvent_CraftSummaryMsg", "OnGenericEvent_CraftSummaryMsg", self)
	Apollo.RegisterEventHandler("CraftingSchematicComplete", 	"OnCraftingSchematicComplete", self)

	Apollo.RegisterTimerHandler("TimerCraftingStationCheck", 	"OnTimerCraftingStationCheck", self)

	-- These pump async into the text field
	Apollo.RegisterEventHandler("TradeSkillFloater", 			"OnTradeSkillFloater", self)
	Apollo.RegisterEventHandler("CraftingDiscoveryHotCold", 	"OnDiscoveryHotCold", self)
	Apollo.RegisterEventHandler("CraftingSchematicLearned", 	"OnCraftingSchematicLearned", self)
	Apollo.RegisterEventHandler("TradeskillAchievementUpdate", 	"OnTradeskillAchievementUpdate", self)

	self.wndMain = Apollo.LoadForm("CraftingSummaryScreen.xml", "CraftingSummaryScreenForm", nil, self)
	self.wndMain:Show(false, true)

	self.bBotchCraft = false
end

function CraftingSummaryScreen:OnTimerCraftingStationCheck() -- Hackish: These are async from the rest of the UI (and definitely can't handle data being set)
	if not self.wndMain or not self.wndMain:IsValid() or not self.wndMain:IsVisible() then
		return
	end

	Apollo.CreateTimer("TimerCraftingStationCheck", 1, false) -- Order matters

	local bResult = true
	local tSchematicInfo = CraftingLib.GetSchematicInfo(self.wndMain:GetData()) -- Data can be either a main or subschematic ID
	if tSchematicInfo and tSchematicInfo.eTradeskillId == CraftingLib.CodeEnumTradeskill.Runecrafting then
		bResult = true
	elseif not CraftingLib.IsAtCraftingStation() then
		bResult = false
	elseif tSchematicInfo then
		for idx, tMaterialData in pairs(tSchematicInfo.tMaterials) do
			if tMaterialData.nAmount > tMaterialData.itemMaterial:GetBackpackCount() then
				bResult = false
				break
			end
		end
	end

	self.wndMain:FindChild("CraftingSummaryRecraftBtn"):Enable(bResult)
end

---------------------------------------------------------------------------------------------------
-- Messages
---------------------------------------------------------------------------------------------------

function CraftingSummaryScreen:OnDiscoveryHotCold(eHotCold, eDirection)
	local strNeedAdjust = ""
	if eDirection == CraftingLib.CodeEnumCraftingDirection.None then
		return
	end

	local tCurrentCraft = CraftingLib.GetCurrentCraft()
	local tSchematicInfo = tCurrentCraft and CraftingLib.GetSchematicInfo(tCurrentCraft.nSchematicId)
	local tInfo = tSchematicInfo and CraftingLib.GetTradeskillInfo(tSchematicInfo.eTradeskillId)
	if tInfo and tInfo.tAxisNames then
		if ktDirectionsNorth[eDirection] then
			strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryMore") .. " " .. tInfo.tAxisNames[2]
		elseif ktDirectionsSouth[eDirection] and tInfo.tAxisNames[2] ~= tInfo.tAxisNames[4] then
			strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryMore") .. " " .. tInfo.tAxisNames[4]
		elseif ktDirectionsSouth[eDirection] then
			strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryLess") .. " " .. tInfo.tAxisNames[2]
		end

		if ktDirectionsEast[eDirection] then
			strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryMore") .. " " .. tInfo.tAxisNames[1]
		elseif ktDirectionsWest[eDirection] and tInfo.tAxisNames[1] ~= tInfo.tAxisNames[3] then
			strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryMore") .. " " .. tInfo.tAxisNames[3]
		elseif ktDirectionsWest[eDirection] then
			strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryLess") .. " " .. tInfo.tAxisNames[1]
		end
	end

	self:HelperWriteToCraftingSummaryDetails(karHotColdToString[eHotCold] .. strNeedAdjust)
end

function CraftingSummaryScreen:OnTradeskillAchievementUpdate(achUpdated, nValueCurr, nValueNeeded)
	if nValueNeeded ~= 0 then
		self:HelperWriteToCraftingSummaryDetails(String_GetWeaselString(Apollo.GetString("Crafting_AchievementProgress"), achUpdated:GetName(), nValueCurr, nValueNeeded))
	end
end

function CraftingSummaryScreen:OnCraftingSchematicLearned(idTradeskill, idSchematic)
	local tSchemInfo = CraftingLib.GetSchematicInfo(idSchematic)
	self:HelperWriteToCraftingSummaryDetails(String_GetWeaselString(Apollo.GetString("Crafting_NewSchematic"), tSchemInfo.strName))
end

function CraftingSummaryScreen:OnTradeSkillFloater(unitAttach, strMessage)
	self:HelperWriteToCraftingSummaryDetails(strMessage)
end

function CraftingSummaryScreen:OnGenericEvent_CraftSummaryMsg(strMessage) -- From Lua
	self:HelperWriteToCraftingSummaryDetails(strMessage)
end

function CraftingSummaryScreen:HelperWriteToCraftingSummaryDetails(strMessage)
	if not self.wndMain or not self.wndMain:IsValid() then
		return
	end

	-- This is asynchronous
	-- TODO: A level up will reset the entire UI. We will have to be smarter for level ups and see what to not redraw.
	local strResult = self.wndMain:FindChild("CraftingSummaryDetails"):GetData() or ""
	strResult = string.format("%s<P Font=\"CRB_InterfaceMedium_B\" TextColor=\"UI_TextHoloBody\">%s</P>", strResult, strMessage)
	self.wndMain:FindChild("CraftingSummaryDetails"):SetAML(strResult)
	self.wndMain:FindChild("CraftingSummaryDetails"):SetData(strResult)
	self.wndMain:FindChild("CraftingSummaryDetails"):SetHeightToContentHeight()
	self.wndMain:FindChild("CraftingSummaryDetailsScroll"):RecalculateContentExtents()
end

-----------------------------------------------------------------------------------------------
-- Main Draw Method
-----------------------------------------------------------------------------------------------

function CraftingSummaryScreen:OnCraftingSchematicComplete(idSchematic, bPass, nEarnedXp, arMaterialReturnedIds, idSchematicCrafted, idItemCrafted) -- Main starting method
	if self.bBotchCraft then -- Skip entire UI if botch craft (e.g. Abandon Button)
		self.bBotchCraft = false
		return
	end

	self.wndMain:ToFront()
	self.wndMain:Show(true)
	self.wndMain:SetData(idSchematic)
	self.wndMain:FindChild("CraftingSummaryRecraftBtn"):SetData(idSchematic)
	self.wndMain:FindChild("CraftingSummaryDetails"):SetAML("")
	self.wndMain:FindChild("CraftingSummaryDetails"):SetData("")

	-- Draw Pass / Fail
	local tSchemInfo = CraftingLib.GetSchematicInfo(idSchematicCrafted) -- GOTCHA: Swapping to the new idSchematicCrafted, previously old tech just used idSchematic
	if tSchemInfo then
		local itemSchem = tSchemInfo.itemOutput
		if bPass then
			self.wndMain:FindChild("CraftingSummaryItemIcon"):SetSprite(itemSchem:GetIcon())
			self.wndMain:FindChild("CraftingSummaryResultsTitle"):SetTextColor("UI_TextHoloTitle")
			self.wndMain:FindChild("CraftingSummaryResultsTitle"):SetText(String_GetWeaselString(Apollo.GetString("CraftSummary_CraftingSuccess"), itemSchem:GetName()))
			Tooltip.GetItemTooltipForm(self, self.wndMain:FindChild("CraftingSummaryItemIcon"), itemSchem, {itemCompare = itemSchem:GetEquippedItemForItemType()})
		else
			self.wndMain:FindChild("CraftingSummaryItemIcon"):SetSprite("ClientSprites:LootCloseBox")
			self.wndMain:FindChild("CraftingSummaryResultsTitle"):SetTextColor("AddonError")
			self.wndMain:FindChild("CraftingSummaryResultsTitle"):SetText(String_GetWeaselString(Apollo.GetString("CraftingSummary_CraftFailedText"), itemSchem:GetName()))
			self.wndMain:FindChild("CraftingSummaryItemIcon"):SetTooltip(Apollo.GetString("CraftingSummary_CraftFailedTooltip"))
		end

		-- XP Bar
		local tTradeskillInfo = CraftingLib.GetTradeskillInfo(tSchemInfo.eTradeskillId)
		self.wndMain:FindChild("CraftingSummaryXPProgBG"):Show(nEarnedXp > 0)

		if nEarnedXp > 0 then -- Assume crafts will always give > 0 xp at non-max tiers
			local nCurrXP = tTradeskillInfo.nXp
			local nNextXP = tTradeskillInfo.nXpForNextTier
			local strProgText = String_GetWeaselString(Apollo.GetString("CraftingSummary_ProgressText"), nEarnedXp, tTradeskillInfo.strName, nCurrXP, nNextXP)
			self.wndMain:FindChild("CraftingSummaryXPProgBar"):SetMax(nNextXP)
			self.wndMain:FindChild("CraftingSummaryXPProgBar"):SetProgress(nCurrXP)
			self.wndMain:FindChild("CraftingSummaryXPProgBar"):EnableGlow(nCurrXP > 0 and nCurrXP < nNextXP)
			self.wndMain:FindChild("CraftingSummaryXPProgText"):SetText(strProgText)
			self.wndMain:FindChild("CraftingSummaryXPProgText"):SetTooltip(strProgText .. "\n" .. Apollo.GetString("CraftingSummary_TierUnlockTooltip"))
		end
	end

	-- Summary Detail Messages
	if arMaterialReturnedIds then
		for idx, nReturnedId in pairs(arMaterialReturnedIds) do
			local itemObject = Item.GetDataFromId(nReturnedId)
			if itemObject then
				self:HelperWriteToCraftingSummaryDetails(String_GetWeaselString(Apollo.GetString("CraftingSummary_ReturnedMaterials"), itemObject:GetName()))
			end
		end
	end
	self:HelperWriteToCraftingSummaryDetails("")

	-- Start station timer and check immediately, so it doesn't flash enabled/disabled for a second
	Apollo.CreateTimer("TimerCraftingStationCheck", 1, false)
	self:OnTimerCraftingStationCheck()
end

function CraftingSummaryScreen:OnBotchCraft()
	self.bBotchCraft = true -- Skip entire UI if botch craft (e.g. Abandon Button)
end

-----------------------------------------------------------------------------------------------
-- UI Interaction
-----------------------------------------------------------------------------------------------

function CraftingSummaryScreen:OnCraftingSummaryRecraftBtn(wndHandler, wndControl) -- Data is idSchematic
	self:OnClose()

	local idSchematic = wndHandler:GetData()
	local tSchematicInfo = CraftingLib.GetSchematicInfo(idSchematic)
	if not tSchematicInfo then
		return
	end

	if tSchematicInfo.eTradeskillId == CraftingLib.CodeEnumTradeskill.Runecrafting then
		Event_FireGenericEvent("TradeskillEngravingStationOpen")
	elseif tSchematicInfo.bIsAutoCraft then
		Event_FireGenericEvent("AlwaysShowTradeskills")
	else
		Event_FireGenericEvent("GenericEvent_CraftFromPL", idSchematic)
	end
end

function CraftingSummaryScreen:OnCraftingSummaryOkBtn(wndHandler, wndControl)
	self:OnClose()
end

function CraftingSummaryScreen:OnCraftingSummaryCloseBtn(wndHandler, wndControl)
	self:OnClose()
end

function CraftingSummaryScreen:OnClose()
	self.wndMain:Show(false)
end

local CraftingSummaryScreenInst = CraftingSummaryScreen:new()
CraftingSummaryScreenInst:Init()
