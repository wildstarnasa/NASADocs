require "Window"
require "Unit"
require "GameLib"
require "Tooltip"
require "GroupLib"

local kHealthStart = 0
local kHealthInGreen = 1
local kHealthInYellow = 2
local kHealthInOrange = 3
local kHealthInRed = 4
local kHealthDead = 5

local PlayerFrame = {}
local EnumGroupSetup = {}

local ksLootThreshIds = {
	"LootThreshAverage",
	"LootThreshGood",
	"LootThreshExcellent",
	"LootThreshSuperb",
	"LootThreshExquisite",
	"LootThreshPhenomenal",
	"LootThreshExtraordinary",
	"LootThreshLegendary",
}

local ksLootTypeIds = {
	"LootDistributionMaster",
	"LootDistributionGroup",
	"LootDistributionNBG",
}

-------------------------------------------------------------------------
------------ modulization -----------------------------------------------
-------------------------------------------------------------------------
function PlayerFrame:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	return o
end

function PlayerFrame:Init()
	Apollo.RegisterAddon(self)
end

function PlayerFrame:OnLoad()
	--[[ Disabling the player frame
	Apollo.RegisterSlashCommand("pf", "OnPlayerFrameOn", self)
	Apollo.RegisterEventHandler("VarChange_FrameCount", "OnUpdate", self)
--	Apollo.RegisterEventHandler("UI_HealthChanged", "UpdateHealth", self)
--	Apollo.RegisterEventHandler("UI_EnergyChanged", "UpdateEnergy", self)
--	Apollo.RegisterEventHandler("UI_LevelChanged", "UpdateLevel", self)
--	Apollo.RegisterEventHandler("UnitNameChanged", "UpdateUnitName", self)
	Apollo.RegisterEventHandler("ContainsMouse", "ContainsMouse", self)
--	Apollo.RegisterEventHandler("MouseMove", "OnMouseMove", self)
	Apollo.RegisterEventHandler("PlayerPortraitMessage", "OnPlayerPortraitMessage", self)
	Apollo.RegisterEventHandler("UnitEnteredCombat", "OnEnteredCombat", self)
	Apollo.RegisterEventHandler("ShowResurrectDialog", "OnDeath", self)
	Apollo.RegisterEventHandler("Mount", "OnMount", self)
	Apollo.RegisterEventHandler("DamageOrHealingDone", "OnDamageOrHealing", self)

	--Apollo.LoadSprites("PlayerFrameSprites.xml")
	--Apollo.LoadSprites("UI\\SpriteDocs\\CRB_PlayerFrameSprites.xml")
	
	self.wndPlayerFrame = Apollo.LoadForm("PlayerFrame.xml", "PlayerFrame", nil, self)
	
	self.wndMountFrame = Apollo.LoadForm("PlayerFrame.xml", "MountFrame", nil, self)
	self.wndMountFrame:Show(false)
	self.wndMountModel = self.wndMountFrame:FindChild("Model")
	
	self.wndGroupSetupMenu = Apollo.LoadForm("PlayerFrame.xml", "GroupSetupMenu", nil, self)
	self.wndGroupSetupMenu:Show(false)
	
	--self.wndPlayerFrame:FindChild("HealthTint"):SetBarColor(CColor.new(0.96, 1.52, 0.36, 2.0))
	--self.wndPlayerFrame:FindChild("EnergyTint"):SetBarColor(CColor.new(0.14, 1.1, 1.5, 2.0))
	
	self.GroupSetupGrid = self.wndGroupSetupMenu:FindChild("GroupSetUpGrid")
	self.LootRuleGrid = self.wndGroupSetupMenu:FindChild("LootRuleGrid")
	self.LootThresholdGrid = self.wndGroupSetupMenu:FindChild("LootThresholdGrid")
	self.DungeonDifficultyGrid = self.wndGroupSetupMenu:FindChild("DungeonDifficultyGrid")
	self.PartyTypeGrid = self.wndGroupSetupMenu:FindChild("PartyTypeGrid")
	self.IconShowGrid = self.wndGroupSetupMenu:FindChild("IconShowGrid")
	self.IconMarkingGrid = self.wndGroupSetupMenu:FindChild("IconMarkingGrid")
	self.wndModel = self.wndPlayerFrame:FindChild("Model")
	self.wndLeaderIndicator = self.wndPlayerFrame:FindChild("GroupLeader")
	
	self.wndStatus = self.wndPlayerFrame:FindChild("FloaterText")
	self.bMessage = false
	self.fTimeMessageStart = 0
	self.unitPlayer = nil
	
	self.healthState = kHealthStart
	
	self.wndCombatSprite = self.wndPlayerFrame:FindChild("CombatNotice")
	self.wndCombatSprite:Show(false)
	]]--
end

function PlayerFrame:OnPlayerFrameOn()
	self.wndPlayerFrame:Show(not self.wndPlayerFrame:IsShown())
end

function PlayerFrame:OnSave(eType)
	return nil
end

function PlayerFrame:OnRestore(eType, t)
end


function PlayerFrame:OnMouseMove(wnd, wndControl, x, y)
	if wnd ~= wndControl then
		self.wndPlayerFrame:SetTooltip ("")
		return
	end
	
	--[[local deathFrame = self.wndPlayerFrame:FindChild("DeathPenaltyBar")
	if deathFrame ~= wnd then 
		self.wndPlayerFrame:SetTooltip ("")
		return
	end
	
	if deathFrame:IsVisible() == false then
		self.wndPlayerFrame:SetTooltip ("")
		return
	end
	
	local tooltip = " " .. tostring (self.deathPenaltyMinutes) .. ":"
	if self.deathPenaltySeconds < 10 then 
		tooltip = tooltip .. "0" -- insert a 0 for small values. double 0 for seconds.
	end
	tooltip = tooltip .. tostring (self.deathPenaltySeconds)--]]
		
	self.wndPlayerFrame:SetTooltip (tooltip)
end



------------------------------------------------------------------------------------

function PlayerFrame:UpdateHealth(nCurrentHealth, nMaxHealth)
	--[[
	if unit:GetHealth() ~= nil then
		local HealthTint = winPlayerFrame:FindChild("HealthTint")
		self:HealthTint:Show(true)
		self:SetBarValue(HealthTint, 0, nMaxHealth, nCurrentHealth)
		winPlayerFrame:FindChild("HealthText"):SetText(nCurrentHealth .. " / " .. nMaxHealth)
	else
		self:HealthTint:Show(false)
	end
	]]--
end

function PlayerFrame:UpdateEnergy(nCurrentEnergy, nMaxEnergy)
	--[[
	if unit:ShouldShowEnergyBar() then
		local EnergyTint = winPlayerFrame:FindChild("EnergyTint")
		
		self:EnergyTint:Show(true)
		
		self:SetBarValue(EnergyTint, 0, nMaxEnergy, nCurrentEnergy)
		winPlayerFrame:FindChild("EnergyText"):SetText(nCurrentEnergy .. " / " .. nMaxEnergy)
	else
		self:EnergyTint::Show(false)
	end
	]]--
end


function PlayerFrame:UpdateLevel(iLevel)
	--[[
	winPlayerFrame:FindChild("UnitLevel"):SetText(iLevel)
	]]--	
end

-------------------------------------------------------------------------------------
function PlayerFrame:UpdateUnitName(unit, sUnitName)
--[[	if unit == self.unitPlayer and self.unitPlayer ~= nil then
		self:SetUnitName(self.wndPlayerFrame, self.unitPlayer, bUnitChanged)
	end--]]
end

-------------------------------------------------------------------------------------
function PlayerFrame:OnUpdate(pszVar, nValue)
	local unitPlayer = GameLib.GetPlayerUnit()
	local bUnitChanged = false
	if self.unitPlayer == nil or self.unitPlayer ~= unitPlayer then
		self.unitPlayer = unitPlayer
		if self.unitPlayer ~= nil then
			--Apollo.DPF("Setting player frame to unitPlayer")
			bUnitChanged = true
			self.wndModel:SetCostume(self.unitPlayer)
		end
	end
	if self.unitPlayer ~= nil then
		local stats = unitPlayer:GetBasicStats ()
		if stats ~= nil then
			self:SetUnitHealth(self.wndPlayerFrame, stats)
			self:SetUnitEnergy(self.wndPlayerFrame, stats)
			--self:SetUnitLevel(self.wndPlayerFrame, stats, bUnitChanged)
			--self:SetUnitName(self.wndPlayerFrame, stats, bUnitChanged)
			--self:UpdateDeathPenalty(self.wndPlayerFrame, stats)
		end

		self.wndLeaderIndicator:Show(GroupLib.InGroup() and GroupLib.AmILeader())
		
		if bUnitChanged then
			self:SetUnitForBuffIcons(self.wndPlayerFrame, self.unitPlayer)
		end		

		local unitMount = GameLib.GetPlayerMountUnit()
		local bMountChanged = false
		if unitMount and self.unitMount ~= unitMount then
			self.unitMount = unitMount
			bMountChanged = true
			--Apollo.DPF("Calling Mount SetCostume")
			self.wndMountModel:SetCostume(unitMount)
		end
		
		if unitMount ~= nil then
			stats = unitMount:GetBasicStats()
			if stats ~= nil then
				self.wndMountFrame:Show(true)
				self:SetUnitHealth(self.wndMountFrame, stats)
				self:SetUnitEnergy(self.wndMountFrame, stats)
				self:SetUnitName(self.wndMountFrame, stats, bMountChanged)
			end
		else
			self.wndMountFrame:Show(false)
		end
		
	end
	if not self.bMessage then
		return
	end
	
	local fMessageAge = GameLib.GetGameTime() - self.fTimeMessageStart
	if fMessageAge > 1.5 then
		self.bMessage = false
		self.fTimeMessageStart = 0
		self.wndStatus:SetText("")
	else
		if fMessageAge > 1.0 then
			local fMessageAlpha = (1.5 - fMessageAge) * 2.0
			self.crMessageText.a = fMessageAlpha
			self.wndStatus:SetTextColor(self.crMessageText)
		end
	end	
end


-------------------------------------------------------------------------------
-- These functions take a window and a unit

function PlayerFrame:SetUnitForBuffIcons(winPlayerFrame, unit)
	local winBeneBar = winPlayerFrame:FindChild("BeneBuffBar")
	local winHarmBar = winPlayerFrame:FindChild("HarmBuffBar")
	for iBuff = 1, 8 do
		local winBuff = winBeneBar:FindChild("Player.BuffIcon" .. tostring(iBuff))
		winBuff:SetUnit(unit)
		winBuff = winHarmBar:FindChild("Player.BuffIcon" .. tostring(iBuff))
		winBuff:SetUnit(unit)
	end
end

--[[ 	there are different sprites for each health state
		I'll put them all into a list
		APB 2/17/2011
--]]
--    DeathState		Green				Yellow					Orange					Red					Dead
local ringSprites = { "", 				"sprLHRing_Yellow", 	"sprLHRing_Orange", 	"sprLHRing_Red", 				"" }
local hbSprites = 	{ "sprHealthFill", 	"sprLHBar_YellowPF", 	"sprLHBar_OrangePF", 	"sprLHBar_RedPF", "sprLHBar_RedPF" }
local edgeSprite = 	{ "sprHealthEndCap", "", 					"", 					"", 					 		""}
local backerSprites = { "", 			"sprLHBar_YellowFrame2PF", "sprLHBar_OrangeFrame2PF", "sprLHBar_RedFrame2PF", ""}

function PlayerFrame:SetUnitHealth(winPlayerFrame, stats)
	if stats.health ~= nil then
		--winPlayerFrame:FindChild("HealthTint"):Show(true)
		local UnitHealth = stats.health
		local UnitMaxHealth = stats.maxHealth

		local percentage = UnitHealth/UnitMaxHealth
		local needToSetSprites = false
		
		if percentage == 0 then
			if self.healthState ~= kHealthDead then
				self.healthState = kHealthDead
				needToSetSprites = true;
			end
		elseif percentage < 0.2 then
			if self.healthState ~= kHealthInRed then
				self.healthState = kHealthInRed
				needToSetSprites = true;
			end
		elseif percentage < 0.3 then
			if self.healthState ~= kHealthInOrange then
				self.healthState = kHealthInOrange
				needToSetSprites = true;
			end
		elseif percentage < 0.4 then
			if self.healthState ~= kHealthInYellow then
				self.healthState = kHealthInYellow
				needToSetSprites = true;
			end
		else
			if self.healthState ~= kHealthInGreen then
				self.healthState = kHealthInGreen
				needToSetSprites = true;
			end
		end

		if needToSetSprites == true then
			self.wndPlayerFrame:FindChild("LowHealthFrame"):SetSprite(ringSprites[self.healthState])
			--self.wndPlayerFrame:FindChild("HealthTint"):SetFullSprite(hbSprites[self.healthState])
			--self.wndPlayerFrame:FindChild("HealthTint"):SetGlowSprite(edgeSprite[self.healthState])
			--self.wndPlayerFrame:FindChild("HealthTintBack"):SetSprite(backerSprites[self.healthState])
		end
		
		--self:SetBarValue(winPlayerFrame:FindChild("HealthTint"), 0, UnitMaxHealth, UnitHealth)
		--winPlayerFrame:FindChild("HealthText"):SetText(UnitHealth .. " / " .. UnitMaxHealth)
	else
		--winPlayerFrame:FindChild("HealthTint"):Show(false)
	end
end

function PlayerFrame:SetUnitEnergy(winPlayerFrame, stats)
--[[	if stats.health ~= nil then
		--winPlayerFrame:FindChild("EnergyTint"):Show(true)
		local UnitEnergy = stats.resource0
		local UnitEnergyMin = stats.resource0min
		local UnitEnergyMax = stats.resource0max
		
		--self:SetBarValue(winPlayerFrame:FindChild("EnergyTint"), UnitEnergyMin, UnitEnergyMax, UnitEnergy)
		
		--winPlayerFrame:FindChild("EnergyText"):SetText(UnitEnergy .. " / " .. UnitEnergyMax)
	else
		--winPlayerFrame:FindChild("EnergyTint"):Show(false)
	end--]]
end

function PlayerFrame:SetUnitLevel(winPlayerFrame, stats, bUnitChanged)
	--[[if stats.effectiveLevel > 0 then
		self.UnitLevel = stats.effectiveLevel
		winPlayerFrame:FindChild("UnitLevel"):SetText(self.UnitLevel .. ' (' .. stats.level .. ')')
	else
		self.UnitLevel = stats.level
		winPlayerFrame:FindChild("UnitLevel"):SetText(self.UnitLevel)
	end--]]
end

function PlayerFrame:SetUnitName(winPlayerFrame, stats, bUnitChanged)
--[[	if bUnitChanged then
		self.UnitName = stats.name
		winPlayerFrame:FindChild("UnitName"):SetText(self.UnitName)
	end--]]
end

function PlayerFrame:SetBarValue(winBar, fMin, fMax, fValue)
	--[[winBar:SetMax(fMax)
	winBar:SetFloor(fMin)
	winBar:SetProgress(fValue)--]]
	
	--TEST LINE
	--winBar:Show(false)
end


function PlayerFrame:UpdateDeathPenalty(winPlayerFrame, stats)
--[[	local deathFrame = self.wndPlayerFrame:FindChild("DeathPenaltyBar")
	local wndPips = {}
	for i = 0,7 do
		wndPips[i] = self.wndPlayerFrame:FindChild("DeathTimerPip" .. tostring(i))
	end 
	
	deathFrame:Show(true)
	local penaltyMinutes = 0
	local fMinPerPip = 5.0
	if stats.shouldShowDeathPenalty == true then
		penaltyMinutes = stats.deathPenaltyMinutes
		if penaltyMinutes < 0 then
			penaltyMinutes = 0
		end
		if penaltyMinutes > 40 then 
			penaltyMinutes = 40
		end
		
		self.deathPenaltyMinutes = stats.deathPenaltyMinutes
		self.deathPenaltySeconds = stats.deathPenaltySeconds
		local str = Apollo.GetString("CRB_Death_Timer_") .. tostring(stats.deathPenaltyMinutes) .. Apollo.GetString("CRB_m_") .. tostring(stats.deathPenaltySeconds) .. Apollo.GetString("CRB_s")
		self.wndPlayerFrame:SetTooltip(str)
	else
		self.wndPlayerFrame:SetTooltip ("")
		self.deathPenaltyMinutes = 0
		self.deathPenaltySeconds = 0
	end

	for i = 0,7 do
		local alpha = 0
		if penaltyMinutes > (i * fMinPerPip) then
			alpha = (penaltyMinutes - i * fMinPerPip) / (fMinPerPip)
			if alpha > 1.0 then
				alpha = 1.0
			end
		end
		wndPips[i]:SetBGColor(CColor.new(1.0, 1.0, 1.0, alpha))
	end
		
		--]]
end

function PlayerFrame:OnMountMouseClick(wnd, wndControl, iButton, x, y, bDouble)

end

function PlayerFrame:OnGenerateTooltip(wndControl, wndHandler, tType, spell)
	Tooltip.GetBuffTooltipForm(self, wndControl, spell)
end

-------------------------------------------------------------------------------- Group Options -------------------------------------------------------------------------------
function PlayerFrame:OnMouseClick(wnd, wndControl, iButton, x, y, bDouble)
	if wnd:GetId() ~= wndControl:GetId() then
		return false
	end
		
	if iButton == 0 then
		GameLib.SetTargetUnit(self.unitPlayer)
	end
	
	if iButton == 1 then
		if IsDemo() then 
			return
		end		
		
		local menu = Menu.new("PlayerFrameMenu.xml", "PlayerFrameMenu")
		
		local bInGroup = GroupLib.InGroup()
		local bLeader = bInGroup and GroupLib.AmILeader()
		
		menu:EnableMenuItem("LeaveGroup", bInGroup)
		
		local iCurThresh = GroupLib.GetLootThreshold()
		for iThresh=1,#ksLootThreshIds do
			if bInGroup then
				if iCurThresh == iThresh then
					menu:SetItemImage(ksLootThreshIds[iThresh], "LootCloseBox")
				else
					menu:SetItemImage(ksLootThreshIds[iThresh], "")
				end
			else
				menu:EnableMenuItem(ksLootThreshIds[iThresh], false)
			end
		end
		
		local iCurType = GroupLib.GetLootDistribution()
		for iType=1,#ksLootTypeIds do
			if bInGroup and bLeader then
				if iCurType == iType then
					menu:SetItemImage(ksLootTypeIds[iType], "LootCloseBox")
				else
					menu:SetItemImage(ksLootTypeIds[iType], "")
				end
			else
				menu:EnableMenuItem(ksLootTypeIds[iType], false)
			end
		end
		
		menu:DoPopupMenu(self.wndPlayerFrame, x, y, self)
		return true	-- stop propagation
	end
	
	--[[
	if self.wndGroupSetupMenu:IsVisible() then
		self.wndGroupSetupMenu:Show(false)
	else
		if iButton == 1 then
			self:SetGroupSetupMenu()
			self.wndGroupSetupMenu:Show(true)
			self:HideSecondaryGrids()
		end
	end
	--]]
	return false
end

function PlayerFrame:OnLeaveGroup()
	GroupLib.LeaveGroup()
end

function PlayerFrame:SetGroupSetupMenu()
	self.GroupSetupGrid:DeleteAll()
	
	self.tSetupMenu = GroupLib.GetSetupMenu()
	--self.tGroupSetup = GroupLib.GetSetupMenu()
	
	for index, CurrentElement in pairs(self.tSetupMenu) do
--		local iIdx = CurrentElement.index
--		local sMenuElements = CurrentElement.localizedString
--		local sLookupValue = CurrentElement.lookupString
		
		self.GroupSetupGrid:AddRow(CurrentElement.localizedString, "", CurrentElement.index)
	end
end

function PlayerFrame:OnLootThresh(wndControl, wndHandler, iRow, strId)
	
	for iThresh = 1,#ksLootThreshIds do
		if strId == ksLootThreshIds[iThresh] then
			GroupLib.SetLootThreshold(iThresh)
		end
	end
end

function PlayerFrame:OnLootType(wndControl, wndHandler, iRow, strId)
	for iType = 1,#ksLootTypeIds do
		if strId == ksLootTypeIds[iType] then
			GroupLib.SetLootDistribution(iType)
		end
	end
end

function PlayerFrame:SelectMenuItem(wndControl, wndHandler, grdRow)
	
	local tLootRule = GroupLib.GetLootRuleList()
	local tLootThreshold = GroupLib.GetLootThresholdList()
	local tDungeonDifficulty = GroupLib.GetDungeonDifficultyList()
	local tPartyType = GroupLib.GetGroupTypeList()
	
	self:HideSecondaryGrids()
	
	if grdRow == 0 then
		self.LootRuleGrid:DeleteAll()
		
		for listIdx, sCurrentIdx in ipairs(tLootRule) do
			self.LootRuleGrid:AddRow(sCurrentIdx.localizedString, "", sCurrentIdx.id)
		end
		
		self.LootRuleGrid:Show(true)
		
	elseif grdRow == 1 then
		self.LootThresholdGrid:DeleteAll()
		
		for listIdx, sCurrentIdx in ipairs(tLootThreshold) do
			self.LootThresholdGrid:AddRow(sCurrentIdx.localizedString, "", sCurrentIdx.id)
		end
		
		self.LootThresholdGrid:Show(true)

	elseif grdRow == 2 then
		self.DungeonDifficultyGrid:DeleteAll()
		
		for listIdx, sCurrentIdx in ipairs(tDungeonDifficulty) do
			self.DungeonDifficultyGrid:AddRow(sCurrentIdx.localizedString, "", sCurrentIdx.id)
		end
		
		self.DungeonDifficultyGrid:Show(true)
	elseif grdRow == 3 then	
		self.PartyTypeGrid:DeleteAll()
		
		for listIdx, sCurrentIdx in ipairs(tPartyType) do
			self.PartyTypeGrid:AddRow(sCurrentIdx.localizedString, "", sCurrentIdx.id)
		end
		
		self.PartyTypeGrid:Show(true)
	
	elseif grdRow == 4 then
		--Apollo.DPF("Icons Display nyi")
	
	elseif grdRow == 5 then
		--Apollo.DPF("Icons Marking nyi")
	
	elseif grdRow == 6 then
		GroupLib.PromotePlayer()
		--Apollo.DPF("Promote Player NYI")
	elseif grdRow == 7 then
		GroupLib.DemotePlayer()
		--Apollo.DPF("Demote Player NYI")
	elseif grdRow == 9 then
		--Apollo.DPF("Remove Player NYI")
	
	elseif grdRow == 10 then
		--Apollo.DPF("Leave Party NYI")
	else
		--Apollo.DPF("Error: Invalid Group Menu Index ... See PlayerFrame.lua")
	end
end

function PlayerFrame:SelectLootRule(wndControl, wndHandler, grdRow)
	--Apollo.DPF(grdRow)
	--GroupLib.SetLootRule(grdRow)
end

function PlayerFrame:SelectLootThreshold(wndControl, wndHandler, grdRow)
	GroupLib.SetLootThreshold(grdRow)
	--self.LootThresholdGrid:Show(false)
end

function PlayerFrame:SelectDungeonDifficulty(wndControl, wndHandler, grdRow)
	GroupLib.SetGroupDungeonDifficulty(grdRow)
end

function PlayerFrame:SelectPartyType(wndControl, wndHandler, grdRow)
	GroupLib.SetGroupType(grdRow)
end

function PlayerFrame:HideSecondaryGrids()
	self.LootRuleGrid:Show(false)
	self.LootThresholdGrid:Show(false)
	self.DungeonDifficultyGrid:Show(false)
	self.PartyTypeGrid:Show(false)
	self.IconShowGrid:Show(false)
	self.IconMarkingGrid:Show(false)
end

function PlayerFrame:OnPlayerPortraitMessage(pszMessage, crText)
	self.wndStatus:SetText(pszMessage)
	self.wndStatus:SetTextColor(crText)
	self.bMessage = true
	self.fTimeMessageStart = GameLib.GetGameTime()
	self.crMessageText = crText
end

function PlayerFrame:OnEnteredCombat(unit, bInCombat)
	if unit == GameLib.GetPlayerUnit() then
		if bInCombat then
			self.wndCombatSprite:Show(true)
		else
			self.wndCombatSprite:Show(false)
		end
		
		if not bInCombat then
			self.wndCombatSprite:Show(false)
		end
	end
end

function PlayerFrame:OnDeath()
	if self.wndCombatSprite:IsVisible() then
	self.wndCombatSprite:Show(false)
	end
end	
	
function PlayerFrame:OnMount(bMounted)
	if bMounted then
		--Print("I'm on a mount!")
	else
		--Print("I'm on neither a mount nor a boat!")
		self.wndMountFrame:Show(false)
	end
end

function PlayerFrame:OnDamageOrHealing( unitCaster, unitTarget, eDamageType, nDamage, nShieldDamaged, nAbsorptionAmount, bCritical )

    -- display the damage on portrait
   
    if not unitTarget or not GameLib.IsControlledUnit( unitTarget ) then -- if the target unit is player's char
        return
    end
    
    local crText = CColor.new(1.0, 1.0, 1.0, 1.0)
    if  eDamageType == GameLib.CodeEnumDamageType.Physical then
       crText = CColor.new(1.0, 1.0, 1.0, 1.0)
    elseif eDamageType == GameLib.CodeEnumDamageType.Tech then
        crText =  CColor.new(1.0, 1.0, 0.0, 1.0) 
    elseif eDamageType == GameLib.CodeEnumDamageType.Magic then
        crText = CColor.new(0.3, 0.8, 0.8, 1.0)
    elseif eDamageType == GameLib.CodeEnumDamageType.Heal then
        crText = CColor.new(0.0, 1.0, 0.4, 1.0)
    end
    
	self.wndStatus:SetText(nDamage)
	self.wndStatus:SetTextColor(crText)
	self.bMessage = true
	self.fTimeMessageStart = GameLib.GetGameTime()
	self.crMessageText = crText
	
end
	
-------------------------------- instance ----------------------------------------------
local PlayerFrameInstance = PlayerFrame:new()
PlayerFrame:Init()
