-----------------------------------------------------------------------------------------------
-- Client Lua Script for Reputation
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "GameLib"

local Reputation = {}
local karRepToColor = 
{
	ApolloColor.new("ff9aaea3"),
	ApolloColor.new("ff9aaea3"), -- Neutral
	ApolloColor.new("ff836725"), -- Liked
	ApolloColor.new("ffc1963d"), -- Accepted
	ApolloColor.new("fff1efda"), -- Popular
	ApolloColor.new("fffefbb5"), -- Esteemed
	ApolloColor.new("ffd5b66d"), -- Beloved
}

--local karRepToBarColor = 
--{ -- TODO: SetBarColor on ProgressBars need to take ApolloColor.new
--	CColor.new(154/255, 174/255, 163/255, 1),
--	CColor.new(154/255, 174/255, 163/255, 1), -- Neutral
--	CColor.new(131/255, 103/255, 37/255, 1), -- Liked
--	CColor.new(193/255, 150/255, 61/255, 1), -- Accepted
--	CColor.new(241/255, 239/255, 218/255, 1), -- Popular
--	CColor.new(254/255, 251/255, 181/255, 1), -- Esteemed
--	CColor.new(213/255, 182/255, 109/255, 1) -- Beloved
--}
	
function Reputation:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function Reputation:Init()
    Apollo.RegisterAddon(self)
end

-----------------------------------------------------------------------------------------------
-- Reputation OnLoad
-----------------------------------------------------------------------------------------------

function Reputation:OnLoad()
    Apollo.RegisterSlashCommand("rep", "OnReputationOn", self)
	Apollo.RegisterEventHandler("ToggleReputationInterface", "OnReputationOn", self)
	Apollo.RegisterEventHandler("ReputationChanged", "OnReputationChanged", self)

    self.wndMain = Apollo.LoadForm("Reputation.xml", "ReputationForm", nil, self)
	self.tReputationLevels = GameLib.GetReputationLevels()
	self.tStrToWndMapping = {}

	-- Default Height Constants
	local wndHeight = Apollo.LoadForm("Reputation.xml", "ListItemLabel", self.wndMain, self)
	local nLeft, nTop, nRight, nBottom = wndHeight:GetAnchorOffsets()
	self.knHeightLabel = nBottom - nTop
	wndHeight:Destroy()

	wndHeight = Apollo.LoadForm("Reputation.xml", "ListItemProgress", self.wndMain, self)
	nLeft, nTop, nRight, nBottom = wndHeight:GetAnchorOffsets()
	self.knHeightProgress = nBottom - nTop
	wndHeight:Destroy()

	wndHeight = Apollo.LoadForm("Reputation.xml", "ListItemTopLevel", self.wndMain, self)
	nLeft, nTop, nRight, nBottom = wndHeight:GetAnchorOffsets()
	self.knHeightTop = nBottom - nTop
	wndHeight:Destroy()
	
	self.tRepCount = 0
	
	self.tTopLabels = {}
	self.tSubLabels = {}
	self.tProgress	= {}
end

-----------------------------------------------------------------------------------------------
-- Reputation Functions
-----------------------------------------------------------------------------------------------

function Reputation:OnReputationOn()
	self.wndMain:Show(true)
	self.wndMain:ToFront()
	self.wndMain:FindChild("BGHeaderText"):SetText(String_GetWeaselString(Apollo.GetString("Reputation_Header"), GameLib.GetPlayerUnit():GetTitleOrName()))
	self:ResetData()
	self:PopulateFactionList()
end

function Reputation:OnClose()
	self:ResetData()
	self.wndMain:Close()
end

function Reputation:ResetData()
	self.tStrToWndMapping = {}
	self.wndMain:FindChild("FactionList"):DestroyChildren()
end

function Reputation:OnReputationChanged(tFaction)
	if not self.wndMain or not self.wndMain:IsShown() then return end
	if self.tStrToWndMapping[tFaction.strParent] then -- Find if the parent and it exists
		for key, wndCurr in pairs(self.tStrToWndMapping[tFaction.strParent]:FindChild("ItemsContainer"):GetChildren()) do
			if wndCurr:GetData() == string.lower(tFaction.nOrder .. tFaction.strName) then
				self:BuildListItemProgress(wndCurr, tFaction)
				return
			end
		end
	end

	-- Add a new entry in the full redraw if we didn't find the parent or itself
	self:ResetData()
	self:PopulateFactionList()
end

function Reputation:SortReps(tRepTable)
	self.tTopLabels = {}
	self.tSubLabels = {}
	self.tProgress = {}
	for idx, tReputation in pairs(tRepTable) do
		local bHasParent = tReputation.strParent and string.len(tReputation.strParent) > 0
		if not bHasParent then
			table.insert(self.tTopLabels, tReputation)
		elseif tReputation.bIsLabel then
			table.insert(self.tSubLabels, tReputation)
		else
			table.insert(self.tProgress, tReputation)
		end
	end
end

function Reputation:PopulateFactionList()
	local tReputations = GameLib.GetReputationInfo()
	if not tReputations then
		return
	end
	
	self.tRepCount = #tReputations
	self:SortReps(tReputations)
	
	local nSafetyCount = 0
	for idx, tReputation in pairs(self.tTopLabels) do
		nSafetyCount = nSafetyCount + 1
		if nSafetyCount < 99 then
			self:BuildFaction(tReputation, nil)
		end
	end
	
	for idx, tReputation in pairs (self.tSubLabels) do
		nSafetyCount = nSafetyCount + 1
		if nSafetyCount < 99 then
			self:BuildFaction(tReputation, self.tStrToWndMapping[tReputation.strParent])
		end
	end
	
	for idx, tReputation in pairs (self.tProgress) do
		nSafetyCount = nSafetyCount + 1
		if nSafetyCount < 99 then
			self:BuildFaction(tReputation, self.tStrToWndMapping[tReputation.strParent])
		end
	end

		
			-- Else condition is bHasParent but not mapped yet, in which case we try again later

	if nSafetyCount >= 99 then
		for idx, tFaction in pairs(tReputations) do
			ChatSystemLib.PostOnChannel(ChatSystemLib.ChatChannel_Debug, String_GetWeaselString(Apollo.GetString("Reputation_NotFound"), tFaction.strParent))
		end
	end

	-- Sort list
	for key, wndCurr in pairs(self.tStrToWndMapping) do
		wndCurr:FindChild("ItemsContainer"):ArrangeChildrenVert(0, function(a,b) return (a:GetData() < b:GetData()) end)
	end
	self.wndMain:FindChild("FactionList"):ArrangeChildrenVert(0, function(a,b) return (a:GetData() < b:GetData()) end)

	self:ResizeItemContainer()
end

function Reputation:BuildFaction(tFaction, wndParent)
	-- This method is agnostic to what level it is at. It must work for level 2 and level 3 data and thus the XML has the same window names at all levels.
	if wndParent and not wndParent:FindChild("ItemsBtn"):IsChecked() then
		return
	end

	local wndCurr = nil
	-- There are 3 types of windows: Progress Bar, Labels with children, and Top Level (which has different bigger button art)
	if not wndParent then
		wndCurr = Apollo.LoadForm("Reputation.xml", "ListItemTopLevel", self.wndMain:FindChild("FactionList"), self)
		wndCurr = self:BuildTopLevel(wndCurr, tFaction)
	elseif tFaction.bIsLabel then
		wndCurr = Apollo.LoadForm("Reputation.xml", "ListItemLabel", wndParent:FindChild("ItemsContainer"), self)
		wndCurr:FindChild("ItemsBtn"):SetCheck(true)
		wndCurr:FindChild("ItemsBtnText"):SetText(tFaction.strName)
		self.tStrToWndMapping[tFaction.strName] = wndCurr
	else
		wndCurr = Apollo.LoadForm("Reputation.xml", "ListItemProgress", wndParent:FindChild("ItemsContainer"), self)
		wndCurr = self:BuildListItemProgress(wndCurr, tFaction)
	end

	-- This data is used for sorting (First by Order then by Name if there is a tie. Lua's "<" operator will handle this on string comparisons.)
	wndCurr:SetData(string.lower(tFaction.nOrder .. tFaction.strName))
end

function Reputation:BuildTopLevel(wndCurr, tFaction)
	wndCurr:FindChild("ItemsBtn"):SetCheck(true)
	wndCurr:FindChild("ItemsBtnText"):SetText(tFaction.strName)
	wndCurr:FindChild("BaseProgressLevelBarC"):Show(not tFaction.bIsLabel)
	if not tFaction.bIsLabel then
		local tLevelData = self.tReputationLevels[tFaction.nLevel]
		wndCurr:FindChild("BaseProgressLevelBar"):SetMax(tLevelData.nMax)
		wndCurr:FindChild("BaseProgressLevelBar"):SetProgress(tFaction.nCurrent)
		wndCurr:FindChild("BaseProgressLevelText"):SetText(String_GetWeaselString(Apollo.GetString("Achievements_ProgressBarProgress"), tFaction.nCurrent, tLevelData.nMax))
	end
	wndCurr:FindChild("ItemsBtn"):ArrangeChildrenVert(1)
	self.tStrToWndMapping[tFaction.strName] = wndCurr
	return wndCurr
end

function Reputation:BuildListItemProgress(wndCurr, tFaction)
	local tLevelData = self.tReputationLevels[tFaction.nLevel]
	wndCurr:FindChild("ProgressName"):SetText(tFaction.strName)
	wndCurr:FindChild("ProgressStatus"):SetText(tLevelData.strName)
	wndCurr:FindChild("ProgressStatus"):SetTextColor(karRepToColor[tFaction.nLevel + 1])
	wndCurr:FindChild("ProgressLevelBar"):SetMax(tLevelData.nMax)
	wndCurr:FindChild("ProgressLevelBar"):SetProgress(tFaction.nCurrent)
	wndCurr:FindChild("ProgressLevelBar"):SetBarColor(karRepToColor[tFaction.nLevel + 1])
	wndCurr:FindChild("ProgressLevelBar"):EnableGlow(tFaction.nCurrent > tLevelData.nMin)
	wndCurr:FindChild("ProgressLevelBarText"):SetText(String_GetWeaselString(Apollo.GetString("Achievements_ProgressBarProgress"), tFaction.nCurrent, tLevelData.nMax))
	wndCurr:SetTooltip(string.format("<P Font=\"CRB_InterfaceMedium\">%s</P>", String_GetWeaselString(Apollo.GetString("Reputation_ProgressText"), tFaction.strName, tLevelData.strName, tFaction.nCurrent, tLevelData.nMax)))
	return wndCurr
end

-----------------------------------------------------------------------------------------------
-- Resize Code
-----------------------------------------------------------------------------------------------

function Reputation:OnTopLevelToggle(wndHandler, wndControl) -- wndHandler is "ListItemTopLevel's ItemsBtn"
	self:ResizeItemContainer()
	if wndHandler:IsChecked() then
		wndHandler:FindChild("ItemsBtnText"):SetTextColor(ApolloColor.new("ff31fcf6"))
	else
		wndHandler:FindChild("ItemsBtnText"):SetTextColor(ApolloColor.new("ff5f6662"))
	end
end

function Reputation:OnMiddleLevelLabelToggle(wndHandler, wndControl) -- wndHandler "ListItemLabel's ItemsBtn"
	self:ResizeItemContainer()
	if wndHandler:IsChecked() then
		wndHandler:FindChild("ItemsBtnText"):SetTextColor(ApolloColor.new("ff9a8460"))
	else
		wndHandler:FindChild("ItemsBtnText"):SetTextColor(ApolloColor.new("ff5f6662"))
	end
end

function Reputation:ResizeItemContainer()
	for key, wndTopGroup in pairs(self.wndMain:FindChild("FactionList"):GetChildren()) do
		wndTopGroup:Show(#wndTopGroup:FindChild("ItemsContainer"):GetChildren() > 0)

		if wndTopGroup:IsShown() then
			local nMiddleHeight = 0
			wndTopGroup:FindChild("ItemsContainer"):Show(wndTopGroup:FindChild("ItemsBtn"):IsChecked())
			if wndTopGroup:FindChild("ItemsBtn"):IsChecked() then
				for idx, wndMiddleGroup in pairs(wndTopGroup:FindChild("ItemsContainer"):GetChildren()) do
					wndMiddleGroup:Show(not wndMiddleGroup:FindChild("ItemsContainer") or #wndMiddleGroup:FindChild("ItemsContainer"):GetChildren() > 0)

					if wndMiddleGroup:IsShown() then
						local nBottomHeight = 0
						local nHeightToUse = self.knHeightProgress

						-- Special formatting if it has a container (different height, show/hide, and arrange vert)
						if wndMiddleGroup:FindChild("ItemsContainer") then
							nHeightToUse = self.knHeightLabel

							wndMiddleGroup:FindChild("ItemsContainer"):Show(wndMiddleGroup:FindChild("ItemsBtn"):IsChecked())
							if wndMiddleGroup:FindChild("ItemsBtn"):IsChecked() then
								nBottomHeight = self.knHeightProgress * #wndMiddleGroup:FindChild("ItemsContainer"):GetChildren()
							end
							wndMiddleGroup:FindChild("ItemsContainer"):ArrangeChildrenVert(0)
						end
						-- End special formatting

						local nLeft, nTop, nRight, nBottom = wndMiddleGroup:GetAnchorOffsets()
						wndMiddleGroup:SetAnchorOffsets(nLeft, nTop, nRight, nTop + nBottomHeight + nHeightToUse)
						nMiddleHeight = nMiddleHeight + nBottomHeight + nHeightToUse
					end
				end
			end

			local nLeft, nTop, nRight, nBottom = wndTopGroup:GetAnchorOffsets()
			wndTopGroup:SetAnchorOffsets(nLeft, nTop, nRight, nTop + nMiddleHeight + self.knHeightTop)
			wndTopGroup:FindChild("ItemsContainer"):ArrangeChildrenVert(0)
		end
	end

	self.wndMain:FindChild("FactionList"):ArrangeChildrenVert(0)
end

-----------------------------------------------------------------------------------------------
-- Reputation Instance
-----------------------------------------------------------------------------------------------
local ReputationInst = Reputation:new()
ReputationInst:Init()
