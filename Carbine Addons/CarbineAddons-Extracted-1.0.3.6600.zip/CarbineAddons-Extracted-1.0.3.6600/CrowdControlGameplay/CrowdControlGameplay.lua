-----------------------------------------------------------------------------------------------
-- Client Lua Script for CrowdControlGameplay
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "Unit"
require "GameLib"

local CrowdControlGameplay = {}

function CrowdControlGameplay:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function CrowdControlGameplay:Init()
    Apollo.RegisterAddon(self)
end

function CrowdControlGameplay:OnLoad()
	Apollo.RegisterEventHandler("ActivateCCStateStun", "OnActivateCCStateStun", self) -- Starting the UI
	Apollo.RegisterEventHandler("UpdateCCStateStun", "OnUpdateCCStateStun", self) -- Hitting the interact key
	Apollo.RegisterEventHandler("RemoveCCStateStun", "OnRemoveCCStateStun", self) -- Close the UI
	Apollo.RegisterEventHandler("StunVGPressed", "OnStunVGPressed", self)

	Apollo.RegisterTimerHandler("CalculateTimeRemaining", "OnCalculateTimeRemaining", self)
	Apollo.RegisterTimerHandler("CrowdControlGameplay_UnclickArt", "OnCrowdControlGameplay_UnclickArt", self)

	self.wndProgress = nil
	self.nTotalTaps = nil
end

-----------------------------------------------------------------------------------------------
-- Rapid Tap
-----------------------------------------------------------------------------------------------

function CrowdControlGameplay:OnActivateCCStateStun(nTotalTaps, fTotalDuration)
	self.wndProgress = Apollo.LoadForm("CrowdControlGameplay.xml", "ButtonHit_Progress", nil, self)
	self.wndProgress:Show(true) -- to get the animation
	self.wndProgress:FindChild("TimeRemainingContainer"):Show(false)
	self.wndProgress:FindChild("KeyText"):SetText(GameLib.GetKeyBinding("Interact"))

	self.nTotalTaps = nTotalTaps
	--self.fTotalDuration = fTotalDuration

	self:OnCalculateTimeRemaining()
end

function CrowdControlGameplay:OnRemoveCCStateStun()
	if self.wndProgress and self.wndProgress:IsValid() then
		self.wndProgress:Destroy()
		self.wndProgress = nil
		self.nTotalTaps = nil
	end
end

function CrowdControlGameplay:OnUpdateCCStateStun(nCurrentTaps) -- Updates Progress Bar
	if not self.wndProgress or not self.wndProgress:IsValid() then
		return
	end

	if self.wndProgress:FindChild("ProgressBar") then
		local nRate = self.nTotalTaps < 10 and 225 or 75
		self.wndProgress:FindChild("ProgressBar"):SetMax(100)
		self.wndProgress:FindChild("ProgressBar"):SetFloor(0)
		self.wndProgress:FindChild("ProgressBar"):SetProgress(math.min(math.max(nCurrentTaps / self.nTotalTaps * 100, 0), 100), nRate)
	end

	self:OnCalculateTimeRemaining()
end

function CrowdControlGameplay:OnCalculateTimeRemaining()
	local nTimeRemaining = GameLib.GetCCStateStunTimeRemaining()
	if not nTimeRemaining or nTimeRemaining == 0 then
		if self.wndProgress and self.wndProgress:IsValid() then
			Apollo.CreateTimer("CalculateTimeRemaining", 0.1, false) -- Try again, in case it hasn't initialized yet
		end
		return
	end

	if self.wndProgress and self.wndProgress:IsShown() and self.wndProgress:FindChild("TimeRemainingContainer") then
		self.wndProgress:FindChild("TimeRemainingContainer"):Show(true)
		local nMaxTime = self.wndProgress:FindChild("TimeRemainingBar"):GetData()
		if not nMaxTime or nTimeRemaining > nMaxTime then
			nMaxTime = nTimeRemaining
			self.wndProgress:FindChild("TimeRemainingBar"):SetMax(100)
			self.wndProgress:FindChild("TimeRemainingBar"):SetData(nMaxTime)
			self.wndProgress:FindChild("TimeRemainingBar"):SetProgress(100)
		end
		self.wndProgress:FindChild("TimeRemainingBar"):SetProgress(math.min(math.max(nTimeRemaining / nMaxTime * 100, 0), 100), 25) -- 2nd Arg is the rate
	end

	if nTimeRemaining > 0 then
		Apollo.CreateTimer("CalculateTimeRemaining", 0.1, false)
	end
end

function CrowdControlGameplay:OnStunVGPressed(bPushed)
	if self.wndProgress and self.wndProgress:IsValid() then
		Apollo.CreateTimer("CrowdControlGameplay_UnclickArt", 0.1, false)
		self.wndProgress:FindChild("ProgressButtonArt"):SetCheck(bPushed)
	end
end

function CrowdControlGameplay:OnCrowdControlGameplay_UnclickArt()
	if self.wndProgress and self.wndProgress:IsValid() then
		self.wndProgress:FindChild("ProgressButtonArt"):SetCheck(false)
	end
end

local CrowdControlGameplayInst = CrowdControlGameplay:new()
CrowdControlGameplayInst:Init()
