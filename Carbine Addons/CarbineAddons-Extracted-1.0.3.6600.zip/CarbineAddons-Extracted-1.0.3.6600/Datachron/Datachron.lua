-- Client lua script
require "Window"
require "Apollo"
require "DialogSys"
require "Quest"
require "MailSystemLib"
require "Sound"
require "GameLib"
require "Tooltip"
require "XmlDoc"
require "PlayerPathLib"
require "CommunicatorLib"
require "MatchingGame"
require "HousingLib"

local Datachron = {}

local knDatachronShift 			= 192 -- TODO: Hardcoded. How far to shift the tracker when the Datachron is minimized/restored

local kstrModeLabelZone = Apollo.GetString("CRB_Zone_Objectives")
local kstrModeLabelInterface = Apollo.GetString("CRB_Interfaces")
local kstrModeLabelHousing = Apollo.GetString("CRB_Housing_Options")

local kcrTitleEnabled = CColor.new(49/255, 252/255, 246/255, 1)
local kcrTitleDisabled = CColor.new(128/255, 64/255, 64/255, 1)
local kcrBodyEnabled = CColor.new(47/255, 148/255, 172/255, 1)
local kcrBodyDisabled = CColor.new(128/255, 0/255, 0/255, 1)

function Datachron:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self

	self.wndMain = nil
	self.strZoneName = nil
	self.idCreature = nil
	self.idState = nil

	self.idSpamMsg = 0
	return o
end

function Datachron:Init()
	Apollo.RegisterAddon(self)
end

function Datachron:OnLoad()
	Apollo.RegisterEventHandler("Datachron_FlashIndicators", 		"FlashIndicators", self)
	Apollo.RegisterEventHandler("Datachron_HideCallPulse", 			"OnDatachron_HideCallPulse", self)

	Apollo.RegisterEventHandler("ChangeWorld", 						"OnChangeWorld", self) -- From code
	Apollo.RegisterEventHandler("SetPlayerPath", 					"SetPath", self) -- From code

	-- PVP
	Apollo.RegisterEventHandler("MatchEntered", 					"OnPVPMatchEntered", self)
	Apollo.RegisterEventHandler("PVPMatchStateUpdated", 			"OnPVPMatchStateUpdated", self)
	Apollo.RegisterEventHandler("MatchExited", 						"OnPVPMatchExited", self)

	-- Housing
	Apollo.RegisterEventHandler("HousingPanelControlOpen", 			"OnEnteredProperty", self)
	Apollo.RegisterEventHandler("ChangeWorld",						"OnLeftProperty", self)
	Apollo.RegisterEventHandler("HousingPanelControlClose", 		"OnLeftProperty", self)

	-- Events
	Apollo.RegisterEventHandler("GenericEvent_RestoreDatachron", 	"OnGenericEvent_RestoreDatachron", self)
	Apollo.RegisterEventHandler("Communicator_ShowSpamMsg", 		"OnCommShowSpamMsg", self)
	Apollo.RegisterEventHandler("ShowResurrectDialog", 				"OnShowResurrectDialog", self)
	Apollo.RegisterEventHandler("PlayerResurrected", 				"OnPlayerResurrected", self)
	Apollo.RegisterEventHandler("CommDisplay_Closed", 				"OnCommDisplay_Closed", self) -- Comm Display X button clicked
	Apollo.RegisterEventHandler("QuestStateChanged", 				"OnQuestStateChanged", self) -- Currently for Comm Queue only
	Apollo.RegisterEventHandler("Dialog_ShowState", 				"OnDialog_ShowState", self) -- Talking to an NPC
	Apollo.RegisterEventHandler("Dialog_Close", 					"OnDialog_Close", self) -- Speech Bubble Close clicked
	Apollo.RegisterEventHandler("Tutorial_RequestUIAnchor", 		"OnTutorial_RequestUIAnchor", self)

	Apollo.RegisterEventHandler("Communicator_EndIncoming", 		"OnCommunicator_EndIncoming", self) -- This is a missed call
	Apollo.RegisterEventHandler("Communicator_SpamVOEnded", 		"OnCommunicator_SpamVOEnded", self)
	Apollo.RegisterEventHandler("Communicator_ShowQuestMsg", 		"OnCommunicator_ShowQuestMsg", self)

	Apollo.RegisterTimerHandler("Datachron_MaxMissedCallTimer",		"Datachron_MaxMissedCallTimer", self)
	Apollo.RegisterTimerHandler("NpcBubbleFade", 					"OnNpcBubbleFade", self) -- Comm Display fade after time

	g_wndDatachron 			= Apollo.LoadForm("Datachron.xml", "Datachron", "FixedHudStratum", self) -- Do not rename. This is global and used by other forms as a parent.
	self.wndMinimized 		= Apollo.LoadForm("Datachron.xml", "MinimizedState", "FixedHudStratum", self)
	self.wndZoneName 		= g_wndDatachron:FindChild("ZoneName")
	self.wndZoneNameMin	 	= self.wndMinimized:FindChild("ZoneNameMin")

	-- Datachron Modes
	self.bAlreadyOnProperty 		= false
	self.wndHousingContainer 		= g_wndDatachron:FindChild("HousingContainer")
	self.wndPathContainer 			= g_wndDatachron:FindChild("PathContainer")
	self.wndPvPContainer 			= g_wndDatachron:FindChild("PvPContainer")
	self.wndPathContainerTopLevel 	= g_wndDatachron:FindChild("PathContainerTopLevel")

	self.strCurrentState = nil -- SpamOngoing, MissedCall, NoCalls, DialogOngoing, IncomingOngoing, CommQueueAvail

	self.tQueuedSpamMsgs = {}

	self.wndZoneName:SetText(kstrModeLabelZone)
	self.wndZoneNameMin:SetText(kstrModeLabelZone)

	self.bRestoreDatachronAlready = false
	self.bIncomingOngoing = false -- TODO Get rid of this when the missed event no longer fires at the start
	self.tListOfDeniedCalls = {}
	-- End Call System

	self:OnMinimizeDatachron()
	self:OnLeftProperty()

	-------
	-- PvP System Events
	-------
	if MatchingGame:IsInMatchingGame() and MatchingGame:GetPVPMatchState() then
		self:OnPVPMatchEntered()
	end

	-- Load Step Two -- TODO HACK
	Apollo.RegisterTimerHandler("LoadStepTwo", "OnLoadStepTwo", self)
    Apollo.CreateTimer("LoadStepTwo", 0.500, false)
	Apollo.StartTimer("LoadStepTwo")

	-- TODO REMOVE HACK
	Apollo.RegisterTimerHandler("Datachron_ChangeWorld", "OnChangeWorld", self)
    Apollo.CreateTimer("Datachron_ChangeWorld", 1, false)
	Apollo.StartTimer("Datachron_ChangeWorld")
end

-- We need to wait a few seconds to let the event handler for SetPath() to get loaded
function Datachron:OnLoadStepTwo()
	self:ProcessDatachronState()

	self.wndMinimized:ToFront()

	self.bSoldierLoaded = false
	self.bSettlerLoaded = false
	self.bExplorerLoaded = false
	self.bScientistLoaded = false
	self.bHoldoutLoaded = false

	if GameLib.GetPlayerUnit() then
		self:SetPath()
	end

	Event_FireGenericEvent("Datachron_LoadPvPContent")
	Event_FireGenericEvent("Datachron_LoadHousingContent")
end

function Datachron:SetPath()
	local unitPlayer = GameLib:GetPlayerUnit()
	if not unitPlayer then
		return
	end

	local ePathType = unitPlayer:GetPlayerPathType()
	if self.wndPathContainerTopLevel then
		self.wndPathContainerTopLevel:Show(ePathType == PlayerPathLib.PlayerPathType_Scientist and not MatchingGame.IsInPVPGame() and not HousingLib.IsHousingWorld())
	end

	-- TODO REFACTOR
	if ePathType ~= PlayerPathLib.PlayerPathType_Soldier then
		if self.bHoldoutLoaded == false then
			self.bHoldoutLoaded = true
			Event_FireGenericEvent("Datachron_LoadQuestHoldoutContent")
		else
			Event_FireGenericEvent("Datachron_ToggleHoldoutContent", true)
		end

		if ePathType == PlayerPathLib.PlayerPathType_Explorer then
			if self.bExplorerLoaded == false then
				self.bExplorerLoaded = true
				Event_FireGenericEvent("Datachron_LoadPathExplorerContent")
			end
			Event_FireGenericEvent("Datachron_TogglePathContent", PlayerPathLib.PlayerPathType_Explorer)
		elseif ePathType == PlayerPathLib.PlayerPathType_Scientist then
			if self.bScientistLoaded == false then
				self.bScientistLoaded = true
				Event_FireGenericEvent("Datachron_LoadPathScientistContent")
			end
			Event_FireGenericEvent("Datachron_TogglePathContent", PlayerPathLib.PlayerPathType_Scientist)
		elseif ePathType == PlayerPathLib.PlayerPathType_Settler then
			if self.bSettlerLoaded == false then
				self.bSettlerLoaded = true
				Event_FireGenericEvent("Datachron_LoadPathSettlerContent")
			end
			Event_FireGenericEvent("Datachron_TogglePathContent", PlayerPathType_Settler)
		else
			return
		end
	else
		Event_FireGenericEvent("Datachron_ToggleHoldoutContent", false)

		if self.bSoldierLoaded == false then
			self.bSoldierLoaded = true
			Event_FireGenericEvent("Datachron_LoadPathSoldierContent")
		end
		Event_FireGenericEvent("Datachron_TogglePathContent", PlayerPathLib.PlayerPathType_Soldier)
	end
end

function Datachron:OnChangeWorld()
	Apollo.StopTimer("Datachron_ChangeWorld")
	local nCurrentZoneMap = GameLib.GetCurrentZoneMap()
	if not nCurrentZoneMap or nCurrentZoneMap.id == 31 then -- 31 is some temporary zone
		Apollo.StartTimer("Datachron_ChangeWorld")
	elseif nCurrentZoneMap and (nCurrentZoneMap.id == 184 or nCurrentZoneMap.id == 151) then -- TODO: REMOVE: If Arkship then maximize
		self:OnGenericEvent_RestoreDatachron(true)
	end
end

---------------------------------------------------------------------------------------------------
-- Maximize/Minimize
---------------------------------------------------------------------------------------------------

function Datachron:OnGenericEvent_RestoreDatachron(bOnlyOnce)
	if g_wndDatachron:IsShown() then
		return
	end

	if bOnlyOnce and not self.bRestoreDatachronAlready then
		self.bRestoreDatachronAlready = true
		self:OnRestoreDatachron()
	elseif not bOnlyOnce then
		self:OnRestoreDatachron()
	end
end

function Datachron:OnMinimizeDatachron()
	g_wndDatachron:Show(false)
	self.wndMinimized:Show(true)
	self.wndMinimized:ToFront()
	g_wndDatachron:FindChild("DisableCommBtn"):SetCheck(true)
	self.wndMinimized:FindChild("DisableCommBtnMin"):SetCheck(true)
	Event_FireGenericEvent("DatachronMinimized", knDatachronShift)
	Sound.Play(Sound.PlayUI38CloseRemoteWindowDigital)

	-- Only on minimize, so a queued calls request will bring it up
	g_wndDatachron:FindChild("QueuedCallsContainer"):Show(false)
end

function Datachron:OnRestoreDatachron()
	g_wndDatachron:Show(true)
	self.wndMinimized:Show(false)
	g_wndDatachron:FindChild("DisableCommBtn"):SetCheck(false)
	self.wndMinimized:FindChild("DisableCommBtnMin"):SetCheck(false)
	Event_FireGenericEvent("DatachronRestored", knDatachronShift)
	Sound.Play(Sound.PlayUI37OpenRemoteWindowDigital)
end

---------------------------------------------------------------------------------------------------
-- Tutorial anchor request
---------------------------------------------------------------------------------------------------

function Datachron:OnTutorial_RequestUIAnchor(eAnchor, idTutorial, strPopupText)
	if eAnchor ~= GameLib.CodeEnumTutorialAnchor.Datachron then return end

	local tRect = {}
	if self.wndMinimized:IsShown() then
		tRect.l, tRect.t, tRect.r, tRect.b = self.wndMinimized:GetRect()
	else
		tRect.l, tRect.t, tRect.r, tRect.b = g_wndDatachron:GetRect()
	end

	Event_FireGenericEvent("Tutorial_RequestUIAnchorResponse", eAnchor, idTutorial, strPopupText, tRect)
end

---------------------------------------------------------------------------------------------------
-- Call System
---------------------------------------------------------------------------------------------------

function Datachron:OnCommPotraitClicked()
	self:OnCommPlayBtn() -- From Comm Display
end

function Datachron:FlashIndicators(fArgDuration, bUseFastSprites)
	local fDuration = fArgDuration or 4.000
	if bUseFastSprites then
		g_wndDatachron:FindChild("DatachronCallTopPulse"):SetSprite("sprDC_TopPulseFast")
		g_wndDatachron:FindChild("DatachronCallSidePulse"):SetSprite("sprDC_SidePulseFast")
		self.wndMinimized:FindChild("DatachronCallTopPulseMin"):SetSprite("sprDC_TopPulseFast")
	else
		g_wndDatachron:FindChild("DatachronCallTopPulse"):SetSprite("CRB_DatachronSprites:sprDC_TopPulse")
		g_wndDatachron:FindChild("DatachronCallSidePulse"):SetSprite("CRB_DatachronSprites:sprDC_SidePulse")
		self.wndMinimized:FindChild("DatachronCallTopPulseMin"):SetSprite("CRB_DatachronSprites:sprDC_TopPulse")
	end

	g_wndDatachron:FindChild("DatachronCallTopPulse"):Show(true)
	g_wndDatachron:FindChild("DatachronCallSidePulse"):Show(true)
	self.wndMinimized:FindChild("DatachronCallTopPulseMin"):Show(true)
	Apollo.StopTimer("StopFlashIndicatorsTimer")

	if fDuration ~= -1 then
		Apollo.RegisterTimerHandler("StopFlashIndicatorsTimer", "StopFlashIndicators", self)
		Apollo.CreateTimer("StopFlashIndicatorsTimer", fDuration, false)
		Apollo.StartTimer("StopFlashIndicatorsTimer")
	end
end

function Datachron:StopFlashIndicators()
	g_wndDatachron:FindChild("DatachronCallTopPulse"):Show(false)
	g_wndDatachron:FindChild("DatachronCallSidePulse"):Show(false)
	self.wndMinimized:FindChild("DatachronCallTopPulseMin"):Show(false)
end

function Datachron:HideCommDisplay()
	Event_FireGenericEvent("HideCommDisplay")
	self.idCreature = nil
	self:DrawCallSystem()
end

function Datachron:SetCommunicatorCreature(idCreature)
	self.idCreature = idCreature
	if self.idCreature ~= 0 then
		local strCreatureName = Creature_GetName(self.idCreature)

		if strCreatureName == nil then
			strCreatureName = Apollo.GetString("Datachron_UnknownCreature")
		end

		g_wndDatachron:FindChild("IncomingCreatureName"):SetText(strCreatureName)
		self.wndMinimized:FindChild("IncomingCreatureNameMin"):SetText(strCreatureName)
	end
end

---------------------------------------------------------------------------------------------------
-- Event Routing for Call System
---------------------------------------------------------------------------------------------------

function Datachron:OnShowResurrectDialog()
	self:DrawCallSystem("TurnOffButtons")
end

function Datachron:OnPlayerResurrected()
	self:ProcessDatachronState()
end

function Datachron:OnDialog_Close() -- User clicks done in the dialog speech bubbles
	Apollo.StopTimer("NpcBubbleFade")

	if next(self.tQueuedSpamMsgs) ~= nil then
		self:HideCommDisplay()
		self:ProcessDatachronState()
	else
		Apollo.CreateTimer("NpcBubbleFade", 9.500, false)
		Apollo.StartTimer("NpcBubbleFade")
	end
end

function Datachron:OnNpcBubbleFade()
	-- NPC bubble fades out
	Apollo.StopTimer("NpcBubbleFade")
	self:HideCommDisplay()
	if self.idSpamMsg ~= 0 then
		CommunicatorLib.QueueNextCall(self.idSpamMsg)
	end
	self:ProcessDatachronState()
end

function Datachron:OnCommDisplay_Closed()
	-- User clicks x button on the comm display
	Apollo.StopTimer("NpcBubbleFade")
	self:HideCommDisplay()
	if self.idSpamMsg ~= 0 then
		CommunicatorLib.QueueNextCall(self.idSpamMsg)
	end
	self:ProcessDatachronState()
end

function Datachron:OnCommunicator_SpamVOEnded()
	if self.strCurrentState == "SpamOngoing" then
		self:DrawCallSystem("SpamEnd")
	end
end

function Datachron:OnCommunicator_EndIncoming()
	 -- Only do stuff if this end event comes when there is an incoming to end

	if self.bIncomingOngoing then
		-- Run off queued spam when an end event comes before going to missed
		if #self.tQueuedSpamMsgs > 0 then
			self:ProcessSpamQueue()
		end

		-- After running off spam see if we can go into missed
		self:DrawCallSystem(self:BuildCallbackList() and "MissedCall" or "NoCalls")
	end
end

function Datachron:OnDialog_ShowState(eState, queCurr) -- Talking to an NPC
	local idQuest = 0
	if queCurr then
		idQuest = queCurr:GetId()
	end -- TODO guard for nil better

	local tResponseList = DialogSys.GetResponses(idQuest)
	if tResponseList == nil or #tResponseList == 0 or eState == DialogSys.DialogState_Inactive then
		self:ProcessDatachronState()
	end

	local idCreature = DialogSys.GetCommCreatureId()

	if idCreature == nil then
		self:ProcessDatachronState()
		return
	end

	if eState == DialogSys.DialogState_TopicChoice or
		 eState == DialogSys.DialogState_QuestAccept or
		 eState == DialogSys.DialogState_QuestComplete or
		 eState == DialogSys.DialogState_QuestIncomplete then

		self.strCurrentState = "DialogOngoing"

		Apollo.StopTimer("NpcBubbleFade")

		local tLayout = nil
		if queCurr then
			tLayout = CommunicatorLib.GetMessageLayoutForQuest(queCurr)
		end

		Event_FireGenericEvent("CommDisplayQuestText", eState, idQuest, true, tLayout)

		self:SetCommunicatorCreature(idCreature)
		self:DrawCallSystem("TurnOffButtons")
		self:DrawCallSystem()
	else
		self:ProcessDatachronState()
	end
end

function Datachron:OnCommunicator_ShowQuestMsg(idMsg, idCreature, queSource, strText)
	if self.strCurrentState == "DialogOngoing" then
		return -- don't interrupt an existing dialog
	end

	if self.strCurrentState == "IncomingOngoing" and self.idCreature == idCreature then
		return -- don't double show
	end

	if queSource:GetState() == Quest.QuestState_Achieved then
		return -- don't show for achieved quests that should go to the tracker
	end

	if self.strCurrentState == "SpamOngoing" then
		Event_FireGenericEvent("CloseCommDisplay") -- TODO Refactor this into HideCommDisplay
		Sound.Play(Sound.PlayUIDatachronEnd)
	end

	self.strCurrentState = "IncomingOngoing"

	self:SetCommunicatorCreature(idCreature)
	self:DrawCallSystem()

	if queSource and queSource:GetId() and queSource:GetId() ~= 0 then
		 -- For deny to put this quest into a deny queue
		g_wndDatachron:FindChild("CommCallDeny"):SetData(queSource:GetId())
		self.wndMinimized:FindChild("CommCallDenyMin"):SetData(queSource:GetId())
	end
end

function Datachron:OnCommShowSpamMsg(idMsg, idCreature, strText, bPriorty)
	local pmNew = CommunicatorLib.GetPathMissionDelivered(idMsg)  -- TODO: Remove once we no longer recieve unlock calls
	if pmNew then
		return false
	end 	 -- TODO: Remove once we no longer recieve unlock calls

	-- priority spam includes the goodbye message from givers. It needs to take priority over other spam messages, or else the goodbye can come in at a weird time.
	if bPriorty then
		table.insert(self.tQueuedSpamMsgs, 1, {idMsg, idCreature, strText})
	else
		table.insert(self.tQueuedSpamMsgs, {idMsg, idCreature, strText})
	end

	-- if we're not in any of these states, recalculate state
	if self.strCurrentState ~= "DialogOngoing" and self.strCurrentState ~= "IncomingOngoing"
		and self.strCurrentState ~= "SpamOngoing" then
		self:ProcessDatachronState()
	end
end

function Datachron:OnQuestStateChanged()
	if self.strCurrentState == "CommQueueAvail" and g_wndDatachron:FindChild("QueuedCallsContainer"):IsShown() then
		-- Run Build List, and if empty process state
		if self:BuildCallbackList() == false then
			self:ProcessDatachronState()
		end
	end
end

---------------------------------------------------------------------------------------------------
-- Simple UI Functions
---------------------------------------------------------------------------------------------------

function Datachron:OnDatachron_HideCallPulse() -- One click hide from the HUD Interact, until a new state
	if self.wndMinimized and self.wndMinimized:IsValid() then -- Once you click it, it's gone until a new state.
		g_wndDatachron:FindChild("CommCallPulseBlue"):Show(false)
		self.wndMinimized:FindChild("CommCallPulseMinBlue"):Show(false)

		g_wndDatachron:FindChild("CommCallPulseRed"):Show(false)
		self.wndMinimized:FindChild("CommCallPulseMinRed"):Show(false)
	end
end

function Datachron:OnCommPlayBtn()
	-- This has both the queue open and play button functionality
	self:StopFlashIndicators()

	if self.strCurrentState ~= "CommQueueAvail" and self.strCurrentState ~= "MissedCall" then
		CommunicatorLib.CallbackLastContact()
		Event_HideQuestLog()
		return
	end

	if self.strCurrentState == "MissedCall" then -- Demote MissedCall to CommQueueAvail
		local bBuildCallbackList = self:BuildCallbackList()
		self:DrawCallSystem(bBuildCallbackList and "CommQueueAvail" or "NoCalls")
		if not bBuildCallbackList then
			return
		end
	end

	if not g_wndDatachron:IsShown() then -- Restores from minimized, as per spec
		self:OnRestoreDatachron()
	end

	g_wndDatachron:FindChild("CommCallPulseBlue"):Show(false) -- Once you click it, it's gone until a new state. -- TODO: Refactor and move
	self.wndMinimized:FindChild("CommCallPulseMinBlue"):Show(false)
	g_wndDatachron:FindChild("QueuedCallsContainer"):Show(not g_wndDatachron:FindChild("QueuedCallsContainer"):IsShown())
end

function Datachron:OnDenyCallbackBtn(wndHandler, wndControl) -- CommCallDeny
	if wndHandler and wndHandler:GetData() then
		self.tListOfDeniedCalls[wndHandler:GetData()] = wndHandler:GetData()
	end

	if self.strCurrentState == "DialogOngoing" then
		Sound.Play(Sound.PlayUIDatachronEnd)
	end

	if self.strCurrentState == "SpamOngoing" then
		Event_FireGenericEvent("CloseCommDisplay")
		self:OnNpcBubbleFade() -- Warning, instead of going to NoCalls simulate a BubbleFade. Potentially hazardous.
		return
	end

	CommunicatorLib.IgnoreCallback()

	-- Update the callback list then go right into that state
	self:DrawCallSystem(self:BuildCallbackList() and "CommQueueAvail" or "NoCalls")
end

function Datachron:OnQueuedCallsItemClick(wndHandler, wndControl)
	if wndHandler ~= wndControl or not wndHandler:GetParent() or not wndHandler:GetParent():GetData() then
		return
	end

	CommunicatorLib.CallContact(wndHandler:GetParent():GetData())

	if DialogSys.GetCommCreatureId() and Creature_GetName(DialogSys.GetCommCreatureId()) then
		g_wndDatachron:FindChild("IncomingCreatureName"):SetText(Creature_GetName(DialogSys.GetCommCreatureId()))
		self.wndMinimized:FindChild("IncomingCreatureNameMin"):SetText(Creature_GetName(DialogSys.GetCommCreatureId()))
	end

	self:DrawCallSystem("DialogOngoing")
end

function Datachron:OnQueuedCallsIgnoreBtn(wndHandler, wndControl)
	if wndHandler ~= wndControl or not wndHandler:GetParent() or not wndHandler:GetParent():GetData() then
		return
	end

	local queQueued = wndHandler:GetParent():GetData()
	if queQueued then
		queQueued:ToggleIgnored()
	end
	-- OnQuestStateChanged will do redrawing as we have to wait after TogglingIgnore
end

function Datachron:BuildCallbackList()
	local bResult = false
	g_wndDatachron:FindChild("QueuedCallsList"):DestroyChildren()

	local tCallbackList = Quest:GetCallbackList(true) -- Boolean is to show out leveled quests or not
	if tCallbackList == nil or #tCallbackList <= 0 then
		return false
	end

	for key, queCurr in ipairs(tCallbackList) do
		if queCurr:GetState() == Quest.QuestState_Mentioned then
			bResult = true

			local wndQCall = Apollo.LoadForm("ui\\Datachron\\Datachron.xml", "QueuedCallsItem", g_wndDatachron:FindChild("QueuedCallsList"), self)
			wndQCall:SetData(queCurr)

			if self.tListOfDeniedCalls[queCurr:GetId()] ~= nil then
				wndQCall:FindChild("QueuedCallsTitle"):SetText(String_GetWeaselString(Apollo.GetString("Datachron_SkippedCall"), queCurr:GetTitle()))
			else
				wndQCall:FindChild("QueuedCallsTitle"):SetText(String_GetWeaselString(Apollo.GetString("Datachron_MissedCall"), queCurr:GetTitle()))
			end
		end
	end

	g_wndDatachron:FindChild("QueuedCallsList"):ArrangeChildrenVert(0)

	return bResult
end

---------------------------------------------------------------------------------------------------
-- The Main State Machine and Draw Method
---------------------------------------------------------------------------------------------------

function Datachron:DrawCallSystem(strNewState)
	local strLocalState = self.strCurrentState

	if strNewState and strNewState ~= "" then
		if strNewState == nil or strNewState == "" then
			return
		else
			strLocalState = strNewState
			self.strCurrentState = strNewState
		end
	end

	self:StopFlashIndicators()
	self.bIncomingOngoing = false
	Event_FireGenericEvent("DatachronCallCleared")
	Apollo.StopTimer("Datachron_MaxMissedCallTimer")

	-- Super Huge State Machine
	local ktValidDenyEnable =
	{
		["IncomingOngoing"] = true,
		["SpamOngoing"] = true,
		["DialogOngoing"] = true,
		["SpamEnd"] = true,
	}

	local ktValidPlayEnable =
	{
		["IncomingOngoing"] = true,
		["CommQueueAvail"] = true,
		["MissedCall"] = true,
	}

	local ktValidIndicatorPulse =
	{
		["IncomingOngoing"] = "sprDC_GreenPulse",
		["CommQueueAvail"] = "sprDC_BluePulse",
		["MissedCall"] = "sprDC_RedPulse",
	}

	local ktValidPlaySprite =
	{
		["CommQueueAvail"] = "CRB_DatachronSprites:btnDC_Queue",
		["MissedCall"] = "CRB_DatachronSprites:btnDC_ExclamationMark",
	}

	g_wndDatachron:FindChild("CommCallPulseRed"):Show(strLocalState == "MissedCall")
	self.wndMinimized:FindChild("CommCallPulseMinRed"):Show(strLocalState == "MissedCall")
	g_wndDatachron:FindChild("CommCallPulseBlue"):Show(strLocalState == "CommQueueAvail")
	self.wndMinimized:FindChild("CommCallPulseMinBlue"):Show(strLocalState == "CommQueueAvail")

	g_wndDatachron:FindChild("QueuedCallsContainer"):Show(false) -- Every action hides this menu, even dialog

	g_wndDatachron:FindChild("CommCallIndicator"):SetSprite(ktValidIndicatorPulse[strLocalState] or "")
	self.wndMinimized:FindChild("CommCallIndicatorMin"):SetSprite(ktValidIndicatorPulse[strLocalState] or "")

	g_wndDatachron:FindChild("CommPlayBtnBlocker"):Show(strLocalState == "NoCalls")
	self.wndMinimized:FindChild("CommPlayBtnBlockerMin"):Show(strLocalState == "NoCalls")

	g_wndDatachron:FindChild("CommCallDeny"):Enable(ktValidDenyEnable[strLocalState])
	self.wndMinimized:FindChild("CommCallDenyMin"):Enable(ktValidDenyEnable[strLocalState])

	g_wndDatachron:FindChild("CommPlayBtn"):Enable(ktValidPlayEnable[strLocalState])
	self.wndMinimized:FindChild("CommPlayBtnMin"):Enable(ktValidPlayEnable[strLocalState])

	g_wndDatachron:FindChild("CommPlayBtn"):ChangeArt(ktValidPlaySprite[strLocalState] or "CRB_DatachronSprites:btnDC_Play")
	self.wndMinimized:FindChild("CommPlayBtnMin"):ChangeArt(ktValidPlaySprite[strLocalState] or "CRB_DatachronSprites:btnDC_Play")

	-- Awkward as TurnOffButtons preserves old state
	if strLocalState ~= "TurnOffButtons" then
		g_wndDatachron:FindChild("CallNameBlocker"):Show(strLocalState ~= "NoCalls")
		self.wndMinimized:FindChild("CallNameBlockerMin"):Show(strLocalState ~= "NoCalls")
	end

	-- Super Huge State Machine
	if strLocalState == "SpamEnd" then

		Event_FireGenericEvent("StopTalkingCommDisplay")

	elseif strLocalState == "CommQueueAvail" then

		g_wndDatachron:FindChild("IncomingCreatureName"):SetText(Apollo.GetString("Datachron_CallsPending"))
		self.wndMinimized:FindChild("IncomingCreatureNameMin"):SetText(Apollo.GetString("Datachron_CallsPending"))

	elseif strLocalState == "NoCalls" then

		self.tListOfDeniedCalls = {}
		g_wndDatachron:FindChild("IncomingCreatureName"):SetText("")
		self.wndMinimized:FindChild("IncomingCreatureNameMin"):SetText("")

	elseif strLocalState == "IncomingOngoing" then

		self.bIncomingOngoing = true
		self:FlashIndicators(13.500, true)
		Event_FireGenericEvent("DatachronCallIncoming")

	elseif strLocalState == "MissedCall" then

		self:FlashIndicators(-1) -- The -1 means infinite
		Event_FireGenericEvent("DatachronCallMissed")
		Apollo.CreateTimer("Datachron_MaxMissedCallTimer", 60, false)
		g_wndDatachron:FindChild("IncomingCreatureName"):SetText(Apollo.GetString("Datachron_MissedCallTitle"))
		self.wndMinimized:FindChild("IncomingCreatureNameMin"):SetText(Apollo.GetString("Datachron_MissedCallTitle"))

	elseif strLocalState == "SpamOngoing" or strLocalState == "DialogOngoing" or strLocalState == "TurnOffButtons" then
		-- Do nothing (rely on default states)
	end
end

function Datachron:ProcessDatachronState()
	-- This computes the state once we're 'done'
	-- If IncomingOngoing Delay -> Check Queued Spam -> Comm Queue Avail -> Go to No Calls

	if self.strCurrentState == "IncomingOngoing" then
		return
	elseif #self.tQueuedSpamMsgs > 0 then
		self:ProcessSpamQueue()
	elseif self:BuildCallbackList() then
		self:DrawCallSystem("CommQueueAvail")
	elseif self.strCurrentState ~= "NoCalls" then
		self:DrawCallSystem("NoCalls")
	end
end

function Datachron:ProcessSpamQueue()
	if self.strCurrentState == "DialogOngoing" then
		self:HideCommDisplay()
	end

	local tSpamMsg = table.remove(self.tQueuedSpamMsgs, 1)
	local idMsg = tSpamMsg[1]
	local idCreature = tSpamMsg[2]
	local strText = tSpamMsg[3]

	self.idSpamMsg = idMsg

	local tLayout = CommunicatorLib.GetMessageLayoutForSpam(idMsg)

	Event_FireGenericEvent("CommDisplayRegularText", idMsg, idCreature, strText, tLayout)

	self.strCurrentState = "SpamOngoing"

	local fDuration = 9.500
	if tLayout and tLayout.fDuration then
		fDuration = tLayout.fDuration
	end

	Apollo.StopTimer("NpcBubbleFade")
	Apollo.CreateTimer("NpcBubbleFade", fDuration, false)
	Apollo.StartTimer("NpcBubbleFade")

	self:SetCommunicatorCreature(idCreature)
	Event_FireGenericEvent("ShowCommDisplay")
	self:DrawCallSystem()

	-- post the message to the chat log
	Chat_PostDatachronMsg(idCreature, strText)
end

function Datachron:Datachron_MaxMissedCallTimer()
	Apollo.StopTimer("Datachron_MaxMissedCallTimer")
	if self.strCurrentState == "MissedCall" then
		self:DrawCallSystem(self:BuildCallbackList() and "CommQueueAvail" or "NoCalls")
	end
end

---------------------------------------------------------------------------------------------------
-- End Call System
---------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------
-- Housing Datachron Mode
---------------------------------------------------------------------------------------------------

function Datachron:OnEnteredProperty(idPropertyInfo, idZone, bPlayerIsInside)
	if MatchingGame.IsInPVPGame() then
		self:OnPVPMatchEntered()
		return
	end
	
	self.wndHousingContainer:Show(true)
	self.wndPathContainer:Show(false)
	self.wndPvPContainer:Show(false)
	self.wndPathContainerTopLevel:Show(false)
end

function Datachron:OnLeftProperty()
	if MatchingGame.IsInPVPGame() then
		self:OnPVPMatchEntered()
		return
	end

	if not HousingLib.IsHousingWorld() or not HousingLib.IsWarplotResidence() then
		self.wndHousingContainer:Show(false)
		self.wndPathContainer:Show(true)
		self.wndPvPContainer:Show(false)
		
		local unitPlayer = GameLib:GetPlayerUnit()
        if not unitPlayer then
            return
        end
	
		local ePathType = unitPlayer:GetPlayerPathType()
	    if self.wndPathContainerTopLevel then
		    self.wndPathContainerTopLevel:Show(ePathType == PlayerPathLib.PlayerPathType_Scientist and not MatchingGame.IsInPVPGame() and not HousingLib.IsHousingWorld())
		end    
	end
end

---------------------------------------------------------------------------------------------------
-- PvP Datachron Mode
---------------------------------------------------------------------------------------------------
function Datachron:OnPVPMatchEntered()
	if not MatchingGame.IsInPVPGame() then
		return
	end

	self.wndHousingContainer:Show(false)
	self.wndPathContainer:Show(false)
	self.wndPvPContainer:Show(true)
	self.wndPathContainerTopLevel:Show(false)
	g_wndDatachron:FindChild("CommPlayBtnBlocker"):Show(true)
	g_wndDatachron:FindChild("CommCallIndicator"):SetSprite("")
end

function Datachron:OnPVPMatchStateUpdated()
	if MatchingGame:IsInMatchingGame() and MatchingGame:GetPVPMatchState() then
		self:OnPVPMatchEntered()
	end
end

function Datachron:OnPVPMatchExited()
	self.wndHousingContainer:Show(false)
	self.wndPathContainer:Show(true)
	self.wndPvPContainer:Show(false)
	self.wndPathContainerTopLevel:Show(ePathType == PlayerPathLib.PlayerPathType_Scientist and not MatchingGame.IsInPVPGame() and not HousingLib.IsHousingWorld())
end

local DatachronInst = Datachron:new()
DatachronInst:Init()
