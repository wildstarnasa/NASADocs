-----------------------------------------------------------------------------------------------
-- Client Lua Script for CraftingGrid
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "CraftingLib"

local CraftingGrid = {}

local karEvalColors = -- TODO: Pick actual colors
{
	"ffB3B3B3",	-- average
	"ffffffff",	-- good
	"ff92D941",	-- excellent
	"ff4192D9",	-- superb
	"ff4D00FF",	-- exquisite
	"ff9900FF",	-- phenomenal
	"ffff00ff",	-- extraordinary
	"ffD94192", -- legendary
	"ff7d7d7d",	-- inferior
}

local ktHotOrColdToString =
{
	[CraftingLib.CodeEnumCraftingDiscoveryHotCold.Cold] = Apollo.GetString("CoordCrafting_Cold"),
	[CraftingLib.CodeEnumCraftingDiscoveryHotCold.Warm] = Apollo.GetString("CoordCrafting_Warm"),
	[CraftingLib.CodeEnumCraftingDiscoveryHotCold.Hot] = Apollo.GetString("CoordCrafting_Hot"),
	[CraftingLib.CodeEnumCraftingDiscoveryHotCold.Success] = Apollo.GetString("CoordCrafting_Success"),
}

-- TODO REFACTOR REPLACE THIS (Use Bit32 functions in CoordinateSchematic:HelperAdditiveCheck?)
local ktAdditiveWndNameToCompassTable = -- N, E, S, W, bAllowZeroes (mainly for diagonals, to make it more loose)
{
	["CompassN"] = {true,true,false,true,false},
	["CompassE"] = {true,true,true,false,false},
	["CompassS"] = {false,true,true,true,false},
	["CompassW"] = {true,false,true,true,false},
	["CompassNE"] = {true,true,false,false,true},
	["CompassNW"] = {true,false,false,true,true},
	["CompassSE"] = {false,true,true,false,true},
	["CompassSW"] = {false,false,true,true,true},
	["CompassMiddle"] = {true,true,true,true,true},
}

function CraftingGrid:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
	return o
end

function CraftingGrid:Init()
    Apollo.RegisterAddon(self)
end

function CraftingGrid:OnLoad()
	Apollo.RegisterEventHandler("GenericEvent_StartCraftingGrid", 			"OnGenericEvent_StartCraftingGrid", self)
	Apollo.RegisterEventHandler("CraftingDiscoveryHotCold", 				"OnCraftingDiscoveryHotCold", self)
	Apollo.RegisterEventHandler("CraftingUpdateCurrent", 					"OnCraftingUpdateCurrent", self)
	Apollo.RegisterEventHandler("UpdateInventory", 							"RedrawAll", self)
	Apollo.RegisterEventHandler("PlayerCurrencyChanged", 					"RedrawCash", self)

	Apollo.RegisterTimerHandler("CraftingGrid_CraftBtnTimer", 				"OnCraftingGrid_CraftBtnTimer", self)
	Apollo.RegisterTimerHandler("CraftingGrid_HideHelperText", 				"OnCraftingGrid_HideHelperText", self)
	Apollo.RegisterTimerHandler("CraftingGrid_StopGridMarkerAnim", 			"OnCraftingGrid_StopGridMarkerAnim", self)
	Apollo.RegisterTimerHandler("CraftingGrid_TimerCraftingStationCheck", 	"OnCraftingGrid_TimerCraftingStationCheck", self)

	Apollo.CreateTimer("CraftingGrid_TimerCraftingStationCheck", 1, true)
	Apollo.CreateTimer("CraftingGrid_CraftBtnTimer", 3.25, false)
	Apollo.StopTimer("CraftingGrid_CraftBtnTimer")
	Apollo.CreateTimer("CraftingGrid_StopGridMarkerAnim", 5, false)
	Apollo.StopTimer("CraftingGrid_StopGridMarkerAnim")

	-- This data exists past Destroy/Initialize (TODO: Move to OnSave/Restore)
	self.bShownStartingTutorial = false
	self.tLastMarkerData =
	{
		wndLastMarker = nil,
		idSchematic = nil,
		nPosX = nil,
		nPosY = nil,
		strTooltip = nil,
		strHotOrCold = nil,
	}
end

function CraftingGrid:OnCoordTutorialCloseBtn() -- TODO REMOVE
	self.wndMain:FindChild("CoordTutorial"):Show(false)
	if self.wndMain:FindChild("Tutorial_SmallLeftArrow") then
		self.wndMain:FindChild("Tutorial_SmallLeftArrow"):Show(true)
	end
end

function CraftingGrid:OnCraftingGrid_TimerCraftingStationCheck()
	if self.wndMain and self.wndMain:IsValid() then
		self.wndMain:FindChild("BGCraftingStationBlocker"):Show(not CraftingLib.IsAtCraftingStation())
	end
end

function CraftingGrid:OnGenericEvent_StartCraftingGrid(idSchematic)
	if not idSchematic then
		return
	end

	self:Initialize()
	self.wndMain:SetData(idSchematic)
	self:BuildNewGrid(idSchematic)
	self:RedrawAll()

	Event_ShowTutorial(GameLib.CodeEnumTutorial.CoordinateCrafting)
end

function CraftingGrid:Initialize()
	if self.wndMain and self.wndMain:IsValid() then
		return
	end

    self.wndMain = Apollo.LoadForm("CraftingGrid.xml", "CraftingGridForm", nil, self)
	self.wndMain:FindChild("CompassMiddle"):SetCheck(true)
	self.wndAdditiveEstimate = nil
	self.wndMarker = nil

	-- TODO TEMP
	self.wndMain:FindChild("CoordTutorial"):Show(not self.bShownStartingTutorial)

	self.bWndMarkerAnim = false
	self.bFullDestroyDueToCatalyst = false
	self.bShownStartingTutorial = true
	self.bShownAdditiveTutorial = false

	self.nMaxY, self.nMaxX, self.nMinX, self.nMinY = nil
	self.tAdditivesAdded = {}
	self.tWndDiscoverable = {}
	self.tWndCircles = {}
end

-----------------------------------------------------------------------------------------------
-- Main Drawing
-----------------------------------------------------------------------------------------------

function CraftingGrid:RedrawAll()
	if not self.wndMain or not self.wndMain:IsValid() then
		return
	end

	self:RedrawCash()

	local idSchematic = self.wndMain:GetData()
	local tCurrentCraft = CraftingLib.GetCurrentCraft()
	local tSchematicInfo = CraftingLib.GetSchematicInfo(idSchematic)
	local bCurrentCraftStarted = tCurrentCraft and tCurrentCraft.nSchematicId == idSchematic

	-- Count Raw Materials
	local bHasEnoughRawMaterials = true
	self.wndMain:FindChild("CraftMaterialsList"):DestroyChildren()
	for idx, tMaterial in pairs(tSchematicInfo.tMaterials) do
		if  tMaterial.itemMaterial:GetBackpackCount() < tMaterial.nAmount then
			bHasEnoughRawMaterials = false
			break
		end
	end

	-- Enough Materials Blocker
	self.wndMain:FindChild("BGNoMaterialsBlocker"):Show(not bCurrentCraftStarted and not bHasEnoughRawMaterials)
	if not bCurrentCraftStarted and not bHasEnoughRawMaterials then
		Print(tostring(bCurrentCraftStarted) .. " and " .. tostring(bHasEnoughRawMaterials))
		self.wndMain:FindChild("BGNoMaterialsList"):DestroyChildren()
		for idx, tMaterial in pairs(tSchematicInfo.tMaterials) do
			local nBackpackCount = tMaterial.itemMaterial:GetBackpackCount()
			local wndNoMaterials = Apollo.LoadForm("CraftingGrid.xml", "RawMaterialsItem", self.wndMain:FindChild("BGNoMaterialsList"), self)
			wndNoMaterials:FindChild("RawMaterialsIcon"):SetTextColor("ffff0000")
			wndNoMaterials:FindChild("RawMaterialsIcon"):SetText(String_GetWeaselString(Apollo.GetString("CRB_Progress"), nBackpackCount, tMaterial.nAmount))
			wndNoMaterials:FindChild("RawMaterialsIcon"):SetSprite(tMaterial.itemMaterial:GetIcon())
			wndNoMaterials:FindChild("RawMaterialsNotEnough"):Show(nBackpackCount < tMaterial.nAmount)
			self:HelperBuildItemTooltip(wndNoMaterials, tMaterial.itemMaterial)
		end
		self.wndMain:FindChild("BGNoMaterialsList"):ArrangeChildrenHorz(1)
		return
	end

	-- Preview Only
	self.wndMain:FindChild("BGPreviewOnlyBlocker"):Show(not bCurrentCraftStarted)
	self.wndMain:FindChild("BGPreviewOnlyBlocker"):FindChild("PreviewStartCraftBtn"):SetData(idSchematic)

	-- Global Catalysts (if Preview Only)
	if not bCurrentCraftStarted then
		self.wndMain:FindChild("CatalystGlobalList"):DestroyChildren()
		for idx, tItemData in pairs(CraftingLib.GetAvailableCatalysts(tSchematicInfo.eTradeskillId, idSchematic)) do
			local itemCatalyst = tItemData.itemCatalyst
			if itemCatalyst:GetGlobalCatalystInfo() then
				local wndCurr = Apollo.LoadForm("CraftingGrid.xml", "GlobalBoostItem", self.wndMain:FindChild("CatalystGlobalList"), self)
				wndCurr:SetData(itemCatalyst)
				wndCurr:FindChild("ButtonIcon"):SetText(tItemData.nCount)
				wndCurr:FindChild("ButtonIcon"):SetSprite(itemCatalyst:GetIcon())
				self:HelperBuildItemTooltip(wndCurr, itemCatalyst)
			end
		end
		self.wndMain:FindChild("CatalystGlobalList"):ArrangeChildrenTiles()
	end

	-- Continue drawing (implictly we have enough materials)
	self:RedrawAllDetailed(idSchematic, tSchematicInfo, tCurrentCraft, bCurrentCraftStarted)
end

function CraftingGrid:RedrawAllDetailed(idSchematic, tSchematicInfo, tCurrentCraft, bCurrentCraftStarted)
	-- Craft Btn
	local bHitSubSchematic = bCurrentCraftStarted and tCurrentCraft.nSchematicId ~= 0 and tCurrentCraft.nSubSchematicId ~= 0
	local tSubSchematicInfo = bHitSubSchematic and CraftingLib.GetSchematicInfo(tCurrentCraft.nSubSchematicId) or tSchematicInfo
	self:HelperBuildItemTooltip(self.wndMain:FindChild("CraftBtn"), tSubSchematicInfo.itemOutput)

	-- Additive Raw Materials
	for idx = 1, tSchematicInfo.nMaxAdditives do
		local bActiveSlot = (not bCurrentCraftStarted and idx == 1) or (bCurrentCraftStarted and (idx - 1 == tCurrentCraft.nAdditiveCount))
		local wndAdditiveMaterial = Apollo.LoadForm("CraftingGrid.xml", "RawMaterialsItem", self.wndMain:FindChild("CraftMaterialsList"), self)
		local strIcon = ""
		if not bCurrentCraftStarted or idx > tCurrentCraft.nAdditiveCount then
			wndAdditiveMaterial:SetTooltip(Apollo.GetString("CoordCrafting_EmptyAdditiveSlot"))
			wndAdditiveMaterial:FindChild("RawMaterialsHelperBtn"):Show(true)
		elseif self.tAdditivesAdded[idx] then
			strIcon = self.tAdditivesAdded[idx]:GetIcon()
			self:HelperBuildItemTooltip(wndAdditiveMaterial:FindChild("RawMaterialsIcon"), self.tAdditivesAdded[idx])
		else
			strIcon = "Icon_ItemArmorWaist_Unidentified_Buckle_0001" -- TODO TEMP
			wndAdditiveMaterial:SetTooltip(Apollo.GetString("CoordCrafting_LeftoverAdditive"))
		end
		wndAdditiveMaterial:FindChild("RawMaterialsIcon"):SetSprite(strIcon)
		wndAdditiveMaterial:FindChild("RawMaterialsCurrentBG"):Show(bActiveSlot)
	end

	self.wndMain:FindChild("CraftMaterialsList"):ArrangeChildrenHorz(1)

	-- Additives Store Filter
	local tAdditiveFilters = { true, true, true, true, true }
	for idx, wndCurr in pairs(self.wndMain:FindChild("FilterCompassItems"):GetChildren()) do
		if wndCurr:IsChecked() then
			tAdditiveFilters = ktAdditiveWndNameToCompassTable[wndCurr:GetName()]
			break
		end
	end

	-- Additives Store Set Up
	local tListAdditives = {}
	for idx, itemCurr in pairs(CraftingLib.GetAvailableAdditives(tSchematicInfo.eTradeskillId, idSchematic)) do
		if self:HelperValidAdditiveCheck(tSchematicInfo, itemCurr, tAdditiveFilters) then
			table.insert(tListAdditives, itemCurr)
		end
	end

	-- Additives Store Draw
	local nPlayerMoneyInCopper = GameLib.GetPlayerCurrency():GetAmount()
	local tTradeskillInfo = CraftingLib.GetTradeskillInfo(tSchematicInfo.eTradeskillId)
	self.wndMain:FindChild("AdditiveList"):DestroyChildren()
	for eAxis, strAxisName in pairs(tTradeskillInfo.tAxisNames) do -- R, T, L, B
		local wndAdditiveHeader = Apollo.LoadForm("CraftingGrid.xml", "AdditiveHeader", self.wndMain:FindChild("AdditiveList"), self)
		wndAdditiveHeader:FindChild("AdditiveHeaderBtn"):SetText(strAxisName)

		for idx2, itemCurr in pairs(tListAdditives) do
			local tAdditive = itemCurr:GetAdditiveInfo()
			if eAxis == 1 and tAdditive.fVectorX > 0 or eAxis == 2 and tAdditive.fVectorY > 0 or eAxis == 3 and tAdditive.fVectorX < 0 or eAxis == 4 and tAdditive.fVectorY < 0 then
				-- Build Additive Item
				local nPriceInCopper = (itemCurr:GetBuyPrice() and itemCurr:GetBuyPrice():GetAmount() or 0)
				local bCanAfford = nPlayerMoneyInCopper > nPriceInCopper
				local wndCurr = Apollo.LoadForm("CraftingGrid.xml", "AdditiveItem", wndAdditiveHeader:FindChild("AdditiveHeaderItems"), self)
				wndCurr:SetData(itemCurr)
				wndCurr:FindChild("AdditiveMouseCatcher"):SetData(itemCurr)
				wndCurr:FindChild("AdditiveIcon"):SetSprite(bCanAfford and itemCurr:GetIcon() or "ClientSprites:LootCloseBox")

				local strAdditiveName = "<P Font=\"CRB_InterfaceSmall\" TextColor=\"ff9d9d9d\">"..itemCurr:GetName().."</P>"
				local strAdditiveCost = String_GetWeaselString(Apollo.GetString("CoordCrafting_AdditiveCost"), self:HelperStringMoneyConvert(nPriceInCopper))
				wndCurr:SetTooltip(string.format("%s<P Font=\"CRB_InterfaceSmall\" TextColor=\"%s\">%s</P>", strAdditiveName, bCanAfford and "white" or "red", strAdditiveCost))

				if not self.bShownAdditiveTutorial then
					local wndTutorialArrow = Apollo.LoadForm("CraftingGrid.xml", "Tutorial_SmallLeftArrow", wndCurr, self)
					wndTutorialArrow:Show(not self.wndMain:FindChild("CoordTutorial"):IsShown())
					self.bShownAdditiveTutorial = true
				end
			end
		end
		wndAdditiveHeader:FindChild("AdditiveHeaderItems"):ArrangeChildrenTiles(0)
	end

	-- Resize Additive List
	for idx, wndAdditiveHeader in pairs(self.wndMain:FindChild("AdditiveList"):GetChildren()) do
		local nRows = math.ceil(#wndAdditiveHeader:FindChild("AdditiveHeaderItems"):GetChildren() / 5) -- TODO SUPER HACK! REMOVE
		local nLeft, nTop, nRight, nBottom = wndAdditiveHeader:GetAnchorOffsets()
		wndAdditiveHeader:SetAnchorOffsets(nLeft, nTop, nRight, nTop + wndAdditiveHeader:FindChild("AdditiveHeaderBtn"):GetHeight() + (nRows * 40))
	end
	self.wndMain:FindChild("AdditiveList"):ArrangeChildrenVert(0)

	-- Last Attempt
	self.wndMain:FindChild("LastAttemptWindow"):Show(false)
	if self.tLastMarkerData and self.tLastMarkerData.idSchematic and self.tLastMarkerData.idSchematic == idSchematic then -- and not IsCraftingCastBar
		self.wndMain:FindChild("LastAttemptWindow"):Show(true)
		self.wndMain:FindChild("LastAttemptWindowLabel"):SetText(self.tLastMarkerData.strHotOrCold)
		self.wndMain:FindChild("LastAttemptWindow"):SetTooltip(string.format("<P Font=\"CRB_InterfaceSmall_O\">%s</P>%s", Apollo.GetString("CoordCrafting_LastCraftTooltip"),
		self.tLastMarkerData.strTooltip or string.format("<P Font=\"CRB_InterfaceSmall_O\">%s</P>", Apollo.GetString("CoordCrafting_NoExtraMats"))))
	end

	-- Marker
	if self.wndMarker then
		self.wndMarker:Destroy()
		self.wndMarker = nil
	end

	-- Marker Positioning
	self.wndMarker = Apollo.LoadForm("CraftingGrid.xml", "GridMarker", self.wndMain:FindChild("CoordinateSchematic"), self)
	if bCurrentCraftStarted then
		local nAdjX = (-self.nMinX + tCurrentCraft.fVectorX) / (-self.nMinX + self.nMaxX)
		local nAdjY = 1.0 - (-self.nMinY + tCurrentCraft.fVectorY) / (-self.nMinY + self.nMaxY)
		self.wndMarker:FindChild("GridMarkerRefreshAnimation"):Show(self.bWndMarkerAnim)
		self.wndMarker:SetAnchorPoints(nAdjX, nAdjY, nAdjX, nAdjY)
		self.wndMarker:ToFront()
	end

	-- Grid Glows
	--[[
	if bCurrentCraftStarted and tCurrentCraft.nSubSchematicId then
		for idx, tCurrTable in pairs({self.tWndCircles, self.tWndDiscoverable}) do
			for idx2, wndCurr in pairs(tCurrTable) do
				wndCurr:FindChild("RadiusBGAnim"):Show(bCurrentCraftStarted and wndCurr:GetData() and wndCurr:GetData().nSchematicId == tCurrentCraft.nSubSchematicId)
			end
		end
	end
	]]--

	-- Enable craft button only if there is enough room in inventory
	local bHaveBagSpace = self.wndMain:FindChild("HiddenBagWindow"):GetTotalEmptyBagSlots() > 0
	self.wndMain:FindChild("CraftBtn"):Enable(bHaveBagSpace)
	if bHaveBagSpace then
		self.wndMain:FindChild("CraftBtn"):SetText(Apollo.GetString("ActivationPrompt_CraftingStation"))
	else
		self.wndMain:FindChild("CraftBtn"):SetText(Apollo.GetString("ItemSetInventory_InventoryFull"))
	end

	-- Hide if at max
	self.wndMain:FindChild("LeftSideItems"):Show(bCurrentCraftStarted and tCurrentCraft.nAdditiveCount < tSchematicInfo.nMaxAdditives)
	self.wndMain:FindChild("BGHelperText_ReadyToCraft"):Show(bCurrentCraftStarted and tCurrentCraft.nAdditiveCount == tSchematicInfo.nMaxAdditives)
end

function CraftingGrid:RedrawCash()
	if not self.wndMain or not self.wndMain:IsValid() or not self.wndMain:IsVisible() then
		return
	end

	self.wndMain:FindChild("BGPlayerCashWindow"):SetAmount(GameLib.GetPlayerCurrency(), true)
end

-----------------------------------------------------------------------------------------------
-- Craft Btn
-----------------------------------------------------------------------------------------------

function CraftingGrid:OnPreviewStartCraft(wndHandler, wndControl) -- PreviewStartCraftBtn, data is idSchematic
	local idSchematic = wndHandler:GetData()
	local tCurrentCraft = CraftingLib.GetCurrentCraft()
	if not tCurrentCraft or tCurrentCraft.nSchematicId == 0 then -- Start if it hasn't started already (i.e. just clicking craft button)
		CraftingLib.CraftItem(idSchematic, self.wndMain:FindChild("CatalystGlobalList"):GetData()) -- 2nd arg is catalyst, and can be nil

		-- Wipe Last Attempt
		if self.tLastMarkerData.wndLastMarker then
			self.tLastMarkerData.wndLastMarker:Destroy()
		end

		self.tLastMarkerData.wndLastMarker = nil
		self.tLastMarkerData.strHotOrCold = nil
		self.tLastMarkerData.strTooltip = nil
		self.tLastMarkerData.idSchematic = nil
		self.tLastMarkerData.nPosX = nil
		self.tLastMarkerData.nPosY = nil
	end

	-- We need a complete redraw for catalysts
	if self.wndMain:FindChild("CatalystGlobalList"):GetData() then
		self.bFullDestroyDueToCatalyst = true
	else
		self:RedrawAll()
	end
end

function CraftingGrid:OnCraftingUpdateCurrent()
	if self.bFullDestroyDueToCatalyst then
		self.bFullDestroyDueToCatalyst = false
		local idSchematic = self.wndMain:GetData()
		self.wndMain:Destroy()
		Event_FireGenericEvent("GenericEvent_StartCraftingGrid", idSchematic)
	else
		self:RedrawAll()
	end
end

function CraftingGrid:OnCraftBtn(wndHandler, wndControl) -- CraftBtn
	if wndHandler ~= wndControl then
		return
	end

	-- Save Last Attempt Data
	local nPosX, nPosY = 0.5, 0.5
	if self.wndMarker and self.wndMarker:IsValid() then
		nPosX, nPosY = self.wndMarker:GetAnchorPoints()
	end

	self.tLastMarkerData =
	{
		nPosX = nPosX,
		nPosY = nPosY,
		idSchematic = self.wndMain:GetData(),
		strHotOrCold = Apollo.GetString("CoordCrafting_ViewLastCraft"),
		strTooltip = self.tLastMarkerData.strTooltip
	}

	-- Now Craft
	CraftingLib.CompleteCraft()

	Apollo.StartTimer("CraftingGrid_CraftBtnTimer")

	-- TODO TEMP!
	self.wndMain:Destroy()
end

function CraftingGrid:OnCraftingGrid_CraftBtnTimer()
	-- Build message to send to crafting summary screen (After Craft)
	local strLastMarkerData = self.tLastMarkerData.strTooltip or ""
	if string.len(strLastMarkerData) > 0 then
		local strCraftSummaryMsg = string.format("<P Font=\"CRB_InterfaceSmall\">%s</P>%s", Apollo.GetString("CoordCrafting_ItemsUsedSummary"), strLastMarkerData)
		Event_FireGenericEvent("GenericEvent_CraftSummaryMsg", strCraftSummaryMsg)
	end
end

function CraftingGrid:OnAdditiveClick(wndHandler, wndControl) -- AdditiveItem, data is an itemData
	if wndHandler ~= wndControl then
		return
	end

	-- Hide additive preview and tutorial
	self:OnAdditiveMouseExit()
	self:OnCraftingGrid_HideHelperText()

	local itemData = wndHandler:GetData()
	local idSchematic = self.wndMain:GetData()

	if itemData then
		CraftingLib.AddAdditive(itemData)

		-- Add to Materials
		local tCurrentCraft = CraftingLib.GetCurrentCraft()
		if tCurrentCraft then
			self.tAdditivesAdded[tCurrentCraft.nAdditiveCount + 1] = itemData
		end

		-- Add to new Last Attempt tooltip
		if tCurrentCraft and tCurrentCraft.nAdditiveCount < CraftingLib.GetSchematicInfo(idSchematic).nMaxAdditives then
			local strPrevious = self.tLastMarkerData.strTooltip or ""
			self.tLastMarkerData.strTooltip = string.format("%s<P Font=\"CRB_InterfaceSmall\">%s</P>", strPrevious, itemData:GetName())
		end
	end

	if self.wndMarker and self.wndMarker:IsValid() then
		Apollo.StartTimer("CraftingGrid_StopGridMarkerAnim")
		self.wndMarker:FindChild("GridMarkerRefreshAnimation"):Show(true)
		self.bWndMarkerAnim = true
	end

	-- Success event will call: self:RedrawAll()
end

function CraftingGrid:OnCraftingGrid_StopGridMarkerAnim()
	if self.wndMarker and self.wndMarker:IsValid() then
		self.wndMarker:FindChild("GridMarkerRefreshAnimation"):Show(false)
		self.bWndMarkerAnim = false
	end
end

-----------------------------------------------------------------------------------------------
-- UI Interaction
-----------------------------------------------------------------------------------------------

function CraftingGrid:OnGlobalBoostItemToggle(wndHandler, wndControl) -- GlobalBoostItem, data is itemCatalyst
	self.wndMain:FindChild("CatalystGlobalList"):SetData(wndHandler:IsChecked() and wndHandler:GetData() or nil)
end

function CraftingGrid:OnBackToTradeskillsBtn(wndHandler, wndControl)
	if self.wndMain and self.wndMain:IsValid() then
		self.wndMain:Destroy()
	end
	Event_FireGenericEvent("AlwaysShowTradeskills")
end

function CraftingGrid:OnCloseBtn(wndHandler, wndControl)
	if self.wndMain and self.wndMain:IsValid() then
		self.wndMain:Destroy()

		local tCurrentCraft = CraftingLib.GetCurrentCraft()
		if tCurrentCraft and tCurrentCraft.nSchematicId ~= 0 then
			Event_FireGenericEvent("GenericEvent_LootChannelMessage", Apollo.GetString("CoordCrafting_CraftingInterrupted"))
		end
	end
	Event_FireGenericEvent("AlwaysShowTradeskills")
end

function CraftingGrid:OnAdditiveMouseEnter(wndHandler, wndControl) -- AdditiveItem's AdditiveMouseCatcher, data is an itemData
	if self.wndAdditiveEstimate and self.wndAdditiveEstimate:IsValid() then
		self.wndAdditiveEstimate:Destroy()
		self.wndAdditiveEstimate = nil
	end

	local itemData = wndControl:GetData()
	local tCurrentCraft = CraftingLib.GetCurrentCraft()
	local tSchematicInfo = CraftingLib.GetSchematicInfo(self.wndMain:GetData())

	-- Early exit if nil or already at max additives
	if not tSchematicInfo or not itemData or (tCurrentCraft and tCurrentCraft.nAdditiveCount >= tSchematicInfo.nMaxAdditives) then
		return
	end

	-- Position and Radius Size
	local tAdditiveInfo = itemData:GetAdditiveInfo()
	local nAdjX = (-self.nMinX + (tCurrentCraft and tCurrentCraft.fVectorX or 0) + tAdditiveInfo.fVectorX) / (-self.nMinX + self.nMaxX)
	local nAdjY = 1.0 - (-self.nMinY + (tCurrentCraft and tCurrentCraft.fVectorY or 0) + tAdditiveInfo.fVectorY) / (-self.nMinY + self.nMaxY)
	local nRadiusAdjX = tAdditiveInfo.fRadius == 0 and 5 or (tAdditiveInfo.fRadius / self.nMaxX * self.wndMain:FindChild("CoordinateSchematic"):GetWidth() / 2.0)
	local nRadiusAdjY = tAdditiveInfo.fRadius == 0 and 5 or (tAdditiveInfo.fRadius / self.nMaxY * self.wndMain:FindChild("CoordinateSchematic"):GetHeight() / 2.0)

	self.wndAdditiveEstimate = Apollo.LoadForm("CraftingGrid.xml", "GridAdditiveEstimate", self.wndMain:FindChild("CoordinateSchematic"), self)
	self.wndAdditiveEstimate:SetAnchorPoints(nAdjX, nAdjY, nAdjX, nAdjY)
	self.wndAdditiveEstimate:SetAnchorOffsets(-nRadiusAdjX, -nRadiusAdjY, nRadiusAdjX, nRadiusAdjY)

	if self.wndMarker then
		self.wndMarker:SetBGColor("66ffffff")
	end
end

function CraftingGrid:OnAdditiveMouseExit(wndHandler, wndControl) -- AdditiveItem or Code
	if self.wndAdditiveEstimate and self.wndAdditiveEstimate:IsValid() then
		self.wndAdditiveEstimate:Destroy()
	end

	if self.wndMarker then
		self.wndMarker:SetBGColor("ffffffff")
	end
end

function CraftingGrid:OnFlashAdditiveContainer(wndHandler, wndControl) -- RawMaterialsHelperBtn or RawMaterialsHelperBtn_Catalyst
	Apollo.CreateTimer("CraftingGrid_HideHelperText", 4, false)
	self.wndMain:FindChild("BGHelperText_Additives"):Show(true)
	self.wndMain:FindChild("BGHelperText_AdditivesAnim"):SetSprite("sprWinAnim_BirthSmallTempDouble")
end

function CraftingGrid:OnCraftingGrid_HideHelperText()
	Apollo.StopTimer("CraftingGrid_HideHelperText")
	if self.wndMain and self.wndMain:IsValid() then
		self.wndMain:FindChild("BGHelperText_Additives"):Show(false)
		self.wndMain:FindChild("BGHelperText_ReadyToCraft"):Show(false)

		if self.wndMain:FindChild("Tutorial_SmallLeftArrow") then
			self.wndMain:FindChild("Tutorial_SmallLeftArrow"):Show(false) -- TODO REFACTOR, temp + intense search
		end
	end
end

function CraftingGrid:OnMaterialsLockedItemBtn(wndHandler, wndControl) -- wndHandler is "MaterialsLockedItemBtn" and its data is achSource
	Event_FireGenericEvent("GenericEvent_OpenToSpecificTechTree", wndHandler:GetData())
end

function CraftingGrid:OnAdditiveFilterUpdate() -- Compass Buttons
	self:RedrawAll(nil)
end

function CraftingGrid:RequestRedrawFromUI(wndHandler, wndControl)
	self:RedrawAll(nil)
end

-----------------------------------------------------------------------------------------------
-- Last Attempt
-----------------------------------------------------------------------------------------------

function CraftingGrid:OnCraftingDiscoveryHotCold(eHotCold, eDirection)
	local tCurrentCraft = CraftingLib.GetCurrentCraft()
	if tCurrentCraft and tCurrentCraft.nSchematicId then
		self.tLastMarkerData.idSchematic = tCurrentCraft.nSchematicId
		self.tLastMarkerData.strHotOrCold = ktHotOrColdToString[eHotCold]
		self.tLastMarkerData.eDirection = eDirection
	end

	-- TODO: More messaging?
	if eHotCold ~= CraftingLib.CodeEnumCraftingDiscoveryHotCold.Success then
		local strNeedAdjust = ""

		if eDirection ~= CraftingLib.CodeEnumCraftingDirection.None then
			local tSchematicInfo = tCurrentCraft and tCurrentCraft.nSchematicId and CraftingLib.GetSchematicInfo(tCurrentCraft.nSchematicId)
			local tInfo = tSchematicInfo and CraftingLib.GetTradeskillInfo(tSchematicInfo.eTradeskillId)
			if tInfo and tInfo.tAxisNames then
				if eDirection == CraftingLib.CodeEnumCraftingDirection.N or eDirection == CraftingLib.CodeEnumCraftingDirection.NE or eDirection == CraftingLib.CodeEnumCraftingDirection.NW then
					strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryMore") .. " " .. tInfo.tAxisNames[2]
				elseif eDirection == CraftingLib.CodeEnumCraftingDirection.S or eDirection == CraftingLib.CodeEnumCraftingDirection.SE or eDirection == CraftingLib.CodeEnumCraftingDirection.SW then
					if tInfo.tAxisNames[2] ~= tInfo.tAxisNames[4] then
						strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryMore") .. " " .. tInfo.tAxisNames[4]
					else
						strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryLess") .. " " .. tInfo.tAxisNames[2]
					end
				end
				if eDirection == CraftingLib.CodeEnumCraftingDirection.E or eDirection == CraftingLib.CodeEnumCraftingDirection.NE or eDirection == CraftingLib.CodeEnumCraftingDirection.SE then
					strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryMore") .. " " .. tInfo.tAxisNames[1]
				elseif eDirection == CraftingLib.CodeEnumCraftingDirection.W or eDirection == CraftingLib.CodeEnumCraftingDirection.NW or eDirection == CraftingLib.CodeEnumCraftingDirection.SW then
					if tInfo.tAxisNames[1] ~= tInfo.tAxisNames[3] then
						strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryMore") .. " " .. tInfo.tAxisNames[3]
					else
						strNeedAdjust = " " .. Apollo.GetString("Crafting_DiscoveryLess") .. " " .. tInfo.tAxisNames[1]
					end
				end
			end
		end
		Event_FireGenericEvent("GenericEvent_LootChannelMessage", String_GetWeaselString(Apollo.GetString("CoordCrafting_DiscoveryLabel"), ktHotOrColdToString[eHotCold] .. strNeedAdjust))
	end
end

function CraftingGrid:OnLastAttemptWindowClick(wndHandler, wndControl)
	if self.tLastMarkerData.wndLastMarker then
		self.tLastMarkerData.wndLastMarker:FindChild("LastMarkerAnim"):Show(true)
	end
end

function CraftingGrid:OnLastAttemptWindowMouseEnter(wndHandler, wndControl)
	local idSchematic = self.wndMain:GetData()
	if idSchematic and self.tLastMarkerData and self.tLastMarkerData.idSchematic == idSchematic then
		if self.tLastMarkerData.wndLastMarker then
			self.tLastMarkerData.wndLastMarker:Destroy()
			self.tLastMarkerData.wndLastMarker = nil
		end

		self.tLastMarkerData.wndLastMarker = Apollo.LoadForm("CraftingGrid.xml", "GridLastMarker", self.wndMain:FindChild("CoordinateSchematic"), self)
		self.tLastMarkerData.wndLastMarker:SetAnchorPoints(self.tLastMarkerData.nPosX, self.tLastMarkerData.nPosY, self.tLastMarkerData.nPosX, self.tLastMarkerData.nPosY)
		self.tLastMarkerData.wndLastMarker:ToFront()
	end
end

function CraftingGrid:OnLastAttemptWindowMouseExit(wndHandler, wndControl)
	if self.tLastMarkerData.wndLastMarker then
		self.tLastMarkerData.wndLastMarker:Destroy()
		self.tLastMarkerData.wndLastMarker = nil
	end
end

-----------------------------------------------------------------------------------------------
-- Set Up
-----------------------------------------------------------------------------------------------

function CraftingGrid:BuildNewGrid(idSchematic)
	local tSchematicInfo = CraftingLib.GetSchematicInfo(idSchematic)
	if not tSchematicInfo then
		return
	end

	-- Math for max dimensions
	self.nMaxX = math.abs(tSchematicInfo.fVectorX) + tSchematicInfo.fRadius
	self.nMaxY = math.abs(tSchematicInfo.fVectorY) + tSchematicInfo.fRadius

	local nCurr = math.max(self.nMaxX, self.nMaxY)
	for idx, tSchem in ipairs(tSchematicInfo.tSubRecipes) do
		if not tSchem.bIsUndiscovered then
			nCurr = math.max(nCurr, math.abs(tSchem.fVectorX) + tSchem.fRadius, math.abs(tSchem.fVectorY) + tSchem.fRadius)
		elseif tSchem.fDiscoveryDistanceMax > nCurr then
			nCurr = tSchem.fDiscoveryDistanceMax
		end
	end
	nCurr = math.max(4, nCurr + 1.0) -- Hardcoded formatting

	self.nMaxY = nCurr
	self.nMaxX = nCurr
	self.nMinX = -nCurr
	self.nMinY = -nCurr

	-- Discoverables
	for key, wndCurr in ipairs(self.tWndDiscoverable) do
		wndCurr:Destroy()
	end
	self.tWndDiscoverable = {}
	for key, tSchem in ipairs(tSchematicInfo.tSubRecipes) do
		if tSchem.bIsUndiscovered then
			table.insert(self.tWndDiscoverable, self:BuildNewDiscoverable(tSchem))
		end
	end

	-- Circles
	for key, wndCurr in ipairs(self.tWndCircles) do
		wndCurr:Destroy()
	end
	self.tWndCircles = {}
	for key, tSchem in ipairs(tSchematicInfo.tSubRecipes) do
		if not tSchem.bIsUndiscovered then
			table.insert(self.tWndCircles, self:BuildNewGridCircle(tSchem))
		end
	end

	-- Axis Labels
	local tInfo = CraftingLib.GetTradeskillInfo(tSchematicInfo.eTradeskillId)
	if tInfo.tAxisNames then
		self.wndMain:FindChild("XAxisRightLabel"):SetText(tInfo.tAxisNames[1])
		self.wndMain:FindChild("YAxisTopLabel"):SetText(tInfo.tAxisNames[2])
		self.wndMain:FindChild("XAxisLeftLabel"):SetText(tInfo.tAxisNames[3])
		self.wndMain:FindChild("YAxisBottomLabel"):SetText(tInfo.tAxisNames[4])
	end

	-- Reset
	self.tAdditivesAdded = {}
end

function CraftingGrid:BuildNewDiscoverable(tSchem) -- discoveryAngle, discoveryDistanceMin, discoveryDistanceMax
	local fLocalRotation = tSchem.fDiscoveryAngle + 45
	local wndResult = Apollo.LoadForm("CraftingGrid.xml", "GridDiscoverable", self.wndMain:FindChild("Discoverables"), self)
	wndResult:SetData(tSchem)
	
	local calcCords = function(nCenter, nRotation)
		local nLocalRadians = 2 * math.pi * (nRotation / 360)
		local nX = (nCenter * (math.cos(nLocalRadians) - math.sin(nLocalRadians)))
		local nY = (nCenter * (math.sin(nLocalRadians) + math.cos(nLocalRadians)))
		
		return nX, nY
	end
	
	local nRadiusMax = tSchem.fDiscoveryDistanceMax / self.nMaxX * self.wndMain:FindChild("CoordinateSchematic"):GetWidth() / 2.0
	local nHalfRadiusMax = nRadiusMax / 2
	local nMaxX, nMaxY = calcCords(nHalfRadiusMax, fLocalRotation)
	
	local tDiscoveryRadius =
	{
		loc =
		{
			fPoints = { 0.5, 0.5, 0.5, 0.5 },
			nOffsets = { nMaxX-nHalfRadiusMax, nMaxY-nHalfRadiusMax, nMaxX+nHalfRadiusMax, nMaxY+nHalfRadiusMax },
		},
		fRotation = math.atan2(-nMaxY, -nMaxX) * (180/math.pi) + 225,
		strSprite = "UI_CRB_QuarterCircle_512",
		cr = ApolloColor.new("UI_TextHoloBody")
	}
	local nBgPixieId = wndResult:AddPixie(tDiscoveryRadius)

	
	local nRadiusMin = tSchem.fDiscoveryDistanceMin / self.nMaxX * self.wndMain:FindChild("CoordinateSchematic"):GetWidth() / 2.0
	local nHalfRadiusMin = nRadiusMin / 2
	local nMinX, nMinY = calcCords(nHalfRadiusMin, fLocalRotation)
	local tDiscoveryRadius =
	{
		loc =
		{
			fPoints = { 0.5, 0.5, 0.5, 0.5 },
			nOffsets = { nMinX-nHalfRadiusMin, nMinY-nHalfRadiusMin, nMinX+nHalfRadiusMin, nMinY+nHalfRadiusMin },
		},
		fRotation = math.atan2(-nMinY, -nMinX) * (180/math.pi) + 225,
		strSprite = "UI_CRB_QuarterCircle_512",
		cr = ApolloColor.new("black")
	}
	local nInnerRadiusPixieId = wndResult:AddPixie(tDiscoveryRadius)
	
	
	
	return wndResult
end

function CraftingGrid:BuildNewGridCircle(tSchem) -- vectorX, vectorY, radius
	local wndResult = Apollo.LoadForm("CraftingGrid.xml", "GridCircle", self.wndMain:FindChild("Graph"), self)
	wndResult:SetData(tSchem)

	-- Resize and Position
	local nAdjX = (-self.nMinX + tSchem.fVectorX) / (-self.nMinX + self.nMaxX)
	local nAdjY = 1.0 - (-self.nMinY + tSchem.fVectorY) / (-self.nMinY + self.nMaxY)
	wndResult:SetAnchorPoints(nAdjX, nAdjY, nAdjX, nAdjY)

	local nRadiusAdjX = tSchem.fRadius / self.nMaxX * self.wndMain:FindChild("CoordinateSchematic"):GetWidth() / 2.0
	local nRadiusAdjY = tSchem.fRadius / self.nMaxY * self.wndMain:FindChild("CoordinateSchematic"):GetHeight() / 2.0
	if nRadiusAdjX < 25 and nRadiusAdjY < 25 and nRadiusAdjX ~= 0 then -- TODO TEMP REMOVE: Bad art minimium size hack
		nRadiusAdjX = 25
		nRadiusAdjY = 25
	end
	wndResult:FindChild("Radius"):SetAnchorOffsets(-nRadiusAdjX, -nRadiusAdjY, nRadiusAdjX, nRadiusAdjY)

	-- Tooltip and Icon
	local itemCraft = tSchem.itemOutput
	if tSchem.bIsKnown or tSchem.bIsUndiscovered then
		local strTooltip = string.format("<P Font=\"CRB_InterfaceSmall\" TextColor=\"ff9d9d9d\">%s</P><P Font=\"CRB_InterfaceSmall\" TextColor=\"%s\">%s</P>",
		Apollo.GetString("CoordCrafting_LandInCircle"), karEvalColors[itemCraft:GetItemQuality()], itemCraft:GetName())
		if itemCraft:GetActivateSpell() then
			strTooltip = strTooltip.."<P Font=\"CRB_InterfaceSmall\">"..itemCraft:GetActivateSpell():GetFlavor().."</P>"
		elseif itemCraft:GetItemFlavor() then
			strTooltip = strTooltip.."<P Font=\"CRB_InterfaceSmall\">"..itemCraft:GetItemFlavor().."</P>"
		end
		wndResult:FindChild("RadiusTooltipHack"):SetTooltip(strTooltip)
	else -- If not yet known and it's not a free to discover one, then show a lock icon
		local wndMaterialsLocked = Apollo.LoadForm("CraftingGrid.xml", "GridMaterialsLockedItem", wndResult, self)
		wndMaterialsLocked:ToFront()
		wndMaterialsLocked:FindChild("MaterialsLockedItemBtn"):SetData(tSchem.achSource)
		wndMaterialsLocked:FindChild("MaterialsLockedItemMouseCatcher"):SetTooltip(string.format(
		"<P Font=\"CRB_InterfaceSmall\" TextColor=\"ff9d9d9d\">%s</P><P Font=\"CRB_InterfaceSmall\">%s</P>", Apollo.GetString("CoordCrafting_UnlockTooltip"), tSchem.itemOutput:GetName()))
	end
	wndResult:FindChild("CoordinateIcon"):SetSprite(itemCraft:GetIcon())

	return wndResult
end

-----------------------------------------------------------------------------------------------
-- Helpers
-----------------------------------------------------------------------------------------------

function CraftingGrid:HelperValidAdditiveCheck(tSchematicInfo, itemCurr, tFilters)
	local tAdditive = itemCurr:GetAdditiveInfo()
	if not tAdditive or tAdditive.eTradeskillId ~= tSchematicInfo.eTradeskillId then
		return false
	end

	local bDisplay = true
	if tFilters[5] then -- Allow 0's
		if tAdditive.fVectorY > 0 and not tFilters[1] then
			bDisplay = false
		elseif tAdditive.fVectorX > 0 and not tFilters[2] then
			bDisplay = false
		elseif tAdditive.fVectorY < 0 and not tFilters[3] then
			bDisplay = false
		elseif tAdditive.fVectorX < 0 and not tFilters[4] then
			bDisplay = false
		end
	else
		if tAdditive.fVectorY >= 0 and not tFilters[1] then
			bDisplay = false
		elseif tAdditive.fVectorX >= 0 and not tFilters[2] then
			bDisplay = false
		elseif tAdditive.fVectorY <= 0 and not tFilters[3] then
			bDisplay = false
		elseif tAdditive.fVectorX <= 0 and not tFilters[4] then
			bDisplay = false
		end
	end

	return bDisplay
end

function CraftingGrid:HelperStringMoneyConvert(nInCopper)
	local strResult = ""
	if nInCopper >= 1000000 then -- 12345678 = 12p 34g 56s 78c
		strResult = String_GetWeaselString(Apollo.GetString("CRB_Platinum"), math.floor(nInCopper/1000000)) .. " "
	end
	if nInCopper >= 10000 then
		strResult = strResult .. String_GetWeaselString(Apollo.GetString("CRB_Gold"), math.floor(nInCopper % 1000000 / 10000)) .. " "
	end
	if nInCopper >= 100 then
		strResult = strResult .. String_GetWeaselString(Apollo.GetString("CRB_Silver"), math.floor(nInCopper % 10000 / 100)) .. " "
	end
	strResult = strResult .. String_GetWeaselString(Apollo.GetString("CRB_Copper"), math.floor(nInCopper % 100))
	return strResult
end

function CraftingGrid:HelperBuildItemTooltip(wndArg, itemCurr)
	wndArg:SetTooltipDoc(nil)
	wndArg:SetTooltipDocSecondary(nil)
	local itemEquipped = itemCurr:GetEquippedItemForItemType()
	Tooltip.GetItemTooltipForm(self, wndArg, itemCurr, {bPrimary = true, bSelling = false, itemCompare = itemEquipped})
end

local CraftingGridInst = CraftingGrid:new()
CraftingGridInst:Init()
