-----------------------------------------------------------------------------------------------
-- Client Lua Script for AccountInventory
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "AccountItemLib"
require "FriendshipLib"


-----------------------------------------------------------------------------------------------
-- AccountInventory Module Definition
-----------------------------------------------------------------------------------------------

local AccountInventory = {}


-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------

function AccountInventory:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function AccountInventory:Init()
    Apollo.RegisterAddon(self)
end


-----------------------------------------------------------------------------------------------
-- AccountInventory OnLoad
-----------------------------------------------------------------------------------------------

function AccountInventory:OnLoad()
    Apollo.RegisterSlashCommand("ai", "OnAccountInventoryOn", self)
	
	Apollo.RegisterEventHandler("AccountPendingItemsUpdate", "OnAccountPendingItemsUpdate", self)
	Apollo.RegisterEventHandler("AccountInventoryUpdate", "OnAccountInventoryUpdate", self)
	Apollo.RegisterEventHandler("AccountEntitlementUpdate", "OnAccountEntitlementUpdate", self)
	
	self.wndMain = nil
	self.wndMainGrid = nil
	self.wndBlocker = nil
	self.wndPending = nil
	self.wndPendingGrid = nil
	self.wndPendingBlocker = nil
	self.wndFriends = nil
	self.wndFriendsGrig = nil
	self.wndCoupons = nil
	self.wndEntitlements = nil
	self.wndEntitlementsGrid = nil
	
	self.btnClaim = nil
	self.btnPendingClaim = nil
	self.btnPendingGift = nil
	self.btnPendingReturn = nil
	self.btnFriendsGift = nil
	
	self.btnObjectClicked = nil
	self.btnFriendClicked = nil
	
	self.bxCodeBox = nil
end

function AccountInventory:OnAccountInventoryOn()
	if self.wndMain == nil then
		self:SetupMainWindow()
	else
		self.wndMain:Destroy()
		self.wndMain = nil
	end
end

function AccountInventory:OnAccountPendingItemsUpdate()
	if self.wndMain == nil or not self.wndMain:IsValid() then
		return
	end
	
	self:RefreshInventory()
end

function AccountInventory:OnAccountInventoryUpdate()
	if self.wndMain == nil or not self.wndMain:IsValid() then
		return
	end
	
	self:RefreshInventory()
end

function AccountInventory:OnAccountEntitlementUpdate()
	if self.wndMain == nil or not self.wndMain:IsValid() then
		return
	end
	
	self:RefreshEntitlements()
end

function AccountInventory:OnClose()
	if self.wndMain ~= nil and self.wndMain:IsValid() then
		self.wndMain:Destroy()
	end
	
	self.wndMain = nil
end

-----------------------------------------------------------------------------------------------
-- Other Functions
-----------------------------------------------------------------------------------------------

function AccountInventory:SetupMainWindow()
	self.wndMain = Apollo.LoadForm("AccountInventory.xml", "AccountInventoryForm", nil, self)
	self.wndMainGrid = self.wndMain:FindChild("MainGridContainer")
	self.wndBlocker = self.wndMain:FindChild("Blocker")
	self.wndPending = self.wndMain:FindChild("PendingForm")
	self.wndPendingGrid = self.wndMain:FindChild("PendingGridContainer")
	self.wndPendingBlocker = self.wndMain:FindChild("PendingBlocker")
	self.wndFriends = self.wndMain:FindChild("FriendsForm")
	self.wndFriendsGrid = self.wndMain:FindChild("FriendsGridContainer")
	self.wndCoupons = self.wndMain:FindChild("CouponsForm")
	self.wndEntitlements = self.wndMain:FindChild("EntitlementsForm")
	self.wndEntitlementsGrid = self.wndMain:FindChild("EntitlementsGridContainer")
	
	self.btnClaim = self.wndMain:FindChild("ClaimButton")
	self.btnPendingClaim = self.wndMain:FindChild("PendingClaimButton")
	self.btnPendingGift = self.wndMain:FindChild("PendingGiftButton")
	self.btnPendingReturn = self.wndMain:FindChild("PendingReturnButton")
	self.btnFriendsGift = self.wndMain:FindChild("FriendsGiftButton")
	
	--Menu buttons
	self.wndInventoryBtn = self.wndMain:FindChild("MenuContainer:InventoryBtn")
	self.wndInventoryBtn:SetCheck(true)
	
	self.wndEntitlementsBtn = self.wndMain:FindChild("MenuContainer:EntitlementsBtn")
	self.wndCouponsBtn = self.wndMain:FindChild("MenuContainer:CouponsBtn")
	self.wndCouponsBtn:Enable(false)
	
	self.wndLogsBtn = self.wndMain:FindChild("MenuContainer:LogsBtn")
	
	--Containers
	self.wndInventory = self.wndMain:FindChild("ContentContainer:Inventory")
	self.wndInventoryGift = self.wndMain:FindChild("ContentContainer:InventoryGift")
	self.wndInventoryClaimConfirm = self.wndMain:FindChild("ContentContainer:InventoryClaimConfirm")
	self.wndInventoryGiftConfirm = self.wndMain:FindChild("ContentContainer:InventoryGiftConfirm")
	self.wndEntitlements = self.wndMain:FindChild("ContentContainer:Entitlements")
	self.wndLog = self.wndMain:FindChild("ContentContainer:Log")
	
	--Currency
	self.wndClaimedCredd = self.wndMain:FindChild("CurrencyContainer:ClaimedCredd")
	self.wndClaimedTransfers = self.wndMain:FindChild("CurrencyContainer:ClaimedTransfers")
	
	--Inventory
	self.wndEscrowGridContainer = self.wndMain:FindChild("ContentContainer:Inventory:EscrowGridContainer")
	self.wndInventoryGridContainer = self.wndMain:FindChild("ContentContainer:Inventory:InventoryGridContainer")
	self.wndInventoryClaimBtn = self.wndMain:FindChild("ContentContainer:Inventory:ClaimBtn")
	self.wndInventoryGiftBtn = self.wndMain:FindChild("ContentContainer:Inventory:GiftBtn")
	
	--Inventory Confirm
	self.wndPendingClaimContainer = self.wndMain:FindChild("ContentContainer:InventoryClaimConfirm:PendingClaimContainer")
	
	--Inventory Gift
	self.wndInventoryGiftFriendContainer = self.wndMain:FindChild("ContentContainer:InventoryGift:FriendContainer")
	self.wndInventoryGiftFriendSelectBtn = self.wndMain:FindChild("ContentContainer:InventoryGift:GiftBtn")
	
	--Inventory Gift Confirm
	self.wndInventoryGiftConfirmItemContainer = self.wndMain:FindChild("ContentContainer:InventoryGiftConfirm:InventoryGiftConfirmItemContainer")
	
	--Entitlements
	self.wndAccountGridContainer = self.wndMain:FindChild("ContentContainer:Entitlements:AccountGridContainer")
	self.wndCharacterGridContainer = self.wndMain:FindChild("ContentContainer:Entitlements:CharacterGridContainer")
	
	
	
	
	self.btnObjectClicked = nil
	self.btnFriendClicked = nil
	
	self.bxCodeBox = self.wndMain:FindChild("CouponsCodeBox")
	
	self:RefreshCurrency()
	self:RefreshInventory()
	self:RefreshEntitlements()
end

function AccountInventory:OnInventoryCheck(wndHandler, wndControl, eMouseButton)
	self:OnInventoryUncheck()
	self.wndInventory:Show(true)
end

function AccountInventory:OnInventoryUncheck(wndHandler, wndControl, eMouseButton)
	self.wndInventory:Show(false)
	self.wndInventoryGift:Show(false)
	self.wndInventoryGiftConfirm:Show(false)
	self.wndInventoryClaimConfirm:Show(false)
end

function AccountInventory:OnEntitlementsCheck(wndHandler, wndControl, eMouseButton)
	self:OnEntitlementsUncheck()
	self.wndEntitlements:Show(true)
end

function AccountInventory:OnEntitlementsUncheck(wndHandler, wndControl, eMouseButton)
	self.wndEntitlements:Show(false)
end

function AccountInventory:OnLogCheck(wndHandler, wndControl, eMouseButton)
	self:OnLogUncheck()
	self.wndLog:Show(true)
end

function AccountInventory:OnLogUncheck(wndHandler, wndControl, eMouseButton)
	self.wndLog:Show(false)
end

function AccountInventory:RefreshCurrency()
	local nClaimedCredd = AccountItemLib.GetAccountCurrency(AccountItemLib.CodeEnumAccountCurrency.CREDD)
	self.wndClaimedCredd:SetText("Credd: "..nClaimedCredd)
	
	local nClaimedTransfers = AccountItemLib.GetAccountCurrency(AccountItemLib.CodeEnumAccountCurrency.RealmTransfer)
	self.wndClaimedTransfers:SetText("Transfers "..nClaimedTransfers)
end

--[[
Inventory
]]--

function AccountInventory:HelperAddPendingSingleToContainer(wndContainer, tPendingAccountItem)
	local strName
	local strIcon
	local strDesc

	if tPendingAccountItem.item ~= nil then
		strName = tPendingAccountItem.item:GetName()
		strIcon = tPendingAccountItem.item:GetIcon()
	elseif tPendingAccountItem.entitlement ~= nil then
		strName = tPendingAccountItem.entitlement.name
		strIcon = tPendingAccountItem.entitlement.icon or strIcon
	elseif tPendingAccountItem.accountCurrency ~= nil then
		strName = "AccountCurrency"
	else
		strName = "Error"
	end
	
	if strIcon == nil or strIcon == "" then
		strIcon = tPendingAccountItem.icon
	end
	
	local wndGroup = Apollo.LoadForm("AccountInventory.xml", "InventoryPendingGroupForm", wndContainer, self)
	wndGroup:SetData({bIsGroup=false, tData = tPendingAccountItem})
	
	local wndGroupContaner = wndGroup:FindChild("ItemContainer")
	local wndObject = Apollo.LoadForm("AccountInventory.xml", "InventoryPendingGroupItemForm", wndGroupContaner, self)
	wndObject:SetData(tPendingAccountItem)
	
	wndObject:FindChild("Name"):SetText(strName)
	wndObject:FindChild("Icon"):SetSprite(strIcon)
	
	local nHeight = wndGroupContaner:ArrangeChildrenVert(0)
	local nLeft, nTop, nRight, nBottom = wndGroupContaner:GetAnchorOffsets()
	wndGroupContaner:SetAnchorOffsets(nLeft, nTop, nRight, nTop+nHeight)
	
	local nLeft, nTop, nRight, nBottom = wndGroup:GetAnchorOffsets()
	wndGroup:SetAnchorOffsets(nLeft, nTop, nRight, nTop+nHeight+20)
end

function AccountInventory:HelperAddPendingGroupToContainer(wndContainer, tPendingAccountItemGroup)
	local wndGroup = Apollo.LoadForm("AccountInventory.xml", "InventoryPendingGroupForm", wndContainer, self)
	wndGroup:SetData({bIsGroup=true, tData = tPendingAccountItemGroup})
	
	local wndGroupContaner = wndGroup:FindChild("ItemContainer")
	for idx, tPendingAccountItem in pairs(tPendingAccountItemGroup.items) do
		local wndObject = Apollo.LoadForm("AccountInventory.xml", "InventoryPendingGroupItemForm", wndGroupContaner, self)
		wndObject:SetData(tPendingAccountItem)
		
		if tPendingAccountItem.item ~= nil then
			wndObject:FindChild("Name"):SetText(tPendingAccountItem.item:GetName())
			wndObject:FindChild("Icon"):SetSprite(tPendingAccountItem.item:GetIcon())
		elseif tPendingAccountItem.entitlement ~= nil then
			wndObject:FindChild("Name"):SetText(tPendingAccountItem.entitlement.name)
			wndObject:FindChild("Icon"):SetSprite(tPendingAccountItem.entitlement.icon)
		else
			wndObject:FindChild("Name"):SetText("Error")
		end
	end
	local nHeight = wndGroupContaner:ArrangeChildrenVert(0)
	local nLeft, nTop, nRight, nBottom = wndGroupContaner:GetAnchorOffsets()
	wndGroupContaner:SetAnchorOffsets(nLeft, nTop, nRight, nTop+nHeight)
	
	local nLeft, nTop, nRight, nBottom = wndGroup:GetAnchorOffsets()
	wndGroup:SetAnchorOffsets(nLeft, nTop, nRight, nTop+nHeight+20)
end

function AccountInventory:RefreshInventory()
	self.wndEscrowGridContainer:DestroyChildren()
	for idx, tPendingAccountItem in pairs(AccountItemLib.GetPendingAccountSingleItems()) do
		self:HelperAddPendingSingleToContainer(self.wndEscrowGridContainer, tPendingAccountItem)
	end
	
	for idx, tPendingAccountItemGroup in pairs(AccountItemLib.GetPendingAccountItemGroups()) do
		self:HelperAddPendingGroupToContainer(self.wndEscrowGridContainer, tPendingAccountItemGroup)
	end
	self.wndEscrowGridContainer:ArrangeChildrenVert(0)
	
	
	
	
	
	
	self.wndInventoryGridContainer:DestroyChildren()
	for idx, tPendingAccountItem in pairs(AccountItemLib.GetAccountItems()) do
		--local wndObject = Apollo.LoadForm("AccountInventory.xml", "InventoryForm", self.wndInventoryGridContainer, self)
	end
	self.wndInventoryGridContainer:ArrangeChildrenVert(0)
	
	self:RefreshInventoryActions()
end

function AccountInventory:RefreshInventoryActions()
	local wndSelectedPendingItem
	
	for idx, wndPendingItem in pairs(self.wndEscrowGridContainer:GetChildren()) do
		if wndPendingItem:FindChild("Button"):IsChecked() then
			wndSelectedPendingItem = wndPendingItem
			break
		end
	end
	
	if wndSelectedPendingItem ~= nil then
		local tSelectedPendingData = wndSelectedPendingItem:GetData()
	
		self.wndInventoryClaimBtn:Enable(tSelectedPendingData.tData.canClaim)
		self.wndInventoryClaimBtn:SetData(tSelectedPendingData)
		self.wndInventoryGiftBtn:Enable(tSelectedPendingData.tData.canGift)
		self.wndInventoryGiftBtn:SetData(tSelectedPendingData)
	else
		self.wndInventoryClaimBtn:Enable(false)
		self.wndInventoryGiftBtn:Enable(false)
	end
end

function AccountInventory:OnPendingInventoryItemCheck(wndHandler, wndControl, eMouseButton)
	self:RefreshInventoryActions()
end

function AccountInventory:OnPendingInventoryItemcUncheck(wndHandler, wndControl, eMouseButton)
	self:RefreshInventoryActions()
end

function AccountInventory:OnPendingClaimBtn(wndHandler, wndControl, eMouseButton)
	self.wndInventoryClaimConfirm:SetData(wndControl:GetData())
	self:RefreshPendingConfirm()
	
	self.wndInventory:Show(false)
	self.wndInventoryClaimConfirm:Show(true)
end

function AccountInventory:OnPendingGiftBtn(wndHandler, wndControl, eMouseButton)
	self.wndInventoryGift:SetData(wndControl:GetData())
	self:RefreshInventoryGift()
	
	self.wndInventory:Show(false)
	self.wndInventoryGift:Show(true)
end

--[[
Inventory Confirm
]]--

function AccountInventory:RefreshPendingConfirm()
	local tSelectedPendingData = self.wndInventoryClaimConfirm:GetData()
	self.wndPendingClaimContainer:DestroyChildren()
	
	if tSelectedPendingData.bIsGroup then
		self:HelperAddPendingGroupToContainer(self.wndPendingClaimContainer, tSelectedPendingData.tData)
	else
		self:HelperAddPendingSingleToContainer(self.wndPendingClaimContainer, tSelectedPendingData.tData)
	end
end

function AccountInventory:OnPendingConfirmBtn(wndHandler, wndControl, eMouseButton)
	local tSelectedPendingData = self.wndInventoryClaimConfirm:GetData()

	if tSelectedPendingData.bIsGroup then
		AccountItemLib.ClaimPendingItemGroup(tSelectedPendingData.tData.index)
	else
		AccountItemLib.ReturnPendingSingleItem(tSelectedPendingData.tData.index)
	end
	
	self:RefreshInventory()
	self.wndInventory:Show(true)
	self.wndInventoryClaimConfirm:Show(false)
end

function AccountInventory:OnPendingConfirmCancelBtn(wndHandler, wndControl, eMouseButton)
	self.wndInventory:Show(true)
	self.wndInventoryClaimConfirm:Show(false)
end

--[[
Inventory Gift
]]--

function AccountInventory:RefreshInventoryGift()
	local tSelectedPendingData = self.wndInventoryGift:GetData()
	
	self.wndInventoryGiftFriendContainer:DestroyChildren()
	for idx, tFriend in pairs(FriendshipLib.GetAccountList()) do
		local wndFriend = Apollo.LoadForm("AccountInventory.xml", "FriendForm", self.wndInventoryGiftFriendContainer, self)
		wndFriend:SetData(tFriend)
		wndFriend:FindChild("Name"):SetText(tFriend.strCharacterName)
	end
	for idx, tFriend in pairs(FriendshipLib.GetList()) do
		local wndFriend = Apollo.LoadForm("AccountInventory.xml", "FriendForm", self.wndInventoryGiftFriendContainer, self)
		wndFriend:SetData(tFriend)
		wndFriend:FindChild("Name"):SetText(tFriend.strCharacterName)
	end
	
	self.wndInventoryGiftFriendContainer:ArrangeChildrenVert(0)
	self:RefreshInventoryGiftActions()
end

function AccountInventory:RefreshInventoryGiftActions()
	local wndSelectedFriend
	
	for idx, wndFriend in pairs(self.wndInventoryGiftFriendContainer:GetChildren()) do
		if wndFriend:FindChild("Button"):IsChecked() then
			wndSelectedFriend = wndFriend
			break
		end
	end
	
	self.wndInventoryGiftFriendSelectBtn:Enable(wndSelectedFriend ~= nil)
end

function AccountInventory:OnFriendCheck(wndHandler, wndControl, eMouseButton)
	self:RefreshInventoryGiftActions()
end

function AccountInventory:OnFriendUncheck(wndHandler, wndControl, eMouseButton)
	self:RefreshInventoryGiftActions()
end

function AccountInventory:OnPendingSelectFriendGiftBtn(wndHandler, wndControl, eMouseButton)
	local tSelectedPendingData = self.wndInventoryGift:GetData()

	tSelectedPendingData.tFriend = tSelectedPendingData
	self.wndInventoryGiftConfirm:SetData(tSelectedPendingData)
	
	self:RefreshInventoryGiftConfirm()
	self.wndInventoryGift:Show(false)
	self.wndInventoryGiftConfirm:Show(true)
end

function AccountInventory:OnPendingGiftCancelBtn(wndHandler, wndControl, eMouseButton)
	self.wndInventory:Show(true)
	self.wndInventoryGift:Show(false)
end

--[[
Inventory Gift Confirm
]]--

function AccountInventory:RefreshInventoryGiftConfirm()
	local tSelectedPendingData = self.wndInventoryGiftConfirm:GetData()
	self.wndInventoryGiftConfirmItemContainer:DestroyChildren()
	
	if tSelectedPendingData.bIsGroup then
		self:HelperAddPendingGroupToContainer(self.wndInventoryGiftConfirmItemContainer, tSelectedPendingData.tData)
	else
		self:HelperAddPendingSingleToContainer(self.wndInventoryGiftConfirmItemContainer, tSelectedPendingData.tData)
	end
end

function AccountInventory:OnPendingGiftConfirmBtn(wndHandler, wndControl, eMouseButton)
	local wndParent = wndControl:GetParent()
	local tSelectedPendingData = wndParent:GetData()

	if tSelectedPendingData.bIsGroup and tSelectedPendingData.tFriend.bFriend then
		AccountItemLib.GiftPendingItemGroupToCharacter(tSelectedPendingData.tData.index, tSelectedPendingData.tFriend.nId)
	elseif tSelectedPendingData.tFriend.bFriend then
		AccountItemLib.GiftPendingItemToCharacter(tSelectedPendingData.tData.index, tSelectedPendingData.tFriend.nId)
	elseif tSelectedPendingData.bIsGroup then
		AccountItemLib.GiftPendingItemToAccount(tSelectedPendingData.tData.index, tSelectedPendingData.tFriend.nId)
	else
		AccountItemLib.GiftPendingItemGroupToAccount(tSelectedPendingData.tData.index, tSelectedPendingData.tFriend.nId)
	end
	
	self:RefreshInventory()
	self.wndInventory:Show(true)
	self.wndInventoryGiftConfirm:Show(false)
end

function AccountInventory:OnPendingGiftConfirmCancelBtn(wndHandler, wndControl, eMouseButton)
	self.wndInventoryGift:Show(true)
	self.wndInventoryGiftConfirm:Show(false)
end


--[[
Entitlements
]]--

function AccountInventory:RefreshEntitlements()
	self.wndAccountGridContainer:DestroyChildren()
	for idx, tEntitlement in pairs(AccountItemLib.GetAccountEntitlements()) do
		local wndObject = Apollo.LoadForm("AccountInventory.xml", "EntitlementsForm", self.wndAccountGridContainer, self)
		wndObject:FindChild("Icon"):SetSprite(tEntitlement.icon)
		wndObject:FindChild("Name"):SetText(tEntitlement.name)
		wndObject:FindChild("Button"):SetTooltip(tEntitlement.description)
		if tEntitlement.maxCount > 1 then
			wndObject:FindChild("Count"):SetText(tEntitlement.count.."/"..tEntitlement.maxCount)
		end
	end
	self.wndAccountGridContainer:ArrangeChildrenVert(0)
	
	self.wndCharacterGridContainer:DestroyChildren()
	for idx, tEntitlement in pairs(AccountItemLib.GetCharacterEntitlements()) do
		local wndObject = Apollo.LoadForm("AccountInventory.xml", "EntitlementsForm", self.wndCharacterGridContainer, self)
		wndObject:FindChild("Icon"):SetSprite(tEntitlement.icon)
		wndObject:FindChild("Name"):SetText(tEntitlement.name)
		wndObject:FindChild("Button"):SetTooltip(tEntitlement.description)
		if tEntitlement.maxCount > 1 then
			wndObject:FindChild("Count"):SetText(tEntitlement.count.."/"..tEntitlement.maxCount)
		end
	end
	self.wndCharacterGridContainer:ArrangeChildrenVert(0)
end

--[[
Log
]]--
--Log stuff goes here when there are log API calls










local AccountInventoryInst = AccountInventory:new()
AccountInventoryInst:Init()

