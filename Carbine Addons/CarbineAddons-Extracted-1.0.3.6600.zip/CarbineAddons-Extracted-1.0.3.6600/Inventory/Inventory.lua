require "Window"
require "Apollo"
require "ApolloCursor"
require "GameLib"
require "ChatSystemLib"

local Inventory = {}

local kidBackpack = 0
local kidBag1 = 1
local kidBag2 = 2
local kidBag3 = 3
local kidBagTS = 4

local kstrRed = "ffff4040"
local kstrOrange = "ffffd100"
local kstrBlue = "ff32fcf6"
local kstrDarkBlue = "ff209d99"

function Inventory:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	return o
end

function Inventory:OnLoad()
	Apollo.RegisterSlashCommand("gearscore", "OnGearScore", self)

	Apollo.RegisterEventHandler("TEMP_Event_Placeholder_ToggleBagAddons", "TEMP_Event_Placeholder_ToggleBagAddons", self) -- TODO TEMP

	Apollo.RegisterEventHandler("ShowInventory", "OnShow", self)
	Apollo.RegisterEventHandler("ToggleInventory", "OnToggle", self)
	Apollo.RegisterEventHandler("LootChuteItemRemoved", "OnLootChuteItemRemoved", self)
	Apollo.RegisterEventHandler("DragDropSysBegin", "OnSystemBeginDragDrop", self)
	Apollo.RegisterEventHandler("DragDropSysEnd", "OnSystemEndDragDrop", self)
	Apollo.RegisterEventHandler("RefreshInventoryBags", "OnRefreshInventoryBags", self)
	Apollo.RegisterEventHandler("PlayerCurrencyChanged", "OnPlayerCurrencyChanged", self)
	Apollo.RegisterEventHandler("StartLooting", "OnStartLooting", self)
	Apollo.RegisterEventHandler("StopLooting", "OnStopLooting", self)
	Apollo.RegisterEventHandler("Tutorial_RequestUIAnchor", "OnTutorial_RequestUIAnchor", self)
	Apollo.RegisterEventHandler("PlayerEquippedItemChanged", "OnPlayerEquippedItemChanged", self)
	Apollo.RegisterEventHandler("LevelUpUnlock_Inventory_Salvage", "OnLevelUpUnlock_Inventory_Salvage", self)
	Apollo.RegisterEventHandler("LevelUpUnlock_Path_Item", "OnLevelUpUnlock_Path_Item", self)

	-- Virtual Inventory
	Apollo.RegisterEventHandler("PlayerPathRefresh", "PlayerPathRefresh", self) -- route to same event
	Apollo.RegisterEventHandler("PlayerPathRefresh", "OnQuestObjectiveUpdated", self) -- route to same event
	Apollo.RegisterEventHandler("QuestStateChanged", "OnQuestObjectiveUpdated", self)
	Apollo.RegisterEventHandler("QuestObjectiveUpdated", "OnQuestObjectiveUpdated", self)
	Apollo.RegisterEventHandler("PublicEventUpdate", "OnQuestObjectiveUpdated", self)
	Apollo.RegisterEventHandler("PublicEventObjectiveUpdate", "OnQuestObjectiveUpdated", self)

	-- for testing
	Apollo.RegisterSlashCommand("showvacuum", "ShowVacuum", self)
	Apollo.RegisterSlashCommand("hidevacuum", "HideVacuum", self)

	-- windows
	self.wndBackpack = Apollo.LoadForm("InventoryForms.xml", "Inventory", nil, self)
	self.wndDisabler = self.wndBackpack:FindChild("BagWindowDisabler")
	self.tBagButton = {}
	self.tBagButton[kidBackpack] = self.wndBackpack:FindChild("BackpackBtn")
	self.tBagButton[kidBag1] = self.wndBackpack:FindChild("BagBtn1")
	self.tBagButton[kidBag2] = self.wndBackpack:FindChild("BagBtn2")
	self.tBagButton[kidBag3] = self.wndBackpack:FindChild("BagBtn3")
	self.tBagButton[kidBagTS] = self.wndBackpack:FindChild("BagBtnTS")

	self.tNewItemIndicator = {}
	self.tNewItemIndicator[kidBackpack] = self.wndBackpack:FindChild("NewItemIndicator0")
	self.tNewItemIndicator[kidBag1] = self.wndBackpack:FindChild("NewItemIndicator1")
	self.tNewItemIndicator[kidBag2] = self.wndBackpack:FindChild("NewItemIndicator2")
	self.tNewItemIndicator[kidBag3] = self.wndBackpack:FindChild("NewItemIndicator3")
	self.tNewItemIndicator[kidBagTS] = self.wndBackpack:FindChild("NewItemIndicator4")

	self.wndPopoutButton = self.wndBackpack:FindChild("PopoutBtn")
	self.wndCash = self.wndBackpack:FindChild("Cash")
	self.wndTrash = self.wndBackpack:FindChild("TrashIcon")
	self.wndSalvage = self.wndBackpack:FindChild("SalvageIcon")
	self.wndBackpack:FindChild("SalvageBlocker"):Show(false)
	--self.tBagButton[kidBagTS]:Enable(false)
	self.wndBackpack:Close()

	self.wndInvokeForm = Apollo.LoadForm("InventoryForms.xml", "InventoryInvokeForm", "FixedHudStratum", self)
	self.wndQuestItemNotice = self.wndInvokeForm:FindChild("QuestItemNotice")
	self.wndInvokeButton = self.wndInvokeForm:FindChild("InvokeBtn")
	self.nOrigInvokeLeft, self.nOrigInvokeTop = self.wndInvokeForm:GetAnchorOffsets()	-- For inventory moving

	self.wndDeleteConfirm = Apollo.LoadForm("InventoryForms.xml", "InventoryDeleteNotice", nil, self)
	self.wndDeleteConfirm:Close()

	self.wndSalvageConfirm = Apollo.LoadForm("InventoryForms.xml", "InventorySalvageNotice", nil, self)
	self.wndSalvageConfirm:Close()

	self.bDragging = false
	self.bVendorOpen = false

	--------------------/Load up our secondary bags/-----------------------------
	self.tBagForms = {}
	self.tContents = {}

	self.tContents[kidBackpack] = self.wndBackpack:FindChild("BagWindow")

	self.tBagForms[kidBag1] = Apollo.LoadForm("InventoryForms.xml", "InventoryBagA", nil, self)
	self.tContents[kidBag1] = self.tBagForms[kidBag1]:FindChild("BagWindow")
	self.tContents[kidBag1]:SetBoxesPerRow(4)
	self.tContents[kidBag1]:SetSquareSize(38, 38)

	self.tBagForms[kidBag2] = Apollo.LoadForm("InventoryForms.xml", "InventoryBagB", nil, self)
	self.tContents[kidBag2] = self.tBagForms[kidBag2]:FindChild("BagWindow")
	self.tContents[kidBag2]:SetBoxesPerRow(4)
	self.tContents[kidBag2]:SetSquareSize(38, 38)

	self.tBagForms[kidBag3] = Apollo.LoadForm("InventoryForms.xml", "InventoryBagC", nil, self)
	self.tContents[kidBag3] = self.tBagForms[kidBag3]:FindChild("BagWindow")
	self.tContents[kidBag3]:SetBoxesPerRow(4)
	self.tContents[kidBag3]:SetSquareSize(38, 38)

	self.tBagForms[kidBagTS] = Apollo.LoadForm("InventoryForms.xml", "InventoryBagD", nil, self)
	self.tContents[kidBagTS] = self.tBagForms[kidBagTS]:FindChild("BagWindow")
	self.tContents[kidBagTS]:SetBoxesPerRow(4)
	self.tContents[kidBagTS]:SetSquareSize(38, 38)

	self.tBagForms[kidBag1]:Close()
	self.tBagForms[kidBag2]:Close()
	self.tBagForms[kidBag3]:Close()
	self.tBagForms[kidBagTS]:Close()

	--------------------/Set up our arrays/-----------------------------
	self.tListBagForms =
	{
		self.tBagForms[kidBag1],
		self.tBagForms[kidBag2],
		self.tBagForms[kidBag3],
		self.tBagForms[kidBagTS]
	}
	self.tListDisablers =
	{
		self.tBagForms[kidBag1]:FindChild("BagWindowDisabler"),
		self.tBagForms[kidBag2]:FindChild("BagWindowDisabler"),
		self.tBagForms[kidBag3]:FindChild("BagWindowDisabler"),
		self.tBagForms[kidBagTS]:FindChild("BagWindowDisabler")
	}
	self.tListTrashIcons =
	{
		self.tBagForms[kidBag1]:FindChild("TrashIcon"),
		self.tBagForms[kidBag2]:FindChild("TrashIcon"),
		self.tBagForms[kidBag3]:FindChild("TrashIcon"),
		self.tBagForms[kidBagTS]:FindChild("TrashIcon")
	}
	self.tListSalvageIcons =
	{
		self.tBagForms[kidBag1]:FindChild("SalvageIcon"),
		self.tBagForms[kidBag2]:FindChild("SalvageIcon"),
		self.tBagForms[kidBag3]:FindChild("SalvageIcon"),
		self.tBagForms[kidBagTS]:FindChild("SalvageIcon")
	}

	--------------------/Establish the default positions/-----------------------------
	self.nLeft, self.nTop, self.nRight, self.nBottom = self.wndBackpack:GetRect()
	self.nLeftA, self.nTopA, self.nRightA, self.nBottomA = self.tBagForms[kidBag1]:GetRect()
	self.nLeftB, self.nTopB, self.nRightB, self.nBottomB = self.tBagForms[kidBag2]:GetRect()
	self.nLeftC, self.nTopC, self.nRightC, self.nBottomC = self.tBagForms[kidBag3]:GetRect()
	self.nLeftD, self.nTopD, self.nRightD, self.nBottomD = self.tBagForms[kidBagTS]:GetRect()
	self.nLeftShift = self.nLeft - 255
	self.nLeftShiftC = self.nLeftB
	self.nLeftShiftD = self.nLeftD - 265

	self.tListClose = {}
	self.tListClose[kidBag1] = self.OnCloseBtnA
	self.tListClose[kidBag2] = self.OnCloseBtnB
	self.tListClose[kidBag3] = self.OnCloseBtnC
	self.tListClose[kidBagTS] = self.OnCloseBtnD

	self.tListOpen = {}
	self.tListOpen[kidBag1] = self.OnBagAOpen
	self.tListOpen[kidBag2] = self.OnBagBOpen
	self.tListOpen[kidBag3] = self.OnBagCOpen
	self.tListOpen[kidBagTS] = self.OnBagDOpen

	--Writ Display Setup
	self.arSystems = {2, 3, 4, 5, 7, 8, 9, 11, 12, 13, 15, 16, 17, 19, 20, 21}
	self.nMoneySystem = 1

	self.wndWritDisplay = self.wndBackpack:FindChild("WritDisplayWindow")
	self.wndWritDisplay:SetMoneySystem(self.arSystems[self.nMoneySystem])

	if false and IsDemo() then
		self.wndBackpack:FindChild("WritDisplay"):Show(false)

		local nBackerLeft, nBackerTop, nBackerRight, nBackerBottom = self.wndBackpack:FindChild("Fill"):GetRect()
		local nWindowLeft, nWindowTop, nWindowRight, nWindowBottom = self.wndCash:GetRect()

		self.wndBackpack:FindChild("Fill"):Move(nBackerLeft, nBackerTop - 14, nBackerRight - nBackerLeft, nBackerBottom - nBackerTop)
		self.wndCash:Move(nWindowLeft, nWindowTop - 14, nWindowRight - nWindowLeft, nWindowBottom - nWindowTop)
	end

	-- New:

	-- Populate Virtual Inventory Btn from reloadui/load
	self:OnQuestObjectiveUpdated()

	-- TEMP: Choose only one bag addon to display
	self.bShowThisAddon = false

	-- game event handlers
    Apollo.RegisterTimerHandler("OneSecTimer", "OnUpdateTimer", self)
	--Apollo.CreateTimer("UpdateTimer", 1.0, true)
	--Apollo.StartTimer("UpdateTimer")
end

function Inventory:OnGearScore()
	ChatSystemLib.PostOnChannel(ChatSystemLib.ChatChannel_System, String_GetWeaselString(Apollo.GetString("Inventory_GearScore"), GameLib.GetGearScore()), "")
end

function Inventory:TEMP_Placeholder_ToggleBagAddons() -- TODO TEMP
	--if not self.bShowThisAddon then return end
	--self:OnToggle()
	--self.bShowThisAddon = false
	--Event_FireGenericEvent("InterfaceMenu_ToggleInventory")
end

function Inventory:TEMP_Event_Placeholder_ToggleBagAddons(arg1) -- TODO TEMP
	--[[
	if arg1 and arg1 == "FromNew" then
		self.bShowThisAddon = true
		self:OnToggle()
	end
	]]--
end

--------------------//-----------------------------
function Inventory:OnSave()--(eType)
--[[	if eType ~= 1 then
		return nil
	end

	local tData = {}
	tData.loc = {}
	tData.loc.x, tData.loc.y = self.wndBackpack:GetPos()

	return tData--]]
end
--------------------//-----------------------------
function Inventory:OnRestore(eType, tData)
	if tData == nil or tData.loc == nil then
		return
	end
	local nWidth = self.wndBackpack:GetWidth()
	local nHeight = self.wndBackpack:GetHeight()

	self.wndBackpack:Move(tData.loc.x, tData.loc.y, nWidth, nHeight)
end

function Inventory:OnCloseBag(wnd, wndControl)
	wnd:FindChild("BagWindow"):MarkAllItemsAsSeen()
end
--------------------//-----------------------------
--------------------//-----------------------------
function Inventory:UpdateNewItemIndicators()
	for idx = kidBackpack, kidBagTS do
		self.tNewItemIndicator[idx]:Show(self.tContents[kidBackpack]:AreAnyItemsNew(idx))
	end
end

function Inventory:OnRefreshInventoryBags()
	for idx = kidBag1, kidBagTS do
		--Apollo.DPF("In OnToggle, iBag = " .. tostring(iBag))
		self.tBagButton[idx]:SetCheck(self.tContents[kidBackpack]:GetBagId() == idx)
		if self.tContents[kidBackpack]:IsBagEquipped(idx) then
			self.tBagButton[idx]:Show(true)
			self.tBagButton[idx]:ChangeArt("btnBag")
		else
			self.tBagButton[idx]:Show(false)
			self.tBagButton[idx]:ChangeArt("btnAddBag")
		end
	end
end
--[[
-- for testing
function Inventory:ShowVacuum()
    self:OnCanVacuumChanged(true)
end
-- for testing
function Inventory:HideVacuum()
    self:OnCanVacuumChanged(false)
end

function Inventory:OnCanVacuumChanged(bCanVacuum)
	-- self.wndVacuumPrompt:Show(bCanVacuum)
	if bCanVacuum == true then
	    MessageManager:RequestShowWindow( LuaEnumMessageType.LootCollectionPrompt, self.wndVacuumPrompt )
	else
	    self.wndVacuumPrompt:Show(false)
	    MessageManager:OnMessageFinished( self.wndVacuumPrompt )
	end
end
--]]
function Inventory:OnGenerateTooltip(wndControl, wndHandler, tType, item)
	if wndControl ~= wndHandler then
		return
	end

	wndControl:SetTooltipDoc(nil)

	if item ~= nil then
		local itemEquipped = item:GetEquippedItemForItemType()

		Tooltip.GetItemTooltipForm(self, wndControl, item, {bPrimary = true, bSelling = self.bVendorOpen, itemCompare = itemEquipped})
	end
end

function Inventory:OnToggleFromDatachronIcon()
	Event_FireGenericEvent("InterfaceMenu_ToggleInventory")
	--if not self.bShowThisAddon then Event_FireGenericEvent("TEMP_Event_Placeholder_ToggleBagAddons", "FromOld") end -- Fire the other one
	--self:OnToggle()
end

function Inventory:OnToggle()
	if not self.bShowThisAddon then return end

	if self.wndBackpack:IsVisible() then
		for idx = kidBag1, kidBagTS do
			self.tBagForms[idx]:Close()
		end
		self.wndBackpack:Close()
		Sound.Play(Sound.PlayUI38CloseRemoteWindowDigital)
	else
	--	Event_ShowTutorial(GameLib.CodeEnumTutorial.Inventory)
		Sound.Play(Sound.PlayUI37OpenRemoteWindowDigital)
		self.wndBackpack:Show(true)
		self:PopulateInventory()
		self.wndPopoutButton:Enable(false)
		self.tBagButton[kidBackpack]:SetCheck(true)

		self:OnRefreshInventoryBags()

		self.wndPopoutButton:Enable(false)
		self.tContents[kidBackpack]:SetBagId(kidBackpack)
		self.wndBackpack:ToFront()
		--[[
		local x, y = self.wndBackpack:GetPos()
		local x2, y2 = self.tBagForms[kidBag1]:GetPos()
		if x == self.leftShift and xA ~= self.leftA then
			self.wndBackpack:Move(self.left, self.top, self.right - self.left, self.bottom - self.top)
		end--]]

		self:OnPlayerCurrencyChanged()
	end
	self.wndDeleteConfirm:Close()
	self.wndSalvageConfirm:Close()
	self.wndDisabler:Close()
end

function Inventory:OnShow(bShow)
	if not self.bShowThisAddon then return end
	self.wndBackpack:Show(bShow)
	self.wndDeleteConfirm:Close()
	self.wndSalvageConfirm:Close()
	self.wndDisabler:Close()
end

--------------------/Vendor-Related Controls/-----------------------------
function Inventory:OnVendorInvokedWindow()
	self.bKeepBackpackOpen = self.wndBackpack:IsVisible()

	self.bVendorOpen = true

	Sound.Play(Sound.PlayUI37OpenRemoteWindowDigital)
	self.wndBackpack:Show(true)
	self:PopulateInventory()
	self.wndPopoutButton:Enable(false)
	self.tBagButton[kidBackpack]:SetCheck(true)

	for idx = kidBag1, kidBagTS do
		--Apollo.DPF("In OnToggle, iBag = " .. tostring(iBag))
		self.tBagButton[idx]:SetCheck(false)
		if self.tContents[kidBackpack]:IsBagEquipped(idx) then
			self.tBagButton[idx]:Show(true)
			self.tBagButton[idx]:ChangeArt("btnBag")
		else
			self.tBagButton[idx]:Close()
			self.tBagButton[idx]:ChangeArt("btnAddBag")
		end
	end

	self.wndPopoutButton:Enable(false)
	self.tContents[kidBackpack]:SetBagId(kidBackpack)
	self.wndBackpack:ToFront()

	self.wndDeleteConfirm:Close()
	self.wndSalvageConfirm:Close()
	self.wndDisabler:Close()

end

function Inventory:OnCloseVendorWindow()
	self.bVendorOpen = false

	if self.bKeepBackpackOpen == true and not self.wndBackpack:IsVisible() then
		self.wndBackpack:Close()
	else
		self.wndBackpack:Show(self.bKeepBackpackOpen)
	end
end


--------------------/Notification/-----------------------------
function Inventory:OnLootChuteItemRemoved()
	--self.wndWarningPulse:Show(true)
	--self.wndWarningPulse:ToFront()
end


--------------------//-----------------------------

function Inventory:PopulateInventory()
end
--------------------//-----------------------------


function Inventory:OnCloseBtn()
	self.wndBackpack:Close()
	self.wndDeleteConfirm:Close()
	self.wndSalvageConfirm:Close()
	self.wndDisabler:Close()
--[[
	local x, y = self.wndBackpack:GetPos()
	local x2, y2 = self.tBagForms[kidBagTS]:GetPos()
	if x == self.leftShift and x2 == self.leftShiftD then
		self.tBagForms[kidBagTS]:Move(self.leftD, self.topD, self.rightD - self.leftD, self.bottomD - self.topD)
	end--]]
end

function Inventory:OnCloseBtnA()
	self.tBagForms[kidBag1]:Close()
	self.tBagButton[kidBag1]:SetCheck(false)
	self.tBagButton[kidBag1]:Enable(true)
--[[
	local x, y = self.wndBackpack:GetPos()
	local left, top, right, bottom = self.wndBackpack:GetRect()
	if left == self.leftShift and top == self.top then
		self.wndBackpack:Move(x + 255, y, self.right - self.left, self.bottom - self.top)
	end

	local x2, y2 = self.tBagForms[kidBagTS]:GetPos()
	if x2 == self.leftShiftD and y2 == self.topD then
		self.tBagForms[kidBagTS]:Move(self.leftD, self.topD, self.rightD - self.leftD, self.bottomD - self.topD)
	end--]]
end

function Inventory:OnCloseBtnB()
	self.tBagForms[kidBag2]:Close()
	self.tBagButton[kidBag2]:SetCheck(false)
	self.tBagButton[kidBag2]:Enable(true)
--[[
	local x, y = self.tBagForms[kidBag3]:GetPos()
	local left, top, right, bottom = self.tBagForms[kidBag3]:GetRect()
	if left == self.leftC and top == self.topC then
		self.tBagForms[kidBag3]:Move(self.leftShiftC, y, self.rightC - self.leftC, self.bottomC - self.topC)
	end--]]
end

function Inventory:OnCloseBtnC()
	self.tBagForms[kidBag3]:Close()
	self.tBagButton[kidBag3]:SetCheck(false)
	self.tBagButton[kidBag3]:Enable(true)
end

function Inventory:OnCloseBtnD()
	self.tBagForms[kidBagTS]:Close()
	self.tBagButton[kidBagTS]:SetCheck(false)
	self.tBagButton[kidBagTS]:Enable(true)
end

--listClose[1] = Inventory:OnCloseBtnA

------------------------------------------------------------------
function Inventory:OnQueryDragDrop(wndHandler, wndControl, nX, nY, wndSource, strType, nValue)
	return Apollo.DragDropQueryResult.Ignore
end

function Inventory:OnDragDrop(wndHandler, wndControl, nX, nY, wndSource, strType, nValue)
	return false
end

function Inventory:OnUpdateTimer()
	--self:UpdateNewItemIndicators()
	self.wndCash:SetAmount(GameLib.GetPlayerCurrency(), false)

	for idx = kidBag1, kidBagTS do
		if not self.bDragging then
			if self.tBagForms[idx]:IsVisible() then
				self.tBagButton[idx]:ChangeArt("btnPopoutBag")
			else
				self.tBagButton[idx]:ChangeArt("btnBag")
			end
		end
	end

	local nAvailableInventory = self.tContents[kidBackpack]:GetTotalEmptyBagSlots()
	local nTotalInventory = self.tContents[kidBackpack]:GetTotalBagSlots()
	local nOccupiedInventory = nTotalInventory - nAvailableInventory

	local strOpenColor = ""
	if nOccupiedInventory == nTotalInventory then
		strOpenColor = kstrRed
		self.wndInvokeButton:ChangeArt("CRB_BaseBarSprites:btnHUD_InventoryBagFull")
	elseif nOccupiedInventory >= nTotalInventory - 3 then
		strOpenColor = kstrOrange
		self.wndInvokeButton:ChangeArt("CRB_BaseBarSprites:btnHUD_InventoryBag")
	else
		strOpenColor = kstrBlue
		self.wndInvokeButton:ChangeArt("CRB_BaseBarSprites:btnHUD_InventoryBag")
	end

	local strPrefix = ""
	if nOccupiedInventory < 10 then strPrefix = "<T TextColor=\"00000000\">.</T>" end
	local strAMLCode = string.format("%s<T Font=\"CRB_Pixel\" TextColor=\"%s\">%s<T TextColor=\"%s\">/%s</T></T>", strPrefix, strOpenColor, nOccupiedInventory, kstrDarkBlue, nTotalInventory)
	self.wndInvokeForm:FindChild("CountText"):SetAML(strAMLCode)
	--self.wndInvokeForm:FindChild("CountText"):SetText(nOccupiedInventory .. "/" .. nTotalInventory)

	local bHaveQuestItem = false
	for idx = kidBackpack, kidBagTS do
		bHaveQuestItem = bHaveQuestItem or self.tContents[kidBackpack]:DoAnyItemsBeginQuest(i)
	end

	self.wndQuestItemNotice:Show(bHaveQuestItem)
end

function Inventory:OnInvokeFormMouseButtonUp()
	--[[
	local l, t, r, b = self.wndInvokeForm:GetAnchorOffsets()
	if not self.wndInvokeForm:FindChild("BGBolt"):IsShown() then
		self.wndInvokeForm:FindChild("BGBolt"):Show(true)
	end

	if l > self.origInvokeL + 25 or l < self.origInvokeL - 5 then
		self.wndInvokeForm:FindChild("BGBolt"):Show(false)
	end
	]]--
end

------------/Inventory Controls/-------------------
function Inventory:OnBagCheck(wndHandler, wndControl)
	local iWhichBag = -1
	for idx = kidBackpack, kidBagTS do
		if self.tBagButton[idx] == wndControl then
			iWhichBag = idx
		end
	end
	if iWhichBag < kidBackpack then
		return
	end

	self.tContents[kidBackpack]:SetBagId(iWhichBag)
	for idx = kidBackpack, kidBagTS do
		self.tBagButton[i]:SetCheck(idx == iWhichBag)
	end

	if iWhichBag >= kidBag1 then
		self.tListClose[iWhichBag](self)
		self.tBagButton[iWhichBag]:SetCheck(true)
	end

	self.wndPopoutButton:Enable(iWhichBag > kidBackpack)
	Sound.Play(Sound.PlayUI53SlideUpDigital)
end

function Inventory:OnPopoutBtn()

Sound.Play(Sound.PlayUI20OpenBagVirtual)

	if self.tBagButton[kidBag1]:IsChecked() then
		self.tBagButton[kidBag1]:SetCheck(false)
		self.tBagForms[kidBag1]:Show(true)
		self.tBagForms[kidBag1]:ToFront()
		self.tContents[kidBag1]:SetBagId(1)
		self:OnBagAOpen()
	elseif self.tBagButton[kidBag2]:IsChecked() then
		self.tBagButton[kidBag2]:SetCheck(false)
		self.tBagForms[kidBag2]:Show(true)
		self.tContents[kidBag2]:SetBagId(2)
		self.tBagForms[kidBag2]:ToFront()
		self:OnBagBOpen()
	elseif self.tBagButton[kidBag3]:IsChecked() then
		self.tBagButton[kidBag3]:SetCheck(false)
		self.tBagForms[kidBag3]:Show(true)
		self.tContents[kidBag3]:SetBagId(3)
		self.tBagForms[kidBag3]:ToFront()
		self:OnBagCOpen()
	elseif self.tBagButton[kidBagTS]:IsChecked() then
		self.tBagButton[kidBagTS]:SetCheck(false)
		self.tBagForms[kidBagTS]:Show(true)
		self.tContents[kidBag3]:SetBagId(4)
		self.tBagForms[kidBagTS]:ToFront()
		self:OnBagDOpen()
	else return
	end

	self.tContents[kidBackpack]:SetBagId(kidBackpack)
	self.tBagButton[kidBackpack]:SetCheck(true)
	self.wndPopoutButton:Enable(false)
end

function Inventory:OnBagAOpen()
--[[	local x, y = self.wndBackpack:GetPos()
	local xA, yA = self.tBagForms[kidBag1]:GetPos()
	local xD, yD = self.tBagForms[kidBagTS]:GetPos()
	local left, top, right, bottom = self.wndBackpack:GetRect()

	if left == self.left and xA == self.leftA then
	self.wndBackpack:Move(self.leftShift, self.top, self.right - self.left, self.bottom - self.top)
	end

	if left == self.left and xD == self.leftD then
	self.tBagForms[kidBagTS]:Move(self.leftShiftD, self.topD, self.rightD - self.leftD, self.bottomD - self.topD)
	end--]]
end

function Inventory:OnBagBOpen()
--[[	local left, top, right, bottom = self.tBagForms[kidBag2]:GetRect()
	local xC, yC = self.tBagForms[kidBag3]:GetPos()


	if left == self.leftB and xC == self.leftShiftC then
	self.tBagForms[kidBag3]:Move(self.leftC, self.topC, self.rightC - self.leftC, self.bottomC - self.topC)
	end--]]
end

function Inventory:OnBagCOpen()
--[[	local left, top, right, bottom = self.tBagForms[kidBag3]:GetRect()
	local xB, yB = self.tBagForms[kidBag2]:GetPos()

	if left == self.leftC and xB ~= self.leftB or not self.tBagForms[kidBag2]:IsVisible() then
	self.tBagForms[kidBag3]:Move(self.leftShiftC, self.topC, self.rightC - self.leftC, self.bottomC - self.topC)
	end--]]
end

function Inventory:OnBagDOpen()
--[[	local left, top, right, bottom = self.wndBackpack:GetRect()
	local xD, yD = self.tBagForms[kidBagTS]:GetPos()

	if left == self.leftShift  and xD == self.leftD then
		self.tBagForms[kidBagTS]:Move(self.leftShiftD, yD, 246, 324)
		self.tBagForms[kidBagTS]:Show(true)
	else
		self.tBagForms[kidBagTS]:Show(true)
	end

	self.tBagForms[kidBagTS]:Show(true)
	self.tContents[kidBagTS]:SetBagId(4)--]]
end

function Inventory:InvokeDelete(iData)
	self.wndDeleteConfirm:Show(true)
	self.wndDeleteConfirm:ToFront()
	self.iItemToDelete = iData
	self.wndDisabler:Show(true)

	for idx = kidBag1, kidBagTS do
		self.tListDisablers[idx]:Show(true)
	end

	Sound.Play(Sound.PlayUI55ErrorVirtual)
end

function Inventory:InvokeSalvage(iData)
	local item = self.tContents[kidBackpack]:GetItem(iData)
	if not item:CanSalvage() then
		return
	end
	self.wndSalvageConfirm:Show(true)
	self.wndSalvageConfirm:ToFront()
	self.iItemToSalvage = iData
	self.wndDisabler:Show(true)

	for idx = kidBag1, kidBagTS do
		self.listDisablers[idx]:Show(true)
	end

	Sound.Play(Sound.PlayUI55ErrorVirtual)
end

function Inventory:OnBagDragDropCancel(wnd, wndControl, strType, iData, eReason)
	if strType == "DDBagItem" then
		if eReason == Apollo.DragDropCancelReason.EscapeKey then
			return false
		end

		local unit = GetMouseOverUnit()
		if unit ~= nil and P2PTrading.CanInitiateTrade(unit) == P2PTrading.P2PTradeError_Ok then
			Event_FireGenericEvent("ItemDropOnTarget", unit, strType, iData)
			return false
		end

		if eReason == Apollo.DragDropCancelReason.ClickedOnNothing then
			self:InvokeDelete(iData)
		end
		if eReason == Apollo.DragDropCancelReason.DroppedOnNothing then
			Apollo.BeginClickStick(wnd, strType, "", iData)
			return true
		end
	end

	if strType == "DDUseItemWithTarget" then
		local unit = GetMouseOverUnit()

		return false
	end

	return false
end

function Inventory:OnDragDropNothingCursor(wnd, wndControl, strType, iData)
	--Apollo.DPF("In OnDragDropNothingCursor")
	if strType == "DDBagItem" then
		local unit = GetMouseOverUnit()
		local cursor = nil
		if unit ~= nil and P2PTrading.CanInitiateTrade(unit) == P2PTrading.P2PTradeError_Ok then
			cursor = ApolloCursor.GetCursor("DragDropTrade")
		else
			cursor = ApolloCursor.GetCursor("DragDropTrash")
		end
		if cursor ~= nil then
			Apollo.SetCursor(cursor)
			return true
		end
	end
	if strType == "DDUseItemWithTarget" then
		local unit = GetMouseOverUnit()
		local cursor = nil
		if unit ~= nil then
			cursor = ApolloCursor.GetCursor("Interact")
		else
			cursor = ApolloCursor.GetCursor("InteractInactive")
		end
		if cursor ~= nil then
			Apollo.SetCursor(cursor)
			return true
		end
	end
	return false
end

function Inventory:OnBagMouseClick(wnd, wndControl, iButton, nX, nY, bDouble)
	if wnd ~= wndControl or iButton ~= 1 then
		return false
	end
	local iWhichBag = -1
	for idx = kidBackpack, kidBagTS do
		if self.tBagButton[idx] == wnd then
			iWhichBag = idx
		end
	end
	if iWhichBag < kidBag1 then
		return false
	end

	self.tListOpen[iWhichBag](self)
	self.tBagForms[iWhichBag]:Show(true)
	self.tBagForms[iWhichBag]:ToFront()
	self.tContents[iWhichBag]:SetBagId(iWhichBag)

	if self.tContents[kidBackpack]:GetBagId() == iWhichBag then
		self.tContents[kidBackpack]:SetBagId(kidBackpack)
	end

	for idx = kidBackpack, kidBagTS do
		self.tBagButton[idx]:SetCheck(self.tContents[kidBackpack]:GetBagId() == idx)
	end
	self.wndPopoutButton:Enable(self.tContents[kidBackpack]:GetBagId() > kidBackpack)

	return true
end

function Inventory:OnSystemBeginDragDrop(wndSource, strType, iData)
	if strType == "DDBagItem" then
		local item = self.tContents[kidBackpack]:GetItem(iData)
		if not item then
			return
		end

		self.bDragging = true
		self.iDraggingIData = iData
		self.wndTrash:SetSprite("spr_trashActive")
		if item:CanSalvage() then
			self.wndSalvage:SetSprite("spr_salvageActive")
			self.wndBackpack:FindChild("SalvageBlocker"):Show(false)

			for idx = kidBag1, kidBagTS do
				self.tListSalvageIcons[idx]:SetSprite("spr_salvageActive")
				self.tBagForms[idx]:FindChild("SalvageBlocker"):Show(false)
			end
		else
			self.wndBackpack:FindChild("SalvageBlocker"):Show(true)

			for idx = kidBag1, kidBagTS do
				self.tBagForms[idx]:FindChild("SalvageBlocker"):Show(true)
			end
		end

		Sound.Play(Sound.PlayUI45LiftVirtual)

		if self.tContents[kidBackpack]:CanDropItemInBag(iData, kidBackpack) then
			self.tBagButton[kidBackpack]:ChangeArt("btnBag")
		else
			self.tBagButton[kidBackpack]:ChangeArt("btnBagFull")
		end

		for idx = kidBag1, kidBagTS do
			self.tListTrashIcons[idx]:SetSprite("spr_trashActive")
			--self.listSalvageIcons[iBag]:SetSprite("spr_salvageActive")

			-- we are dragging an item so set the art for our buttons appropriately
			if self.tContents[kidBackpack]:IsBagEquipped(idx) then
				self.tBagButton[idx]:Show(true)
				self.tBagButton[idx]:ChangeArt("btnBag")

				if iData == self.tContents[kidBackpack]:GetInventoryIdForBag(idx) then
					self.tBagButton[idx]:ChangeArt("btnLiftedBag")
				elseif self.tContents[idx]:CanAssignBag(iData, idx) then
					self.tBagButton[idx]:ChangeArt("btnReplaceBag")
				elseif not self.tContents[idx]:CanDropItemInBag(iData, idx) then
					self.tBagButton[idx]:ChangeArt("btnBagFull")
				end

			else
				if self.tContents[kidBackpack]:CanAssignBag(iData, idx) then
					self.tBagButton[idx]:Show(true)
				else
					self.tBagButton[idx]:Close()
				end
				self.tBagButton[idx]:ChangeArt("btnAddBag")
			end


		end

	end
end

function Inventory:OnSystemEndDragDrop(strType, iData)
	self.wndTrash:SetSprite("spr_trashDisabled")
	self.wndSalvage:SetSprite("spr_salvageDisabled")
	self.wndBackpack:FindChild("SalvageBlocker"):Show(false)
	self.tBagButton[kidBackpack]:ChangeArt("btnBag")
	self.bDragging = false
	self.iDraggingIData = nil

	Sound.Play(Sound.PlayUI46PlaceVirtual)

	for idx = kidBag1, kidBagTS do
		self.tBagForms[idx]:FindChild("SalvageBlocker"):Show(false)
		self.tListTrashIcons[idx]:SetSprite("spr_trashDisabled")
		self.tListSalvageIcons[idx]:SetSprite("spr_salvageDisabled")

		if self.tContents[kidBackpack]:IsBagEquipped(idx) then
			self.tBagButton[idx]:Show(true)
			self.tBagButton[idx]:ChangeArt("btnBag")
		else
			self.tBagButton[idx]:Close()
			self.tBagButton[idx]:ChangeArt("btnAddBag")
		end
	end
	for idx = kidBackpack, kidBagTS do
		if idx > kidBackpack and self.tBagForms[idx]:IsVisible() then
			if not self.tContents[kidBackpack]:IsBagEquipped(idx) then
				self.tBagForms[idx]:Close()
			end
		end
	end

end

function Inventory:OnQueryDragDropTrash(wnd, wndControl, nX, nY, wndSource, strType, iData)
	if strType == "DDBagItem" then
		return Apollo.DragDropQueryResult.Accept
	end
	return Apollo.DragDropQueryResult.Ignore
end

function Inventory:OnDragDropNotifyTrash(wnd, wndControl, bMe)
	if bMe then
		self.wndTrash:SetSprite("spr_trashOver")

		for idx = kidBag1, kidBagTS do
			self.tListTrashIcons[idx]:SetSprite("spr_trashOver")
		end

	else
		self.wndTrash:SetSprite("spr_trashActive")

		for idx = kidBag1, kidBagTS do
			self.tListTrashIcons[idx]:SetSprite("spr_trashActive")
		end
	end
end

function Inventory:OnDragDropTrash(wnd, wndControl, nX, nY, wndSource, strType, iData)
	--Apollo.DPF("Here")
	if strType == "DDBagItem" then

		if Apollo.IsShiftKeyDown() then
			local item = self.tContents[kidBackpack]:GetItem(iData)
			Tooltip.GetItemTooltipForm(self, wndControl, item, {bPrimary = true, bPermanent=true})
		else
			self:InvokeDelete(iData)
		end
	end
	return false
end

function Inventory:OnQueryDragDropSalvage(wnd, wndControl, nX, nY, wndSource, strType, iData)
	local item = self.tContents[kidBackpack]:GetItem(iData)
	if strType == "DDBagItem" and item:CanSalvage() then
		return Apollo.DragDropQueryResult.Accept
	end
	return Apollo.DragDropQueryResult.Ignore
end

function Inventory:OnDragDropNotifySalvage(wnd, wndControl, bMe)
	if not self.iDraggingIData then
		return
	end
	local item = self.tContents[kidBackpack]:GetItem(self.iDraggingIData)
	if not item:CanSalvage() then
		return
	end
	if bMe then
		self.wndSalvage:SetSprite("spr_salvageOver")

		for idx = kidBag1, kidBagTS do
			self.tListSalvageIcons[idx]:SetSprite("spr_salvageOver")
		end

	else
		self.wndSalvage:SetSprite("spr_salvageActive")

		for idx = kidBag1,kidBagTS do
			self.tListSalvageIcons[idx]:SetSprite("spr_salvageActive")
		end
	end
end

function Inventory:OnDragDropSalvage(wnd, wndControl, x, y, wndSource, strType, iData)
	--Apollo.DPF("Here")
	local item = self.tContents[kidBackpack]:GetItem(iData)
	if strType == "DDBagItem" and item:CanSalvage() then

		if Apollo.IsShiftKeyDown() then
			local item = self.tContents[kidBackpack]:GetItem(iData)
			Tooltip.GetItemTooltipForm(self, wndControl, item, {bPrimary = true, bPermanent = true})
		else
			self:InvokeSalvage(iData)
		end
	end
	return false
end

function Inventory:OnCancelDeleteBtn()
	--Apollo.DPF("In OnCancelDeleteBtn")
	self.wndDeleteConfirm:Close()
	self.wndDisabler:Close()
	self.iItemToDelete = nil

	for idx = kidBag1, kidBagTS do
		self.tListDisablers[idx]:Close()
	end

end

function Inventory:OnDeleteBtn()
	if self.iItemToDelete ~= nil then
		self.tContents[kidBackpack]:DeleteItem(self.iItemToDelete)
	end
	self.iItemToDelete = nil
	self.wndDeleteConfirm:Close()
	self.wndDisabler:Close()

	for idx = kidBag1, kidBagTS do
		self.listDisablers[idx]:Close()
	end
end

function Inventory:OnCancelSalvageBtn()
	--Apollo.DPF("In OnCancelSalvageBtn")
	self.wndSalvageConfirm:Close()
	self.wndDisabler:Close()
	self.iItemToSalvage = nil

	for idx = kidBag1, kidBagTS do
		self.listDisablers[idx]:Close()
	end

end

function Inventory:OnSalvageBtn()
	if self.iItemToSalvage ~= nil then
		self.tContents[kidBackpack]:SalvageItem(self.iItemToSalvage)
	end
	self.iItemToSalvage = nil
	self.wndSalvageConfirm:Close()
	self.wndDisabler:Close()

	for idx = kidBag1,kidBagTS do
		self.listDisablers[idx]:Close()
	end
end

function Inventory:OnBagBtnQueryBeginDragDrop(wnd, wndControl, nX, nY)
	if wnd ~= wndControl then
		return false
	end

	local wndParent = wnd:GetParent()
	if wndParent == nil then
		return false
	end
	local wndBag = wndParent:FindChild("BagWindow")
	if wndBag == nil then
		return false
	end

	local iWhichBag = -1
	for idx = 0,4 do
		if self.tBagButton[idx] == wnd then
			iWhichBag = idx
		end
	end
	if iWhichBag < 1 then
		return false
	end

	if wndBag:CanRemoveBag(iWhichBag) then
		local idInventory = wndBag:GetInventoryIdForBag(iWhichBag)
		Apollo.BeginDragDrop(wndBag, "DDBagItem", "", idInventory)

		self:OnBagCheck(nil, self.tBagButton[kidBackpack]) -- TODO HACK, to prevent bugs if the current focus is moved we click on the backpack btn
		return true
	end

	return false
end

function Inventory:OnBagBtnQueryDragDrop(wnd, wndControl, nX, nY, wndSource, strType, iData)
	if wnd ~= wndControl then
		return Apollo.DragDropQueryResult.PassOn
	end

	local wndParent = wnd:GetParent()
	if wndParent == nil then
		return Apollo.DragDropQueryResult.Ignore
	end
	local wndBag = wndParent:FindChild("BagWindow")
	if wndBag == nil then
		return Apollo.DragDropQueryResult.Ignore
	end

	local iWhichBag = -1
	for idx = kidBackpack, kidBagTS do
		if self.tBagButton[idx] == wnd then
			iWhichBag = idx
		end
	end
	if iWhichBag < kidBackpack then
		return Apollo.DragDropQueryResult.Ignore
	end

	if strType ~= "DDBagItem" then
		return Apollo.DragDropQueryResult.Ignore
	end

	if wndBag:IsItemABag(iData) and wndBag:CanAssignBag(iData, iWhichBag) and wndBag:CanRemoveBag() then
		return Apollo.DragDropQueryResult.Accept
	elseif wndBag:CanDropItemInBag(iData, iWhichBag) then
		return Apollo.DragDropQueryResult.Accept
	elseif not wndBag:IsBagEquipped(nWhichBag) then
		return Apollo.DragDropQueryResult.Accept
	end
	return Apollo.DragDropQueryResult.Invalid

end

function Inventory:OnBagBtnDragDrop(wnd, wndControl, nX, nY, wndSource, strType, iData)
	if wnd ~= wndControl then
		return false
	end

	local wndParent = wnd:GetParent()
	if wndParent == nil then
		return false
	end
	local wndBag = wndParent:FindChild("BagWindow")
	if wndBag == nil then
		return false
	end

	local iWhichBag = -1
	for idx = kidBackpack, kidBagTS do
		if self.tBagButton[idx] == wnd then
			iWhichBag = idx
		end
	end

	if iWhichBag < 0 then
		return false
	end

	if strType ~= "DDBagItem" then
		return false
	end

	if wndBag:IsItemABag(iData) and wndBag:CanAssignBag(iData, iWhichBag) and wndBag:CanRemoveBag() then
		wndBag:AssignBag(iData, iWhichBag)
	elseif wndBag:CanDropItemInBag(iData, iWhichBag) then
		wndBag:DropItemInBag(iData, iWhichBag)
	elseif not wndBag:IsBagEquipped(nWhichBag) then
		wndBag:AssignBag(iData, iWhichBag)
	end

	return false
end

--------------------/Writ Display Interface/-----------------------------
function Inventory:OnPlayerCurrencyChanged()
	self.wndWritDisplay:SetMoneySystem(self.arSystems[self.nMoneySystem])
	self.wndWritDisplay:SetAmount(GameLib.GetPlayerCurrency(self.arSystems[self.nMoneySystem]))
end

function Inventory:PreviousWritDisplay()
	self.nMoneySystem = self.nMoneySystem - 1
	if self.nMoneySystem == 0 then
		self.nMoneySystem = #self.arSystems
	end

	self:OnPlayerCurrencyChanged()
end

function Inventory:NextWritDisplay()
	if self.nMoneySystem == #self.arSystems then
		self.nMoneySystem = 1
	else
		self.nMoneySystem = self.nMoneySystem + 1
	end

	self:OnPlayerCurrencyChanged()
end

---------------------------------------------------
function Inventory:OnPlayerEquippedItemChanged(nEquippedSlot, uNewItem, uOldItem)
	if uNewItem ~= nil then
		uNewItem:PlayEquipSound()
	end
end

-----------------------------------------------------------------------------------------------
-- Virtual Inventory
-----------------------------------------------------------------------------------------------

function Inventory:OnVirtualInvToggle()
	self.wndBackpack:FindChild("VirtualInvBG"):Show(self.wndBackpack:FindChild("VirtualInvBtn"):IsChecked())

	--[[
	local l,t,r,b = self.wndBackpack:FindChild("BackpackAndBagContainer"):GetAnchorOffsets()
	if self.wndBackpack:FindChild("VirtualInvBtn"):IsChecked() then
		self.wndBackpack:FindChild("BackpackAndBagContainer"):SetAnchorOffsets(l,t,r,b - 106)
	else
		self.wndBackpack:FindChild("BackpackAndBagContainer"):SetAnchorOffsets(l,t,r,b + 106)
	end
	]]--
end

function Inventory:VirtualInvCloseBtnClick()
	self.wndBackpack:FindChild("VirtualInvBtn"):SetCheck(false)
	self:OnVirtualInvToggle()
end

function Inventory:OnQuestObjectiveUpdated()
	local tVirtualItems = Item.GetVirtualItems()
	self.wndBackpack:FindChild("VirtualInvBtn"):Enable(#tVirtualItems > 0)
	self:HelperRedrawVirtualItems(tVirtualItems)
end

function Inventory:HelperRedrawVirtualItems(tVirtualItems)
	--[[
	self.wndBackpack:FindChild("VirtualInvContainer"):DestroyChildren()
	for _, tCurrItem in pairs(tVirtualItems) do
		local wndCurr = Apollo.LoadForm("InventoryForms.xml", "VirtualItem", self.wndBackpack:FindChild("VirtualInvContainer"), self)
		if tCurrItem.count > 1 then wndCurr:FindChild("VirtualItemCount"):SetText(tCurrItem.count) end
		wndCurr:FindChild("VirtualItemDisplay"):SetSprite(tCurrItem.icon)
		wndCurr:SetTooltip(string.format("<P Font=\"CRB_InterfaceSmall\">%s</P><P Font=\"CRB_InterfaceSmall\" TextColor=\"aaaaaaaa\">%s</P>", tCurrItem.name, tCurrItem.flavor))
	end
	self.wndBackpack:FindChild("VirtualInvContainer"):ArrangeChildrenTiles(0)
	]]--
end

function Inventory:OnLevelUpUnlock_Inventory_Salvage()
	self:OnShow(true)
	self.wndBackpack:ToFront()
end

function Inventory:OnLevelUpUnlock_Path_Item(itemFromPath)
	self:OnShow(true)
	self.wndBackpack:ToFront()
end

---------------------------------------------------------------------------------------------------
-- Tutorial anchor request
---------------------------------------------------------------------------------------------------
function Inventory:OnTutorial_RequestUIAnchor(eAnchor, idTutorial, strPopupText)
	if eAnchor ~= GameLib.CodeEnumTutorialAnchor.Inventory then return end

	local tRect = {}
	tRect.l, tRect.t, tRect.r, tRect.b = self.wndInvokeForm:GetRect()

	Event_FireGenericEvent("Tutorial_RequestUIAnchorResponse", eAnchor, idTutorial, strPopupText, tRect)
end

----------------globals----------------------------

local Inventory_Singleton = Inventory:new()
Apollo.RegisterAddon(Inventory_Singleton)
