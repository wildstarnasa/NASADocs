-----------------------------------------------------------------------------------------------
-- Client Lua Script for ItemPreview
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "GameLib"
require "Item"

-----------------------------------------------------------------------------------------------
-- ItemPreview Module Definition
-----------------------------------------------------------------------------------------------
local ItemPreview = {}

-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
local ktVisibleSlots = {
	2,
	3,
	0,
	5,
	1,
	4,
	16
}

-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
function ItemPreview:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self

    -- initialize variables here

    return o
end

function ItemPreview:Init()
    Apollo.RegisterAddon(self)
end


-----------------------------------------------------------------------------------------------
-- ItemPreview OnLoad
-----------------------------------------------------------------------------------------------
function ItemPreview:OnLoad()
    -- Register handlers for events, slash commands and timer, etc.
    -- e.g. Apollo.RegisterEventHandler("KeyDown", "OnKeyDown", self)
	Apollo.RegisterEventHandler("ShowItemInDressingRoom", "OnShowItemInDressingRoom", self)
	self.bSheathed = false
end


-----------------------------------------------------------------------------------------------
-- ItemPreview Functions
-----------------------------------------------------------------------------------------------
-- Define general functions here
function ItemPreview:OnShowItemInDressingRoom(item)
	if self.wndMain ~= nil then
		self:OnWindowClosed()
	end

	if item == nil or not self:HelperValidateSlot(item) then
		return
	end

	self.wndMain = Apollo.LoadForm("ItemPreview.xml", "ItemPreviewForm", "TooltipStratum", self)
	local nWndLeft, nWndTop, nWndRight, nWndBottom = self.wndMain:GetRect()
	local nWndWidth = nWndRight - nWndLeft
	local nWndHeight = nWndBottom - nWndTop

	self.wndMain:SetSizingMinimum(nWndWidth - 10, nWndHeight - 10)
	self.wndMain:FindChild("PreviewWindow"):SetCostume(GameLib.GetPlayerUnit())
	self.wndMain:FindChild("PreviewWindow"):SetItem(item)

	-- Position
	local tScreen = Apollo.GetDisplaySize()
	local tPointer = Apollo.GetMouse()
	local nPadding = 25 -- how far to offset the window from the mouse (also used on the outside to leave some breathing room)
	local nHeightPadded = (nWndHeight / 2) + nPadding
	local nWidthPadded = nWndWidth + (nPadding * 2)

	-- Vertical
	if tPointer.y < nHeightPadded then -- too close to the top
		nWndTop = nPadding -- shift down to align with mouse
	elseif (tScreen.nHeight - tPointer.y) < nHeightPadded then -- too near the bottom
		nWndTop = tScreen.nHeight - wndHeight - nPadding -- shift up all the way
	else -- enough vertical room
		nWndTop = tPointer.y - (nWndHeight / 2) -- shift halfway up
	end

	-- horizontal
	if tPointer.x < (tScreen.nWidth / 2) then -- left side of the screen
		nWndLeft = tPointer.x + nPadding -- flip to the right
	else -- right and dead center
		nWndLeft = tPointer.x - (nWndWidth + nPadding) -- flip to the right
	end


	self.wndMain:Move(nWndLeft, nWndTop, nWndWidth, nWndHeight)


	-- set item name;
	local strLabel = string.format("<T Font=\"CRB_InterfaceMedium\" TextColor=\"ff9a8460\" Align=\"Center\">%s</T>", Apollo.GetString("Inventory_ItemPreviewLabel"))
	local strItem = string.format("<T Font=\"CRB_InterfaceMedium\" TextColor=\"ffdad1c2\" Align=\"Center\">%s</T>", item:GetName())
	self.wndMain:FindChild("ItemLabel"):SetAML("<P Align=\"Center\">"..String_GetWeaselString(strLabel, strItem).."</P>")

	-- set sheathed or not
	local eItemType = item:GetItemType()
	self.bSheathed = not self:HelperCheckForWeapon(eItemType)

	self.wndMain:FindChild("PreviewWindow"):SetSheathed(self.bSheathed)
	self:HelperFormatSheathButton(self.bSheathed)

	self.wndMain:Show(true)
end

function ItemPreview:HelperCheckForWeapon(eItemType)
	local bIsWeapon = false

	if eItemType >= Item.CodeEnumItemType.WeaponMHPistols and eItemType <= Item.CodeEnumItemType.WeaponMHSword then
		bIsWeapon = true
	end

	return bIsWeapon
end

function ItemPreview:HelperFormatSheathButton(bSheathed)
	if bSheathed == true then
		self.wndMain:FindChild("SheathButton"):SetText(Apollo.GetString("Inventory_DrawWeapons"))
	else
		self.wndMain:FindChild("SheathButton"):SetText(Apollo.GetString("Inventory_Sheathe"))
	end
end

function ItemPreview:HelperValidateSlot(item)
	local bVisibleSlot = false
	local bRightClassOrProf = false
	local tProficiency = item:GetProficiencyInfo()
	local arReqClass = item:GetRequiredClass()
	local unitPlayer = GameLib.GetPlayerUnit()

    if #arReqClass > 0 then
		for idx,tClass in ipairs(arReqClass) do
			if tClass.idClassReq == unitPlayer:GetClassId() then
				bRightClassOrProf = true
			end
		end
	elseif tProficiency and tProficiency.bHasProficiency then
		bRightClassOrProf = true
	end

	for idx, nSlot in pairs(ktVisibleSlots) do
		if item:GetSlot() and item:GetSlot() == nSlot then
			bVisibleSlot = bRightClassOrProf
			break
		end

	end

	return bVisibleSlot
end

-----------------------------------------------------------------------------------------------
-- ItemPreviewForm Functions
-----------------------------------------------------------------------------------------------
function ItemPreview:OnWindowClosed( wndHandler, wndControl )
	if self.wndMain ~= nil then
		--self.wndMain:Close()
		self.wndMain:Destroy()
		self.wndMain = nil
	end
end

function ItemPreview:OnToggleSheathButton( wndHandler, wndControl, eMouseButton )
	local bWeapon = wndControl:IsChecked()
	self.wndMain:FindChild("PreviewWindow"):SetSheathed(bWeapon)
end

function ItemPreview:OnCloseBtn( wndHandler, wndControl, eMouseButton )
	self:OnWindowClosed()
end

function ItemPreview:OnToggleSheathed( wndHandler, wndControl, eMouseButton )
	local bSheathed = not self.bSheathed
	self.wndMain:FindChild("PreviewWindow"):SetSheathed(bSheathed)
	self:HelperFormatSheathButton(bSheathed)

	self.bSheathed = bSheathed
end

function ItemPreview:OnRotateRight()
	self.wndMain:FindChild("PreviewWindow"):ToggleLeftSpin(true)
end

function ItemPreview:OnRotateRightCancel()
	self.wndMain:FindChild("PreviewWindow"):ToggleLeftSpin(false)
end

function ItemPreview:OnRotateLeft()
	self.wndMain:FindChild("PreviewWindow"):ToggleRightSpin(true)
end

function ItemPreview:OnRotateLeftCancel()
	self.wndMain:FindChild("PreviewWindow"):ToggleRightSpin(false)
end

-----------------------------------------------------------------------------------------------
-- ItemPreview Instance
-----------------------------------------------------------------------------------------------
local ItemPreviewInst = ItemPreview:new()
ItemPreviewInst:Init()
