-----------------------------------------------------------------------------------------------
-- Client Lua Script for RaidFrameBase
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"

local RaidFrameBase = {}

-- TODO: This should be enums (string comparison already fails on esper)
local ktIdToClassSprite =
{
	[GameLib.CodeEnumClass.Esper] 			= "Icon_Windows_UI_CRB_Esper",
	[GameLib.CodeEnumClass.Medic] 			= "Icon_Windows_UI_CRB_Medic",
	[GameLib.CodeEnumClass.Stalker] 		= "Icon_Windows_UI_CRB_Stalker",
	[GameLib.CodeEnumClass.Warrior] 		= "Icon_Windows_UI_CRB_Warrior",
	[GameLib.CodeEnumClass.Engineer] 		= "Icon_Windows_UI_CRB_Engineer",
	[GameLib.CodeEnumClass.Spellslinger] 	= "Icon_Windows_UI_CRB_Spellslinger",
}

local ktIdToClassTooltip =
{
	[GameLib.CodeEnumClass.Esper] 			= "CRB_Esper",
	[GameLib.CodeEnumClass.Medic] 			= "CRB_Medic",
	[GameLib.CodeEnumClass.Stalker] 		= "CRB_Stalker",
	[GameLib.CodeEnumClass.Warrior] 		= "CRB_Warrior",
	[GameLib.CodeEnumClass.Engineer] 		= "CRB_Engineer",
	[GameLib.CodeEnumClass.Spellslinger] 	= "CRB_Spellslinger",
}

local ktIdToRoleSprite =  -- 0 is valid
{
	[0] = "",
	[1] = "sprRaid_Icon_RoleDPS",
	[2] = "sprRaid_Icon_RoleHealer",
	[3] = "sprRaid_Icon_RoleTank",
}

local ktIdToRoleTooltip =
{
	[0] = "",
	[1] = "Matching_Role_DPS",
	[2] = "Matching_Role_Healer",
	[3] = "Matching_Role_Tank",
}

local ktIdToLeaderSprite =  -- 0 is valid
{
	[0] = "",
	[1] = "CRB_Raid:sprRaid_Icon_Leader",
	[2] = "CRB_Raid:sprRaid_Icon_TankLeader",
	[3] = "CRB_Raid:sprRaid_Icon_AssistLeader",
	[4] = "CRB_Raid:sprRaid_Icon_2ndLeader",
}

local ktIdToLeaderTooltip =
{
	[0] = "",
	[1] = "RaidFrame_RaidLeader",
	[2] = "RaidFrame_MainTank",
	[3] = "RaidFrame_CombatAssist",
	[4] = "RaidFrame_RaidAssist",
}

local kstrRaidMarkerToSprite =
{
	"Icon_Windows_UI_CRB_Marker_Bomb",
	"Icon_Windows_UI_CRB_Marker_Ghost",
	"Icon_Windows_UI_CRB_Marker_Mask",
	"Icon_Windows_UI_CRB_Marker_Octopus",
	"Icon_Windows_UI_CRB_Marker_Pig",
	"Icon_Windows_UI_CRB_Marker_Chicken",
	"Icon_Windows_UI_CRB_Marker_Toaster",
	"Icon_Windows_UI_CRB_Marker_UFO",
}

local ktLootModeToString =
{
	[GroupLib.LootRule.Master] 			= "Group_MasterLoot",
	[GroupLib.LootRule.RoundRobin] 		= "Group_RoundRobin",
	[GroupLib.LootRule.FreeForAll] 		= "Group_FFA",
	[GroupLib.LootRule.NeedBeforeGreed] = "Group_NeedVsGreed",
}

local ktItemQualityToStr =
{
	[Item.CodeEnumItemQuality.Inferior] 		= Apollo.GetString("CRB_Inferior"),
	[Item.CodeEnumItemQuality.Average] 			= Apollo.GetString("CRB_Average"),
	[Item.CodeEnumItemQuality.Good] 			= Apollo.GetString("CRB_Good"),
	[Item.CodeEnumItemQuality.Excellent] 		= Apollo.GetString("CRB_Excellent"),
	[Item.CodeEnumItemQuality.Superb] 			= Apollo.GetString("CRB_Superb"),
	[Item.CodeEnumItemQuality.Legendary] 		= Apollo.GetString("CRB_Legendary"),
	[Item.CodeEnumItemQuality.Artifact]	 		= Apollo.GetString("CRB_Artifact")
}

local ktRowSizeIndexToPixels =
{
	[1] = 21, -- Previously 19
	[2] = 28,
	[3] = 33,
	[4] = 38,
	[5] = 42,
}

local knReadyCheckTimeout = 60 -- in seconds

function RaidFrameBase:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function RaidFrameBase:Init()
    Apollo.RegisterAddon(self)
end

function RaidFrameBase:OnLoad()
	Apollo.RegisterEventHandler("CharacterCreated", 						"OnCharacterCreated", self)
	Apollo.RegisterEventHandler("Group_Updated", 							"CheckRaidStatus", self)
	Apollo.RegisterEventHandler("Group_Join", 								"CheckRaidStatus", self)
	Apollo.RegisterEventHandler("Group_Left", 								"CheckRaidStatus", self)
	Apollo.RegisterEventHandler("UnitEnteredCombat", 						"OnEnteredCombat", self)
	Apollo.RegisterEventHandler("GenericEvent_Raid_ToggleRaidUnTear", 		"OnRaidUnTearOff", self)
	Apollo.RegisterEventHandler("GenericEvent_Raid_UncheckMasterLoot", 		"OnUncheckMasterLoot", self)
	Apollo.RegisterEventHandler("GenericEvent_Raid_UncheckLeaderOptions", 	"OnUncheckLeaderOptions", self)

	Apollo.RegisterEventHandler("Group_Remove",								"OnDestroyAndRedrawAll", self) -- Kicked, or someone else leaves (yourself leaving is Group_Leave)
	Apollo.RegisterEventHandler("Group_ReadyCheck",							"OnGroup_ReadyCheck", self)
	Apollo.RegisterEventHandler("Group_MemberFlagsChanged",					"OnDestroyAndRedrawAll", self)

	Apollo.RegisterTimerHandler("ReadyCheckTimeout", 						"OnReadyCheckTimeout", self)
	Apollo.RegisterTimerHandler("RaidFrameBaseTimer", 						"OnRaidFrameBaseTimer", self)
	Apollo.RegisterTimerHandler("RaidFrameDestroyedTimer", 					"CheckRaidStatus", self)

	Apollo.CreateTimer("RaidFrameBaseTimer", 0.5, true)
	Apollo.StopTimer("RaidFrameBaseTimer")

	Apollo.CreateTimer("RaidFrameDestroyedTimer", 1, true)
	Apollo.StopTimer("RaidFrameDestroyedTimer")

	self.xmlDoc = XmlDoc.CreateFromFile("RaidFrameBase.xml")
	self.wndMain = Apollo.LoadForm(self.xmlDoc, "RaidFrameBaseForm", nil, self)
    self.wndMain:FindChild("RaidConfigureBtn"):AttachWindow(self.wndMain:FindChild("RaidOptions"))
	
	local wndRaidOptions = self.wndMain:FindChild("RaidOptions:SelfConfigRaidCustomizeOptions")
	wndRaidOptions:FindChild("RaidCustomizeLockInCombat"):SetCheck(true)
	wndRaidOptions:FindChild("RaidCustomizeLeaderIcons"):SetCheck(true)
	wndRaidOptions:FindChild("RaidCustomizeCategories"):SetCheck(true)
	wndRaidOptions:FindChild("RaidCustomizeShowNames"):SetCheck(true)
	wndRaidOptions:FindChild("RaidCustomizeRowSizeText:RaidCustomizeRowSizeSub"):Enable(false) -- as self.nRowSize == 1 at default
	wndRaidOptions:FindChild("RaidCustomizeNumColText:RaidCustomizeNumColSub"):Enable(false) -- as self.nNumColumns == 1 at default
	self.wndMain:Show(false)

	self.nRowSize					= 1
	self.nNumColumns 				= 1
	self.kstrMyName 				= ""
	self.nHealthWarn 				= 0.4
	self.nHealthWarn2 				= 0.6
	self.tTearOffMemberIDs 			= {}
	self.wndReadyCheckPopup 		= nil
	self.bSwapToTwoColsOnce 		= false
	self.bTimerRunning 				= false
	self.nNumReadyCheckResponses 	= -1 -- -1 means no check, 0 and higher means there is a check
	self.nPrevMemberCount			= 0

	local wndMeasure = Apollo.LoadForm(self.xmlDoc, "RaidCategory", nil, self)
	self.knWndCategoryHeight = wndMeasure:GetHeight()
	wndMeasure:Destroy()

	self.knWndMainHeight = self.wndMain:GetHeight()

	local unitPlayer = GameLib.GetPlayerUnit()
	if unitPlayer then
		self.kstrMyName = unitPlayer:GetName()
		self:CheckRaidStatus()
	end
end

function RaidFrameBase:OnCharacterCreated()
	local unitPlayer = GameLib.GetPlayerUnit()
	self.kstrMyName = unitPlayer:GetName()
	self:CheckRaidStatus()
end

function RaidFrameBase:CheckRaidStatus()
	local bInRaid = GroupLib.InRaid()
	if bInRaid and not self.bTimerRunning then
		Apollo.StartTimer("RaidFrameBaseTimer")
		self.bTimerRunning = true
		self.wndMain:Show(true)
	elseif not bInRaid then
		Apollo.StopTimer("RaidFrameBaseTimer")
		self.bTimerRunning = false
		self.wndMain:Show(false)
	end
end

function RaidFrameBase:OnRaidFrameBaseTimer()
	if not GroupLib.InRaid() then
		if self.wndMain and self.wndMain:IsValid() and self.wndMain:IsShown() then
			self.wndMain:Show(false)
		end
		return
	end

	self.wndMain:Show(true)
	self:UpdateAllFrames()
	self:ResizeAllFrames()
	-- TODO UpdateJustHP() to save processing
end

-----------------------------------------------------------------------------------------------
-- Main Draw Methods
-----------------------------------------------------------------------------------------------

function RaidFrameBase:UpdateAllFrames()
	local nGroupMemberCount = GroupLib.GetMemberCount()
	if nGroupMemberCount == 0 then
		self:OnLeaveBtn()
		return
	elseif not self.bSwapToTwoColsOnce and nGroupMemberCount > 20 then
		self.bSwapToTwoColsOnce = true
		self:OnRaidCustomizeNumColAdd(self.wndMain:FindChild("RaidCustomizeNumColAdd"), self.wndMain:FindChild("RaidCustomizeNumColAdd")) -- TODO HACK
	end

	if nGroupMemberCount ~= self.nPrevMemberCount then
		self.nPrevMemberCount = nGroupMemberCount
		self:OnDestroyAndRedrawAll()
		return
	end

	local tMemberList = {}
	for idx = 1, nGroupMemberCount do
		tMemberList[idx] = {idx, GroupLib.GetGroupMember(idx)}
	end

	local tCategoriesToUse = {Apollo.GetString("RaidFrame_Members")}
	if self.wndMain:FindChild("RaidOptions:SelfConfigRaidCustomizeOptions:RaidCustomizeCategories"):IsChecked() then
		tCategoriesToUse = {Apollo.GetString("RaidFrame_Tanks"), Apollo.GetString("RaidFrame_Healers"), Apollo.GetString("RaidFrame_DPS")}
	end

	if self.nNumReadyCheckResponses >= 0 then
		self.nNumReadyCheckResponses = 0 -- Will get added up in UpdateSpecificHP
	end

	local nInvalidOrDeadMembers = 0
	local unitTarget = GameLib.GetTargetUnit()
	local bFrameLocked = self.wndMain:FindChild("RaidLockFrameBtn"):IsChecked()

	for idx, tCurrMemberList in pairs(tMemberList) do
		local tMemberData = tCurrMemberList[2]
		if not tMemberData.bIsOnline or tMemberData.nHealthMax == 0 or tMemberData.nHealth == 0 then
			nInvalidOrDeadMembers = nInvalidOrDeadMembers + 1
		end
	end

	for key, strCurrCategory in pairs(tCategoriesToUse) do
		local wndCategory = self:LoadByName("RaidCategory", self.wndMain:FindChild("RaidCategoryContainer"), strCurrCategory)
		wndCategory:FindChild("RaidCategoryBtn"):Show(not self.wndMain:FindChild("RaidLockFrameBtn"):IsChecked())
		if wndCategory:FindChild("RaidCategoryName"):GetText() == "" then
			wndCategory:FindChild("RaidCategoryName"):SetText(" " .. strCurrCategory)
		end

		if wndCategory:FindChild("RaidCategoryBtn"):IsEnabled() and not wndCategory:FindChild("RaidCategoryBtn"):IsChecked() then
			for idx, tCurrMemberList in pairs(tMemberList) do
				local nCodeIdx = tCurrMemberList[1] -- Since actual lua index can change
				local tMemberData = tCurrMemberList[2]
				if tMemberData and self:HelperVerifyMemberCategory(strCurrCategory, tMemberData) then
					local wndRaidMember = self:LoadByName("RaidMember", wndCategory:FindChild("RaidCategoryItems"), nCodeIdx)
					self:UpdateSpecificHP(wndRaidMember, nCodeIdx, tMemberData, unitTarget, nGroupMemberCount, bFrameLocked)

					-- Me, Self Config at top right
					if tMemberData.strCharacterName == self.kstrMyName then -- TODO better comparison
						self:UpdateRaidOptions(nCodeIdx, tMemberData)
						self.wndMain:FindChild("RaidLeaderOptionsBtn"):Show(tMemberData.bIsLeader or tMemberData.bRaidAssistant)
						self.wndMain:FindChild("RaidMasterLootIconOnly"):Show(not tMemberData.bIsLeader)
						self.wndMain:FindChild("RaidMasterLootBtn"):Show(tMemberData.bIsLeader)
					end

					-- Speed up performance, as we only draw once anyways
					tMemberList[idx] = nil
				end
			end
		end

		if wndCategory:FindChild("RaidCategoryBtn"):IsEnabled() then
			wndCategory:Show(wndCategory:FindChild("RaidCategoryBtn"):IsChecked() or #wndCategory:FindChild("RaidCategoryItems"):GetChildren() > 0)
		else
			wndCategory:Show(true)
		end

		wndCategory:FindChild("RaidCategoryItems"):ArrangeChildrenTiles(0)
		local nLeft, nTop, nRight, nBottom = wndCategory:GetAnchorOffsets()
		local nChildrenHeight = math.ceil(#wndCategory:FindChild("RaidCategoryItems"):GetChildren() / self.nNumColumns) * ktRowSizeIndexToPixels[self.nRowSize]
		wndCategory:SetAnchorOffsets(nLeft, nTop, nRight, nTop + nChildrenHeight + self.knWndCategoryHeight)
	end
	self.wndMain:FindChild("RaidTitle"):SetText(String_GetWeaselString(Apollo.GetString("RaidFrame_MemberCount"), nGroupMemberCount - nInvalidOrDeadMembers, nGroupMemberCount))

	-- Loot Settings (TODO Refactor out if possible)
	local tLootRules = GroupLib.GetLootRules()
	local strThresholdQuality = ktItemQualityToStr[tLootRules.eThresholdQuality]
	local strTooltip = string.format("<P Font=\"CRB_InterfaceSmall_O\">%s</P><P Font=\"CRB_InterfaceSmall_O\">%s</P><P Font=\"CRB_InterfaceSmall_O\">%s</P>",
						Apollo.GetString("RaidFrame_LootRules"),
						String_GetWeaselString(Apollo.GetString("RaidFrame_UnderThreshold"), strThresholdQuality, Apollo.GetString(ktLootModeToString[tLootRules.eNormalRule])),
						String_GetWeaselString(Apollo.GetString("RaidFrame_ThresholdAndAbove"), strThresholdQuality, Apollo.GetString(ktLootModeToString[tLootRules.eThresholdRule])))
	self.wndMain:FindChild("RaidMasterLootIconOnly"):SetTooltip(strTooltip)
end

function RaidFrameBase:ResizeAllFrames()
	local wndRaidMemberWidth = (self.wndMain:GetWidth() - 22) / self.nNumColumns

	-- Calculate this outside the loop, as its the same for entry (TODO REFACTOR)
	local nLeftOffsetStartValue = 0
	if self.wndMain:FindChild("RaidOptions:SelfConfigRaidCustomizeOptions:RaidCustomizeClassIcons"):IsChecked() then
		nLeftOffsetStartValue = nLeftOffsetStartValue + 16 --wndRaidMember:FindChild("RaidMemberClassIcon"):GetWidth()
	end
	if self.nNumReadyCheckResponses >= 0 then
		nLeftOffsetStartValue = nLeftOffsetStartValue + 16 --wndRaidMember:FindChild("RaidMemberReadyIcon"):GetWidth()
	end

	for key, wndCategory in pairs(self.wndMain:FindChild("RaidCategoryContainer"):GetChildren()) do
		for key2, wndRaidMember in pairs(wndCategory:FindChild("RaidCategoryItems"):GetChildren()) do
			local nLeft, nTop, nRight, nBottom = wndRaidMember:GetAnchorOffsets()
			wndRaidMember:SetAnchorOffsets(nLeft, nTop, nLeft + wndRaidMemberWidth, nTop + ktRowSizeIndexToPixels[self.nRowSize])
			wndRaidMember:ArrangeChildrenHorz(0)

			-- Button Offsets (from tear off button)
			local nLeftOffset = nLeftOffsetStartValue
			if wndRaidMember:FindChild("RaidMemberIsLeader"):IsShown() then
				nLeftOffset = nLeftOffset + wndRaidMember:FindChild("RaidMemberIsLeader"):GetWidth()
			end
			if wndRaidMember:FindChild("RaidMemberRoleIcon"):IsShown() then
				nLeftOffset = nLeftOffset + wndRaidMember:FindChild("RaidMemberRoleIcon"):GetWidth()
			end
			if wndRaidMember:FindChild("RaidMemberMarkIcon"):IsShown() then
				nLeftOffset = nLeftOffset + wndRaidMember:FindChild("RaidMemberMarkIcon"):GetWidth()
			end
			if wndRaidMember:FindChild("RaidTearOffBtn"):IsShown() then
				nLeftOffset = nLeftOffset + wndRaidMember:FindChild("RaidTearOffBtn"):GetWidth()
			end

			-- Resize Button
			nLeft,nTop,nRight,nBottom = wndRaidMember:FindChild("RaidMemberBtn"):GetAnchorOffsets()
			wndRaidMember:FindChild("RaidMemberBtn"):SetAnchorOffsets(nLeft, nTop, nLeft + wndRaidMemberWidth - nLeftOffset, nTop + ktRowSizeIndexToPixels[self.nRowSize] + 9)
		end
	end

	-- Lock Max Height
	local nLeft, nTop, nRight, nBottom = self.wndMain:GetAnchorOffsets()
	self.wndMain:SetAnchorOffsets(nLeft, nTop, nRight, nTop + math.max(self.wndMain:FindChild("RaidCategoryContainer"):ArrangeChildrenVert(0) + 58, self.knWndMainHeight))
	self.wndMain:SetSizingMinimum(175, self.wndMain:GetHeight())
	self.wndMain:SetSizingMaximum(1000, self.wndMain:GetHeight())
end

function RaidFrameBase:UpdateRaidOptions(nCodeIdx, tMemberData)
	local wndRaidOptions = self.wndMain:FindChild("RaidOptions")
	local wndRaidOptionsToggles = self.wndMain:FindChild("RaidOptions:SelfConfigSetAsLabel")

	wndRaidOptionsToggles:FindChild("SelfConfigSetAsDPS"):SetData(nCodeIdx)
	wndRaidOptionsToggles:FindChild("SelfConfigSetAsDPS"):SetCheck(tMemberData.bDPS)
	
	wndRaidOptionsToggles:FindChild("SelfConfigSetAsHealer"):SetData(nCodeIdx)
	wndRaidOptionsToggles:FindChild("SelfConfigSetAsHealer"):SetCheck(tMemberData.bHealer)
	
	wndRaidOptionsToggles:FindChild("SelfConfigSetAsNormTank"):SetData(nCodeIdx)
	wndRaidOptionsToggles:FindChild("SelfConfigSetAsNormTank"):SetCheck(tMemberData.bTank)
	
	wndRaidOptionsToggles:Show(not tMemberData.bRoleLocked)
	wndRaidOptions:FindChild("SelfConfigReadyCheckLabel"):Show(tMemberData.bIsLeader or tMemberData.bMainTank or tMemberData.bMainAssist or tMemberData.bRaidAssistant)

	local nLeft, nTop, nRight, nBottom = wndRaidOptions:GetAnchorOffsets()
	wndRaidOptions:SetAnchorOffsets(nLeft, nTop, nRight, nTop + wndRaidOptions:ArrangeChildrenVert(0))
end

function RaidFrameBase:UpdateSpecificHP(wndRaidMember, nCodeIdx, tMemberData, unitTarget, nGroupMemberCount, bFrameLocked)
	if not wndRaidMember or not wndRaidMember:IsValid() then
		return
	end

	local wndMemberBtn = wndRaidMember:FindChild("RaidMemberBtn")
	
	wndMemberBtn:FindChild("HealthBar"):Show(false)
	wndMemberBtn:FindChild("MaxAbsorbBar"):Show(false)
	wndMemberBtn:FindChild("MaxShieldBar"):Show(false)
	wndMemberBtn:FindChild("MaxShieldBar:CurrShieldBar"):Show(false)
	wndMemberBtn:FindChild("RaidMemberMouseHack"):SetData(tMemberData.nMemberIdx)
	
	wndRaidMember:FindChild("RaidTearOffBtn"):SetData(nCodeIdx)

	local bOutOfRange = tMemberData.nHealthMax == 0
	local bDead = tMemberData.nHealth == 0 and tMemberData.nHealthMax ~= 0
	if not tMemberData.bIsOnline then
		wndMemberBtn:Enable(false)
		wndMemberBtn:ChangeArt("CRB_Raid:btnRaid_ThinHoloRedBtn")
		wndMemberBtn:FindChild("RaidMemberStatusIcon"):SetSprite("CRB_Raid:sprRaid_Icon_Disconnect")
		wndRaidMember:FindChild("RaidMemberName"):SetText(String_GetWeaselString(Apollo.GetString("Group_OfflineMember"), tMemberData.strCharacterName))
	elseif bDead then
		wndMemberBtn:Enable(true)
		wndMemberBtn:ChangeArt("CRB_Raid:btnRaid_ThinHoloRedBtn")
		wndMemberBtn:FindChild("RaidMemberStatusIcon"):SetSprite("")
		wndMemberBtn:FindChild("RaidMemberName"):SetText(String_GetWeaselString(Apollo.GetString("Group_DeadMember"), tMemberData.strCharacterName))
	elseif bOutOfRange then
		wndMemberBtn:Enable(false)
		wndMemberBtn:ChangeArt("CRB_Raid:btnRaid_ThinHoloBlueBtn")
		wndMemberBtn:FindChild("RaidMemberStatusIcon"):SetSprite("CRB_Raid:sprRaid_Icon_OutOfRange")
		wndMemberBtn:FindChild("RaidMemberName"):SetText(String_GetWeaselString(Apollo.GetString("Group_OutOfRange"), tMemberData.strCharacterName))
	else
		wndMemberBtn:Enable(true)
		wndMemberBtn:ChangeArt("CRB_Raid:btnRaid_ThinHoloBlueBtn")
		wndMemberBtn:FindChild("RaidMemberStatusIcon"):SetSprite("")
		wndMemberBtn:FindChild("RaidMemberName"):SetText(tMemberData.strCharacterName)
	end
	
	local wndOptions = self.wndMain:FindChild("RaidOptions:SelfConfigRaidCustomizeOptions")
	wndMemberBtn:FindChild("RaidMemberName"):Show(wndOptions:FindChild("RaidCustomizeShowNames"):IsChecked())

	local bShowClassIcon = wndOptions:FindChild("RaidCustomizeClassIcons"):IsChecked()
	local wndClassIcon = wndRaidMember:FindChild("RaidMemberClassIcon")
	if bShowClassIcon then
		wndClassIcon:SetSprite(ktIdToClassSprite[tMemberData.eClassId])
		wndClassIcon:SetTooltip(Apollo.GetString(ktIdToClassTooltip[tMemberData.eClassId]))
	end
	wndClassIcon:Show(bShowClassIcon)

	local nLeaderIdx = 0
	local bShowLeaderIcon = wndOptions:FindChild("RaidCustomizeLeaderIcons"):IsChecked()
	local wndLeaderIcon = wndRaidMember:FindChild("RaidMemberIsLeader")
	if bShowLeaderIcon then
		if tMemberData.bIsLeader then
			nLeaderIdx = 1
		elseif tMemberData.bMainTank then
			nLeaderIdx = 2
		elseif tMemberData.bMainAssist then
			nLeaderIdx = 3
		elseif tMemberData.bRaidAssistant then
			nLeaderIdx = 4
		end
		wndLeaderIcon:SetSprite(ktIdToLeaderSprite[nLeaderIdx])
		wndLeaderIcon:SetTooltip(Apollo.GetString(ktIdToLeaderTooltip[nLeaderIdx]))
	end
	wndLeaderIcon:Show(bShowLeaderIcon and nLeaderIdx ~= 0)

	local nRoleIdx = 0
	local bShowRoleIcon = wndOptions:FindChild("RaidCustomizeRoleIcons"):IsChecked()
	local wndRoleIcon = wndRaidMember:FindChild("RaidMemberRoleIcon")
	if bShowRoleIcon then
		if tMemberData.bDPS then
			nRoleIdx = 1
		elseif tMemberData.bHealer then
			nRoleIdx = 2
		elseif tMemberData.bTank then
			nRoleIdx = 3
		end

		wndRoleIcon:SetSprite(ktIdToRoleSprite[nRoleIdx])
		wndRoleIcon:SetTooltip(Apollo.GetString(ktIdToRoleTooltip[nRoleIdx]))
	end
	wndRoleIcon:Show(bShowRoleIcon and nRoleIdx ~= 0)

	local nMarkIdx = 0
	local bShowMarkIcon = wndOptions:FindChild("RaidCustomizeMarkIcons"):IsChecked()
	local wndMarkIcon = wndRaidMember:FindChild("RaidMemberMarkIcon")
	if bShowMarkIcon then
		nMarkIdx = tMemberData.nMarkerId or 0
		wndMarkIcon:SetSprite(kstrRaidMarkerToSprite[nMarkIdx])
	end
	wndMarkIcon:Show(bShowMarkIcon and nMarkIdx ~= 0)

	-- Ready Check
	if self.nNumReadyCheckResponses >= 0 then
		local wndReadyCheckIcon = wndRaidMember:FindChild("RaidMemberReadyIcon")
		if tMemberData.bHasSetReady and tMemberData.bReady then
			self.nNumReadyCheckResponses = self.nNumReadyCheckResponses + 1
			wndReadyCheckIcon:SetText(Apollo.GetString("RaidFrame_Ready"))
			wndReadyCheckIcon:SetSprite("CRB_Raid:sprRaid_Icon_ReadyCheckDull")
		elseif tMemberData.bHasSetReady and not tMemberData.bReady then
			self.nNumReadyCheckResponses = self.nNumReadyCheckResponses + 1
			wndReadyCheckIcon:SetText("")
			wndReadyCheckIcon:SetSprite("CRB_Raid:sprRaid_Icon_NotReadyDull")
		else
			wndReadyCheckIcon:SetText("")
			wndReadyCheckIcon:SetSprite("")
		end
		wndReadyCheckIcon:Show(true)
		--wndRaidMember:BringChildToTop(wndReadyCheckIcon)

		if self.nNumReadyCheckResponses == nGroupMemberCount then
			self:OnReadyCheckTimeout()
		end
	end

	-- HP and Shields
	local unitCurr = GroupLib.GetUnitForGroupMember(nCodeIdx)
	if unitCurr then
		local bTargetThisMember = unitTarget and unitTarget == unitCurr
		wndMemberBtn:SetCheck(bTargetThisMember)
		wndRaidMember:FindChild("RaidTearOffBtn"):Show(bTargetThisMember and not bFrameLocked and not self.tTearOffMemberIDs[nCodeIdx])
		self:DoHPAndShieldResizing(wndMemberBtn, unitCurr)

		-- Mana Bar
		local bShowManaBar = wndOptions:FindChild("RaidCustomizeManaBar"):IsChecked()
		if bShowManaBar and tMemberData.nManaMax and tMemberData.nManaMax > 0 then
			local wndManaBar = self:LoadByName("RaidMemberManaBar", wndMemberBtn, "RaidMemberManaBar")
			wndManaBar:SetMax(tMemberData.nManaMax)
			wndManaBar:SetProgress(tMemberData.nMana)
			wndManaBar:Show(tMemberData.bIsOnline and not bDead and not bOutOfRange and unitCurr:GetHealth() > 0 and unitCurr:GetMaxHealth() > 0)
		end
	end
end

-----------------------------------------------------------------------------------------------
-- UI
-----------------------------------------------------------------------------------------------

function RaidFrameBase:OnRaidCategoryBtnToggle(wndHandler, wndControl) -- RaidCategoryBtn
	wndHandler:GetParent():FindChild("RaidCategoryItems"):DestroyChildren()
	self:OnRaidFrameBaseTimer()
end

function RaidFrameBase:OnRaidLeaderOptionsToggle(wndHandler, wndControl) -- RaidLeaderOptionsBtn
	Event_FireGenericEvent("GenericEvent_Raid_ToggleMasterLoot", false)
	Event_FireGenericEvent("GenericEvent_Raid_ToggleLeaderOptions", wndHandler:IsChecked())
end

function RaidFrameBase:OnRaidMasterLootToggle(wndHandler, wndControl) -- RaidMasterLootBtn
	Event_FireGenericEvent("GenericEvent_Raid_ToggleMasterLoot", wndHandler:IsChecked())
	Event_FireGenericEvent("GenericEvent_Raid_ToggleLeaderOptions", false)
end

function RaidFrameBase:OnRaidConfigureToggle(wndHandler, wndControl) -- RaidConfigureBtn
	if wndHandler:IsChecked() then
		Event_FireGenericEvent("GenericEvent_Raid_ToggleMasterLoot", false)
		Event_FireGenericEvent("GenericEvent_Raid_ToggleLeaderOptions", false)
	end
end

function RaidFrameBase:OnRaidTearOffBtn(wndHandler, wndControl) -- RaidTearOffBtn
	Event_FireGenericEvent("GenericEvent_Raid_ToggleRaidTearOff", wndHandler:GetData())
	self.tTearOffMemberIDs[wndHandler:GetData()] = true
end

function RaidFrameBase:OnRaidUnTearOff(wndArg) -- GenericEvent_Raid_ToggleRaidUnTear
	self.tTearOffMemberIDs[wndArg] = nil
end

function RaidFrameBase:OnLeaveBtn(wndHandler, wndControl)
	self:OnUncheckLeaderOptions()
	self:OnUncheckMasterLoot()
	GroupLib.LeaveGroup()
end

function RaidFrameBase:OnRaidLeaveShowPrompt(wndHandler, wndControl)
	if self.wndMain and self.wndMain:IsValid() and self.wndMain:FindChild("RaidConfigureBtn") then
		self.wndMain:FindChild("RaidConfigureBtn"):SetCheck(false)
	end
	self:OnUncheckLeaderOptions()
	self:OnUncheckMasterLoot()
	Apollo.LoadForm(self.xmlDoc, "RaidLeaveYesNo", nil, self)
end

function RaidFrameBase:OnRaidLeaveYes(wndHandler, wndControl)
	wndHandler:GetParent():Destroy()
	self:OnLeaveBtn()
end

function RaidFrameBase:OnRaidLeaveNo(wndHandler, wndControl)
	wndHandler:GetParent():Destroy()
end

function RaidFrameBase:OnUncheckLeaderOptions()
	if self.wndMain and self.wndMain:IsValid() then
		self.wndMain:FindChild("RaidLeaderOptionsBtn"):SetCheck(false)
	end
end

function RaidFrameBase:OnUncheckMasterLoot()
	if self.wndMain and self.wndMain:IsValid() then
		self.wndMain:FindChild("RaidMasterLootBtn"):SetCheck(false)
	end
end

-----------------------------------------------------------------------------------------------
-- Ready Check
-----------------------------------------------------------------------------------------------

function RaidFrameBase:OnStartReadyCheckBtn(wndHandler, wndControl) -- StartReadyCheckBtn
	local strMessage = self.wndMain:FindChild("RaidOptions:SelfConfigReadyCheckLabel:ReadyCheckMessageBG:ReadyCheckMessageEditBox"):GetText()
	if string.len(strMessage) <= 0 then
		strMessage = Apollo.GetString("RaidFrame_AreYouReady")
	end

	GroupLib.ReadyCheck(strMessage) -- Sanitized in code
	self.wndMain:FindChild("RaidConfigureBtn"):SetCheck(false)
	wndHandler:SetFocus() -- To remove out of edit box
end

function RaidFrameBase:OnGroup_ReadyCheck(nMemberIdx, strMessage)
	local tMember = GroupLib.GetGroupMember(nMemberIdx)
	local strName = Apollo.GetString("RaidFrame_TheRaid")
	if tMember then
		strName = tMember.strCharacterName
	end

	if self.wndReadyCheckPopup and self.wndReadyCheckPopup:IsValid() then
		self.wndReadyCheckPopup:Destroy()
	end

	self.wndReadyCheckPopup = Apollo.LoadForm(self.xmlDoc, "RaidReadyCheck", nil, self)
	self.wndReadyCheckPopup:SetData(wndReadyCheckPopup)
	self.wndReadyCheckPopup:FindChild("ReadyCheckNoBtn"):SetData(wndReadyCheckPopup)
	self.wndReadyCheckPopup:FindChild("ReadyCheckYesBtn"):SetData(wndReadyCheckPopup)
	self.wndReadyCheckPopup:FindChild("ReadyCheckCloseBtn"):SetData(wndReadyCheckPopup)
	self.wndReadyCheckPopup:FindChild("ReadyCheckMessage"):SetText(String_GetWeaselString(Apollo.GetString("RaidFrame_ReadyCheckStarted"), strName) .. "\n" .. strMessage)

	self.nNumReadyCheckResponses = 0
	Apollo.CreateTimer("ReadyCheckTimeout", knReadyCheckTimeout, false)
end

function RaidFrameBase:OnReadyCheckResponse(wndHandler, wndControl)
	if wndHandler == wndControl then
		GroupLib.SetReady(wndHandler:GetName() == "ReadyCheckYesBtn") -- TODO Quick Hack
	end

	if self.wndReadyCheckPopup and self.wndReadyCheckPopup:IsValid() then
		self.wndReadyCheckPopup:Destroy()
	end
end

function RaidFrameBase:OnReadyCheckTimeout()
	self.nNumReadyCheckResponses = -1
	Apollo.StopTimer("ReadyCheckTimeout")

	if self.wndReadyCheckPopup and self.wndReadyCheckPopup:IsValid() then
		self.wndReadyCheckPopup:Destroy()
	end

	local strMembersNotReady = ""
	for key, wndCategory in pairs(self.wndMain:FindChild("RaidCategoryContainer"):GetChildren()) do
		for key2, wndMember in pairs(wndCategory:FindChild("RaidCategoryItems"):GetChildren()) do
			if wndMember:FindChild("RaidMemberReadyIcon") and wndMember:FindChild("RaidMemberReadyIcon"):IsValid() then
				if wndMember:FindChild("RaidMemberReadyIcon"):GetText() ~= Apollo.GetString("RaidFrame_Ready") then
					if strMembersNotReady == "" then
						strMembersNotReady = wndMember:FindChild("RaidMemberName"):GetText()
					else
						strMembersNotReady = String_GetWeaselString(Apollo.GetString("RaidFrame_NotReadyList"), strMembersNotReady, wndMember:FindChild("RaidMemberName"):GetText())
					end
				end
				--wndMember:FindChild("RaidMemberReadyIcon"):Destroy()
				wndMember:FindChild("RaidMemberReadyIcon"):Show(false)
			elseif strMembersNotReady == "" then
				strMembersNotReady = wndMember:FindChild("RaidMemberName"):GetText()
			else
				strMembersNotReady = String_GetWeaselString(Apollo.GetString("RaidFrame_NotReadyList"), strMembersNotReady, wndMember:FindChild("RaidMemberName"):GetText())
			end
		end
	end

	self:OnRaidFrameBaseTimer()

	if strMembersNotReady == "" then
		ChatSystemLib.PostOnChannel(ChatSystemLib.ChatChannel_Party, Apollo.GetString("RaidFrame_ReadyCheckSuccess"), "")
	else
		ChatSystemLib.PostOnChannel(ChatSystemLib.ChatChannel_Party, String_GetWeaselString(Apollo.GetString("RaidFrame_ReadyCheckFail"), strMembersNotReady), "")
	end
end

-----------------------------------------------------------------------------------------------
-- Self Config and Customization
-----------------------------------------------------------------------------------------------

function RaidFrameBase:OnConfigSetAsDPSToggle(wndHandler, wndControl)
	GroupLib.SetRoleDPS(wndHandler:GetData(), wndHandler:IsChecked()) -- Will fire event Group_MemberFlagsChanged
end

function RaidFrameBase:OnConfigSetAsTankToggle(wndHandler, wndControl)
	GroupLib.SetRoleTank(wndHandler:GetData(), wndHandler:IsChecked()) -- Will fire event Group_MemberFlagsChanged
end

function RaidFrameBase:OnConfigSetAsHealerToggle(wndHandler, wndControl)
	GroupLib.SetRoleHealer(wndHandler:GetData(), wndHandler:IsChecked()) -- Will fire event Group_MemberFlagsChanged
end

function RaidFrameBase:OnRaidMemberBtnClick(wndHandler, wndControl) -- RaidMemberMouseHack
	-- GOTCHA: Use MouseUp instead of ButtonCheck to avoid weird edgecase bugs
	if wndHandler ~= wndControl or not wndHandler or not wndHandler:GetData() then
		return
	end

	local unit = GroupLib.GetUnitForGroupMember(wndHandler:GetData())
	if unit then
		GameLib.SetTargetUnit(unit)
		self:OnRaidFrameBaseTimer()
		self:ResizeAllFrames() -- TODO HACK to immediate redraw
	end
end

function RaidFrameBase:OnRaidLockFrameBtnToggle(wndHandler, wndControl) -- RaidLockFrameBtn
	self.wndMain:SetStyle("Sizable", not wndHandler:IsChecked())
	self.wndMain:SetStyle("Moveable", not wndHandler:IsChecked())
	if wndHandler:IsChecked() then
		self.wndMain:SetSprite("sprRaid_BaseNoArrow")
	else
		self.wndMain:SetSprite("sprRaid_Base")
	end
end

function RaidFrameBase:OnRaidCustomizeNumColAdd(wndHandler, wndControl) -- RaidCustomizeNumColAdd, and once from bSwapToTwoColsOnce
	self.nNumColumns = self.nNumColumns + 1
	if self.nNumColumns >= 5 then
		self.nNumColumns = 5
		wndHandler:Enable(false)
	end
	self.wndMain:FindChild("RaidCustomizeNumColSub"):Enable(true)
	self.wndMain:FindChild("RaidCustomizeNumColValue"):SetText(self.nNumColumns)
	self:OnRaidFrameBaseTimer()
	self:ResizeAllFrames() -- TODO HACK to immediate redraw
end

function RaidFrameBase:OnRaidCustomizeNumColSub(wndHandler, wndControl) -- RaidCustomizeNumColSub
	self.nNumColumns = self.nNumColumns - 1
	if self.nNumColumns <= 1 then
		self.nNumColumns = 1
		wndHandler:Enable(false)
	end
	self.wndMain:FindChild("RaidCustomizeNumColAdd"):Enable(true)
	self.wndMain:FindChild("RaidCustomizeNumColValue"):SetText(self.nNumColumns)
	self:OnRaidFrameBaseTimer()
	self:ResizeAllFrames() -- TODO HACK to immediate redraw
end

function RaidFrameBase:OnRaidCustomizeRowSizeAdd(wndHandler, wndControl) -- RaidCustomizeRowSizeAdd
	self.nRowSize = self.nRowSize + 1
	if self.nRowSize >= 5 then
		self.nRowSize = 5
		wndHandler:Enable(false)
	end
	self.wndMain:FindChild("RaidCustomizeRowSizeSub"):Enable(true)
	self.wndMain:FindChild("RaidCustomizeRowSizeValue"):SetText(self.nRowSize)
	self:OnRaidFrameBaseTimer()
	self:ResizeAllFrames() -- TODO HACK to immediate redraw
end

function RaidFrameBase:OnRaidCustomizeRowSizeSub(wndHandler, wndControl) -- RaidCustomizeRowSizeSub
	self.nRowSize = self.nRowSize - 1
	if self.nRowSize <= 1 then
		self.nRowSize = 1
		wndHandler:Enable(false)
	end
	self.wndMain:FindChild("RaidCustomizeRowSizeAdd"):Enable(true)
	self.wndMain:FindChild("RaidCustomizeRowSizeValue"):SetText(self.nRowSize)
	self:OnRaidFrameBaseTimer()
	self:ResizeAllFrames() -- TODO HACK to immediate redraw
end

function RaidFrameBase:DestroyAndRedrawAllFromUI(wndHandler, wndControl) -- RaidCustomizeRoleIcons
	self:OnDestroyAndRedrawAll()
end

function RaidFrameBase:OnDestroyAndRedrawAll() -- Group_MemberFlagsChanged, DestroyAndRedrawAllFromUI
	if self.wndMain and self.wndMain:IsValid() then
		self.wndMain:FindChild("RaidCategoryContainer"):DestroyChildren()
		self:OnRaidFrameBaseTimer()
		self:OnRaidFrameBaseTimer() -- TODO HACK to immediate redraw
	end
end

-----------------------------------------------------------------------------------------------
-- Helpers
-----------------------------------------------------------------------------------------------

function RaidFrameBase:OnEnteredCombat(unit, bInCombat)
	if self.wndMain and self.wndMain:IsValid() and self.wndMain:IsVisible() and unit == GameLib.GetPlayerUnit() and self.wndMain:FindChild("RaidCustomizeLockInCombat"):IsChecked() then
		self.wndMain:FindChild("RaidLockFrameBtn"):SetCheck(bInCombat)
		self:OnRaidLockFrameBtnToggle(self.wndMain:FindChild("RaidLockFrameBtn"), self.wndMain:FindChild("RaidLockFrameBtn"))
	end
end

function RaidFrameBase:HelperVerifyMemberCategory(strCurrCategory, tMemberData)
	local bResult = true
	if strCurrCategory == Apollo.GetString("RaidFrame_Tanks") then
		bResult =  tMemberData.bTank
	elseif strCurrCategory == Apollo.GetString("RaidFrame_Healers") then
		bResult = tMemberData.bHealer
	elseif strCurrCategory == Apollo.GetString("RaidFrame_DPS") then
		bResult = not tMemberData.bTank and not tMemberData.bHealer
	end
	return bResult
end

function RaidFrameBase:DoHPAndShieldResizing(wndMemberBtn, unitPlayer)
	if not unitPlayer then
		return
	end

	local nHealthCurr = unitPlayer:GetHealth()
	local nHealthMax = unitPlayer:GetMaxHealth()
	local nShieldCurr = unitPlayer:GetShieldCapacity()
	local nShieldMax = unitPlayer:GetShieldCapacityMax()
	local nAbsorbCurr = 0
	local nAbsorbMax = unitPlayer:GetAbsorptionMax()
	if nAbsorbMax > 0 then
		nAbsorbCurr = unitPlayer:GetAbsorptionValue() -- Since it doesn't clear when the buff drops off
	end
	local nTotalMax = nHealthMax + nShieldMax + nAbsorbMax

	-- Bars
	local wndHealthBar = wndMemberBtn:FindChild("HealthBar")
	local wndMaxAbsorb = wndMemberBtn:FindChild("MaxAbsorbBar")
	local wndMaxShield = wndMemberBtn:FindChild("MaxShieldBar")
	wndHealthBar:Show(nHealthCurr > 0 and nHealthMax > 0)
	wndMaxAbsorb:Show(nHealthCurr > 0 and nAbsorbMax > 0)
	wndMaxShield:Show(nHealthCurr > 0 and nShieldMax > 0)
	
	local wndCurrShieldBar = wndMaxShield:FindChild("CurrShieldBar")
	wndCurrShieldBar:Show(nHealthCurr > 0 and nShieldMax > 0)
	wndCurrShieldBar:SetMax(nShieldMax)
	wndCurrShieldBar:SetProgress(nShieldCurr)
	wndCurrShieldBar:EnableGlow((wndCurrShieldBar):GetWidth() * nShieldCurr/nShieldMax > 4)
	
	local wndCurrAbsorbBar = wndMaxAbsorb:FindChild("CurrAbsorbBar")
	wndCurrAbsorbBar:SetMax(nAbsorbMax)
	wndCurrAbsorbBar:SetProgress(nAbsorbCurr)
	wndCurrAbsorbBar:EnableGlow((wndCurrAbsorbBar:GetWidth() * nAbsorbCurr/nAbsorbMax) > 4)
	
	local wndHealthBarGlow = wndHealthBar:FindChild("HealthBarEdgeGlow")
	wndHealthBarGlow:Show(nShieldMax <= 0)

	-- Health Bar Color
	if (nHealthCurr / nHealthMax) < self.nHealthWarn then
		wndHealthBar:SetSprite("sprRaid_HealthProgBar_Red")
		wndHealthBarGlow:SetSprite("sprRaid_HealthEdgeGlow_Red")
	elseif (nHealthCurr / nHealthMax) < self.nHealthWarn2 then
		wndHealthBar:SetSprite("sprRaid_HealthProgBar_Orange")
		wndHealthBarGlow:SetSprite("sprRaid_HealthEdgeGlow_Orange")
	else
		wndHealthBar:SetSprite("sprRaid_HealthProgBar_Green")
		wndHealthBarGlow:SetSprite("sprRaid_HealthEdgeGlow_Green")
	end

	-- Scaling
	local nArtOffset = 2
	local nWidth = wndMemberBtn:GetWidth() - 4
	local nPointHealthRight = nWidth * (nHealthCurr / nTotalMax)
	local nPointShieldRight = nWidth * ((nHealthCurr + nShieldMax) / nTotalMax)
	local nPointAbsorbRight = nWidth * ((nHealthCurr + nShieldMax + nAbsorbMax) / nTotalMax)

	local nLeft, nTop, nRight, nBottom = wndHealthBar:GetAnchorOffsets()
	if not self.wndMain:FindChild("RaidOptions:SelfConfigRaidCustomizeOptions:RaidCustomizeFixedShields"):IsChecked() then
		wndHealthBar:SetAnchorOffsets(nLeft, nTop, nPointHealthRight, nBottom)
		wndMaxShield:SetAnchorOffsets(nPointHealthRight - nArtOffset, nTop, nPointShieldRight, nBottom)
		wndMaxAbsorb:SetAnchorOffsets(nPointShieldRight - nArtOffset, nTop, nPointAbsorbRight, nBottom)
	elseif nAbsorbMax == 0 then
		wndHealthBar:SetAnchorOffsets(nLeft, nTop, nWidth * 0.9 * nHealthCurr / nHealthMax, nBottom)
		wndMaxShield:SetAnchorOffsets(nWidth * 0.9, nTop, nWidth, nBottom)
	else
		wndHealthBar:SetAnchorOffsets(nLeft, nTop, nWidth * 0.9 * nHealthCurr / nHealthMax, nBottom)
		wndMaxShield:SetAnchorOffsets(nWidth * 0.9, nTop, nWidth, nBottom)
		wndMaxAbsorb:SetAnchorOffsets(nWidth * 0.8, nTop, nWidth * 0.9, nBottom)
	end
end

function RaidFrameBase:LoadByName(strForm, wndParent, strCustomName)
	local wndNew = wndParent:FindChild(strCustomName)
	if not wndNew then
		wndNew = Apollo.LoadForm(self.xmlDoc, strForm, wndParent, self)
		wndNew:SetName(strCustomName)
	end
	return wndNew
end

local RaidFrameBaseInst = RaidFrameBase:new()
RaidFrameBaseInst:Init()
