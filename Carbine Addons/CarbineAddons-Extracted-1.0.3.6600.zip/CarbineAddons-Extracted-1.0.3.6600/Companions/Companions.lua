require "Window"

local Companions = {}

function Companions:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	
	return o
end

--[[

local bHasPets()
--This checks to see if a player has pets.


local bHasLandMounts()
--This checks to see if a player has land mounts.


local bHasFlyingMounts()
--This checks to see if a player has flying mounts.


function Companions:ModuleTrigger()
	if bHasPets == true	or
		bHasLandMounts == true	or
		bFlyingMounts == true return true
	else
		return false
	end
end

local bModuleTrigger = self:ModuleTrigger()


--This checks the other three booleans and activates the Companions Module if any are true.

--]]

--------------------//-----------------------------
function Companions:Init()
	Apollo.RegisterAddon(self)
end

--------------------//-----------------------------
function Companions:OnLoad()
	Apollo.RegisterEventHandler("VarChange_FrameCount", "OnFrame", self)

	--[[
--> RegisterEventHandler("PetAdded", "OnPetAdded", self) 
	A global for this needs to be added.
	
-->	Apollo.RegisterEventHandler("LandMountAdded", "OnLandMountAdded", self) 
	A global for this needs to be added. 
	
-->	Apollo.RegisterEventHandler("FlyingMountAdded", "OnFlyingMountAdded", self) 
	A global for this needs to be added. 
	]]--

	self.wndCompanions = Apollo.LoadForm("CompanionsForms.xml", "CompanionsMenu", nil, self)
	self.wndCompanionsModule = Apollo.LoadForm("CompanionsForms.xml", "CompanionsModule", nil, self)
	self.MenuButton = self.wndCompanionsModule:FindChild("CompanionsBtn")
	self.PetButton = self.wndCompanionsModule:FindChild("PetBtn")
	self.LandMountButton = self.wndCompanionsModule:FindChild("LandMountBtn")
	self.FlyingMountButton = self.wndCompanionsModule:FindChild("FlyingMountBtn")
	self.wndCompanionsModule:Show(true)
	self.wndCompanions:Show(false)
	
	self.PetTab = self.wndCompanions:FindChild("PetsTabBtn")
	self.LandTab = self.wndCompanions:FindChild("LandMountsTabBtn")
	self.FlyingTab = self.wndCompanions:FindChild("FlyingMountsTabBtn")
--[[	
	self.wndCompanionsModule:Show(bModuleTrigger) --Turns the Module on if the player has pets/land mounts/flying mounts
	self.PetButton:Show(bHasPets) --Turns the Pets button on if the player has pets
	self.LandMountButton:Show(bHasLandMounts) --Turns the Land Mounts button on if the player has land mounts
	self.FlyingMountButton:Show(bHasFlyingMounts) --Turns the Flying Mounts button on if the player has flying mounts
--]]

		self.wndCompanionsModule:Show(false)
end

--------------------//-----------------------------
function Companions:OnSave(eType)
	return nil
end
--------------------//-----------------------------
function Companions:OnRestore(eType, t)
end
--------------------//-----------------------------
function Companions:OnFrame()
	if IsDemo() then 
		return
	end	
	
	if self.wndCompanions:IsVisible() then
		self.MenuButton:SetCheck(true)
	else
		self.MenuButton:SetCheck(false)
	end
end

--[[
-------------------New Items Added----------------------------
--Setting the parameters for new pets/mounts to add the UI buttons if a player doesn't already have them

function Companions:OnPetAdded()
	self.wndCompanionsModule:Show(true)
	self.PetButton:Show(true)
end

function Companions:OnLandMountAdded()
	self.wndCompanionsModule:Show(true)
	self.LandMountButton(true)
end

function Companions:OnFlyingMountAdded()
	self.wndCompanionsModule:Show(true)
	self.FlyingMountButton(true)
end
--]]

--------------------//-----------------------------
--------------------//-----------------------------
function Companions:OnButtonCheck()
		self.wndCompanions:Show(true)
	--	self:PopulateCompanions()  Need the command for populating the Companions Menu (below)
		self.wndCompanions:ToFront()
		self.MenuButton:SetCheck(true)
		self.PetTab:SetCheck(true)
		self.LandTab:SetCheck(false)
		self.FlyingTab:SetCheck(false)
	Sound.Play(Sound.PlayUI37OpenRemoteWindowDigital)
end

--------------------//-----------------------------
function Companions:OnButtonUncheck()
	self.wndCompanions:Show(false)
	self.MenuButton:SetCheck(false)
	Sound.Play(Sound.PlayUI38CloseRemoteWindowDigital)
end

--------------------Populate Companions Menus-----------------------------
--[[

This is where the populate controls for the Companions menu will go.

--]]
--------------------//-----------------------------


----------------------Module Button Functions---------------------------------
function Companions:OnPetBtn()
	--Event_FireGenericEvent("SummonDefaultPet")
	--[[This event needs to check and see if the player has a default pet selected, 
	and supply them with a random one from their inventory if they do not.--]]
end
--------------------//-----------------------------
function Companions:OnLandMountBtn()
	--Event_FireGenericEvent("SummonDefaultLandMount")
	--[[This event needs to check and see if the player has a default land mount selected, 
	and supply them with a random one from their inventory if they do not.--]]
end
--------------------//-----------------------------
function Companions:OnFlyingMountBtn()
	--Event_FireGenericEvent("SummonDefaultFlyingMount")
	--[[This event needs to check and see if the player has a default flying mount selected, 
	and supply them with a random one from their inventory if they do not.--]]
end

----------------------Window Button Functions---------------------------------
function Companions:OnCloseBtn()
	self.wndCompanions:Show(false)
end

function Companions:OnMountBtn()

end


function Companions:OnSetdefaultCheck()
	Sound.Play(Sound.PlayUI23And25GenericToggleOnPhysical02)
end

function Companions:OnSetdefaultUncheck()
	Sound.Play(Sound.PlayUI24And26GenericToggleOffPhysical02)
end

--------------------/Window Tab Controls/-----------------------------
function Companions:OnPetsTab()
	--[[self.PetTab:Show(true)
	self.LandTab:Show(false)
	self.FlyingTab:Show(false)]]--
	Sound.Play(Sound.PlayUI07SelectTabPhysical)
end

function Companions:OnLandMountsTab()
	--[[self.PetTab:Show(false)
	self.LandTab:Show(true)
	self.FlyingTab:Show(false)--]]
	Sound.Play(Sound.PlayUI07SelectTabPhysical)
end

function Companions:OnFlyingMountsTab()
	--[[self.PetTab:Show(false)
	self.LandTab:Show(false)
	self.FlyingTab:Show(true)]]--
	Sound.Play(Sound.PlayUI07SelectTabPhysical)
end

---------------------------------------------------
----------------globals----------------------------

local CompanionsInstance = Companions:new()

--------------------------------------------------
--------------------------------------------------
