-----------------------------------------------------------------------------------------------
-- Client Lua Script for FriendsList
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "Unit"
require "FriendshipLib"
require "math"
require "string"
require "ChatSystemLib"
require "PlayerPathLib"
require "HousingLib"

-----------------------------------------------------------------------------------------------
-- FriendsList Module Definition
-----------------------------------------------------------------------------------------------
local NeighborsList = {}

-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
-- e.g. local kiExampleVariableMax = 999

local kstrClassIcon =
{
	[GameLib.CodeEnumClass.Medic] 			= "Icon_Windows_UI_CRB_Medic",
	[GameLib.CodeEnumClass.Esper] 			= "Icon_Windows_UI_CRB_Esper",
	[GameLib.CodeEnumClass.Warrior] 		= "Icon_Windows_UI_CRB_Warrior",
	[GameLib.CodeEnumClass.Stalker] 		= "Icon_Windows_UI_CRB_Stalker",
	[GameLib.CodeEnumClass.Engineer] 		= "Icon_Windows_UI_CRB_Engineer",
	[GameLib.CodeEnumClass.Spellslinger] 	= "Icon_Windows_UI_CRB_Spellslinger",
	[5] = "Icon_Windows_UI_CRB_Spellslinger",
}

local kstrPath =
{
	[PlayerPathLib.PlayerPathType_Soldier] 		= Apollo.GetString("PlayerPathSoldier"),
	[PlayerPathLib.PlayerPathType_Settler] 		= Apollo.GetString("PlayerPathSettler"),
	[PlayerPathLib.PlayerPathType_Scientist] 	= Apollo.GetString("PlayerPathExplorer"),
	[PlayerPathLib.PlayerPathType_Explorer] 	= Apollo.GetString("PlayerPathScientist"),
}

local kstrPathIcon =
{
	[PlayerPathLib.PlayerPathType_Soldier] 		= "Icon_Windows_UI_CRB_Soldier",
	[PlayerPathLib.PlayerPathType_Settler] 		= "Icon_Windows_UI_CRB_Colonist",
	[PlayerPathLib.PlayerPathType_Scientist] 	= "Icon_Windows_UI_CRB_Scientist",
	[PlayerPathLib.PlayerPathType_Explorer] 	= "Icon_Windows_UI_CRB_Explorer",
}

-- Color was not being used in function.  If added, structure should look like = {strMessage = <String>, crColor = <Color>},
local ktHousingResultStrings =
{
	[HousingLib.HousingResult_Neighbor_Success] 			= "Neighbors_SuccessMsg",
	[HousingLib.HousingResult_Neighbor_RequestTimedOut] 	= "Neighbors_RequestTimedOut", 		--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_RequestAccepted] 	= "Neighbors_RequestAccepted",
	[HousingLib.HousingResult_Neighbor_RequestDeclined] 	= "Neighbors_RequestDeclined", 		--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_PlayerNotFound] 		= "Neighbors_PlayerNotFound", 		--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_PlayerNotOnline] 	= "Neighbors_PlayerNotOnline", 		--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_PlayerNotAHomeowner] = "Neighbors_NotAHomeowner", 		--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_PlayerDoesntExist] 	= "Neighbors_PlayerDoesntExist", 	--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_InvalidNeighbor] 	= "Neighbors_InvalidNeighbor", 		--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_AlreadyNeighbors] 	= "Neighbors_AlreadyNeighbors", 	--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_NoPendingInvite] 	= "Neighbors_NoPendingInvites", 	--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_InvitePending] 		= "Neighbors_InvitePending", 		--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_PlayerWrongFaction] 	= "Neighbors_DifferentFaction", 	--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_Full] 				= "Neighbors_NeighborListFull", 	--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Visit_Private] 				= "Neighbors_PrivateResidence", 	--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Visit_Ignored] 				= "Neighbors_IgnoredByHost", 		--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Visit_InvalidWorld] 			= "Neighbors_InvalidWorld", 		--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Visit_Failed] 				= "Neighbors_VisitFailed", 			--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
}

local ktMyHousingResultStrings =
{
	[HousingLib.HousingResult_Neighbor_RequestAccepted] 	= "Neighbors_RequestAcceptedSelf",
	[HousingLib.HousingResult_Neighbor_RequestDeclined] 	= "Neighbors_RequestDeclinedSelf",
	[HousingLib.HousingResult_Neighbor_PlayerNotAHomeowner]	= "Neighbors_NotAHomeownerSelf", 		--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_InvalidNeighbor] 	= "Neighbors_InvalidPlayer", 			--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")},
	[HousingLib.HousingResult_Neighbor_Full] 				= "Neighbors_YourNeighborListFull", 	--strColorToUse = ApolloColor.new("UI_BtnTextRedNormal")}
}

local kcrOnline = ApolloColor.new("white")
local kcrOffline = ApolloColor.new("UI_TextHoloBodyHighlight")
local kcrNeutral = ApolloColor.new("UI_TextHoloBodyHighlight")

-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
function NeighborsList:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self

    -- initialize variables here

    return o
end

function NeighborsList:Init()
    Apollo.RegisterAddon(self)
end


-----------------------------------------------------------------------------------------------
-- FriendsList OnLoad
-----------------------------------------------------------------------------------------------
function NeighborsList:OnLoad()

    Apollo.RegisterSlashCommand("neighborlist", 						"OnShow", self)

	Apollo.RegisterEventHandler("HousingResult", 						"OnHousingResult", self)
	Apollo.RegisterEventHandler("HousingNeighborsLoaded", 				"RefreshList", self)
	Apollo.RegisterEventHandler("HousingNeighborUpdate", 				"RefreshList", self)
	Apollo.RegisterEventHandler("HousingNeighborInviteRecieved", 		"OnNeighborInviteRecieved", self)
	Apollo.RegisterEventHandler("HousingNeighborInviteAccepted", 		"OnNeighborInviteAccepted", self)
	Apollo.RegisterEventHandler("HousingNeighborInviteDeclined", 		"OnNeighborInviteDeclined", self)
	Apollo.RegisterEventHandler("HousingPrivacyUpdated", 				"OnPrivacyUpdated", self)
	Apollo.RegisterEventHandler("HousingRandomResidenceListRecieved", 	"OnRandomResidenceList", self)
	Apollo.RegisterEventHandler("EventGeneric_OpenNeighborsList", 		"OnEventGeneric_OpenNeighborsList", self)
	Apollo.RegisterEventHandler("InvokeNeighborsList", 					"OnShow", self)
	Apollo.RegisterEventHandler("ChangeWorld", 							"OnChangeWorld", self)
	Apollo.RegisterTimerHandler("MessageDisplayTimer", 					"OnMessageDisplayTimer", self)

    -- load our forms
    self.wndMain = Apollo.LoadForm("NeighborsList.xml", "FriendsListForm", nil, self)
    self.wndMain:Show(false)
	self.wndListContainer = self.wndMain:FindChild("ListContainer")
	self.wndMessage = self.wndMain:FindChild("UpdateMessage")
	self.wndMessage = self.wndMain:FindChild("UpdateMessage")
	self.wndMessage:Show(false)
	--self.wndMain:FindChild("RecallActionBtn"):SetContentId(GameLib.CodeEnumRecallCommand.House)

	self.wndMain:FindChild("VisitBtn"):AttachWindow(self.wndMain:FindChild("VisitBtn"):FindChild("VisitWindow"))
	self.wndMain:FindChild("ModifyBtn"):AttachWindow(self.wndMain:FindChild("ModifyBtn"):FindChild("ModifyWindow"))
	self.wndMain:FindChild("AddBtn"):AttachWindow(self.wndMain:FindChild("AddBtn"):FindChild("AddWindow"))

	self.wndRandomList = Apollo.LoadForm("NeighborsList.xml", "RandomFriendsForm", nil, self)
	self.wndRandomList:Show(false)
	self.wndRandomList:FindChild("VisitRandomBtn"):AttachWindow(self.wndRandomList:FindChild("VisitRandomBtn"):FindChild("VisitWindow"))

end


-----------------------------------------------------------------------------------------------
-- FriendsList Functions
-----------------------------------------------------------------------------------------------
-- Define general functions here
function NeighborsList:OnShow()
	for _, wndOld in pairs(self.wndListContainer:GetChildren()) do
		wndOld:FindChild("FriendBtn"):SetCheck(false)
	end

	self:RefreshList()
	self.wndMain:Show(true)
	self.wndMain:ToFront()
end

function NeighborsList:OnClose()
	self.wndMain:Show(false)
end

function NeighborsList:OnChangeWorld()
	self.wndRandomList:Show(false)
	self.wndMain:Show(false)
end

function NeighborsList:OnEventGeneric_OpenNeighborsList(tPos)
	local nLeft, nTop, nRight, nBottom = self.wndMain:GetAnchorOffsets()
	self.wndMain:SetAnchorOffsets(tPos["x"], tPos["y"], tPos["x"] + (nRight - nLeft), tPos["y"] + (nBottom - nTop))
	self:OnShow()
end

function NeighborsList:RefreshList()

	local nPrevId = nil
	for key, wndOld in pairs(self.wndListContainer:GetChildren()) do
		if wndOld:FindChild("FriendBtn"):IsChecked() then
			nPrevId = wndOld:GetData().nId
		end
	end

	local tNeighbors = {}
	self.wndListContainer:DestroyChildren()

	tNeighbors = HousingLib.GetNeighborList()
	for key, tCurrNeighbor in pairs(tNeighbors) do
		local wndListItem = Apollo.LoadForm("NeighborsList.xml", "FriendForm", self.wndListContainer, self)
		wndListItem:SetData(tCurrNeighbor) -- set the full table since we have no direct lookup for neighbors
		wndListItem:FindChild("Name"):SetText(tCurrNeighbor.strCharacterName)
		wndListItem:FindChild("Class"):SetSprite(kstrClassIcon[tCurrNeighbor.nClassId])
		wndListItem:FindChild("Path"):SetSprite(kstrPathIcon[tCurrNeighbor.nPathId])
		wndListItem:FindChild("Level"):SetText(tCurrNeighbor.nLevel)

		if nPrevId ~= nil then
			wndListItem:FindChild("FriendBtn"):SetCheck(tCurrNeighbor.nId == nPrevId)
		end

		wndListItem:FindChild("RoommateIcon"):Show(tCurrNeighbor.ePermissionNeighbor == HousingLib.NeighborPermissionLevel.Roommate)
		if tCurrNeighbor.ePermissionNeighbor == HousingLib.NeighborPermissionLevel.Roommate then
			wndListItem:FindChild("RoommateIcon"):SetTooltip(Apollo.GetString("Neighbors_RoommateTooltip"))
		end
		
		wndListItem:FindChild("AccountIcon"):Show(tCurrNeighbor.ePermissionNeighbor == HousingLib.NeighborPermissionLevel.Account)
		if tCurrNeighbor.ePermissionNeighbor == HousingLib.NeighborPermissionLevel.Account then
			wndListItem:FindChild("AccountIcon"):SetTooltip(Apollo.GetString("Neighbors_RoommateTooltip"))
		end

		local strColorToUse = kcrOffline
		if tCurrNeighbor.fLastOnline == 0 then -- online / check for strWorldZone
			strColorToUse = kcrOnline
			wndListItem:FindChild("LastOnline"):SetText(Apollo.GetString("Neighbors_Online"))
		else
			wndListItem:FindChild("LastOnline"):SetText(self:HelperConvertToTime(tCurrNeighbor.fLastOnline))
		end

		wndListItem:FindChild("Name"):SetTextColor(strColorToUse)
		wndListItem:FindChild("Level"):SetTextColor(strColorToUse)
		wndListItem:FindChild("LastOnline"):SetTextColor(strColorToUse)
	end

	-- set scroll
	self.wndListContainer:ArrangeChildrenVert()
	self:UpdateControls()
end

function NeighborsList:UpdateControls()
	local wndControls = self.wndMain:FindChild("Controls")
	local tCurr = nil

	for key, wndListItem in pairs(self.wndListContainer:GetChildren()) do
		if wndListItem:FindChild("FriendBtn"):IsChecked() then
			tCurr = wndListItem:GetData()
		end
	end

	-- must be on my skymap to visit; must be on someone else's to return (add button)
	wndControls:FindChild("TeleportHomeBtn"):Enable(HousingLib.IsHousingWorld())
	wndControls:FindChild("RandomBtn"):Enable(HousingLib.IsHousingWorld())
	wndControls:FindChild("HomeDisabledBlocker"):Show(not HousingLib.IsHousingWorld())
	wndControls:FindChild("VisitDisabledBlocker"):Show(not HousingLib.IsHousingWorld())
	wndControls:FindChild("RandomDisabledBlocker"):Show(not HousingLib.IsHousingWorld())
	if HousingLib.IsHousingWorld() == false then
		wndControls:FindChild("RandomBtn"):FindChild("RandomIcon"):SetBGColor(ApolloColor.new(1, 0, 0, .5))
		wndControls:FindChild("TeleportHomeBtn"):FindChild("TeleportHomeIcon"):SetBGColor(ApolloColor.new(1, 0, 0, .5))
	else
		wndControls:FindChild("RandomBtn"):FindChild("RandomIcon"):SetBGColor(ApolloColor.new(1, 1, 1, 1))
		wndControls:FindChild("TeleportHomeBtn"):FindChild("TeleportHomeIcon"):SetBGColor(ApolloColor.new(1, 1, 1, 1))
	end

	if tCurr == nil then
		wndControls:FindChild("ModifyBtn"):Enable(false)
		wndControls:FindChild("WhisperBtn"):Enable(false)
		wndControls:FindChild("VisitBtn"):Enable(false)
		return
	end

	wndControls:FindChild("ModifyBtn"):Enable(tCurr.ePermissionNeighbor ~= HousingLib.NeighborPermissionLevel.Account)
	wndControls:FindChild("WhisperBtn"):Enable(tCurr.fLastOnline == 0)
	wndControls:FindChild("VisitBtn"):Enable(HousingLib.IsHousingWorld())


	wndControls:FindChild("ModifyBtn"):SetData(tCurr)
	wndControls:FindChild("WhisperBtn"):SetData(tCurr.strCharacterName)
	wndControls:FindChild("VisitBtn"):SetData(tCurr)
end

-----------------------------------------------------------------------------------------------
-- FriendsListForm Button Functions
-----------------------------------------------------------------------------------------------
function NeighborsList:OnSocialPanelBtn(wndHandler, wndControl)
	local nLeft, nTop, nRight, nBottom = self.wndMain:GetAnchorOffsets()
	Event_FireGenericEvent("EventGeneric_OpenSocialPanel", { ["x"] = nLeft, ["y"] = nTop })
	self:OnClose()
end

function NeighborsList:OnFriendBtn(wndHandler, wndControl, eMouseButton)
	local tCurrNeighbor = wndControl:GetParent():GetData()
	
	if tCurrNeighbor == nil then
		return false
	end

	--local tFriend = FriendshipLib.GetById(nFriendId)
	if eMouseButton == GameLib.CodeEnumInputMouse.Right then
		Event_FireGenericEvent("GenericEvent_NewContextMenuPlayer", self.wndMain, tCurrNeighbor.strCharacterName)
	else
		for key, wndPlayerEntry in pairs(self.wndListContainer:GetChildren()) do
			wndPlayerEntry:FindChild("FriendBtn"):SetCheck(wndPlayerEntry:GetData() == tCurrNeighbor)
		end
	end

	self:UpdateControls()
end

function NeighborsList:OnFriendBtnUncheck(wndHandler, wndControl, eMouseButton)
	local tCurrNeighbor = wndControl:GetParent():GetData()
	
	if tCurrNeighbor == nil then
		return false
	end

	--local tFriend = FriendshipLib.GetById(nFriendId)
	if eMouseButton == GameLib.CodeEnumInputMouse.Right then
		Event_FireGenericEvent("GenericEvent_NewContextMenuPlayer", self.wndMain, tCurrNeighbor.strCharacterName)
	end
	
	self:UpdateControls()
end


-- Add Sub-Window Functions
function NeighborsList:OnAddBtn(wndHandler, wndControl)
	local wndAdd = wndControl:FindChild("AddWindow")
	wndAdd:FindChild("AddMemberEditBox"):SetText("")
	wndAdd:FindChild("AddMemberEditBox"):SetFocus()
	wndAdd:Show(true)
end

function NeighborsList:OnAddMemberYesClick( wndHandler, wndControl )
	local wndParent = wndControl:GetParent()
	local strName = wndParent:FindChild("AddMemberEditBox"):GetText()
	if strName ~= nil and strName ~= "" then
		HousingLib.NeighborInviteByName(strName)
	end
	wndControl:GetParent():Show(false)
end

function NeighborsList:OnSubCloseBtn( wndHandler, wndControl )
	wndControl:GetParent():Show(false)
end

-- Whisper Button Functions
function NeighborsList:OnWhisperBtn(wndHandler, wndControl)
	local strName = wndControl:GetData()
	if strName ~= nil then
		Event_FireGenericEvent("Event_EngageWhisper", strName)
	end
end

-- Modify Sub-Window Functions
function NeighborsList:OnModifyBtn(wndHandler, wndControl)
	local tCurrNeighbor = wndControl:GetData()
	if tCurrNeighbor == nil then
		return
	end

	local wndModify = wndControl:FindChild("ModifyWindow")
	wndModify:SetData(tCurrNeighbor)

	-- set the permissions button
	if tCurrNeighbor.ePermissionNeighbor == HousingLib.NeighborPermissionLevel.Roommate then
		wndModify:FindChild("ModifyPermissionsBtn"):SetText(Apollo.GetString("Neighbors_SetToNormal"))
	else
		wndModify:FindChild("ModifyPermissionsBtn"):SetText(Apollo.GetString("Neighbors_SetToRoommate"))
	end

	wndModify:Show(true)
end

function NeighborsList:OnModifyRemoveBtn(wndHandler, wndControl)
	local wndParent = wndControl:GetParent()
	local tCurr = wndParent:GetData()

	if tCurr ~= nil then
		HousingLib.NeighborEvict(tCurr.nId)
	end

	wndParent:Show(false)
end

function NeighborsList:OnModifyPermissionsBtn(wndHandler, wndControl)
	local wndParent = wndControl:GetParent()
	local tCurr = wndParent:GetData()

	if tCurr ~= nil and tCurr.ePermissionNeighbor == HousingLib.NeighborPermissionLevel.Roommate then
		HousingLib.NeighborSetPermission(tCurr.nId, HousingLib.NeighborPermissionLevel.Normal)
	else
		HousingLib.NeighborSetPermission(tCurr.nId, HousingLib.NeighborPermissionLevel.Roommate)
	end

	wndParent:Show(false)
end

function NeighborsList:OnModifyIgnoreBtn(wndHandler, wndControl)
	local wndParent = wndControl:GetParent()
	local tCurr = wndParent:GetData()

	if tCurr ~= nil then
		FriendshipLib.AddByName(FriendshipLib.CharacterFriendshipType_Ignore, tCurr.strCharacterName)
	end

	wndParent:Show(false)
end

-- Visit Sub-Window Functions
function NeighborsList:OnVisitBtn(wndHandler, wndControl)
	local tCurrNeighbor = wndControl:GetData()
	local wndVisit = wndControl:FindChild("VisitWindow")
	if tCurrNeighbor == nil then
		return
	end
	wndVisit:SetData(tCurrNeighbor)
	wndVisit:Show(true)
end

function NeighborsList:OnVisitConfirmBtn(wndHandler, wndControl)
	local wndParent = wndControl:GetParent()
	local tCurrNeighbor = wndParent:GetData()

	if tCurrNeighbor ~= nil then
		HousingLib.VisitNeighborResidence(tCurrNeighbor.nId)
	end

	wndParent:Show(false)
	self:OnClose()
end

function NeighborsList:OnRandomBtn(wndHandler, wndControl)
	if self.wndRandomList:IsShown() then
		self.wndRandomList:Show(false)
	else
		self:ShowRandomList()
	end
end

function NeighborsList:OnTeleportHomeBtn(wndHandler, wndControl)
	HousingLib.RequestTakeMeHome()
end

-----------------------------------------------------------------------------------------------
-- Draw Helpers
-----------------------------------------------------------------------------------------------

function NeighborsList:HelperConvertToTime(nDays)
	if nDays == 0 then
		return Apollo.GetString("Neighbors_Online")
	end
	if nDays == nil then
		return ""
	end

	local tTimeInfo = {["name"] = "", ["count"] = nil}

	if nDays >= 365 then -- Years
		tTimeInfo["name"] = Apollo.GetString("CRB_Year")
		tTimeInfo["count"] = math.floor(nDays / 365)
	elseif nDays >= 30 then -- Months
		tTimeInfo["name"] = Apollo.GetString("CRB_Month")
		tTimeInfo["count"] = math.floor(nDays / 30)
	elseif nDays >= 7 then
		tTimeInfo["name"] = Apollo.GetString("CRB_Week")
		tTimeInfo["count"] = math.floor(nDays / 7)
	elseif nDays >= 1 then -- Days
		tTimeInfo["name"] = Apollo.GetString("CRB_Day")
		tTimeInfo["count"] = math.floor(nDays)
	else
		local fHours = nDays * 24
		local nHoursRounded = math.floor(fHours)
		local nMin = math.floor(fHours*60)

		if nHoursRounded > 0 then
			tTimeInfo["name"] = Apollo.GetString("CRB_Hour")
			tTimeInfo["count"] = nHoursRounded
		elseif nMin > 0 then
			tTimeInfo["name"] = Apollo.GetString("CRB_Min")
			tTimeInfo["count"] = nMin
		else
			tTimeInfo["name"] = Apollo.GetString("CRB_Min")
			tTimeInfo["count"] = 1
		end
	end

	return String_GetWeaselString(Apollo.GetString("CRB_TimeOffline"), tTimeInfo)
end


-----------------------------------------------------------------------------------------------
-- FEEDBACK WINDOW
-----------------------------------------------------------------------------------------------

function NeighborsList:OnHousingResult(strName, eResult)

	strName = tostring(strName) -- just in case.
	local strResult = nil
	local strColorToUse = ApolloColor.new("UI_TextHoloTitle")

	local strHousingResultString = ktHousingResultStrings[eResult]
	if strHousingResultString == nil or strHousingResultString == '' then
	    return
	end

	local tResults = string.len(strName) > 1 and ktHousingResultStrings or ktMyHousingResultStrings

	if tResults[eResult] then
		strResult = Apollo.GetString(tResults[eResult])

		if string.find(strResult, "%$1n") then
			strResult = String_GetWeaselString(strResult, strName)
		end
	else
		strResult = String_GetWeaselString(Apollo.GetString("Neighbors_UndefinedResult"), eResult)
	end

	if strResult ~= nil and strResult ~= 0 then
        if self.wndMain:IsShown() then
            -- (Re)start the timer and show the window. We're not queuing these since they come as results of direct action
            self.wndMessage:FindChild("MessageText"):SetText(strResult)
            self.wndMessage:Show(true)
            Apollo.StopTimer("MessageDisplayTimer")
            Apollo.CreateTimer("MessageDisplayTimer", 4.000, false)
        else
            ChatSystemLib.PostOnChannel(ChatSystemLib.ChatChannel_System, String_GetWeaselString(Apollo.GetString("Neighbors_FriendsListError"), strResult), "")
        end
	end
end

function NeighborsList:OnMessageDisplayTimer()
	self.wndMessage:Show(false)
end

-----------------------------------------------------------------------------------------------
-- Neighbor Invite Window
-----------------------------------------------------------------------------------------------
function NeighborsList:OnNeighborInviteRecieved(strName)
	self.wndInvite = Apollo.LoadForm("NeighborsList.xml", "NeighborInviteConfirmation", nil, self)
	self.wndInvite:FindChild("NeighborInviteLabel"):SetText(String_GetWeaselString(Apollo.GetString("Neighbors_InviteReceived"), strName))
	self.wndInvite:Show(true)
	self.wndInvite:ToFront()
end

function NeighborsList:OnNeighborInviteAccept(wndHandler, wndControl)
	HousingLib.NeighborInviteAccept()
	if self.wndInvite then
		self.wndInvite:Destroy()
	end
end

function NeighborsList:OnNeighborInviteDecline() -- This can come from a variety of sources
	HousingLib.NeighborInviteDecline()
	if self.wndInvite then
		self.wndInvite:Destroy()
	end
end

function NeighborsList:OnNeighborInviteAccepted(strName)
	if self.wndInvite then
		self.wndInvite:Destroy()
	end

	if self.wndMain:IsShown() then
		self:OnHousingResult(strName,  HousingLib.HousingResult_Neighbor_RequestAccepted)
	else
		local strMessage = Apollo.GetString("Neighbors_InviteAcceptedSelf")
		if string.len(strName) > 1 then
			strMessage = String_GetWeaselString(Apollo.GetString("Neighbors_InviteAccepted"), strName)
		end

		ChatSystemLib.PostOnChannel(ChatSystemLib.ChatChannel_System, strMessage, "")
	end
end

function NeighborsList:OnNeighborInviteDeclined(strName)
	if self.wndInvite then
		self.wndInvite:Destroy()
	end

	if self.wndMain:IsShown() then
		self:OnHousingResult(strName,  HousingLib.HousingResult_Neighbor_RequestDeclined)
	else
		local strMessage = Apollo.GetString("Neighbors_InvitationExpired")
		if string.len(strName) > 1 then
			strMessage = String_GetWeaselString(Apollo.GetString("Neighbors_RequestDeclined"), strName)
		end

		ChatSystemLib.PostOnChannel(ChatSystemLib.ChatChannel_System, strMessage, "")
	end
end



---------------------------------------------------------------------------------------------------
-- Random List Functions
---------------------------------------------------------------------------------------------------
function NeighborsList:ShowRandomList()
	local nWidth = self.wndRandomList:GetWidth()
	local nHeight = self.wndRandomList:GetHeight()
	local nLeft, nTop, nRight, nBottom = self.wndMain:GetAnchorOffsets()

	self.wndRandomList:SetAnchorOffsets(nRight - 15, nTop + 60, nRight + nWidth - 15, nTop + 60 + nHeight)

	--populate
	HousingLib.RequestRandomResidenceList()
	self.wndRandomList:FindChild("VisitRandomBtn"):Enable(false)
	self.wndRandomList:FindChild("ListContainer"):DestroyChildren()
	self.wndRandomList:Show(true)
end

function NeighborsList:OnRandomResidenceList()
	local arResidences = HousingLib.GetRandomResidenceList()

	for key, tHouse in pairs(arResidences) do
		local wnd = Apollo.LoadForm("NeighborsList.xml", "RandomFriendForm", self.wndRandomList:FindChild("ListContainer"), self)
		wnd:SetData(tHouse.nId) -- set the full table since we have no direct lookup for neighbors
		wnd:FindChild("PlayerName"):SetText(String_GetWeaselString(Apollo.GetString("Neighbors_OwnerListing"), tHouse.strCharacterName))
		wnd:FindChild("PropertyName"):SetText(tHouse.strResidenceName)
	end

	self.wndRandomList:FindChild("ListContainer"):ArrangeChildrenVert()
	self.wndRandomList:FindChild("VisitRandomBtn"):Enable(false)
end

function NeighborsList:OnRandomFriendClose()
	self.wndRandomList:Show(false)
end

function NeighborsList:OnVisitRandomBtn(wndHandler, wndControl)
	wndControl:FindChild("VisitWindow"):Show(true)
end

function NeighborsList:OnVisitRandomConfirmBtn(wndHandler, wndControl)
	local nId = wndControl:GetParent():GetData()
	HousingLib.RequestRandomVisit(nId)
	wndControl:GetParent():Show(false)
end

function NeighborsList:OnRandomFriendBtn(wndHandler, wndControl)
	local nId = wndControl:GetParent():GetData()

	for key, wndRandomNeighbor in pairs(self.wndRandomList:FindChild("ListContainer"):GetChildren()) do
		wndRandomNeighbor:FindChild("FriendBtn"):SetCheck(nId == wndRandomNeighbor:GetData())
	end

	self.wndRandomList:FindChild("VisitRandomBtn"):FindChild("VisitWindow"):SetData(nId)
	self.wndRandomList:FindChild("VisitRandomBtn"):Enable(true)
end

function NeighborsList:OnRandomFriendBtnUncheck(wndHandler, wndControl)
	self.wndRandomList:FindChild("VisitRandomBtn"):Enable(false)
end
-----------------------------------------------------------------------------------------------
-- NeighborsList Instance
-----------------------------------------------------------------------------------------------
local NeighborsListInst = NeighborsList:new()
NeighborsList:Init()




