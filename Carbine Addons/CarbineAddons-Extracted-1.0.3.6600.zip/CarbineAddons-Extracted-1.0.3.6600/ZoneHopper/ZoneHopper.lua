-----------------------------------------------------------------------------------------------
-- Client Lua Script for ZoneHopper
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "GameLib"

local ZoneHopper = {}
local changeFaction = 0
local goLoc = 0
local lastMajorZone = 0		-- Stores the key zones that players port to when changing maps (ie: Tremor Ridge = 51)

local toggleCheck = 0		-- Queries the user to make sure they're set up correct for the Malgrave Adventure
local zones = {}

function ZoneHopper:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self

    return o
end

function ZoneHopper:Init()
    Apollo.RegisterAddon(self)
end

-----------------------------------------------------------------------------------------------
-- ZoneHopper OnLoad
-----------------------------------------------------------------------------------------------
function ZoneHopper:OnLoad()
    Apollo.RegisterSlashCommand("zh", "OnZHOn", self)
	Apollo.RegisterEventHandler("SubZoneChanged", "ChangedZones", self)
	Apollo.RegisterTimerHandler("AutoSalvageHeirloomKitTimer", "OnAutoSalvageHeirloomKitTimer", self)
	Apollo.RegisterTimerHandler("OneSecTimer", "OnOneSecTimer", self)
	
	self.bInitialShow = false

    self.wndMain = Apollo.LoadForm("ZoneHopper.xml", "ZoneHopperForm", nil, self)

	self.wndMain:FindChild("bExiles"):SetData("Exiles");
	self.wndMain:FindChild("bDominion"):SetData("Dominion");
	self.wndMain:FindChild("bAdventure"):SetData("Adventure");
	self.wndMain:FindChild("bDungeon"):SetData("Dungeon");

	self.wndMain:FindChild("bTogEm"):SetCheck(true)
	self.wndMain:FindChild("bTogQuest"):SetCheck(true)

	self.wndMain:FindChild("bAdventure"):Show(false);	-- Turns off the adventure button
	self.wndMain:FindChild("TabsContainer"):ArrangeChildrenHorz(1)

	self:SetUpList()
	self.bNeedToSalvage = false
	self.wndMain:FindChild("TutorialText"):SetText(
		"1. Click a button to teleport to a zone. \n\n"..
		"2. Zone Hopper will also auto-level and give quests for each zone. This can be turned off with the toggle buttons. \n\n"..
		"3. You can also receive items for your level. Right click to equip these in your inventory (\'i\' key). \n\n"..
		"4. Use \'/zh\' to open Zone Hopper again. Note you'll receive different options as a Dominion or Exile character.")
		
end

function ZoneHopper:OnOneSecTimer()
	if self.bInitialShow == true then
		return 
	end

	if GameLib.GetPlayerUnit() == nil then
		return
	end
	
	local tInfo = GameLib.GetAccountRealmCharacter()
	if string.sub(tInfo.strAccount, 1, 3) == "zh_" then
		self:OnZHOn()
	else
		self.bInitialShow = true
	end
	
end

function ZoneHopper:OnZHOn()
	self.wndMain:Show(true)
	self.bInitialShow = true

	self.bInAZoneChange = false

	local nFaction = GameLib.GetPlayerUnit():GetFaction()
	if nFaction then
		self.wndMain:FindChild("bExiles"):Show(nFaction == Unit.CodeEnumFaction.ExilesPlayer)
		self.wndMain:FindChild("bDominion"):Show(nFaction == Unit.CodeEnumFaction.DominionPlayer)
		self.wndMain:FindChild("wndExiles"):Show(nFaction == Unit.CodeEnumFaction.ExilesPlayer)
		self.wndMain:FindChild("wndDominion"):Show(nFaction == Unit.CodeEnumFaction.DominionPlayer)
		self.wndMain:FindChild("TabsContainer"):ArrangeChildrenHorz(1)
	end
end

function ZoneHopper:OnCancel()	-- Minimize the addon
	self.wndMain:Show(false)
end

-----------------------------------------------------------------------------------------------
-- ZoneHopperForm Functions
-----------------------------------------------------------------------------------------------

function ZoneHopper:OnHeirloomBtn()
	Apollo.ParseInput("/c ci 13415")

	self.bNeedToSalvage = true
	Apollo.CreateTimer("AutoSalvageHeirloomKitTimer", 0.100, false)
	Apollo.StartTimer("AutoSalvageHeirloomKitTimer")
end

function ZoneHopper:OnAutoSalvageHeirloomKitTimer()
	Apollo.StopTimer("AutoSalvageHeirloomKitTimer")

	if self.bNeedToSalvage then
		for _, tCurr in pairs(GameLib.GetPlayerUnit():GetInventoryItems()) do
			if tCurr.itemInBag:GetItemId() and tCurr.itemInBag:GetItemId() == 13415 then
				self.wndMain:FindChild("HiddenBagWindow"):SalvageItem(tCurr.itemInBag:GetInventoryId())

				self.bNeedToSalvage = false
				return
			end
		end

		Apollo.CreateTimer("AutoSalvageHeirloomKitTimer", 1.000, false)
		Apollo.StartTimer("AutoSalvageHeirloomKitTimer")
	end
end

function ZoneHopper:ChangedZones(idZone, pszZoneName)
	if changeFaction=="Exile" then		-- Exile
		Apollo.ParseInput("/c setfaction 167")
	elseif changeFaction=="Dominion" then	-- Dominion
		Apollo.ParseInput("/c setfaction 166")
	end
	changeFaction = 0

	if not (goLoc==0) then		-- If a port location was recorded from a button press then port there now
		if (goLoc=="start") then
			Apollo.ParseInput("/c go start")
		else
			Apollo.ParseInput("/c port "..goLoc)
		end
		goLoc = 0
	end

	-- Record the last zone that was entered upon arriving in a new map. This is how I keep track of what map players are in.
	if pszZoneName=="Tremor Ridge" or pszZoneName=="Settler's Reach" or pszZoneName=="Savage Coast" or pszZoneName=="Bloodfire Village" or "Sespine Point" then
		lastMajorZone = pszZoneName
	end

	self.bInAZoneChange = false
end

function ZoneHopper:changeLevels(lvl)
	if self.wndMain:FindChild("bTogEm"):IsChecked() then
		Apollo.ParseInput("/c lvl "..lvl)
	end
end

function ZoneHopper:getQuest(qId, nPhase)
	if self.wndMain:FindChild("bTogQuest"):IsChecked() then
		Apollo.ParseInput("/c qg "..qId)
		if nPhase then
			Apollo.ParseInput("/c setphase "..nPhase)
		end
	end
end

function ZoneHopper:displayZones(wndHandler, wndControl)	--Displays each of the four main windows depending on which button is clicked at the bottom of the UI
	local strData = wndControl:GetData()
	self.wndMain:FindChild("wndExiles"):Show(strData =="Exiles")
	self.wndMain:FindChild("wndDominion"):Show(strData =="Dominion")
	self.wndMain:FindChild("wndDungeon"):Show(strData =="Dungeon")
	self.wndMain:FindChild("wndAdventure"):Show(strData =="Adventure")
end

function ZoneHopper:goMap51()
	if not (lastMajorZone == "Tremor Ridge") then --If the last map you entered wasn't 51, then port to 51
		if not (changeFaction == "Dominion") then
			changeFaction = "Exile"
		end
		Apollo.ParseInput("/c gm 51")
	else
		Apollo.ParseInput("/c port "..goLoc)	-- Otherwise, you were already in 51, so just port somewhere in it
		goLoc = 0
	end
end

function ZoneHopper:goMap22()
	if not (lastMajorZone == "Bloodfire Village") then --If the last map you entered wasn't 22, then port to 22
		if not (changeFaction == "Exile") then
			changeFaction = "Dominion"
		end
		Apollo.ParseInput("/c gm 22")
	else
		Apollo.ParseInput("/c port "..goLoc)	-- Otherwise, you were already in 22, so just port somewhere in it
		goLoc = 0
	end
end

---------------------------------------------------------------------------------------------------
-- wndZone Functions
---------------------------------------------------------------------------------------------------

function ZoneHopper:SetUpList()
	--When adding a new zone, update the i for loop, increment by one and add a new section to handle each tract
	for i=0, 8 do		-- EXILE ZONES
		table.insert(zones, Apollo.LoadForm("ZoneHopper.xml", "wndZone", self.wndMain:FindChild("wndExiles"), self))
		if i==0 then	-- Northern Wilds
			zones[# zones]:FindChild("wndZone"):SetText("Northern Wilds")
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("bZoneT1"):SetData("NWT1")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This ports you to the start of Northern Wilds and levels you to 3")

			zones[# zones]:FindChild("bZoneT2"):SetData("NWT2")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This ports you to the entrance of the Skeech Camp and levels you to 5")

			zones[# zones]:FindChild("bZoneT3"):SetData("NWT3")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("This ports you to the start of Camp Icefury and levels you to 5")
		elseif i==1 then	-- Algoroc T1
			zones[# zones]:FindChild("wndZone"):SetText("Algoroc T1")
			zones[# zones]:FindChild("bZoneT1"):SetData("AlgorocT1A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This will take you to Tremor Ridge, the start of Algoroc tract 1 and level you to 6")

			zones[# zones]:FindChild("bZoneT2"):SetData("AlgorocT1B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This will take you to Coldwater Gulch and level you to 6")

			zones[# zones]:FindChild("bZoneT3"):SetData("AlgorocT1C")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("This takes you to the Pikefall Expedition. This is a public event and will scale with however many people are in the area. It can be done with just one person, but will take forever to complete it. Also levels you to 7")

			zones[# zones]:FindChild("bZoneT4"):SetData("AlgorocT1D")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("This takes you to the entrance of the Chua Cave. Make sure you check out the laser grid puzzle in the middle of the cave! Also level to 7")
		elseif i==2 then	-- Algoroc T3
			zones[# zones]:FindChild("wndZone"):SetText("Algoroc T3")
			zones[# zones]:FindChild("bZoneT1"):SetData("AlgorocT3A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This takes you to the Excavation Base Camp, the start of Algoroc tract 3 and levels you to 12")

			zones[# zones]:FindChild("bZoneT2"):SetData("AlgorocT3B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This takes you to the Exo-Lab and levels you to 12")

			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)
		elseif i==3 then	-- Galeras T1
			zones[# zones]:FindChild("wndZone"):SetText("Galeras T1")
			zones[# zones]:FindChild("bZoneT1"):SetData("GalerasT1A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This one will port you to Thayd. This is the start of Galeras tract 1 and levels you to 14")

			zones[# zones]:FindChild("bZoneT2"):SetData("GalerasT1B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This takes you to the Ravaged Front, the war-torn area just outside Thayd and levels you to 14")

			zones[# zones]:FindChild("bZoneT3"):SetData("GalerasT1C")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("This will take you to the start of Tempest Refuge and levels you to 14")

			zones[# zones]:FindChild("bZoneT4"):Show(false)
		elseif i==4 then	-- Galeras T3
			zones[# zones]:FindChild("wndZone"):SetText("Galeras T3")
			zones[# zones]:FindChild("bZoneT1"):SetData("GalerasT3A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This one takes you to Camp Dustdevil, the start of Galeras tract 3 and levels you to 18")

			zones[# zones]:FindChild("bZoneT2"):SetData("GalerasT3B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This one will port you to the XAS Forward Camp and level you to 18")

			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)
		elseif i==5 then	-- Galeras T4
			zones[# zones]:FindChild("wndZone"):SetText("Galeras T4")
			zones[# zones]:FindChild("bZoneT1"):SetData("GalerasT4A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This ports you to Skywatch, the start of Galeras tract 4, and levels you to 20")

			zones[# zones]:FindChild("bZoneT2"):SetData("GalerasT4B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This will take you to the start of the Temple of Osiric. Combat can get sketchy here for one person, so be cautious of pulls or put on God mode. Also levels you to 20")

			zones[# zones]:FindChild("bZoneT3"):SetData("GalerasT4C")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("This ports you to the beginning of Kel Vishal, the Falkrin temple, and levels you to 20")

			zones[# zones]:FindChild("bZoneT4"):Show(false)
		elseif i==6 then	-- Whitevale T1
			zones[# zones]:FindChild("wndZone"):SetText("Whitevale T1")
			zones[# zones]:FindChild("bZoneT1"):SetData("WhitevaleT1A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This will take you to Thermock Hold, the start of Whitevale tract 1. There is currently water missing from half of the lake, so might want to avoid going in that general area. Also levels you to 23")

			zones[# zones]:FindChild("bZoneT2"):SetData("WhitevaleT1B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This takes you to the Aurin area, Snowfade Grounds. You'll want to have sound turned on when you do the quest for Misty and Wiggles. Wiggles' sneezing is adorable. Also levels you to 24")

			zones[# zones]:FindChild("bZoneT3"):SetData("WhitevaleT1C")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("This will port you to the Gas n' Guzzle and level you to 24")

			zones[# zones]:FindChild("bZoneT4"):SetData("WhitevaleT1D")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("This takes you to the Freebot town of Locus Dawn and levels you to 24")
		elseif i==7 then	-- Whitevale T3
			zones[# zones]:FindChild("wndZone"):SetText("Whitevale T3")
			zones[# zones]:FindChild("bZoneT1"):SetData("WhitevaleT3A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This takes you to Wigwalli Village, the start of Whitevale tract 3, and levels you to 27")

			zones[# zones]:FindChild("bZoneT2"):SetData("WhitevaleT3B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This takes you to Raxen's Holdout, the start of the zombie area in Whitevale. Sometimes this area likes to lag, most likely because of all the spell effects. Also levels you to 28")

			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)
		elseif i==8 then	-- Whitevale T4
			zones[# zones]:FindChild("wndZone"):SetText("Whitevale T4")
			zones[# zones]:FindChild("bZoneT1"):SetData("WhitevaleT4A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This ports you to Prosperity Junction, the start of Whitevale tract 4, and levels you to 30")

			zones[# zones]:FindChild("bZoneT2"):SetData("WhitevaleT4B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This takes you to Calmwater Commune and levels you to 31")

			zones[# zones]:FindChild("bZoneT3"):SetData("WhitevaleT4C")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("This takes you to the start of Augment Facility X426, the exo-lab section of Whitevale Tract 4. The black sludge in this area will instant kill you, so steer clear. Also levels you to 31")

			zones[# zones]:FindChild("bZoneT4"):Show(false)
		end
	end
	for i=0, 3 do		-- DOMINION ZONES
		table.insert(zones, Apollo.LoadForm("ZoneHopper.xml", "wndZone", self.wndMain:FindChild("wndDominion"), self))
		if i==0 then	-- Crimson Isle
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("wndZone"):SetText("Crimson Isle")
			zones[# zones]:FindChild("bZoneT1"):SetData("CrimsonT1A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This will take you to the start of Crimson Isle and level you to 3")

			zones[# zones]:FindChild("bZoneT2"):SetData("CrimsonT1B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This will take you to Megatech, the last half of Crimson Isle. Also levels you to 5")
		elseif i==1 then	-- Levian Bay
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT4"):Show(false)

			zones[# zones]:FindChild("wndZone"):SetText("Levian Bay")
			zones[# zones]:FindChild("bZoneT1"):SetData("LevianT1A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This takes you to the start of Levian Bay and levels you to 3")

			zones[# zones]:FindChild("bZoneT2"):SetData("LevianT1B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This will port you to Star-Comm Station, the exo-lab area of Levian Bay. "
				.. "The fog here is pretty thick. You may want to turn the fog off in the console if you want to be able to see the entire station. Also levels you to 3")
		elseif i==2 then	-- Deradune T1
			zones[# zones]:FindChild("wndZone"):SetText("Deradune T1")
			zones[# zones]:FindChild("bZoneT1"):SetData("DeraduneT1A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This will port you to Bloodfire Village, the start of Deradune tract 1, and level you to 6")

			zones[# zones]:FindChild("bZoneT2"):SetData("DeraduneT1B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This will port you to the start of Deadwind Hollow, the Moodie area of Deradune tract 1, and level you to 6")

			zones[# zones]:FindChild("bZoneT3"):SetData("DeraduneT1C")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("This ports you to Jagged Rock, the beachfront Exile stronghold, and level you to 6")

			zones[# zones]:FindChild("bZoneT4"):SetData("DeraduneT1D")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("This ports you to Deradune's shiphand mission. These can be tricky for one person so you might want to turn on God mode. Also levels you to 8")
		elseif i==3 then	-- Deradune T2
			zones[# zones]:FindChild("wndZone"):SetText("Deradune T2")
			zones[# zones]:FindChild("bZoneT1"):SetData("DeraduneT2A")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("This will port you to Outreach Post, the start of Deradune tract 2, and level you to 8")

			zones[# zones]:FindChild("bZoneT2"):SetData("DeraduneT2B")
			zones[# zones]:FindChild("bZoneT2"):SetTooltip("This will port you to Feralplain Park and level you to 8")

			zones[# zones]:FindChild("bZoneT3"):SetData("DeraduneT2C")
			zones[# zones]:FindChild("bZoneT3"):SetTooltip("This will take you to Tall Rock Point, the start of the Falkrin area of Deradune tract 2, and level you to 10")

			zones[# zones]:FindChild("bZoneT4"):SetData("DeraduneT2D")
			zones[# zones]:FindChild("bZoneT4"):SetTooltip("This takes you to Wildwood Grove, the Aurin area of Deradune tract 2, and levels you to 10")
		end
	end
	for i=0, 1 do		-- DUNGEONS
		table.insert(zones, Apollo.LoadForm("ZoneHopper.xml", "wndZone", self.wndMain:FindChild("wndDungeon"), self))
		if i==0 then
			zones[# zones]:FindChild("wndZone"):SetText("Stormtalon's Lair")
			zones[# zones]:FindChild("bZoneT4"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):SetData("Stormtalon")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Stormtalon's Lair is tuned for 5 people. So if you go in solo you'll want to use God mode.")
		elseif i==1 then
			zones[# zones]:FindChild("wndZone"):SetText("Skullcano Island")
			zones[# zones]:FindChild("bZoneT4"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):SetData("Skullcano")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Skullcano is tuned for 5 people. So if you go in solo you'll want to use God mode.")
		end
	end
	for i=0, 3 do		-- ADVENTURES
		table.insert(zones, Apollo.LoadForm("ZoneHopper.xml", "wndZone", self.wndMain:FindChild("wndAdventure"), self))
		if i==0 then
			zones[# zones]:FindChild("wndZone"):SetText("Hycrest")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):SetData("AdvHycrest")
			zones[# zones]:FindChild("bZoneT4"):SetText("Start")
			zones[# zones]:FindChild("bZoneT4"):SetData("StartAdvHycrest")
		elseif i==1 then
			zones[# zones]:FindChild("wndZone"):SetText("Malgrave")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):SetData("AdvMalgrave")
			zones[# zones]:FindChild("bZoneT4"):SetText("Start")
			zones[# zones]:FindChild("bZoneT4"):SetData("StartAdvMalgrave")
		elseif i==2 then
			zones[# zones]:FindChild("wndZone"):SetText("Galeras")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):SetData("AdvGaleras")
			zones[# zones]:FindChild("bZoneT4"):SetText("Start")
			zones[# zones]:FindChild("bZoneT4"):SetData("StartAdvGaleras")
		elseif i==3 then
			zones[# zones]:FindChild("wndZone"):SetText("Whitevale")
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):SetData("AdvWhitevale")
			zones[# zones]:FindChild("bZoneT4"):SetText("Start")
			zones[# zones]:FindChild("bZoneT4"):SetData("StartAdvWhitevale")
		end
	end
	for i=9, 10 do		-- DUNGEONS into Exiles and Dominions (TEMP)
		table.insert(zones, Apollo.LoadForm("ZoneHopper.xml", "wndZone", self.wndMain:FindChild("wndExiles"), self))
		if i==9 then
			zones[# zones]:FindChild("wndZone"):SetText("Stormtalon's Lair")
			zones[# zones]:FindChild("bZoneT4"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):SetData("Stormtalon")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Stormtalon's Lair is tuned for 5 people. So if you go in solo you'll want to use God mode.")
		elseif i==10 then
			zones[# zones]:FindChild("wndZone"):SetText("Skullcano Island")
			zones[# zones]:FindChild("bZoneT4"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):SetData("Skullcano")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Skullcano is tuned for 5 people. So if you go in solo you'll want to use God mode.")
		end

		table.insert(zones, Apollo.LoadForm("ZoneHopper.xml", "wndZone", self.wndMain:FindChild("wndDominion"), self))
		if i==9 then
			zones[# zones]:FindChild("wndZone"):SetText("Stormtalon's Lair")
			zones[# zones]:FindChild("bZoneT4"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):SetData("Stormtalon")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Stormtalon's Lair is tuned for 5 people. So if you go in solo you'll want to use God mode.")
		elseif i==10 then
			zones[# zones]:FindChild("wndZone"):SetText("Skullcano Island")
			zones[# zones]:FindChild("bZoneT4"):Show(false)
			zones[# zones]:FindChild("bZoneT2"):Show(false)
			zones[# zones]:FindChild("bZoneT3"):Show(false)
			zones[# zones]:FindChild("bZoneT1"):SetData("Skullcano")
			zones[# zones]:FindChild("bZoneT1"):SetTooltip("Skullcano is tuned for 5 people. So if you go in solo you'll want to use God mode.")
		end
	end

	self.wndMain:FindChild("wndExiles"):ArrangeChildrenVert(0)
	self.wndMain:FindChild("wndDominion"):ArrangeChildrenVert(0)
	self.wndMain:FindChild("wndDungeon"):ArrangeChildrenVert(0)
	self.wndMain:FindChild("wndAdventure"):ArrangeChildrenVert(0)
end

function ZoneHopper:goZone( wndHandler, wndControl, eMouseButton )
	--if self.bInAZoneChange then return end -- TEMP disabled

														-- EXILES *********************************
	if wndControl:GetData()=="NWT1" then				-- Northern Wilds - Start
		changeFaction = "Exile"
		self:changeLevels(3)
		goLoc = "3911.21 -699.89 -5330.62 -24.95"
		Apollo.ParseInput("/c gm 426")
	elseif wndControl:GetData()=="NWT2" then			-- Northern Wilds - Skeech Camp
		changeFaction = "Exile"
		self:changeLevels(4)
		goLoc = "4614.40 -719.23 -5644.10 -75.14"
		Apollo.ParseInput("/c qc 3486")
		Apollo.ParseInput("/c setphase 2")
		self:getQuest(3668)
		Apollo.ParseInput("/c gm 426")
	elseif wndControl:GetData()=="NWT3" then			-- Northern Wilds - Camp Icefury
		changeFaction = "Exile"
		self:changeLevels(5)
		goLoc = "4484.15 -720.89 -5348.95 -158.38"
		Apollo.ParseInput("/c qc 3486")
		Apollo.ParseInput("/c qc 3673")
		Apollo.ParseInput("/c gm 426")
	elseif wndControl:GetData()=="AlgorocT1A" then		-- Algoroc T1- Start
		self:changeLevels(6)
		goLoc = "3828.85 -996.68 -4483.92 -17.16"
		self:goMap51()
	elseif wndControl:GetData()=="AlgorocT1B" then		-- Algoroc T1- Coldwater Gulch
		self:changeLevels(6)
		goLoc = "3362.85 -816.07 -4887.40 80.70"
		self:goMap51()
	elseif wndControl:GetData()=="AlgorocT1C" then		-- Algoroc T1- Pikefall Expedition (Public Event)
		self:changeLevels(7)
		goLoc = "2960.53 -970.50 -3832.82 -57.72"
		self:goMap51()
	elseif wndControl:GetData()=="AlgorocT1D" then		-- Algoroc T1- Chua Cave
		self:changeLevels(7)
		goLoc = "3557.36 -1019.22 -3800.94 166.60"
		self:getQuest(3765)
		self:goMap51()
	elseif wndControl:GetData()=="AlgorocT3A" then		-- Algoroc T3- Start
		self:changeLevels(12)
		goLoc = "4422.04 -1105.13 -3936.69 -156.00"
		self:goMap51()
	elseif wndControl:GetData()=="AlgorocT3B" then		-- Algoroc T3- Exo Lab
		self:changeLevels(12)
		goLoc = "4893.56 -1222.27 -4227.72 -95.04"
		self:getQuest(4853)
		self:goMap51()
	elseif wndControl:GetData()=="GalerasT1A" then		-- Galeras T1 - Thayd
		self:changeLevels(14)
		goLoc = "4101.77 -803.21 -2349.14 -126.32"
		self:goMap51()
	elseif wndControl:GetData()=="GalerasT1B" then		-- Galeras T1 - Ravaged Front
		self:changeLevels(14)
		goLoc = "4595.23 -846.86 -2339.29 -54.24"
		self:getQuest(4967)
		self:goMap51()
	elseif wndControl:GetData()=="GalerasT1C" then		-- Galeras T1 - Tempest Refuge
		self:changeLevels(14)
		goLoc = "5169.24 -883.09 -2287.48 -39.62"
		self:goMap51()
	elseif wndControl:GetData()=="GalerasT3A" then		-- Galeras T3 - Start
		self:changeLevels(18)
		goLoc = "5387.98 -996.34 -2772.92 -0.05"
		self:goMap51()
	elseif wndControl:GetData()=="GalerasT3B" then		-- Galeras T3 - XAS Forward Camp
		self:changeLevels(18)
		goLoc = "5612.59 -1012.67 -2430.34 -0.72"
		self:goMap51()
	elseif wndControl:GetData()=="GalerasT4A" then		-- Galeras T4 - Start
		self:changeLevels(20)
		goLoc = "5753.92 -868.84 -2536.53 -154.69"
		self:goMap51()
	elseif wndControl:GetData()=="GalerasT4B" then		-- Galeras T4 - Temple of Osiric
		self:changeLevels(20)
		goLoc = "6110.73 -876.12 -2938.88 -113.20"
		self:getQuest(4666)
		self:goMap51()
	elseif wndControl:GetData()=="GalerasT4C" then		-- Galeras T4 - Kel Vishal
		self:changeLevels(20)
		goLoc = "5962.26 -887.49 -2119.83 144.62"
		Apollo.ParseInput("/c qg 5324")
		self:getQuest(5325)
		self:goMap51()
	elseif wndControl:GetData()=="WhitevaleT1A" then	-- Whitevale T1 - Start
		self:changeLevels(23)
		goLoc = "4496.42 -936.95 -575.72 -51.24"
		self:goMap51()
	elseif wndControl:GetData()=="WhitevaleT1B" then	-- Whitevale T1 - Snowfade Grounds
		self:changeLevels(24)
		goLoc = "5217.85 -970.70 -74.64 -23.79"
		self:goMap51()
	elseif wndControl:GetData()=="WhitevaleT1C" then	-- Whitevale T1 - Gas n' Guzzle
		self:changeLevels(24)
		goLoc = "5360.15 -851.21 -1262.84 108.70"
		self:goMap51()
	elseif wndControl:GetData()=="WhitevaleT1D" then	-- Whitevale T1 - Locus Dawn
		self:changeLevels(24)
		goLoc = "5850.37 -943.54 -1084.53 -69.32"
		self:goMap51()
	elseif wndControl:GetData()=="WhitevaleT3A" then	-- Whitevale T3 - Start
		self:changeLevels(27)
		goLoc = "3472.37 -943.62 -434.92 43.64"
		self:goMap51()
	elseif wndControl:GetData()=="WhitevaleT3B" then	-- Whitevale T3 - Raxen's Holdout
		self:changeLevels(28)
		goLoc = "3900.76 -960.80 31.61 60.37"
		self:goMap51()
	elseif wndControl:GetData()=="WhitevaleT4A" then	-- Whitevale T4 - Start
		self:changeLevels(30)
		goLoc = "3090.42 -1031.10 772.00 -124.58"
		self:goMap51()
	elseif wndControl:GetData()=="WhitevaleT4B" then	-- Whitevale T4 - Calmwater Commune
		self:changeLevels(31)
		goLoc = "2671.19 -1073.20 1208.22 118.59"
		self:goMap51()
	elseif wndControl:GetData()=="WhitevaleT4C" then	-- Whitevale T4 - Augment Facility
		self:changeLevels(31)
		goLoc = "2428.47 -1039.12 443.17 -42.81"
		self:getQuest(5947)
		self:goMap51()											-- DOMINION **********************************
	elseif wndControl:GetData()=="CrimsonT1A" then				-- Crimson Isle - Start
		changeFaction = "Dominion"
		self:changeLevels(3)
		goLoc = "-7665.67 -991.88 18.18 -26.28"
		self:getQuest(5595)
		Apollo.ParseInput("/c gm 870")
	elseif wndControl:GetData()=="CrimsonT1B" then				-- Crimson Isle - Megatech
		changeFaction = "Dominion"
		self:changeLevels(5)
		goLoc = "-7249.89 -985.45 -1100.07 61.85"
		self:getQuest(5604)
		Apollo.ParseInput("/c gm 870")
	elseif wndControl:GetData()=="LevianT1A" then				-- Levian Bay - Start
		changeFaction = "Dominion"
		self:changeLevels(3)
		Apollo.ParseInput("/c gm 1387")
	elseif wndControl:GetData()=="LevianT1B" then				-- Levian Bay - Star-Comm Station
		changeFaction = "Dominion"
		self:changeLevels(3)
		goLoc = "-3019.90 -959.10 -6073.39 -121.47"
		Apollo.ParseInput("/c gm 1387")
	elseif wndControl:GetData()=="DeraduneT1A" then				-- Deradune T1 - Start
		self:changeLevels(6)
		self:goMap22()
	elseif wndControl:GetData()=="DeraduneT1B" then				-- Deradune T1 - Moodies
		self:changeLevels(6)
		goLoc = "-5484.92 -967.01 -1079.21 1.90"
		self:getQuest(3316)
		self:goMap22()
	elseif wndControl:GetData()=="DeraduneT1C" then				-- Deradune T1 - Jagged Rock
		self:changeLevels(6)
		goLoc = "-5531.71 -980.52 -166.73 106.12"
		self:getQuest(5943)
		self:goMap22()
	elseif wndControl:GetData()=="DeraduneT1D" then				-- Deradune T1 - Shiphand Mission
		self:changeLevels(8)
		goLoc = "-5652.30 -981.12 -830.63 112.78"
		self:goMap22()
	elseif wndControl:GetData()=="DeraduneT2A" then				-- Deradune T2 - Start
		self:changeLevels(8)
		goLoc = "-5089.52 -944.55 -1551.12 53.49"
		self:goMap22()
	elseif wndControl:GetData()=="DeraduneT2B" then				-- Deradune T2 - Feralplain Park
		self:changeLevels(8)
		goLoc = "-4856.49 -945.16 -1202.99 -109.55"
		self:goMap22()
	elseif wndControl:GetData()=="DeraduneT2C" then				-- Deradune T2 - Falkrin Diplomacy
		self:changeLevels(10)
		goLoc = "-4715.86 -910.25 -1545.34 -37.21"
		self:getQuest(5509)
		self:goMap22()
	elseif wndControl:GetData()=="DeraduneT2D" then				-- Deradune T2 - Wildwood Grove
		self:changeLevels(10)
		goLoc = "-4484.02 -939.27 -974.88 -126.28"
		self:getQuest(5633)
		self:goMap22()
	elseif wndControl:GetData()=="Stormtalon" then				-- DUNGEONS ***********************************
		self:changeLevels(18)
		Apollo.ParseInput("/c gm 382")
	elseif wndControl:GetData()=="Skullcano" then
		self:changeLevels(35)
		Apollo.ParseInput("/c gm 1263")
	elseif wndControl:GetData()=="AdvHycrest" then				-- ADVENTURES *********************************
		self:changeLevels(12)											-- Hycrest Adventure
		Apollo.ParseInput("/c cm 18343")
	elseif wndControl:GetData()=="AdvMalgrave" then						-- Malgrave Adventure
		if (toggleCheck==0) then
			toggleCheck = 1
		else
			self:changeLevels(55)
			goLoc = "start"
			Apollo.ParseInput("/c ci 12877")
			Apollo.ParseInput("/c gm 1181 1000")
		end
	elseif wndControl:GetData()=="StartAdvMalgrave" then
		Apollo.ParseInput("/c sigw 7425")
	elseif wndControl:GetData()=="AdvGaleras" then						-- Galeras Adventure
		self:changeLevels(30)
		goLoc = "start"
		Apollo.ParseInput("/c ci 13109")
		Apollo.ParseInput("/c gm 1233 1000")
	elseif wndControl:GetData()=="StartAdvGaleras" then
		Apollo.ParseInput("/c sigw 8043")
	elseif wndControl:GetData()=="AdvWhitevale" then
		self:changeLevels(40)
		goLoc = "4327.07 -943.53 173.47 -44.05"
		Apollo.ParseInput("/c ci 13589")
		Apollo.ParseInput("/c gm 1323 1000")
	elseif wndControl:GetData()=="StartAdvWhitevale" then
		Apollo.ParseInput("/c sigw 8625")
	else
		self.bInAZoneChange = false
		return
	end

	self.bInAZoneChange = true
end

-----------------------------------------------------------------------------------------------
-- ZoneHopper Instance
-----------------------------------------------------------------------------------------------
local ZoneHopperInst = ZoneHopper:new()
ZoneHopperInst:Init()
