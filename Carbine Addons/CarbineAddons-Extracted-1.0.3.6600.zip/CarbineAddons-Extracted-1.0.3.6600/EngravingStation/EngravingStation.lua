-----------------------------------------------------------------------------------------------
-- Client Lua Script for EngravingStation
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "CraftingLib"
require "GameLib"
require "Item"

-- TODO: Delete string EngravingStation_AvailableRune

local knTEMPLargeCreateSize = 94
local knTEMPSmallCreateRuneSize = 48

local karEvalColors =
{
	[Item.CodeEnumItemQuality.Inferior] 		= "ItemQuality_Inferior",
	[Item.CodeEnumItemQuality.Average] 			= "ItemQuality_Average",
	[Item.CodeEnumItemQuality.Good] 			= "ItemQuality_Good",
	[Item.CodeEnumItemQuality.Excellent] 		= "ItemQuality_Excellent",
	[Item.CodeEnumItemQuality.Superb] 			= "ItemQuality_Superb",
	[Item.CodeEnumItemQuality.Legendary] 		= "ItemQuality_Legendary",
	[Item.CodeEnumItemQuality.Artifact]		 	= "ItemQuality_Artifact"
}

local karSigilElementsToSprite =
{
	[Item.CodeEnumSigilType.Air]		= "ClientSprites:Icon_Windows_UI_CRB_Tooltip_Air",
	[Item.CodeEnumSigilType.Fire]		= "ClientSprites:Icon_Windows_UI_CRB_Tooltip_Fire",
	[Item.CodeEnumSigilType.Water]		= "ClientSprites:Icon_Windows_UI_CRB_Tooltip_Water",
	[Item.CodeEnumSigilType.Earth]		= "ClientSprites:Icon_Windows_UI_CRB_Tooltip_Earth",
	[Item.CodeEnumSigilType.Logic]		= "ClientSprites:Icon_Windows_UI_CRB_Tooltip_Logic",
	[Item.CodeEnumSigilType.Life]		= "ClientSprites:Icon_Windows_UI_CRB_Tooltip_Life",
	[Item.CodeEnumSigilType.Fusion]		= "ClientSprites:Icon_Windows_UI_CRB_Tooltip_Fusion",
	[Item.CodeEnumSigilType.Omni]		= "ClientSprites:Icon_Windows_UI_CRB_Tooltip_Omni",
	--[Item.CodeEnumSigilType.Shadow]	= "ClientSprites:Icon_Windows_UI_CRB_Tooltip_Shadow",
}

local karAttributesToSprite =
{
	[Unit.CodeEnumProperties.Dexterity] 					= "Icon_Windows_UI_CRB_Attribute_Finesse",
	[Unit.CodeEnumProperties.Technology] 					= "Icon_Windows_UI_CRB_Attribute_Technology",
	[Unit.CodeEnumProperties.Magic] 						= "Icon_Windows_UI_CRB_Attribute_Moxie",
	[Unit.CodeEnumProperties.Wisdom] 						= "Icon_Windows_UI_CRB_Attribute_Insight",
	[Unit.CodeEnumProperties.Stamina] 						= "Icon_Windows_UI_CRB_Attribute_Grit",
	[Unit.CodeEnumProperties.Strength] 						= "Icon_Windows_UI_CRB_Attribute_BruteForce",

	[Unit.CodeEnumProperties.Armor] 						= "ClientSprites:Icon_Mission_Soldier_Swat",
	[Unit.CodeEnumProperties.ShieldCapacityMax] 			= "ClientSprites:Icon_Windows_UI_CRB_Tooltip_Omni",

	[Unit.CodeEnumProperties.AssaultPower] 					= "Icon_Windows_UI_CRB_Attribute_AssaultPower",
	[Unit.CodeEnumProperties.SupportPower] 					= "Icon_Windows_UI_CRB_Attribute_SupportPower",
	[Unit.CodeEnumProperties.Rating_AvoidReduce] 			= "Icon_Windows_UI_CRB_Attribute_Strikethrough",
	[Unit.CodeEnumProperties.Rating_CritChanceIncrease] 	= "Icon_Windows_UI_CRB_Attribute_CriticalHit",
	[Unit.CodeEnumProperties.RatingCritSeverityIncrease] 	= "Icon_Windows_UI_CRB_Attribute_CriticalSeverity",
	[Unit.CodeEnumProperties.Rating_AvoidIncrease] 			= "Icon_Windows_UI_CRB_Attribute_Deflect",
	[Unit.CodeEnumProperties.Rating_CritChanceDecrease] 	= "Icon_Windows_UI_CRB_Attribute_DeflectCritical",
	[Unit.CodeEnumProperties.ManaPerFiveSeconds] 			= "Icon_Windows_UI_CRB_Attribute_Recovery",
	[Unit.CodeEnumProperties.HealthRegenMultiplier] 		= "Icon_Windows_UI_CRB_Attribute_Recovery",
	[Unit.CodeEnumProperties.BaseHealth] 					= "Icon_Windows_UI_CRB_Attribute_Health",
}

local ktAttributeToText =
{
	[Unit.CodeEnumProperties.Dexterity] 					= Apollo.GetString("CRB_Finesse"),
	[Unit.CodeEnumProperties.Technology] 					= Apollo.GetString("CRB_Tech_Attribute"),
	[Unit.CodeEnumProperties.Magic] 						= Apollo.GetString("CRB_Moxie"),
	[Unit.CodeEnumProperties.Wisdom] 						= Apollo.GetString("UnitPropertyInsight"),
	[Unit.CodeEnumProperties.Stamina] 						= Apollo.GetString("CRB_Grit"),
	[Unit.CodeEnumProperties.Strength] 						= Apollo.GetString("CRB_Brutality"),

	[Unit.CodeEnumProperties.Armor] 						= Apollo.GetString("CRB_Armor") ,
	[Unit.CodeEnumProperties.ShieldCapacityMax] 			= Apollo.GetString("CBCrafting_Shields"),

	[Unit.CodeEnumProperties.AssaultPower] 					= Apollo.GetString("CRB_Assault_Power"),
	[Unit.CodeEnumProperties.SupportPower] 					= Apollo.GetString("CRB_Support_Power"),
	[Unit.CodeEnumProperties.Rating_AvoidReduce] 			= Apollo.GetString("CRB_Strikethrough_Rating"),
	[Unit.CodeEnumProperties.Rating_CritChanceIncrease] 	= Apollo.GetString("CRB_Critical_Chance"),
	[Unit.CodeEnumProperties.RatingCritSeverityIncrease] 	= Apollo.GetString("CRB_Critical_Severity"),
	[Unit.CodeEnumProperties.Rating_AvoidIncrease] 			= Apollo.GetString("CRB_Deflect_Rating"),
	[Unit.CodeEnumProperties.Rating_CritChanceDecrease] 	= Apollo.GetString("CRB_Deflect_Critical_Hit_Rating"),
	[Unit.CodeEnumProperties.ManaPerFiveSeconds] 			= Apollo.GetString("CRB_Attribute_Recovery_Rating"),
	[Unit.CodeEnumProperties.HealthRegenMultiplier] 		= Apollo.GetString("CRB_Health_Regen_Factor"),
	[Unit.CodeEnumProperties.BaseHealth] 					= Apollo.GetString("CRB_Health_Max"),
}

local kstrLineBreak = "<P Font=\"CRB_InterfaceLarge_B\" TextColor=\"0\">.</P>" -- TODO TEMP HACK

local EngravingStation = {}

function EngravingStation:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function EngravingStation:Init()
    Apollo.RegisterAddon(self)
end

function EngravingStation:OnLoad()
	--[[ DEPRECATED: Replaced with \UI\Runecrafting
	Apollo.RegisterEventHandler("TradeskillEngravingStationClose", 		"OnClose", self)
	Apollo.RegisterEventHandler("TradeskillEngravingStationOpen", 		"OnTradeskillEngravingStationOpen", self)
	Apollo.RegisterEventHandler("TradeSkillSigilResult", 				"OnTradeSkillSigilResult", self)
	Apollo.RegisterEventHandler("PlayerCurrencyChanged",				"OnPlayerCurrencyChanged", self)
	Apollo.RegisterEventHandler("PlayerEquippedItemChanged", 			"OnRedrawAllFromCode", self)
	Apollo.RegisterEventHandler("UpdateInventory", 						"OnRedrawAllFromCode", self)
	Apollo.RegisterEventHandler("ItemModified", 						"OnRedrawAllFromCode", self)

	Apollo.RegisterEventHandler("DragDropSysBegin", 					"OnSystemBeginDragDrop", self)
	Apollo.RegisterEventHandler("DragDropSysEnd", 						"OnSystemEndDragDrop", self)
	]]--
end

function EngravingStation:Initialize()
	if self.wndMain and self.wndMain:IsValid() then
		return
	end

	self.xmlDoc = XmlDoc.CreateFromFile("EngravingStation.xml") -- EngravingStation will always be kept in memory, to save parsing it over and over
    self.wndMain = Apollo.LoadForm(self.xmlDoc, "EngravingStationForm", nil, self)
	self.wndMain:FindChild("CreateFilterElement"):SetCheck(true)
	self.wndMain:FindChild("HeaderEquippedBtn"):SetCheck(true)
	self.wndSets = nil

	local wndMeasure = Apollo.LoadForm(self.xmlDoc, "SigilSlot", nil, self)
	self.knSigilSlotHeight = wndMeasure:GetHeight()
	wndMeasure:Destroy()

	self.bDragging = false
	self.itemDragging = nil
	self.bShowOnlyCraftable = true
	self.wndCurrentConfirmPopup = nil

	--Event_FireGenericEvent("GenericEvent_OpenRunecraftingForm", self.wndMain:FindChild("RuneCreationParent"))
	self:OnPlayerCurrencyChanged()
end

function EngravingStation:OnClose(wndHandler, wndControl)
	if self.wndMain and self.wndMain:IsValid() then
		self.wndMain:Destroy()
	end
	if self.wndSets and self.wndSets:IsValid() then
		self.wndSets:Destroy()
	end
	Event_CancelEngravingStation()
end

function EngravingStation:OnSetsClose(wndHandler, wndControl)
	if self.wndSets and self.wndSets:IsValid() then
		self.wndSets:Destroy()
	end
end

function EngravingStation:OnTradeskillEngravingStationOpen()
	self:Initialize()
	self:RedrawAll()
end

function EngravingStation:OnRedrawAllFromCode()
	if self.wndMain and self.wndMain:IsValid() and self.wndMain:IsVisible() then
		self:RedrawAll()
	end
end

function EngravingStation:OnRedrawAndShowToggle(wndHandler, wndControl)
	self.bShowOnlyCraftable = not self.bShowOnlyCraftable
	self.wndMain:FindChild("RuneCreationListItem"):DestroyChildren()
	self:RedrawAll()
end

function EngravingStation:OnPlayerCurrencyChanged()
	if self.wndMain and self.wndMain:IsValid() then
		self.wndMain:FindChild("BGFooter:PlayerCashContainer:PlayerCashWindow"):SetAmount(GameLib.GetPlayerCurrency())
	end
end

-----------------------------------------------------------------------------------------------
-- Main Draw Method
-----------------------------------------------------------------------------------------------

function EngravingStation:RedrawAll()
	-- Glyphable Items (Armor, Swords, etc.)
	local nVScrollPos = self.wndMain:FindChild("MainItemList"):GetVScrollPos()
	self.wndMain:FindChild("MainItemList"):DestroyChildren()
	for idx, tCurrItem in pairs(CraftingLib.GetValidGlyphableItems(self.wndMain:FindChild("HeaderEquippedBtn"):IsChecked(), self.wndMain:FindChild("HeaderBagBtn"):IsChecked())) do
		self:NewEquipmentItem(tCurrItem)
	end
	self.wndMain:FindChild("MainItemList"):ArrangeChildrenVert(0)
	self.wndMain:FindChild("MainItemList"):SetVScrollPos(nVScrollPos)
	self.wndMain:FindChild("MainItemList"):RecalculateContentExtents()
	self.wndMain:FindChild("MainItemList"):SetText(#self.wndMain:FindChild("MainItemList"):GetChildren() == 0 and Apollo.GetString("EngravingStation_NoInscribableItems") or "")

	-- Current Inventory
	local tCurrentGlyphsInBag = {}
	for idx, itemGlyph in pairs(CraftingLib.GetValidGlyphItems()) do
		tCurrentGlyphsInBag[itemGlyph:GetName()] = itemGlyph
	end

	-- Create a Rune
	local wndCreateARuneParent = self.wndMain:FindChild("RuneCreationListItem")
	local tSchematicList = CraftingLib.GetSchematicList(CraftingLib.CodeEnumTradeskill.Runecrafting, nil, nil, false)
	for idx, tCurrSchematic in pairs(tSchematicList) do
		local tSchematicInfo = CraftingLib.GetSchematicInfo(tCurrSchematic.nSchematicId)
		local tItemGlyphInfo = tSchematicInfo.itemOutput:GetGlyphInfo()
		local wndCurr = self:LoadByName("NewRuneItem", wndCreateARuneParent, "NewRuneItem"..tCurrSchematic.nSchematicId)

		-- Materials
		local bHasMaterials = true
		wndCurr:FindChild("NewRuneItemRawMaterialsList"):DestroyChildren()
		for idx2, tData in pairs(tSchematicInfo.tMaterials) do
			if tData.nAmount > tData.itemMaterial:GetBackpackCount() then
				bHasMaterials = false
				if not wndCurr:FindChild("NewRuneMoreInfoBtn"):IsChecked() then
					break
				end
			end

			if wndCurr:FindChild("NewRuneMoreInfoBtn"):IsChecked() then
				local wndMaterial = self:LoadByName("RawMaterialsItem", wndCurr:FindChild("NewRuneItemRawMaterialsList"), "RawMaterialsItem"..tData.itemMaterial:GetName())
				wndMaterial:FindChild("RawMaterialsIcon"):SetSprite(tData.itemMaterial:GetIcon())
				wndMaterial:FindChild("RawMaterialsIcon"):SetText(String_GetWeaselString(Apollo.GetString("CRB_NOutOfN"), tData.itemMaterial:GetBackpackCount(), tData.nAmount))
				wndMaterial:FindChild("RawMaterialsNotEnough"):Show(tData.nAmount > tData.itemMaterial:GetBackpackCount())
				Tooltip.GetItemTooltipForm(self, wndMaterial, tData.itemMaterial, {bSelling = false})
			end
		end
		wndCurr:FindChild("NewRuneItemRawMaterialsList"):ArrangeChildrenHorz(2)

		-- Continue only if valid -- TODO REFACTOR
		if self.bShowOnlyCraftable and not bHasMaterials and not tCurrentGlyphsInBag[tCurrSchematic.strName] then
			wndCurr:Destroy()
		else
			-- Formatting
			wndCurr:FindChild("NewRuneMoreInfoBtn"):SetData({ wndCurr, tSchematicInfo })
			wndCurr:FindChild("NewRuneItemCraftBtn"):Enable(bHasMaterials)
			wndCurr:FindChild("NewRuneItemCraftBtn"):SetData(tCurrSchematic.nSchematicId)
			wndCurr:FindChild("NewRuneMoreInfoName"):SetText(tCurrSchematic.strName)
			wndCurr:FindChild("NewRuneMoreInfoName"):SetTextColor(bHasMaterials and "UI_TextMetalGoldHighlight" or "AddonError")
			wndCurr:FindChild("NewRuneMoreIcon1"):SetSprite(tSchematicInfo.itemOutput:GetIcon())
			wndCurr:FindChild("NewRuneMoreIcon2"):SetSprite(karAttributesToSprite[tItemGlyphInfo.idUnitProperty] or "Icon_Windows_UI_CRB_Attribute_Grit")
			self:HelperBuildItemTooltip(wndCurr:FindChild("NewRuneMoreIcon1"), tSchematicInfo.itemOutput)

			-- Attach Bag Item
			if tCurrentGlyphsInBag[tCurrSchematic.strName] then
				local itemGlyph = tCurrentGlyphsInBag[tCurrSchematic.strName]
				wndCurr:FindChild("NewRuneMoreIcon1"):SetText(itemGlyph:GetBackpackCount() or "")
				--[[ TODO: Delete, also see if we're still using drag drop code
				local itemGlyph = tCurrentGlyphsInBag[tCurrSchematic.strName]
				local wndGlyph = self:LoadByName("GlyphBagItem", wndCurr, "GlyphBagItem"..itemGlyph:GetName())
				wndGlyph:FindChild("GlyphBagDrag"):SetData(itemGlyph)
				wndGlyph:FindChild("GlyphBagIcon"):SetSprite(itemGlyph:GetIcon())
				wndGlyph:FindChild("GlyphBagIcon"):SetText(itemGlyph:GetBackpackCount())
				self:HelperBuildItemTooltip(wndGlyph, itemGlyph)
				]]--
			end

			-- For sorting
			if self.wndMain:FindChild("CreateFilterSet"):IsChecked() then
				wndCurr:SetData(tCurrSchematic.strName)
			elseif self.wndMain:FindChild("CreateFilterStat"):IsChecked() then
				wndCurr:SetData(tostring(tItemGlyphInfo.idUnitProperty))
			elseif self.wndMain:FindChild("CreateFilterElement"):IsChecked() then
				wndCurr:SetData(karSigilElementsToSprite[tItemGlyphInfo.eType])
			end
		end
	end

	if self.bShowOnlyCraftable then
		local wndSwapBtn = self:LoadByName("RedrawAndShowAll", wndCreateARuneParent, "RedrawAndShowAll")
		wndSwapBtn:SetData("") -- for sorting
	else
		local wndSwapBtn =  self:LoadByName("RedrawAndShowCraftable", wndCreateARuneParent, "RedrawAndShowCraftable")
		wndSwapBtn:SetData("") -- for sorting
	end
	wndCreateARuneParent:ArrangeChildrenVert(0, function(a,b) return a:GetData() > b:GetData() end)
end

function EngravingStation:OnNewRuneMoreInfoCheck(wndHandler, wndControl) -- NewRuneMoreInfoBtn, data is { NewRuneItem, tSchematicInfo }
	local wndParent = wndHandler:GetData()[1]
	local tSchematicInfo = wndHandler:GetData()[2]
	local nLeft, nTop, nRight, nBottom = wndParent:GetAnchorOffsets()
	wndParent:SetAnchorOffsets(nLeft, nTop, nRight, nTop + knTEMPLargeCreateSize)
	self.wndMain:FindChild("RuneCreationListItem"):ArrangeChildrenVert(0, function(a,b) return a:GetData() > b:GetData() end)

	for idx2, tData in pairs(tSchematicInfo.tMaterials) do
		if wndParent:FindChild("NewRuneMoreInfoBtn"):IsChecked() then
			local wndMaterial = self:LoadByName("RawMaterialsItem", wndParent:FindChild("NewRuneItemRawMaterialsList"), "RawMaterialsItem"..tData.itemMaterial:GetName())
			wndMaterial:FindChild("RawMaterialsIcon"):SetSprite(tData.itemMaterial:GetIcon())
			wndMaterial:FindChild("RawMaterialsIcon"):SetText(String_GetWeaselString(Apollo.GetString("CRB_NOutOfN"), tData.itemMaterial:GetBackpackCount(), tData.nAmount))
			wndMaterial:FindChild("RawMaterialsNotEnough"):Show(tData.nAmount > tData.itemMaterial:GetBackpackCount())
			Tooltip.GetItemTooltipForm(self, wndMaterial, tData.itemMaterial, {bSelling = false})
		end
		wndParent:FindChild("NewRuneItemRawMaterialsList"):ArrangeChildrenHorz(2)
	end
end

function EngravingStation:OnNewRuneMoreInfoUncheck(wndHandler, wndControl)
	local wndParent = wndHandler:GetData()[1]
	local nLeft, nTop, nRight, nBottom = wndParent:GetAnchorOffsets()
	wndParent:SetAnchorOffsets(nLeft, nTop, nRight, nTop + knTEMPSmallCreateRuneSize)

	self.wndMain:FindChild("RuneCreationListItem"):ArrangeChildrenVert(0)
end

function EngravingStation:OnNewRuneItemCraftBtn(wndHandler, wndControl)
	CraftingLib.CraftItem(wndHandler:GetData()) -- Schematic Id
end

-----------------------------------------------------------------------------------------------
-- Sets
-----------------------------------------------------------------------------------------------

function EngravingStation:OnOpenSetsBtn(wndHandler, wndControl)
	if self.wndSets and self.wndSets:IsValid() then
		self.wndSets:Destroy()
	else
		self:RedrawSets(self.wndMain:FindChild("HeaderEquippedBtn"):IsChecked(), self.wndMain:FindChild("HeaderBagBtn"):IsChecked())
	end
end

function EngravingStation:RedrawSets(bHeaderEquipped, bHeaderBag)
	if not self.wndSets or not self.wndSets:IsValid() then
		self.wndSets = Apollo.LoadForm(self.xmlDoc, "SetsForm", nil, self)
	end

	-- Sets from equipped items only
	local tListOfSets = {}
	for idx, itemCurr in pairs(CraftingLib.GetValidGlyphableItems(bHeaderEquipped, bHeaderBag)) do
		for idx2, tSetInfo in ipairs(itemCurr:GetSetBonuses()) do
			if tSetInfo and tSetInfo.strName and not tListOfSets[tSetInfo.strName] then
				tListOfSets[tSetInfo.strName] = tSetInfo
			end
		end
	end

	-- Current Glyphs
	for idx, itemGlyph in pairs(CraftingLib.GetValidGlyphItems()) do
		local tMicrochipData = itemGlyph:GetMicrochipInfo()
		for idx, tSetInfo in pairs(tMicrochipData.tSet or {}) do
			if tSetInfo and tSetInfo.strName and not tListOfSets[tSetInfo.strName] then
				tSetInfo.nPower = 0 -- HACK
				tListOfSets[tSetInfo.strName] = tSetInfo
			end
		end
	end

	-- Draw sets now
	local strFullText = ""
	for idx, tSetInfo in pairs(tListOfSets) do
		local strLocalSetText = string.format("<P Font=\"CRB_InterfaceLarge_B\" TextColor=\"ItemQuality_Good\">%s</P>",
		String_GetWeaselString(Apollo.GetString("EngravingStation_RuneSetText"), tSetInfo.strName, tSetInfo.nPower, tSetInfo.nMaxPower))

		local tBonuses = tSetInfo.arBonuses
		table.sort(tBonuses, function(a,b) return a.nPower < b.nPower end)

		for idx3, tBonusInfo in pairs(tBonuses) do
			-- tBonusInfo.active, tBonusInfo.power, tBonusInfo.spell:GetFlavor()
			local strLocalColor = tBonusInfo.bIsActive and "ItemQuality_Good" or "UI_TextHoloBody"
			strLocalSetText = string.format("%s<P Font=\"CRB_InterfaceMedium\" TextColor=\"%s\">%s</P><P TextColor=\"0\">.</P>", strLocalSetText, strLocalColor,
			String_GetWeaselString(Apollo.GetString("EngravingStation_BonusInfo"), tBonusInfo.nPower, tBonusInfo.splBonus:GetFlavor()))
		end

		strFullText = strFullText .. kstrLineBreak .. strLocalSetText
	end

	self.wndSets:FindChild("SetsListNormalText"):SetAML(strFullText)
	self.wndSets:FindChild("SetsListNormalText"):SetHeightToContentHeight()
	self.wndSets:FindChild("SetsListContainer"):RecalculateContentExtents()
	self.wndSets:FindChild("SetsListContainer"):ArrangeChildrenVert(0)
	self.wndSets:FindChild("SetsListEmptyText"):Show(strFullText == "")
end

-----------------------------------------------------------------------------------------------
-- Equipment
-----------------------------------------------------------------------------------------------

function EngravingStation:NewEquipmentItem(itemSource)
	if not itemSource then
		return
	end

	local wndItem = Apollo.LoadForm(self.xmlDoc, "EquipmentItem", self.wndMain:FindChild("MainItemList"), self)
	wndItem:FindChild("EquipmentItemCantUseIcon"):Show(self:HelperPrereqFailed(itemSource))
	wndItem:FindChild("EquipmentItemStats"):SetAML(self:HelperBuildItemStats(itemSource))
	wndItem:FindChild("EquipmentItemName"):SetTextColor(karEvalColors[itemSource:GetItemQuality()])
	wndItem:FindChild("EquipmentItemName"):SetText(itemSource:GetName())
	wndItem:FindChild("EquipmentItemIcon"):SetSprite(itemSource:GetIcon())
	Tooltip.GetItemTooltipForm(self, wndItem:FindChild("EquipmentItemIcon"), itemSource, { bPrimary = true, bSelling = false })

	-- Sigils
	wndItem:FindChild("EquipmentItemSigilContainer"):DestroyChildren()
	local tSigilData = itemSource:GetSigils()
	if tSigilData and tSigilData.bIsDefined then
		local bFirstLockedSlot = true
		for idx, tCurrSigil in pairs(tSigilData.arSigils) do
			local wndSigil = self:LoadByName(tCurrSigil.bUnlocked and "SigilSlot" or "SigilLockedSlot", wndItem:FindChild("EquipmentItemSigilContainer"), "SigilSlot"..idx)
			wndSigil:FindChild("SigilSlotBtn"):SetData({ idx, tCurrSigil, itemSource })
			wndSigil:FindChild("SigilSlotType"):SetSprite(karSigilElementsToSprite[tCurrSigil.eType])

			local tSigilItemData = Item.GetDataFromId(tCurrSigil.idGlyph)
			if tSigilItemData and wndSigil:FindChild("SigilSlotIcon") then
				wndSigil:FindChild("SigilSlotIcon"):SetSprite(tSigilItemData:GetIcon())
				self:HelperBuildItemTooltip(wndSigil, tSigilItemData)
			elseif tCurrSigil.bUnlocked then
				wndSigil:SetTooltip(String_GetWeaselString(Apollo.GetString("EngravingStation_AvailableSlot"), tCurrSigil.strName))
			elseif bFirstLockedSlot then
				bFirstLockedSlot = false
				wndSigil:SetTooltip(String_GetWeaselString(Apollo.GetString("EngravingStation_LockedSlot"), tCurrSigil.strName))
			else
				wndSigil:FindChild("SigilSlotBtn"):Show(false) -- TODO REFACTOR
				wndSigil:SetTooltip(Apollo.GetString("EngravingStation_LockedChildSlot"))
			end
		end
	end
	wndItem:FindChild("EquipmentItemSigilContainer"):ArrangeChildrenTiles(0)

	-- Resize
	if #wndItem:FindChild("EquipmentItemSigilContainer"):GetChildren() > 5 then
		local nLeft, nTop, nRight, nBottom = wndItem:FindChild("EquipmentItemSigilContainer"):GetAnchorOffsets()
		wndItem:FindChild("EquipmentItemSigilContainer"):SetAnchorOffsets(nLeft, nBottom - (self.knSigilSlotHeight * 2), nRight, nBottom) -- hardcoded formatting
	end

	local nWidth, nHeight = wndItem:FindChild("EquipmentItemStats"):SetHeightToContentHeight()
	local nSigilHeight = #wndItem:FindChild("EquipmentItemSigilContainer"):GetChildren() > 5 and (self.knSigilSlotHeight * 2) or self.knSigilSlotHeight
	local nLeft, nTop, nRight, nBottom = wndItem:GetAnchorOffsets()
	wndItem:SetAnchorOffsets(nLeft, nTop, nRight, nTop + nHeight + nSigilHeight + 40)
end

function EngravingStation:OnCurrentConfirmPopupClose(wndHandler, wndControl)
	if self.wndCurrentConfirmPopup and self.wndCurrentConfirmPopup:IsValid() then
		self.wndCurrentConfirmPopup:Destroy()
		self.wndCurrentConfirmPopup = nil
	end
end

function EngravingStation:OnSigilLockedSlotBtn(wndHandler, wndControl) -- SigilSlotBtn of SigilLockedSlot
	local nSlotIndex = wndHandler:GetData()[1]
	local itemSource = wndHandler:GetData()[3]
	local tEngravingInfo = CraftingLib.GetEngravingInfo(itemSource)
	local tCurrentCosts = tEngravingInfo.tUnlockInfo.tCost
	self:OnCurrentConfirmPopupClose()
	self.wndCurrentConfirmPopup = Apollo.LoadForm(self.xmlDoc, "UnlockConfirm", wndHandler, self)
	self.wndCurrentConfirmPopup:FindChild("UnlockConfirmYes"):SetData(wndHandler:GetData())
	self.wndCurrentConfirmPopup:FindChild("UnlockCashWindow"):SetAmount(tCurrentCosts and tCurrentCosts["currencyCredits"] or 0)
end

function EngravingStation:OnUnlockConfirmYes(wndHandler, wndControl)
	local nSlotIndex = wndHandler:GetData()[1]
	local itemSource = wndHandler:GetData()[3] -- Data is passed along, origates from SigilSlotBtn and is { idx, tCurrSigil, itemSource }
	CraftingLib.UnlockSigil(itemSource, nSlotIndex)
	self:OnCurrentConfirmPopupClose()
end

-----------------------------------------------------------------------------------------------
-- Add Picker or Clear
-----------------------------------------------------------------------------------------------

function EngravingStation:HelperDoSigilAndGlyphMatch(tItemGlyphInfo, tSigil)
	return tSigil.eType == Item.CodeEnumSigilType.Omni or tItemGlyphInfo.eType == Item.CodeEnumSigilType.Omni or tItemGlyphInfo.eType == tSigil.eType
end

function EngravingStation:OnSigilSlotBtn(wndHandler, wndControl) -- SigilSlotBtn of SigilLockedSlot
	local nSlotIndex = wndHandler:GetData()[1]
	local tCurrSigil = wndHandler:GetData()[2]
	local itemSource = wndHandler:GetData()[3]

	self:OnCurrentConfirmPopupClose()

	if self.itemDragging and self.itemDragging:GetGlyphInfo().eType ~= tCurrSigil.eType then
		return Apollo.DragDropQueryResult.Accept -- HACK
	end

	if tCurrSigil.idGlyph == 0 then
		self.wndCurrentConfirmPopup = Apollo.LoadForm(self.xmlDoc, "AddPicker", wndHandler, self)
		for idx, itemGlyph in pairs(CraftingLib.GetValidGlyphItems()) do
			local tItemGlyphInfo = itemGlyph:GetGlyphInfo()
			if self:HelperDoSigilAndGlyphMatch(tItemGlyphInfo, tCurrSigil) then
				local wndGlyph = self:LoadByName("GlyphPickerItem", self.wndCurrentConfirmPopup:FindChild("AddPickerList"), "AddPickerList"..idx..itemGlyph:GetName())
				wndGlyph:FindChild("GlyphPickerBtn"):SetData({wndHandler, itemGlyph})
				wndGlyph:FindChild("GlyphPickerIcon"):SetSprite(itemGlyph:GetIcon())
				wndGlyph:FindChild("GlyphPickerIcon"):SetText(itemGlyph:GetBackpackCount())
				wndGlyph:FindChild("GlyphPickerType"):SetSprite(karSigilElementsToSprite[tItemGlyphInfo.eType])
				self:HelperBuildItemTooltip(wndGlyph, itemGlyph)
			end
		end
		local bHasItems = #self.wndCurrentConfirmPopup:FindChild("AddPickerList"):GetChildren() > 0
		self.wndCurrentConfirmPopup:FindChild("AddPickerList"):ArrangeChildrenTiles(0)
		self.wndCurrentConfirmPopup:FindChild("AddPickerList"):SetText(bHasItems and "" or Apollo.GetString("EngravingStation_NoRunesFound"))
	else
		local tEngravingInfo = CraftingLib.GetEngravingInfo(itemSource)
		local tCurrentCosts = tEngravingInfo.tClearInfo.arCosts[nSlotIndex]
		self.wndCurrentConfirmPopup = Apollo.LoadForm(self.xmlDoc, "ClearConfirm", wndHandler, self)
		self.wndCurrentConfirmPopup:FindChild("ClearConfirmYes"):SetData(wndHandler:GetData())
		self.wndCurrentConfirmPopup:FindChild("ClearCashWindow"):SetAmount(tCurrentCosts and tCurrentCosts.monCost or 0)
	end
	return Apollo.DragDropQueryResult.Accept -- HACK
end

function EngravingStation:OnGlyphPickerBtn(wndHandler, wndControl)
	self:DrawGlyphAddConfirm(wndHandler:GetData()[1], wndHandler:GetData()[2])
end

function EngravingStation:DrawGlyphAddConfirm(wndHandler, itemGlyph)
	local nSlotIndex = wndHandler:FindChild("SigilSlotBtn"):GetData()[1]
	local itemSource = wndHandler:FindChild("SigilSlotBtn"):GetData()[3]
	self:OnCurrentConfirmPopupClose()

	-- What the glyph will add to the item, if successful
	local tItemEffectData = itemSource:GetGlyphBonus(itemGlyph, nSlotIndex)
	local strItemEffect = String_GetWeaselString(Apollo.GetString("EngravingStation_EffectIfSuccessful"), tItemEffectData.nValue, ktAttributeToText[tItemEffectData.eProperty])

	-- Draw Window
	self.wndCurrentConfirmPopup = Apollo.LoadForm(self.xmlDoc, "AddConfirm", wndHandler, self)
	self.wndCurrentConfirmPopup:FindChild("AddConfirmYes"):SetData({ nSlotIndex, itemGlyph, itemSource }) -- GOTCHA: Different 2nd argument than normal
	self.wndCurrentConfirmPopup:FindChild("AddConfirmItemEffect"):SetText(strItemEffect)
	self.wndCurrentConfirmPopup:FindChild("AddConfirmIcon"):SetSprite(itemGlyph:GetIcon())	
	self.wndCurrentConfirmPopup:FindChild("AddConfirmText"):Show(itemSource:IsSoulbound())
	self.wndCurrentConfirmPopup:FindChild("AddConfirmSoulboundWarning"):Show(not itemSource:IsSoulbound())
	self:HelperBuildItemTooltip(self.wndCurrentConfirmPopup:FindChild("AddConfirmIcon"), itemGlyph)
end

function EngravingStation:OnClearConfirmYes(wndHandler, wndControl)
	local nSlotIndex = wndHandler:GetData()[1]
	local itemSource = wndHandler:GetData()[3] -- Data is passed along, origates from SigilSlotBtn and is { idx, tCurrSigil, itemSource }
	CraftingLib.ClearSigil(itemSource, nSlotIndex)
	self:OnCurrentConfirmPopupClose()
end

function EngravingStation:DrawGlyphReplaceConfirm(wndHandler, itemGlyph)
	local nSlotIndex = wndHandler:FindChild("SigilSlotBtn"):GetData()[1]
	local itemSource = wndHandler:FindChild("SigilSlotBtn"):GetData()[3]
	local tEngravingInfo = CraftingLib.GetEngravingInfo(itemSource)
	local tCurrentCosts = tEngravingInfo.tClearInfo.arCosts[nSlotIndex]
	self:OnCurrentConfirmPopupClose()

	-- Draw Window
	self.wndCurrentConfirmPopup = Apollo.LoadForm(self.xmlDoc, "ReplaceConfirm", wndHandler, self)
	self.wndCurrentConfirmPopup:FindChild("AddConfirmYes"):SetData({ nSlotIndex, itemGlyph, itemSource }) -- GOTCHA: Different 2nd argument than normal
	self.wndCurrentConfirmPopup:FindChild("AddConfirmIcon"):SetSprite(itemGlyph:GetIcon())
	self.wndCurrentConfirmPopup:FindChild("ClearCashWindow"):SetAmount(tCurrentCosts and tCurrentCosts.monCost or 0)
	self:HelperBuildItemTooltip(self.wndCurrentConfirmPopup:FindChild("AddConfirmIcon"), itemGlyph)
end

-----------------------------------------------------------------------------------------------
-- Drag Drop Events
-----------------------------------------------------------------------------------------------

function EngravingStation:OnSystemBeginDragDrop()
	self.bDragging = true
end

function EngravingStation:OnSystemEndDragDrop()
	self.bDragging = false
end

function EngravingStation:OnGlyphBagBeginDragDrop(wndHandler, wndControl) -- GlyphBagDrag
	if wndHandler == wndControl and wndHandler:GetData() and not self.bDragging then
		self.itemDragging = wndControl:GetData()
		Apollo.BeginDragDrop(wndControl, "DDBagItem", wndControl:GetData():GetIcon(), wndControl:GetData():GetInventoryId())
		return true
	end
end

function EngravingStation:OnGlyphBagQueryDragDrop(wndHandler, wndControl, x, y, wndSource, strType, nData, eResult)
	return Apollo.DragDropQueryResult.Invalid -- Can't drop anything onto GlyphBag items
end

function EngravingStation:OnSigilSlotQueryDragDrop(wndHandler, wndControl, x, y, wndSource, strType, nDragInventoryItemIdx, eResult)
	local itemSource = self.wndMain:FindChild("HiddenBagWindow"):GetItem(nDragInventoryItemIdx)
	if itemSource and strType == "DDBagItem" then
		local tCurrSigil = wndHandler:GetData()[2]
		local tItemGlyphInfo = self.wndMain:FindChild("HiddenBagWindow"):GetItem(nDragInventoryItemIdx):GetGlyphInfo()
		if tCurrSigil.eType and tItemGlyphInfo then
			return Apollo.DragDropQueryResult.Accept
		end
	end
	return Apollo.DragDropQueryResult.Ignore
end

function EngravingStation:OnSigilSlotDragDrop(wndHandler, wndControl, x, y, wndSource, strType, nDragInventoryItemIdx, bDragDropHasBeenReset)
	local itemSource = self.wndMain:FindChild("HiddenBagWindow"):GetItem(nDragInventoryItemIdx)
	if itemSource and strType == "DDBagItem" then
		local tCurrSigil = wndHandler:GetData()[2]
		local tItemGlyphInfo = self.wndMain:FindChild("HiddenBagWindow"):GetItem(nDragInventoryItemIdx):GetGlyphInfo()
		if self:HelperDoSigilAndGlyphMatch(tItemGlyphInfo, tCurrSigil) then
			if tCurrSigil.idGlyph == 0 then -- No rune in slot
				self:DrawGlyphAddConfirm(wndHandler:GetParent(), self.wndMain:FindChild("HiddenBagWindow"):GetItem(nDragInventoryItemIdx))
			else -- Replace rune in slot
				self:DrawGlyphReplaceConfirm(wndHandler:GetParent(), self.wndMain:FindChild("HiddenBagWindow"):GetItem(nDragInventoryItemIdx))
			end
		end
		return false
	end
	return true
end

function EngravingStation:OnAddConfirmYes(wndHandler, wndControl) -- Potentially from drag drop or from picker
	local nSlotIndex = wndHandler:GetData()[1]
	local itemGlyph = wndHandler:GetData()[2] -- GOTCHA: This is an item object, not the normal table of data
	local itemSource = wndHandler:GetData()[3]

	local tSigilData = itemSource:GetSigils()
	if tSigilData and tSigilData.bIsDefined then
		local tListOfGlyphs = {}
		for idx, tCurrSigil in pairs(tSigilData.arSigils) do
			if tCurrSigil.bUnlocked then
				tListOfGlyphs[idx] = tCurrSigil.idGlyph
			end
		end
		tListOfGlyphs[nSlotIndex] = itemGlyph:GetItemId() -- Replace with the desired
		CraftingLib.InstallGlyphs(itemSource, tListOfGlyphs)
	end
	self:OnCurrentConfirmPopupClose()
end

function EngravingStation:OnReplaceConfirmYes( wndHandler, wndControl, eMouseButton )
	local nSlotIndex = wndHandler:GetData()[1]
	local itemGlyph = wndHandler:GetData()[2] -- GOTCHA: This is an item object, not the normal table of data
	local itemSource = wndHandler:GetData()[3]

	local tSigilData = itemSource:GetSigils()
	if tSigilData and tSigilData.bIsDefined then
		local tListOfGlyphs = {}
		for idx, tCurrSigil in pairs(tSigilData.arSigils) do
			if tCurrSigil.bUnlocked then
				tListOfGlyphs[idx] = tCurrSigil.idGlyph
			end
		end
		tListOfGlyphs[nSlotIndex] = itemGlyph:GetItemId() -- Replace with the desired
		CraftingLib.ClearSigil(itemSource, nSlotIndex)
		CraftingLib.InstallGlyphs(itemSource, tListOfGlyphs)
	end

	self:OnCurrentConfirmPopupClose()
end

-----------------------------------------------------------------------------------------------
-- Helpers
-----------------------------------------------------------------------------------------------

function EngravingStation:HelperPrereqFailed(tCurrItem)
	return tCurrItem and tCurrItem:IsEquippable() and not tCurrItem:CanEquip()
end

function EngravingStation:HelperBuildItemTooltip(wndArg, itemCurr)
	Tooltip.GetItemTooltipForm(self, wndArg, itemCurr, { bPrimary = true, bSelling = false, itemCompare = itemCurr:GetEquippedItemForItemType() })
end

function EngravingStation:HelperBuildItemStats(itemCurr)
	local strStats = ""
	local tItemInfo = itemCurr:GetDetailedInfo()
	if not tItemInfo then
		return strStats
	end

	tItemInfo = tItemInfo.tPrimary
	if not tItemInfo then
		return strStats
	end

	--[[ We'll rely on the tooltip now
	if tItemInfo.arInnateProperties then
		table.sort(tItemInfo.arInnateProperties, function(a,b) return a.nSortOrder and b.nSortOrder and a.nSortOrder < b.nSortOrder end)
		for idx, tProp in pairs(tItemInfo.arInnateProperties) do
			strStats = string.format("%s<P Font=\"CRB_InterfaceMedium\" TextColor=\"UI_TextMetalBodyHighlight\">%d %s</P>", strStats, tProp.nValue, Item.GetPropertyName(tProp.eProperty))
		end
	end
	if tItemInfo.arBudgetBasedProperties then
		table.sort(tItemInfo.arBudgetBasedProperties, function(a,b) return a.nSortOrder and b.nSortOrder and a.nSortOrder < b.nSortOrder end)
		for ndx, tProp in pairs(tItemInfo.arBudgetBasedProperties) do
			strStats = string.format("%s<P Font=\"CRB_InterfaceMedium\" TextColor=\"UI_TextMetalBodyHighlight\">%d %s</P>", strStats, tProp.nValue, Item.GetPropertyName(tProp.eProperty))
		end
	end
	]]--

	if tItemInfo.tSigils and tItemInfo.tSigils.arSigils then
		table.sort(tItemInfo.tSigils.arSigils, function(a,b) return a.nSortOrder and b.nSortOrder and a.nSortOrder < b.nSortOrder end)
		for ndx, tProp in pairs(tItemInfo.tSigils.arSigils) do
			if tProp.eProperty and tProp.nValue then
				strStats = string.format("%s<P Font=\"CRB_InterfaceMedium\" TextColor=\"ItemQuality_Good\">+%d %s</P>", strStats, tProp.nValue, Item.GetPropertyName(tProp.eProperty))
			end
		end
	end

	return strStats
end

function EngravingStation:OnTradeSkillSigilResult(eResult)
	local tEnumTable = CraftingLib.CodeEnumTradeskillResult
	local kstrTradeskillResultTable =
	{
		[tEnumTable.Success] 					= Apollo.GetString("EngravingStation_Success"),
		[tEnumTable.InsufficentFund] 			= Apollo.GetString("EngravingStation_NeedMoreMoney"),
		[tEnumTable.InvalidItem] 				= Apollo.GetString("EngravingStation_InvalidItem"),
		[tEnumTable.InvalidSlot]			 	= Apollo.GetString("EngravingStation_InvalidSlot"),
		[tEnumTable.MissingEngravingStation] 	= Apollo.GetString("EngravingStation_StationTooFar"),
		[tEnumTable.Unlocked] 					= Apollo.GetString("EngravingStation_UnlockSuccessfull"),
		[tEnumTable.UnknownError] 				= Apollo.GetString("EngravingStation_Failure"),
		[tEnumTable.GlyphExists] 				= Apollo.GetString("EngravingStation_ExistingRune"),
		[tEnumTable.MissingGlyph] 				= Apollo.GetString("EngravingStation_RuneMissing"),
		[tEnumTable.DuplicateGlyph]				= Apollo.GetString("EngravingStation_DuplicateRune"),
		[tEnumTable.AttemptFailed] 				= Apollo.GetString("EngravingStation_Failure"),
		[tEnumTable.GlyphSlotLimit] 			= Apollo.GetString("EngravingStation_SlotLimitReached"),
	}

	Event_FireGenericEvent("GenericEvent_LootChannelMessage", kstrTradeskillResultTable[eResult])
end

function EngravingStation:LoadByName(strForm, wndParent, strCustomName)
	local wndNew = wndParent:FindChild(strCustomName)
	if not wndNew then
		wndNew = Apollo.LoadForm(self.xmlDoc, strForm, wndParent, self)
		wndNew:SetName(strCustomName)
	end
	return wndNew
end

local EngravingStationInst = EngravingStation:new()
EngravingStationInst:Init()
