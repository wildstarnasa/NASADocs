-----------------------------------------------------------------------------------------------
-- Client Lua Script for Death
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------
require "Window"
require "Tooltip"
require "XmlDoc"
require "GameLib"
require "MatchingGame"

---------------------------------------------------------------------------------------------------
-- Death module definition
---------------------------------------------------------------------------------------------------
local Death = {}

---------------------------------------------------------------------------------------------------
-- local constants
---------------------------------------------------------------------------------------------------
local RezType =
{
	Here = 1,
	Eldan = 2,
	SpellCasterLocation = 4,
	ExitInstance = 32
}

local kcrCanResurrectButtonColor = CColor.new(1, 1, 1, 1)
local kcrCannotResurrectButtonColor = CColor.new(.6, .6, .6, 1)
local kcrCanResurrectTextColor = ApolloColor.new("ff9aaea3")
local kcrCannotResurrectTextColor = CColor.new(.3, .3, .3, 1)

---------------------------------------------------------------------------------------------------
-- Death functions
---------------------------------------------------------------------------------------------------
function Death:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self

	o.wndResurrect = nil
	o.nGoldPenalty = 0
	o.bEnableRezHere = true
	o.bEnableCasterRez = false
	o.bHasCasterRezRequest = false
	o.nRezCost = 0
	o.fTimeBeforeRezable = 0
	o.fTimeBeforeWakeHere = 0

	return o
end

function Death:Init()
	Apollo.RegisterAddon(self)
end

---------------------------------------------------------------------------------------------------
-- EventHandlers
---------------------------------------------------------------------------------------------------
function Death:OnLoad()
    Apollo.RegisterTimerHandler("TenthSecTimer", "OnTenthSecTimer", self)
	
	Apollo.RegisterEventHandler("ShowResurrectDialog", 		"OnShowResurrectDialog", self)
	Apollo.RegisterEventHandler("ShowIncapacitationBar", 	"ShowIncapacitationBar", self)
	Apollo.RegisterEventHandler("HideIncapacitationBar", 	"HideIncapacitationBar", self)
	Apollo.RegisterEventHandler("CasterResurrectedPlayer", 	"CasterResurrectedPlayer", self)
	Apollo.RegisterEventHandler("ForceResurrect", 			"OnForcedResurrection", self)
	Apollo.RegisterEventHandler("ScriptResurrect", 			"OnScriptResurrection", self)
	Apollo.RegisterEventHandler("MatchExited", 				"OnForcedResurrection", self)
	Apollo.RegisterEventHandler("PVPDeathmatchPoolUpdated", "OnPVPDeathmatchPoolUpdated", self)
	Apollo.RegisterEventHandler("CharacterCreated", 		"OnCharacterCreated", self)

	self.wndResurrect = Apollo.LoadForm("Death.xml", "ResurrectDialog", nil, self)
	self.wndResurrect:Show(false)

	self.wndExitConfirm = Apollo.LoadForm("Death.xml", "ExitInstanceDialog", nil, self)
	self.wndExitConfirm:Show(false)	
	
	self.nTimerProgress = nil
	self.bDead = false
	
	Apollo.CreateTimer("TenthSecTimer", 0.10, true)
	Apollo.StopTimer("TenthSecTimer")

	self.monPlayerCash = self.wndResurrect:FindChild("ResurrectDialog.PlayerCash")
	if GameLib.GetPlayerUnit() then
		self:OnCharacterCreated()
	end
end

function Death:OnSave(eType)
	local tSaveData = {bCasterRezzed = self.bHasCasterRezRequest}
	return tSaveData
end

function Death:OnRestore(eType, tSavedData)
	self.bHasCasterRezRequest = tSavedData.bCasterRezzed
end

---------------------------------------------------------------------------------------------------
-- Interface
---------------------------------------------------------------------------------------------------
function Death:OnCharacterCreated()
	local unitPlayer = GameLib.GetPlayerUnit()
	
	if unitPlayer:IsDead() == false then
		return
	end
	
	self.bDead = true
	self.fTimeBeforeRezable = GetDeathPenalty() 
	self.fTimeBeforeWakeHere = GetWakeHereTime() 
	self.fTimeBeforeForceRez = GetForceRezTime() 
	self.nRezCost = GetRezCost() 
	self.bEnableRezHere = GetRezOptionWakeHere() 
	self.bEnableRezHoloCrypt = GetRezOptionHolocrypt() 
	self.bEnableRezExitInstance = GetRezOptionExitInstance()
	self.bEnableCasterRez = GetRezOptionAcceptCasterRez()
	
	self:OnShowResurrectDialog(self.bDead, self.bEnableRezHere, self.bEnableRezHoloCrypt, self.bEnableRezExitInstance, self.bEnableCasterRez, self.bHasCasterRezRequest, self.nRezCost, self.fTimeBeforeRezable, self.fTimeBeforeWakeHere, self.fTimeBeforeForceRez)
end

function Death:OnShowResurrectDialog(bPlayerIsDead, bEnableRezHere, bEnableRezHoloCrypt, bEnableRezExitInstance, bEnableCasterRez, bHasCasterRezRequest, nRezCost, fTimeBeforeRezable, fTimeBeforeWakeHere, fTimeBeforeForceRez)
	Apollo.StartTimer("TenthSecTimer")

	self.bEnableRezHere = bEnableRezHere
	self.bEnableRezHoloCrypt = bEnableRezHoloCrypt
	self.bEnableRezExitInstance = bEnableRezExitInstance
	self.bEnableCasterRez = bEnableCasterRez or false
	self.bHasCasterRezRequest = bHasCasterRezRequest
	self.bDead = bPlayerIsDead
	self.nRezCost = nRezCost
	self.fTimeBeforeRezable = fTimeBeforeRezable
	self.fTimeBeforeWakeHere = fTimeBeforeWakeHere
	self.fTimeBeforeForceRez = fTimeBeforeForceRez

	if self.bDead == false then
		self.wndExitConfirm:Show(false)	
		self.wndResurrect:Show(false)
		self.nTimerProgress = nil
		return
	end
	
	--hide and format everything
	self.wndExitConfirm:Show(false)	
	self.wndResurrect:FindChild("ResurrectDialog.Caster"):Show(false)
	self.wndResurrect:FindChild("ResurrectDialog.Here"):Show(false)
	self.wndResurrect:FindChild("ResurrectDialog.Eldan"):Show(false)
	self.wndResurrect:FindChild("ResurrectDialog.ExitInstance"):Show(false)
	self.wndResurrect:FindChild("ResurrectDialog.EldanSmall"):Show(false)
	self.wndResurrect:FindChild("ResurrectDialog.ExitInstanceSmall"):Show(false)	
	self.wndResurrect:FindChild("ArtTimeToRezHere"):SetText(Apollo.GetString("CRB_Time_Remaining_2"))
	self.wndResurrect:FindChild("ArtTimeToRezHere"):Show(true)
	self.wndResurrect:FindChild("ForceRezText"):Show(false)
	
	self.wndResurrect:Show(true)
end


------------------------------------//------------------------------
function Death:OnTenthSecTimer() -- there's no reason we can't run the whole thing off of this
	if self.bDead ~= true or not self.wndResurrect:IsVisible() then
		self.bHasCasterRezRequest = false
		return
	end
	
	-- update all of our timers
	self.fTimeBeforeWakeHere = self.fTimeBeforeWakeHere - 100
	self.fTimeBeforeForceRez = self.fTimeBeforeForceRez - 100
	self.fTimeBeforeRezable = self.fTimeBeforeRezable - 100
			
	if self.fTimeBeforeRezable > 0 then -- this timer takes precendence over everything. if it has a count, the player can't do anything
		local strTimeBeforeRezableFormatted = self:HelperCalcTimeSecondsMS(self.fTimeBeforeRezable)
		self.wndResurrect:FindChild("ResurrectDialog.Timer"):SetText(strTimeBeforeRezableFormatted .. Apollo.GetString("CRB__seconds"))
		self.wndResurrect:FindChild("ResurrectDialog.Timer"):Show(true)
	else
		local tMatchInfo = MatchingGame.GetPVPMatchState()
		if tMatchInfo ~= nil then
			if tMatchInfo.eRules == MatchingGame.Rules.DeathmatchPool then
				if (tMatchInfo.eMyTeam == MatchingGame.Team.Team1 and tMatchInfo.tLivesRemaining.nTeam1 == 0) or (tMatchInfo.eMyTeam == MatchingGame.Team.Team2 and tMatchInfo.tLivesRemaining.nTeam2 == 0) then
					self.wndResurrect:FindChild("ResurrectDialog.Timer"):SetText(Apollo.GetString("Death_NoLives"))
					self.wndResurrect:FindChild("ResurrectDialog.Timer"):Show(true)	
					self.wndResurrect:FindChild("ForceRezText"):Show(false)
					self.wndResurrect:FindChild("ResurrectDialog.Here"):Show(false)
					self.wndResurrect:FindChild("ResurrectDialog.Eldan"):Show(false)
					self.wndResurrect:FindChild("ResurrectDialog.EldanSmall"):Show(false)
					self.wndResurrect:FindChild("ResurrectDialog.ExitInstanceSmall"):Show(false)		
					self.wndResurrect:FindChild("ResurrectDialog.Caster"):Show(false)	
					return
				end
			elseif tMatchInfo.eRules == MatchingGame.Rules.WaveRespawn then
				self.wndResurrect:Show(false)
				return
			end
		end
	
		self.wndResurrect:FindChild("ArtTimeToRezHere"):Show(false)
		self.wndResurrect:FindChild("ResurrectDialog.Timer"):Show(false)
		
		self.wndResurrect:FindChild("ForceRezText"):Show(self.bEnableRezHoloCrypt)
		self.wndResurrect:FindChild("ResurrectDialog.Here"):Show(self.bEnableRezHere)
		self.wndResurrect:FindChild("ResurrectDialog.Eldan"):Show(self.bEnableRezHoloCrypt and not self.bEnableRezExitInstance)
		self.wndResurrect:FindChild("ResurrectDialog.ExitInstance"):Show(not self.bEnableRezHoloCrypt and self.bEnableRezExitInstance)
		self.wndResurrect:FindChild("ResurrectDialog.EldanSmall"):Show(self.bEnableRezHoloCrypt and self.bEnableRezExitInstance)
		self.wndResurrect:FindChild("ResurrectDialog.ExitInstanceSmall"):Show(self.bEnableRezHoloCrypt and self.bEnableRezExitInstance)		
		self.wndResurrect:FindChild("ResurrectDialog.Caster"):Show(self.bEnableCasterRez and self.bHasCasterRezRequest)	

		-- set up rez here
		if self.wndResurrect:FindChild("ResurrectDialog.Here"):IsShown() then
			local wndBtn = self.wndResurrect:FindChild("ResurrectDialog.Here")
			wndBtn:FindChild("ResurrectDialog.Cash"):SetAmount(self.nRezCost)
						
			if self.fTimeBeforeWakeHere <= 0 then  -- ready to go
				local bCanAfford = self.nRezCost <= GameLib.GetPlayerCurrency():GetAmount()
				wndBtn:Enable(bCanAfford)
				wndBtn:FindChild("WakeHereText"):SetText(Apollo.GetString("Death_WakeHere"))
				wndBtn:FindChild("WakeHereCooldownText"):SetText("")
				wndBtn:FindChild("ResurrectDialog.Cash"):Show(true)
				wndBtn:FindChild("CostLabel"):Show(true)
				if bCanAfford then
					self.wndResurrect:FindChild("ResurrectDialog.Here"):SetBGColor(kcrCanResurrectButtonColor)
					wndBtn:FindChild("WakeHereText"):SetTextColor(kcrCanResurrectTextColor)
					wndBtn:FindChild("ResurrectDialog.Cash"):SetTextColor(ApolloColor.new("white"))
				else -- not enough money
					self.wndResurrect:FindChild("ResurrectDialog.Here"):SetBGColor(kcrCannotResurrectButtonColor)
					wndBtn:FindChild("WakeHereText"):SetTextColor(kcrCannotResurrectTextColor)	
					wndBtn:FindChild("ResurrectDialog.Cash"):SetTextColor(ApolloColor.new("red"))						
				end	
			else -- still cooling down
				wndBtn:Enable(false)
				local strCooldownFormatted = self:HelperCalcTimeMS(self.fTimeBeforeWakeHere)
				wndBtn:FindChild("WakeHereCooldownText"):SetText(String_GetWeaselString(Apollo.GetString("Death_CooldownTimer"), strCooldownFormatted))
				wndBtn:FindChild("ResurrectDialog.Cash"):Show(false)
				wndBtn:FindChild("CostLabel"):Show(false)
				self.wndResurrect:FindChild("ResurrectDialog.Here"):SetBGColor(kcrCannotResurrectButtonColor)
				wndBtn:FindChild("WakeHereText"):SetTextColor(kcrCannotResurrectTextColor)					
			end
		end	
	end
		
	if self.fTimeBeforeForceRez > 0 then
		local strTimeFormatted = self:HelperCalcTimeMS(self.fTimeBeforeForceRez)
		self.wndResurrect:FindChild("ForceRezText"):SetText(String_GetWeaselString(Apollo.GetString("Death_AutoRelease"), strTimeFormatted))
	end

	self.monPlayerCash:SetAmount(GameLib.GetPlayerCurrency():GetAmount(), false)
end

------------------------------------//------------------------------

function Death:CasterResurrectedPlayer(strCasterName)
	self.bHasCasterRezRequest = true;
end

function Death:OnResurrectHere()
	if GameLib.GetPlayerUnit() ~= nil then
		GameLib.GetPlayerUnit():Resurrect(RezType.Here, 0)
	end
	
	self.wndResurrect:Show(false)
	self.bDead = false
	
	Apollo.StopTimer("TenthSecTimer")
	Event_FireGenericEvent("PlayerResurrected")
end
------------------------------------//------------------------------
function Death:OnResurrectCaster()
	if GameLib.GetPlayerUnit() ~= nil then
		GameLib.GetPlayerUnit():Resurrect(RezType.SpellCasterLocation, 0) -- WIP, this should send in the UnitId of the caster
	end
	
	self.wndResurrect:Show(false)
	self.bDead = false
	
	Apollo.StopTimer("TenthSecTimer")
	Event_FireGenericEvent("PlayerResurrected")
end
------------------------------------//------------------------------
function Death:OnResurrectEldan()
	if GameLib.GetPlayerUnit() ~= nil then
		GameLib.GetPlayerUnit():Resurrect(RezType.Eldan, 0)
	end

	self.wndResurrect:Show(false)
	self.bDead = false
	
	Apollo.StopTimer("TenthSecTimer")
	Event_FireGenericEvent("PlayerResurrected")
end

------------------------------------//------------------------------
function Death:OnExitInstance()
	self.wndExitConfirm:Show(true)	
	self.wndResurrect:Show(false)
end

function Death:OnConfirmExit()
	if GameLib.GetPlayerUnit() ~= nil then
		GameLib.GetPlayerUnit():Resurrect(RezType.ExitInstance, 0)
	end

	self.wndExitConfirm:Show(false)	
	self.wndResurrect:Show(false)
	self.bDead = false
	
	Apollo.StopTimer("TenthSecTimer")
	Event_FireGenericEvent("PlayerResurrected")
end

function Death:OnCancelExit()
	self.wndExitConfirm:Show(false)	
	self.wndResurrect:Show(true)
end

------------------------------------//------------------------------
function Death:OnForcedResurrection()
	self.wndExitConfirm:Show(false)	
	self.wndResurrect:Show(false)
	self.bDead = false

	Apollo.StopTimer("TenthSecTimer")
	Event_FireGenericEvent("PlayerResurrected")
end

------------------------------------//------------------------------
function Death:OnScriptResurrection()
	self.wndExitConfirm:Show(false)	
	self.wndResurrect:Show(false)
	self.bDead = false

	Apollo.StopTimer("TenthSecTimer")
	Event_FireGenericEvent("PlayerResurrected")
end

------------------------------------//------------------------------

function Death:HideIncapacitationBar()

	self.wndExitConfirm:Show(false)	
	self.wndResurrect:Show(false)
end

function Death:HelperCalcTimeSecondsMS(fTimeMS)
	local fTime = math.floor(fTimeMS / 1000)
	local fMillis = fTimeMS % 1000
	return string.format("%d.%d", fTime, math.floor(fMillis / 100))
end

function Death:HelperCalcTimeMS(fTimeMS)
	local fSeconds = fTimeMS / 1000
	local fMillis = fTimeMS % 1000
	local strOutputSeconds = "00"
	if math.floor(fSeconds % 60) >= 10 then
		strOutputSeconds = tostring(math.floor(fSeconds % 60))
	else
		strOutputSeconds = "0" .. math.floor(fSeconds % 60)
	end
	
	return String_GetWeaselString(Apollo.GetString("CRB_TimeMinsToMS"), math.floor(fSeconds / 60), strOutputSeconds, math.floor(fMillis / 100))
end

function Death:HelperCalcTime(fSeconds)
	local strOutputSeconds = "00"
	if math.floor(fSeconds % 60) >= 10 then
		strOutputSeconds = tostring(math.floor(fSeconds % 60))
	else
		strOutputSeconds = "0" .. math.floor(fSeconds % 60)
	end
	
	return String_GetWeaselString(Apollo.GetString("CRB_TimeMinsToMS"), math.floor(fSeconds / 60), strOutputSeconds)
end

---------------------------------------------------------------------------------------------------
-- Death instance
---------------------------------------------------------------------------------------------------
local DeathInst = Death:new()
DeathInst:Init()
