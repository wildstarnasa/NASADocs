-----------------------------------------------------------------------------------------------
-- Client Lua Script for BaseBarCorner
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "Apollo"
require "GroupLib"

local BaseBarCorner = {}
local knMaxLevel = 50 -- TODO: Replace with a variable from code

function BaseBarCorner:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function BaseBarCorner:Init()
    Apollo.RegisterAddon(self)
end

function BaseBarCorner:OnLoad()
	Apollo.RegisterEventHandler("ChangeWorld", 					"OnClearCombatFlag", self)
	Apollo.RegisterEventHandler("ShowResurrectDialog", 			"OnClearCombatFlag", self)
	Apollo.RegisterEventHandler("UnitEnteredCombat", 			"OnEnteredCombat", self)
	Apollo.RegisterEventHandler("PlayerCurrencyChanged",		"RedrawAll", self)	-- Can't filter to just elder gems yet

	Apollo.RegisterEventHandler("Group_MentorRelationship", 	"RedrawAll", self)
	Apollo.RegisterEventHandler("CharacterCreated", 			"RedrawAll", self)
	Apollo.RegisterEventHandler("UnitPvpFlagsChanged", 			"RedrawAll", self)
	Apollo.RegisterEventHandler("UnitNameChanged", 				"RedrawAll", self)
	Apollo.RegisterEventHandler("PersonaUpdateCharacterStats", 	"RedrawAll", self)
	Apollo.RegisterEventHandler("PlayerLevelChange", 			"RedrawAll", self)
	Apollo.RegisterEventHandler("UI_XPChanged", 				"RedrawAll", self)
	Apollo.RegisterEventHandler("ElderPointsGained", 			"RedrawAll", self)

	Apollo.RegisterTimerHandler("BaseBarCorner_RedrawCooldown", "RedrawCooldown", self)
	Apollo.CreateTimer("BaseBarCorner_RedrawCooldown", 1, false)
	Apollo.StopTimer("BaseBarCorner_RedrawCooldown")

    self.wndSolidFill = Apollo.LoadForm("BaseBarCorner.xml", "BaseBarSolidFill", nil, self) -- TODO TEMP: ART HACK: REMOVE

    self.wndMain = Apollo.LoadForm("BaseBarCorner.xml", "BaseBarCornerForm", nil, self)
	self.wndPlayerName = self.wndMain:FindChild("PlayerName")
	self.wndPlayerNameSubtitle = self.wndMain:FindChild("PlayerNameSubtitle")

	self.bInCombat = false
	self.bOnRedrawCooldown = false

	self:RedrawAll()
end

function BaseBarCorner:RedrawCooldown()
	Apollo.StopTimer("BaseBarCorner_RedrawCooldown")
	self.bOnRedrawCooldown = false
	self:RedrawAllPastCooldown()
end

function BaseBarCorner:RedrawAll()
	if not self.bOnRedrawCooldown then
		self.bOnRedrawCooldown = true
		self:RedrawAllPastCooldown()
	end

	Apollo.StartTimer("BaseBarCorner_RedrawCooldown")
end

function BaseBarCorner:RedrawAllPastCooldown()
	local unitPlayer = GameLib.GetPlayerUnit()
	if not unitPlayer then
		return
	end

	local strName = unitPlayer:GetName()
	local tStats = unitPlayer:GetBasicStats()
	local tMyGroupData = GroupLib.GetGroupMember(1)
	local strTextColor = self.bInCombat and ApolloColor.new("6631fcf6") or ApolloColor.new("UI_TextHoloBodyHighlight")
	local strLevel = String_GetWeaselString(Apollo.GetString("BaseBar_LevelPrefix"), tStats.nLevel) -- Can be refactored

	-- XP/EP Progress Bar and Tooltip
	local strXPorEP = ""
	local strTooltip = ""
	if tStats.nLevel == knMaxLevel then -- TODO: Hardcoded max level
		strXPorEP = String_GetWeaselString(Apollo.GetString("BaseBar_EPBracket"), self:RedrawEP())
		strTooltip = self:ConfigureEPTooltip(unitPlayer)
	else
		strXPorEP = String_GetWeaselString(Apollo.GetString("BaseBar_XPBracket"), self:RedrawXP())
		strTooltip = self:ConfigureXPTooltip(unitPlayer)
	end

	-- If grouped, Mentored by
	if tMyGroupData and #tMyGroupData.tMentoredBy ~= 0 then
		strName = String_GetWeaselString(Apollo.GetString("BaseBar_MenteeAppend"), strName)
		for idx, nMentorGroupIdx in pairs(tMyGroupData.tMentoredBy) do
			local tTargetGroupData = GroupLib.GetGroupMember(nMentorGroupIdx)
			if tTargetGroupData then
				strTooltip = "<P Font=\"CRB_InterfaceSmall_O\">"..String_GetWeaselString(Apollo.GetString("BaseBar_MenteeTooltip"), tTargetGroupData.strCharacterName).."</P>"..strTooltip
			end
		end
	end

	-- If grouped, Mentoring
	if tMyGroupData and tMyGroupData.bIsMentoring then -- unitPlayer:IsMentoring() -- tStats.effectiveLevel ~= 0 and tStats.effectiveLevel ~= tStats.level
		strName = String_GetWeaselString(Apollo.GetString("BaseBar_MentorAppend"), strName, tStats.nEffectiveLevel)
		local tTargetGroupData = GroupLib.GetGroupMember(tMyGroupData.nMenteeIdx)
		if tTargetGroupData then
			strTooltip = "<P Font=\"CRB_InterfaceSmall_O\">"..String_GetWeaselString(Apollo.GetString("BaseBar_MentorTooltip"), tTargetGroupData.strCharacterName).."</P>"..strTooltip
		end
	end

	-- If in an instance (or etc.) and Rallied
	if unitPlayer:IsRallied() and tStats.nEffectiveLevel ~= tStats.nLevel then
		strName = String_GetWeaselString(Apollo.GetString("BaseBar_RallyAppend"), strName, tStats.nEffectiveLevel)
		strTooltip = "<P Font=\"CRB_InterfaceSmall_O\">"..Apollo.GetString("BaseBar_YouAreRallyingTooltip").."</P>"..strTooltip
	end

	-- PvP
	local tPvPFlagInfo = GameLib.GetPvpFlagInfo()
	if tPvPFlagInfo and tPvPFlagInfo.bIsFlagged then
		strTextColor = self.bInCombat and ApolloColor.new("6601ff07") or ApolloColor.new("DispositionFriendly")
		strName = String_GetWeaselString(Apollo.GetString("BaseBar_PvPAppend"), strName)
	end

	self.wndPlayerName:SetText(strName)
	self.wndPlayerName:SetTextColor(strTextColor)
	self.wndPlayerNameSubtitle:SetTextColor(strTextColor)
	self.wndPlayerNameSubtitle:SetText(String_GetWeaselString(Apollo.GetString("BaseBar_SubtitleFormatting"), strLevel, strXPorEP))

	self.wndMain:FindChild("XPBarContainer"):SetBGColor(self.bInCombat and ApolloColor.new("66ffffff") or ApolloColor.new("white"))
	self.wndMain:SetTooltip(strTooltip)
end

-----------------------------------------------------------------------------------------------
-- Elder Points (When at max level)
-----------------------------------------------------------------------------------------------

function BaseBarCorner:RedrawXP()
	local nCurrentXP = GetXp() - GetXpToCurrentLevel() 		-- current amount of xp into the current level
	local nNeededXP = GetXpToNextLevel() 					-- total amount needed to move through current level
	local nRestedXP = GetRestXp() 							-- amount of rested xp
	local nRestedXPPool = GetRestXpKillCreaturePool() 		-- amount of rested xp remaining from creature kills

	if not nCurrentXP or not nNeededXP or not nNeededXP or not nRestedXP then
		return
	end

	local wndXPBarFill = self.wndMain:FindChild("XPBarContainer:XPBarFill")
	local wndRestXPBarFill = self.wndMain:FindChild("XPBarContainer:RestXPBarFill")
	local wndRestXPBarGoal = self.wndMain:FindChild("XPBarContainer:RestXPBarGoal")
	local wndMaxEPBar = self.wndMain:FindChild("XPBarContainer:DailyMaxEPBar")
	
	wndXPBarFill:SetMax(nNeededXP)
	wndXPBarFill:SetProgress(nCurrentXP)

	-- Rest Bar and Goal (where it ends)
	wndRestXPBarFill:SetMax(nNeededXP)
	wndRestXPBarFill:Show(nRestedXP and nRestedXP > 0)
	if nRestedXP and nRestedXP > 0 then
		wndRestXPBarFill:SetProgress(math.min(nNeededXP, nCurrentXP + nRestedXP))
	end

	local bShowRestXPGoal = nRestedXP and nRestedXPPool and nRestedXP > 0 and nRestedXPPool > 0
	wndRestXPBarGoal:SetMax(nNeededXP)
	wndRestXPBarGoal:Show(bShowRestXPGoal)
	if bShowRestXPGoal then
		wndRestXPBarGoal:SetProgress(math.min(nNeededXP, nCurrentXP + nRestedXPPool))
	end

	-- This is only for EP at max level
	wndMaxEPBar:SetProgress(0)
	wndMaxEPBar:Show(false)

	return math.min(99.9, nCurrentXP / nNeededXP * 100)
end

function BaseBarCorner:RedrawEP()
	local nCurrentEP = GetElderPoints()
	local nEPToAGem = GameLib.ElderPointsPerGem
	local nEPDailyMax = GameLib.ElderPointsDailyMax
	local nRestedEP = GetRestXp() 							-- amount of rested xp
	local nRestedEPPool = GetRestXpKillCreaturePool() 		-- amount of rested xp remaining from creature kills

	if not nCurrentEP or not nEPToAGem or not nEPDailyMax or not nRestedEP then
		return
	end
	
	local wndXPBarFill = self.wndMain:FindChild("XPBarContainer:XPBarFill")
	local wndRestXPBarFill = self.wndMain:FindChild("XPBarContainer:RestXPBarFill")
	local wndRestXPBarGoal = self.wndMain:FindChild("XPBarContainer:RestXPBarGoal")
	local wndMaxEPBar = self.wndMain:FindChild("XPBarContainer:DailyMaxEPBar")

	wndXPBarFill:SetMax(nEPToAGem)
	wndXPBarFill:SetProgress(nCurrentEP)

	-- Rest Bar and Goal (where it ends)
	wndRestXPBarFill:SetMax(nEPToAGem)
	wndRestXPBarFill:Show(nRestedEP and nRestedEP > 0)
	if nRestedEP and nRestedEP > 0 then
		wndRestXPBarFill:SetProgress(math.min(nEPToAGem, nCurrentEP + nRestedEP))
	end

	local bShowRestEPGoal = nRestedEP and nRestedEPPool and nRestedEP > 0 and nRestedEPPool > 0
	wndRestXPBarGoal:SetMax(nEPToAGem)
	wndRestXPBarGoal:Show(bShowRestEPGoal)
	if bShowRestEPGoal then
		wndRestXPBarGoal:SetProgress(math.min(nEPToAGem, nCurrentEP + nRestedEPPool))
	end

	-- This is special to Rested EP, as there is a daily max
	wndMaxEPBar:SetMax(nEPToAGem)
	wndMaxEPBar:Show(nEPDailyMax ~= nEPToAGem)
	if nEPDailyMax < nEPToAGem then
		wndMaxEPBar:SetProgress(nEPDailyMax)
	elseif nEPDailyMax > nEPToAGem then
		wndMaxEPBar:SetProgress(nEPToAGem)
	end

	return math.min(99.9, nCurrentEP / nEPToAGem * 100)
end

function BaseBarCorner:ConfigureEPTooltip()
	local nCurrentEP = GetElderPoints()
	local nCurrentToDailyMax = GetPeriodicElderPoints()
	local nEPToAGem = GameLib.ElderPointsPerGem
	local nEPDailyMax = GameLib.ElderPointsDailyMax

	local nRestedEP = GetRestXp() 							-- amount of rested xp
	local nRestedEPPool = GetRestXpKillCreaturePool() 		-- amount of rested xp remaining from creature kills

	if not nCurrentEP or not nEPToAGem or not nEPDailyMax then
		return
	end

	-- Top String
	local strTooltip = String_GetWeaselString(Apollo.GetString("BaseBar_ElderPointsPercent"), nCurrentEP, nEPToAGem, math.min(99.9, nCurrentEP / nEPToAGem * 100))
	if nCurrentEP == nEPDailyMax then
		strTooltip = "<P Font=\"CRB_InterfaceSmall_O\">" .. strTooltip .. "</P><P Font=\"CRB_InterfaceSmall_O\">" .. Apollo.GetString("BaseBar_ElderPointsAtMax") .. "</P>"
	else
		local strDailyMax = String_GetWeaselString(Apollo.GetString("BaseBar_ElderPointsWeeklyMax"), nCurrentToDailyMax, nEPDailyMax, math.min(99.9, nCurrentToDailyMax / nEPDailyMax * 100))
		strTooltip = "<P Font=\"CRB_InterfaceSmall_O\">" .. strTooltip .. "</P><P Font=\"CRB_InterfaceSmall_O\">" .. strDailyMax .. "</P>"
	end

	-- Rested
	if nRestedEP > 0 then
		local strRestLineOne = String_GetWeaselString(Apollo.GetString("Base_EPRested"), nRestedEP, nRestedEP / nEPToAGem * 100)
		strTooltip = string.format("%s<P Font=\"CRB_InterfaceSmall_O\" TextColor=\"ffda69ff\">%s</P>", strTooltip, strRestLineOne)

		if nCurrentEP + nRestedEPPool > nEPToAGem then
			strTooltip = string.format("%s<P Font=\"CRB_InterfaceSmall_O\" TextColor=\"ffda69ff\">%s</P>", strTooltip, Apollo.GetString("Base_EPRestedEndsAfterLevelTooltip"))
		else
			local strRestLineTwo = String_GetWeaselString(Apollo.GetString("Base_EPRestedPoolTooltip"), nRestedEPPool, ((nRestedEPPool + nCurrentEP)  / nEPToAGem) * 100)
			strTooltip = string.format("%s<P Font=\"CRB_InterfaceSmall_O\" TextColor=\"ffda69ff\">%s</P>", strTooltip, strRestLineTwo)
		end
	end

	return strTooltip
end

-----------------------------------------------------------------------------------------------
-- XP (When less than level 50)
-----------------------------------------------------------------------------------------------

function BaseBarCorner:RedrawXP()
	local nCurrentXP = GetXp() - GetXpToCurrentLevel() 		-- current amount of xp into the current level
	local nNeededXP = GetXpToNextLevel() 					-- total amount needed to move through current level
	local nRestedXP = GetRestXp() 							-- amount of rested xp
	local nRestedXPPool = GetRestXpKillCreaturePool() 		-- amount of rested xp remaining from creature kills

	if not nCurrentXP or not nNeededXP or not nNeededXP or not nRestedXP then
		return
	end
	
	local wndXPBarFill = self.wndMain:FindChild("XPBarContainer:XPBarFill")
	local wndRestXPBarFill = self.wndMain:FindChild("XPBarContainer:RestXPBarFill")
	local wndRestXPBarGoal = self.wndMain:FindChild("XPBarContainer:RestXPBarGoal")

	wndXPBarFill:SetMax(nNeededXP)
	wndXPBarFill:SetProgress(nCurrentXP)

	wndRestXPBarFill:SetMax(nNeededXP)
	wndRestXPBarFill:Show(nRestedXP and nRestedXP > 0)
	if nRestedXP and nRestedXP > 0 then
		wndRestXPBarFill:SetProgress(math.min(nNeededXP, nCurrentXP + nRestedXP))
	end

	wndRestXPBarGoal:SetMax(nNeededXP)
	wndRestXPBarGoal:Show(nRestedXP and nRestedXPPool and nRestedXP > 0 and nRestedXPPool > 0)
	if nRestedXP and nRestedXPPool and nRestedXP > 0 and nRestedXPPool > 0 then
		wndRestXPBarGoal:SetProgress(math.min(nNeededXP, nCurrentXP + nRestedXPPool))
	end

	return math.min(99.9, nCurrentXP / nNeededXP * 100)
end

function BaseBarCorner:ConfigureXPTooltip(unitPlayer)
	local nCurrentXP = GetXp() - GetXpToCurrentLevel() 		-- current amount of xp into the current level
	local nNeededXP = GetXpToNextLevel() 					-- total amount needed to move through current level
	local nRestedXP = GetRestXp() 							-- amount of rested xp
	local nRestedXPPool = GetRestXpKillCreaturePool() 		-- amount of rested xp remaining from creature kills

	if not nCurrentXP or not nNeededXP or not nNeededXP or not nRestedXP then
		return
	end

	local strTooltip = string.format("<P Font=\"CRB_InterfaceSmall_O\">%s</P>", String_GetWeaselString(Apollo.GetString("Base_XPValue"), nCurrentXP, nNeededXP, nCurrentXP / nNeededXP * 100))
	if nRestedXP > 0 then
		local strRestLineOne = String_GetWeaselString(Apollo.GetString("Base_XPRested"), nRestedXP, nRestedXP / nNeededXP * 100)
		strTooltip = string.format("%s<P Font=\"CRB_InterfaceSmall_O\" TextColor=\"ffda69ff\">%s</P>", strTooltip, strRestLineOne)

		if nCurrentXP + nRestedXPPool > nNeededXP then
			strTooltip = string.format("%s<P Font=\"CRB_InterfaceSmall_O\" TextColor=\"ffda69ff\">%s</P>", strTooltip, Apollo.GetString("Base_XPRestedEndsAfterLevelTooltip"))
		else
			local strRestLineTwo = String_GetWeaselString(Apollo.GetString("Base_XPRestedPoolTooltip"), nRestedXPPool, ((nRestedXPPool + nCurrentXP)  / nNeededXP) * 100)
			strTooltip = string.format("%s<P Font=\"CRB_InterfaceSmall_O\" TextColor=\"ffda69ff\">%s</P>", strTooltip, strRestLineTwo)
		end
	end
	return strTooltip
end

-----------------------------------------------------------------------------------------------
-- Events to Redraw All
-----------------------------------------------------------------------------------------------

function BaseBarCorner:OnEnteredCombat(unitArg, bInCombat)
	if unitArg == GameLib.GetPlayerUnit() then
		self.bInCombat = bInCombat
		self:RedrawAll()
	end
end

function BaseBarCorner:OnClearCombatFlag()
	self.bInCombat = false
	self:RedrawAll()
end

local BaseBarCornerInst = BaseBarCorner:new()
BaseBarCornerInst:Init()
