-----------------------------------------------------------------------------------------------
-- Client Lua Script for Options
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Apollo"
require "Window"

local OptionsAddon = {}

---------------------------------------------------------------------------------------------------
-- local constants
---------------------------------------------------------------------------------------------------

local kfFrameTime = 0.10
local kfMetersPerUpdate = 32
local kstrFormFile = "OptionsForms.xml"

local karStatusTextString =
{
	"Options_AddonInvalid",
	"Options_AddonOff",
	"Options_AddonError",
	"Options_AddonLoaded",
	"Options_AddonSuspended",
	"Options_AddonRunningWithErrors",
	"",
}

local karStatusText =
{
	"CRB_ModuleStatus_Invalid",
	"CRB_ModuleStatus_NotLoaded",
	"CRB_ModuleStatus_ParsingError",
	"CRB_ModuleStatus_Loaded",
	"CRB_ModuleStatus_Suspended",
	"CRB_ModuleStatus_RunningWithErrors",
	"CRB_ModuleStatus_RunningOk",
}

local karStatusColors =
{
	ApolloColor.new("AddonError"),
	ApolloColor.new("AddonNotLoaded"),
	ApolloColor.new("AddonError"),
	ApolloColor.new("AddonLoaded"),
	ApolloColor.new("AddonError"),
	ApolloColor.new("AddonWarning"),
	ApolloColor.new("AddonOk"),
}

local EnumAddonColumns =
{
	Status 			= 1,
	Name 			= 2,
	Folder 			= 3,
	Author			= 4,
	Memory 			= 5,
	Calls 			= 6,
	TotalTime 		= 7,
	MaxTime 		= 8,
	MsPerFrame         = 9,
	LastModified 	= 10,
	APIVersion 		= 11,
	Replaces 		= 12,
	LoadSetting 	= 13,
}

---------------------------------------------------------------------------------------------------
-- Options initialization
---------------------------------------------------------------------------------------------------
function OptionsAddon:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	return o
end

---------------------------------------------------------------------------------------------------
function OptionsAddon:Init()
	Apollo.RegisterAddon(self)
end

---------------------------------------------------------------------------------------------------
-- Options EventHandlers
---------------------------------------------------------------------------------------------------


function OptionsAddon:OnLoad()
	Apollo.RegisterTimerHandler("ResChangedTimer", 		"OnResChangedTimer", self)
	Apollo.RegisterTimerHandler("ResExChangedTimer", 	"OnResExChangedTimer", self)
	Apollo.RegisterTimerHandler("AddonsUpdateTimer", 	"OnAddonsUpdateTimer", self)
	
	Apollo.RegisterEventHandler("SystemKeyDown", 		"OnSystemKeyDown", self)
	Apollo.RegisterEventHandler("TriggerDemoOptions", 	"OnInvokeOptionsScreen", self) --gamescom
	Apollo.RegisterEventHandler("EnteredCombat", 		"OnEnteredCombat", self)
	Apollo.RegisterEventHandler("RefreshOptionsDialog", "OnRefreshOptionsDialog", self)
	Apollo.RegisterEventHandler("InvokeEscapeMenu", 	"OnEscapeMenu", self)

	Apollo.CreateTimer("ResChangedTimer", 1.000, false)
	Apollo.StopTimer("ResChangedTimer")

	Apollo.CreateTimer("ResExChangedTimer", 1.000, false)
	Apollo.StopTimer("ResExChangedTimer")

	if IsDemo() then
		Apollo.CreateTimer("DemoTimer", 1.0, true)
		Apollo.RegisterTimerHandler("DemoTimer", "OnDemoTimer", self)
	end

	self.wndDemo = Apollo.LoadForm(kstrFormFile, "DemoOptions", nil, self)
	self.wndDemo:Show(IsDemo())

	self.wndDemoGoodbye = Apollo.LoadForm(kstrFormFile, "DemoSummary", nil, self)
	self.wndDemoGoodbye:Show(false)


	self.wndAddCoins = Apollo.LoadForm(kstrFormFile, "DemoAddCoin", nil, self)
	self.wndAddCoins:Show(false)

	self.tAddons = {}
	self.nSortedBy = 0

	self.OptionsDlg = Apollo.LoadForm(kstrFormFile, "OptionsMenu", nil, self)
	self.OptionsDlg:Show(not IsDemo())
	self.OptionsDlg:SetFocus()

	self.wndVideo = Apollo.LoadForm(kstrFormFile, "VideoOptionsDialog", nil, self)
	self.wndVideo:FindChild("ResolutionParent"):FindChild("Resolution"):Enable(true)
	self.wndVideo:FindChild("DropToggleExclusive"):AttachWindow(self.wndVideo:FindChild("ResolutionParent"))
	self.wndVideoConfirm = self.wndVideo:FindChild("TimedChangeBlocker")
	self.wndVideoConfirm:Show(false)


	----

	self.wndSounds = Apollo.LoadForm(kstrFormFile, "SoundOptionsDialog", nil, self)
	self.wndAddons = Apollo.LoadForm(kstrFormFile, "AddonsDialog", nil, self)
	
	self.wndTargeting = Apollo.LoadForm(kstrFormFile, "TargettingDialog", nil, self)
	Apollo.LoadForm(kstrFormFile, "TargettingDialogControls", self.wndTargeting:FindChild("GroupContainer"), self)
	

	self.bAddonsTimerCreated = false
	self.OptionsDlg:SetRadioSel("OptionsGroup", 0)
	self:OnOptionsCheck()

	self.nDemoAutoTimeout = 0 -- TODO: more demo crap to remove

	if IsDemo() then
		self.mapCB2CVs = {
			-- interface
			{wnd = self.wndDemo:FindChild("InvertMouse"), 		consoleVar = "camera.invertMouse"},
			{wnd = self.wndDemo:FindChild("ClickToMove"), 		consoleVar = "player.clickToMove"},
			{wnd = self.wndDemo:FindChild("MoveToActivate"),	consoleVar = "player.moveToActivate"},
			{wnd = self.wndDemo:FindChild("DashDoubleTapBtn"),	consoleVar = "player.doubleTapToDash"},
			{wnd = self.wndDemo:FindChild("DashDirectionalBtn"),	consoleVar = "player.directionalDashBackward"},
		}
	else
		self.mapCB2CVs =  -- these are auto-mapped options than don't need custom handlers
		{
			-- video options
			--{wnd = self.wndVideo:FindChild("FullScreen"), 			consoleVar = "video.fullscreen"},
			--{wnd = self.wndVideo:FindChild("Maximized"), 			consoleVar = "video.windowMaximized"},
			{wnd = self.wndVideo:FindChild("VerticalSync"), 		consoleVar = "video.verticalSync"},
			--{wnd = self.wndVideo:FindChild("Exclusive"), 			consoleVar = "video.exclusive"},
			--{wnd = self.wndVideo:FindChild("TripleBuffer"), 		consoleVar = "video.exclusiveTripleBuffer"},
			{wnd = self.wndVideo:FindChild("EnableCameraShake"), 	consoleVar = "camera.shake"},
			--{wnd = self.wndVideo:FindChild("DisableFluxEffect"), 	consoleVar = "flux.disable"},
			{wnd = self.wndVideo:FindChild("EnableFixedCamera"), 	consoleVar = "camera.reorient"},
			{wnd = self.wndVideo:FindChild("EnableFXAA"), 			consoleVar = "fxaa.enable"}
		}
	end

	self.mapSB2CVs =  -- these are auto-mapped sliders that don't need custom handlers
	{
		-- video options
		--{wnd = self.wndVideo:FindChild("NightScale"), 				consoleVar = "sky.nightScale",		buddy = self.wndVideo:FindChild("NightScaleBox")},
		{wnd = self.wndVideo:FindChild("ViewDistanceSlider"), 		consoleVar = "lod.viewDistance",		buddy = self.wndVideo:FindChild("ViewDistanceEditBox")},
		{wnd = self.wndVideo:FindChild("VDFogSlider"), 				consoleVar = "lod.farFogDistance",		buddy = self.wndVideo:FindChild("VDFogEditBox")},
		{wnd = self.wndVideo:FindChild("ClutterDistanceSlider"), 	consoleVar = "lod.clutterDistance",		buddy = self.wndVideo:FindChild("ClutterDistanceEditBox")},
		{wnd = self.wndVideo:FindChild("CameraDistanceSlider"),		consoleVar = "camera.distanceMax",		buddy = self.wndVideo:FindChild("CameraDistanceEditBox")},
		{wnd = self.wndVideo:FindChild("ParallaxSlider"),			consoleVar = "lod.landLod",				buddy = self.wndVideo:FindChild("ParallaxEditBox")},
		{wnd = self.wndVideo:FindChild("RenderScaleSlider"),		consoleVar = "lod.renderTargetScale", 	buddy = self.wndVideo:FindChild("RenderScaleEditBox")},
		{wnd = self.wndVideo:FindChild("FXAASlider"),				consoleVar = "fxaa.preset",				buddy = self.wndVideo:FindChild("FXAAEditBox")},
		{wnd = self.wndVideo:FindChild("GammaScaleSlider"),			consoleVar = "ppp.gamma",				buddy = self.wndVideo:FindChild("GammaScaleEditBox")},
		{wnd = self.wndVideo:FindChild("SceneDetailSlider"),		consoleVar = "world.propScreenHeightPercentMin",	buddy = self.wndVideo:FindChild("SceneDetailEditBox")},
		
		-- audio options
		{wnd = self.wndSounds:FindChild("MasterVolume"), 		consoleVar = "sound.volumeMaster"},
		{wnd = self.wndSounds:FindChild("MusicVolume"), 		consoleVar = "sound.volumeMusic"},
		{wnd = self.wndSounds:FindChild("UIVolume"), 			consoleVar = "sound.volumeUI"},
		{wnd = self.wndSounds:FindChild("SoundFXVolume"), 		consoleVar = "sound.volumeSfx"},
		{wnd = self.wndSounds:FindChild("AmbientVolume"), 		consoleVar = "sound.volumeAmbient"},
		{wnd = self.wndSounds:FindChild("VoiceVolume"), 		consoleVar = "sound.volumeVoice"},
	}

	self.mapDDParents = {
		{wnd = self.wndVideo:FindChild("DropToggleResolution"),		consoleVar = "video.fullscreen", 		radio = "ResolutionMode"},
		{wnd = self.wndVideo:FindChild("DropToggleTexLOD"),			consoleVar = "lod.textureLodMin",		radio = "TextureResolution"},
		{wnd = self.wndVideo:FindChild("DropToggleTexFilter"),		consoleVar = "lod.textureFilter", 		radio = "TextureFiltering"},
		{wnd = self.wndVideo:FindChild("DropToggleClutterDensity"),	consoleVar = "lod.clutterDensity", 		radio = "ClutterDensity"},
		{wnd = self.wndVideo:FindChild("DropToggleShadow"),			consoleVar = "draw.shadows", 			radio = "ShadowSetting"},
	}

	for idx, wndDD in pairs(self.mapDDParents) do
		wndDD.wnd:AttachWindow(wndDD.wnd:FindChild("ChoiceContainer"))
		wndDD.wnd:FindChild("ChoiceContainer"):Show(false)
	end

	self.tPrevExcRes = nil
	self.tPrevResSettings = nil

	local bPlayerSetting = Apollo.GetConsoleVariable("player.showDoubleTapToDash")
	Apollo.SetConsoleVariable("player.doubleTapToDash", bPlayerSetting) -- these should match

	self:InitOptionsControls()

	self.bReachedTheEnd = false
	self.pathMissionCount = 1
	self.pathMissionCompleted = 1

	if not self.bAddonsTimerCreated and not IsDemo() then
		Apollo.CreateTimer("AddonsUpdateTimer", 1.0, true)
		self.bAddonsTimerCreated = true
	end
end


---------------------------------------------------------------------------------------------------
-- Functions
---------------------------------------------------------------------------------------------------

function OptionsAddon:OnRefreshOptionsDialog()
	if not self.OptionsDlg:IsShown() then
		return
	end

	self:OnOptionsCheck()
end

function OptionsAddon:OnOptionsCheck()
	local nOptions = self.OptionsDlg:FindChild("InnerFrame"):GetRadioSel("OptionsGroup")
	self.wndVideo:Show(nOptions == 1)
	self.wndSounds:Show(nOptions == 2)
	self.wndAddons:Show(nOptions == 3)
	self.wndTargeting:Show(nOptions == 4)

	if nOptions ~= 1 and self.nOptionsTimer ~= 0 then -- unsaved graphic change
		self:OnChangeCancelBtn()
	end

	if nOptions == 1 then
		self:InitOptionsControls()
		self:EnableVideoControls()
	elseif nOptions == 3 then
		self:OnAddonsCheck(true)
	elseif nOptions == 4 then
		self.wndTargeting:FindChild("UseButtonDownBtn"):SetCheck(Apollo.GetConsoleVariable("spell.useButtonDownForAbilities"))
		self.wndTargeting:FindChild("HoldToContinueCastingBtn"):SetCheck(Apollo.GetConsoleVariable("spell.holdToContinueCasting"))
		self.wndTargeting:FindChild("UseAbilityQueueBtn"):SetCheck(Apollo.GetConsoleVariable("player.abilityQueueMax") > 0)
		self.wndTargeting:FindChild("AutoSelfCastBtn"):SetCheck(Apollo.GetConsoleVariable("spell.autoSelectCharacter"))
		self.wndTargeting:FindChild("MoveToBtn"):SetCheck(Apollo.GetConsoleVariable("Player.moveToTargetOnSelfAOE"))
		self.wndTargeting:FindChild("AlwaysFaceBtn"):SetCheck(not Apollo.GetConsoleVariable("Player.ignoreAlwaysFaceTarget"))
		self.wndTargeting:FindChild("FacingLockBtn"):SetCheck(not Apollo.GetConsoleVariable("Player.disableFacingLock"))
		self.wndTargeting:FindChild("AutoPushTarget"):SetCheck(Apollo.GetConsoleVariable("spell.disableAutoTargeting"))
		self.wndTargeting:FindChild("DashDoubleTapBtn"):SetCheck(Apollo.GetConsoleVariable("player.showDoubleTapToDash"))
		self.wndTargeting:FindChild("DashDirectionalBtn"):SetCheck(Apollo.GetConsoleVariable("player.directionalDashBackward"))
		self.wndTargeting:FindChild("SelfOpacitySliderBar"):SetValue(Apollo.GetConsoleVariable("spell.selfTelegraphOpacity") or 0)
		self.wndTargeting:FindChild("EnemyDetrimentalOpacitySliderBar"):SetValue(Apollo.GetConsoleVariable("spell.enemyDetrimentalTelegraphOpacity") or 0)
		self.wndTargeting:FindChild("AllyBeneficialOpacitySliderBar"):SetValue(Apollo.GetConsoleVariable("spell.allyBeneficialTelegraphOpacity") or 0)
		self.wndTargeting:FindChild("OtherActionOpacitySliderBar"):SetValue(Apollo.GetConsoleVariable("spell.enemyBeneficalAllyDetrimentalTelegraphOpacity") or 0)
		-- NOTE: all 4 outlines are being set to the same value so reading any 1 of them will be valid.
		self.wndTargeting:FindChild("OutlineOpacitySliderBar"):SetValue(Apollo.GetConsoleVariable("spell.selfTelegraphOutline") or 0)
		self.wndTargeting:FindChild("SelfDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.selfTelegraphDisplay"))
		self.wndTargeting:FindChild("EnemyDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.enemyTelegraphDisplay"))
		self.wndTargeting:FindChild("EnemyNPCDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.enemyNPCTelegraphDisplay"))
		self.wndTargeting:FindChild("EnemyNPCBeneficialDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.enemyNPCBeneficialTelegraphDisplay"))
		self.wndTargeting:FindChild("EnemyNPCDetrimentalDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.enemyNPCDetrimentalTelegraphDisplay"))
		self.wndTargeting:FindChild("EnemyPlayerDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.enemyPlayerTelegraphDisplay"))
		self.wndTargeting:FindChild("EnemyPlayerBeneficialDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.enemyPlayerBeneficialTelegraphDisplay"))
		self.wndTargeting:FindChild("EnemyPlayerDetrimentalDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.enemyPlayerDetrimentalTelegraphDisplay"))
		self.wndTargeting:FindChild("AllyDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.allyTelegraphDisplay"))
		self.wndTargeting:FindChild("PartyAllyDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.partyMemberAllyTelegraphDisplay"))
		self.wndTargeting:FindChild("AllyNPCDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.enemyNPCTelegraphDisplay"))
		self.wndTargeting:FindChild("AllyNPCBeneficialDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.allyNPCBeneficialTelegraphDisplay"))
		self.wndTargeting:FindChild("AllyNPCDetrimentalDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.allyNPCDetrimentalTelegraphDisplay"))
		self.wndTargeting:FindChild("AllyPlayerDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.enemyPlayerTelegraphDisplay"))
		self.wndTargeting:FindChild("AllyPlayerBeneficialDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.allyPlayerBeneficialTelegraphDisplay"))
		self.wndTargeting:FindChild("AllyPlayerDetrimentalDisplayBtn"):SetCheck(Apollo.GetConsoleVariable("spell.allyPlayerDetrimentalTelegraphDisplay"))
		self.wndTargeting:FindChild("ColorBlindNoneBtn"):SetCheck(Apollo.GetConsoleVariable("world.telegraphColorblindDisplay") == 0)
		self.wndTargeting:FindChild("ColorBlindDeuteranopialBtn"):SetCheck(Apollo.GetConsoleVariable("world.telegraphColorblindDisplay") == 1)
		self.wndTargeting:FindChild("ColorBlindProtanopiaBtn"):SetCheck(Apollo.GetConsoleVariable("world.telegraphColorblindDisplay") == 2)
		self.wndTargeting:FindChild("ColorBlindTratanopiaBtn"):SetCheck(Apollo.GetConsoleVariable("world.telegraphColorblindDisplay") == 3)
	end
end

---------------------------------------------------------------------------------------------------
-- Addons Management functions
---------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------
-- AddonsDialog Functions
---------------------------------------------------------------------------------------------------

function SortConfigButtons(wnd1, wnd2)
	local str1 = ""
	local str2 = ""
	
	if wnd1 ~= nil and wnd1:FindChild("ConfigureAddonBtn") ~= nil then
		str1 = wnd1:FindChild("ConfigureAddonBtn"):GetText()
	end
	if wnd2 ~= nil and wnd2:FindChild("ConfigureAddonBtn") ~= nil then
		str2 = wnd2:FindChild("ConfigureAddonBtn"):GetText()
	end
	return str1 < str2
end

function OptionsAddon:FillConfigureList()
	self:GetAddonsList()
	--Apollo.DPF("In FillConfigureList")
	local wndList = self.OptionsDlg:FindChild("ConfigureList")

	if self.tConfigureButtons == nil then
		self.tConfigureButtons = {}
	end

	-- copy all existing addons into kill list
	local tKill = {}
	for k, v in pairs(self.tConfigureButtons) do
		tKill[k] = v
	end

	for i, tAddon in ipairs(self.tAddons) do
		if tAddon.bHasConfigure then
			if self.tConfigureButtons[tAddon.strFolder] == nil then
				local wndConf = Apollo.LoadForm(kstrFormFile, "ConfigureAddonItem", wndList, self)
				wndConf:FindChild("ConfigureAddonBtn"):SetText(tAddon.strConfigureButtonText)
				wndConf:FindChild("ConfigureAddonBtn"):SetData(tAddon.strFolder)
				self.tConfigureButtons[tAddon.strFolder] = wndConf
			else
				self.tConfigureButtons[tAddon.strFolder]:FindChild("ConfigureAddonBtn"):SetText(tAddon.strConfigureButtonText)
			end
			-- remove the addon from the kill list
			tKill[tAddon.strFolder] = nil
		end
	end

	-- if any items remain in kill list, destroy them because we the addon has disappeared
	for k, wnd in pairs(tKill) do
		wnd:Destroy()
		self.tConfigureButtons[k] = nil
	end

	wndList:ArrangeChildrenVert(0, SortConfigButtons)
end

function OptionsAddon:UpdateAddonInfo(tAddon)
	tAddon.strStatus = Apollo.GetString(karStatusText[tAddon.eStatus])

	if tAddon.bCarbine then
		tAddon.strAuthor = Apollo.GetString("Options_AuthorCarbine")
	else
		tAddon.strAuthor = Apollo.GetString("Options_AuthorUnknown") -- this is temporary until the real info is passed from the client
	end
end

function OptionsAddon:GetAddonsList()
	self.tAddons = GetAddons()

	for idx, tAddon in ipairs(self.tAddons) do
		self:UpdateAddonInfo(tAddon)
	end
end

function OptionsAddon:UpdateAddonGridRow(wndGrid, nRow, tAddon)
	wndGrid:SetCellLuaData(nRow, EnumAddonColumns.Name, tAddon.strFolder)
	wndGrid:SetCellText(nRow, EnumAddonColumns.Name, tAddon.strName)
	wndGrid:SetCellText(nRow, EnumAddonColumns.Folder, tAddon.strFolder)
	wndGrid:SetCellText(nRow, EnumAddonColumns.Author, tAddon.strAuthor)
	wndGrid:SetCellText(nRow, EnumAddonColumns.APIVersion, tostring(tAddon.nAPIVersion))

	local strReplace = ""
	for idx, strAddon in ipairs(tAddon.arReplacedAddons) do
		if string.len(strReplace) > 0 then
			strReplace = String_GetWeaselString(Apollo.GetString("Archive_TextList"), strReplace, strAddon)
		else
			strReplace = strAddon
		end
	end
	wndGrid:SetCellText(nRow, EnumAddonColumns.Replaces, strReplace)

	local fTotalTime 	= tAddon.fTotalTime or 0.0
	local nTotalCalls 	= tAddon.nTotalCalls or 0
	local strTotalCalls = string.format("%5d", nTotalCalls)
	local fLongest 		= tAddon.fLongestCall or 0.0
	local strKb 		= string.format("%10.2fKb", tAddon.nMemoryUsage / 1024)
	local strTotalTime 	= string.format("%10.3fs", fTotalTime)
	local strLongest 	= string.format("%10.3fs", fLongest)
	local strMsPerFrame = string.format("%10.3fms", tAddon.fCallTimePerFrame * 1000.0)
	local strStatus 	= Apollo.GetString(karStatusTextString[tAddon.eStatus])

	wndGrid:SetCellText(nRow, EnumAddonColumns.Memory, strKb)
	wndGrid:SetCellText(nRow, EnumAddonColumns.Calls, strTotalCalls)
	wndGrid:SetCellText(nRow, EnumAddonColumns.TotalTime, strTotalTime)
	wndGrid:SetCellText(nRow, EnumAddonColumns.MaxTime, strLongest)
	wndGrid:SetCellText(nRow, EnumAddonColumns.MsPerFrame, strMsPerFrame)
	wndGrid:SetCellText(nRow, EnumAddonColumns.Status, strStatus)
	wndGrid:SetCellImage(nRow, EnumAddonColumns.Status, "CRB_MinimapSprites:sprMMIndicator")
	wndGrid:SetCellImageColor(nRow, EnumAddonColumns.Status, karStatusColors[tAddon.eStatus])
	
	local strLoad = Apollo.GetString("CRB_No")
	if WillAddonLoad(tAddon.strFolder) then
		strLoad = Apollo.GetString("CRB_Yes")
	end
	wndGrid:SetCellText(nRow, EnumAddonColumns.LoadSetting, strLoad)
	wndGrid:SetCellText(nRow, EnumAddonColumns.LastModified, tAddon.strLastModified)
	wndGrid:SetCellSortText(nRow, EnumAddonColumns.LastModified, tAddon.strLastModifiedSort)
end

function OptionsAddon:OnAddonsCheck(bReload)
	if bReload or self.tAddons == nil then
		self:GetAddonsList()
		self.wndAddons:FindChild("LoadSettings"):Enable(false)
		self.wndAddons:FindChild("ShowError"):Enable(false)
		self.wndAddons:FindChild("Configure"):Enable(false)
	end

	if self.wndErrorDetail ~= nil then
		self.wndErrorDetail:Destroy()
		self.wndErrorDetail = nil
	end
	if self.wndLoadConditions ~= nil then
		self.wndLoadConditions:Destroy()
		self.wndLoadConditions = nil
	end

	local wndGrid = self.wndAddons:FindChild("AddonGrid")
	local nPos = wndGrid:GetVScrollPos()
	local nSortCol = wndGrid:GetSortColumn() or 1
	local bAscending = wndGrid:IsSortAscending()

	wndGrid:DeleteAll()
	for idx, tAddon in ipairs(self.tAddons) do
		local nRow = wndGrid:AddRow(tAddon.strName)
		wndGrid:SetCellLuaData(nRow, EnumAddonColumns.Name, tAddon.strFolder)
		self:UpdateAddonGridRow(wndGrid, nRow, tAddon)
	end
	wndGrid:SetSortColumn(nSortCol, bAscending)
	wndGrid:SetVScrollPos(nPos)
end

function OptionsAddon:OnAddonsUpdateTimer()
	if not IsScreenVisible() then
		return
	end

	self:FillConfigureList()
	self.OptionsDlg:FindChild("Camp"):Enable(IsInGame())

	if IsInCombat() then
		self.OptionsDlg:FindChild("OptionsLabel"):SetTextColor(CColor.new(1, 0, 0, 1))
	else
		self.OptionsDlg:FindChild("OptionsLabel"):SetTextColor(CColor.new(1, 1, 1, 1))
	end

	-- TODO: this logic got borked at some point (addition of the timer?) and the highlight is always shown. Need to investigate. 
	if self.wndAddons:IsVisible() then
		local wndGrid = self.wndAddons:FindChild("AddonGrid")
		local arRowsToRemove = {}
		local bHighlightReloadButton = false
		for iRow = 1, wndGrid:GetRowCount() do
			local tNewInfo = GetAddonInfo(wndGrid:GetCellData(iRow, 2))
			if tNewInfo == nil then
				arRowsToRemove[#arRowsToRemove + 1] = iRow
			else
				self:UpdateAddonGridRow(wndGrid, iRow, tNewInfo)

				if (WillAddonLoad(tNewInfo.strFolder) and tNewInfo.eStatus <= OptionsScreen.CodeEnumAddonStatus.ParsingError)
					or (not WillAddonLoad(tNewInfo.strFolder) and tNewInfo.eStatus >= OptionsScreen.CodeEnumAddonStatus.Loaded) then
					bHighlightReloadButton = true
				end
			end
		end
		if bHighlightReloadButton then
			--self.wndAddons:FindChild("ReloadUI"):ChangeArt("CRB_UIKitSprites:btn_square_LARGE_Green")
			self.wndAddons:FindChild("ClickReloadPrompt"):Show(true)
		else
			--self.wndAddons:FindChild("ReloadUI"):ChangeArt("CRB_UIKitSprites:btn_square_LARGE_Red")
			self.wndAddons:FindChild("ClickReloadPrompt"):Show(false)
		end

		for iRow = 1, #arRowsToRemove do
			--wndGrid:DeleteRow(arRowsToRemove[iRow])
			-- TODO TEMP disabled for now
		end
	end
end


function OptionsAddon:OnShowErrors(wndHandler, wndControl)

	if self.strSelectedAddon == nil then
		return
	end

	local tAddon = GetAddonInfo(self.strSelectedAddon)
	if tAddon == nil then
		return
	end

	if self.wndErrorDetail ~= nil then
		self.wndErrorDetail:Destroy()
		self.wndErrorDetail = nil
	end

	local wnd = Apollo.LoadForm("OptionsForms.xml", "AddonError", "OptionsDialogs", self)

	local strError = ""
	for i, str in ipairs(tAddon.arErrors) do
		strError = strError .. str .. "\r\n\r\n"
	end

	wnd:FindChild("ErrorText"):SetText(strError)
	wnd:ToFront()
	self.wndErrorDetail = wnd

end

function OptionsAddon:OnCloseErrorWindow(wndHandler, wndControl)
	wndHandler:GetParent():Destroy()
end

function OptionsAddon:OnCopyToClipboard(wndHandler, wndControl)
	local wnd = wndHandler:GetParent()
	wnd:FindChild("ErrorText"):CopyTextToClipboard()
end


function OptionsAddon:InvokeAddonLoadOnStartDlg(tAddon)

	-- TEMPORARY SOLUTION FOR FX-68822
	if tAddon.strFolder == "EscapeMenu" then
		return
	end

	if self.wndLoadConditions ~= nil then
		self.wndLoadConditions:Destroy()
		self.wndLoadConditions = nil
	end

	local wnd = Apollo.LoadForm("OptionsForms.xml", "AddonLoadOptions", "OptionsDialogs", self)

	self.wndLoadConditions = wnd
	wnd:SetData(tAddon.strFolder)
	self:UpdateAddonLoadSetting(wnd)

	local mapLoadSettingToRadio = {
		[OptionsScreen.CodeEnumLoadType.Default] = 3,
		[OptionsScreen.CodeEnumLoadType.Yes] = 1,
		[OptionsScreen.CodeEnumLoadType.No] = 2,
	}

	--[[
	for k,v in pairs(OptionsScreen) do
		Apollo.DPF("OptionsScreen["..tostring(k).."] = " .. tostring(v))
	end
	for k,v in pairs(OptionsScreen.CodeEnumLoadType) do
		Apollo.DPF("OptionsScreen.CodeEnumLoadType["..tostring(k).."] = " .. tostring(v))
	end
	for k,v in pairs(OptionsScreen.CodeEnumLoadLevel) do
		Apollo.DPF("OptionsScreen.CodeEnumLoadLevel["..tostring(k).."] = " .. tostring(v))
	end
	--]]

	local tInfo = GetAccountRealmCharacter()
	wnd:FindChild("Character"):SetText(tInfo.strCharacter)
	wnd:FindChild("Realm"):SetText(tInfo.strRealm)
	wnd:FindChild("Account"):SetText(tInfo.strAccount)

	wnd:FindChild("OptionsFrame"):SetRadioSel("MachineLoad", mapLoadSettingToRadio[tAddon.arLoadConditions[OptionsScreen.CodeEnumLoadLevel.Machine]])
	wnd:FindChild("AdvancedAddonOptions"):SetRadioSel("AccountLoad", mapLoadSettingToRadio[tAddon.arLoadConditions[OptionsScreen.CodeEnumLoadLevel.Account]])
	wnd:FindChild("AdvancedAddonOptions"):SetRadioSel("RealmLoad", mapLoadSettingToRadio[tAddon.arLoadConditions[OptionsScreen.CodeEnumLoadLevel.Realm]])
	wnd:FindChild("AdvancedAddonOptions"):SetRadioSel("CharacterLoad", mapLoadSettingToRadio[tAddon.arLoadConditions[OptionsScreen.CodeEnumLoadLevel.Character]])
	wnd:FindChild("AdvancedAddonOptions"):FindChild("IgnoreVersionMismatch"):SetCheck(tAddon.bIgnoreVersion)

	--SetAddonLoadOnStart(tAddon.strFolder, wndHandler:IsChecked())
end

function OptionsAddon:OnSetToDefault()
	self:HelperUncheckAllInnerFrame()
	ResetToDefaultAddons()
end

function OptionsAddon:HelperUncheckAllInnerFrame()
	self.OptionsDlg:FindChild("VideoBtn"):SetCheck(false)
	self.OptionsDlg:FindChild("SoundBtn"):SetCheck(false)
	self.OptionsDlg:FindChild("ExitGame"):SetCheck(false)
	self.OptionsDlg:FindChild("AddonsBtn"):SetCheck(false)
	self.OptionsDlg:FindChild("TargetingBtn"):SetCheck(false)

	self.wndVideo:Show(false)
	self.wndSounds:Show(false)
	self.wndAddons:Show(false)
	self.wndTargeting:Show(false)
end

local g_mapRadioToLoadSetting = {
	OptionsScreen.CodeEnumLoadType.Yes,
	OptionsScreen.CodeEnumLoadType.No,
	OptionsScreen.CodeEnumLoadType.Default,
}

function OptionsAddon:UpdateAddonLoadSetting(wnd)
	local tAddon = GetAddonInfo(wnd:GetData())
	local str = tAddon.strName
	if WillAddonLoad(tAddon.strFolder) then
		str = String_GetWeaselString(Apollo.GetString("Options_WillLoad"), str)
	else
		str = String_GetWeaselString(Apollo.GetString("Options_WillNotLoad"), str)
	end
	wnd:FindChild("AddonTitle"):SetText(str)

	local nAPIVersion = Apollo.GetAPIVersion()
	local str = String_GetWeaselString(Apollo.GetString("Options_APICheck"), nAPIVersion, tAddon.nAPIVersion)
	wnd:FindChild("VersionMatchInformation"):SetText(str)
	if nAPIVersion == tAddon.nAPIVersion then
		wnd:FindChild("VersionMatchInformation"):SetTextColor(CColor.new(1, 1, 1, 1))
	else
		wnd:FindChild("VersionMatchInformation"):SetTextColor(CColor.new(1, 0, 0, 1))
	end
end

function OptionsAddon:OnIgnoreVersionMismatchCheck(wndHandler, wndControl, eMouseButton)
end

function OptionsAddon:OnChangeMachineLoad(wndHandler, wndControl, eMouseButton)
	local wndAddon = wndHandler:GetParent():GetParent()
	local tAddon = GetAddonInfo(wndAddon:GetData())

	local nRadio = wndHandler:GetParent():GetRadioSel("MachineLoad")
	SetAddonLoadCondition(tAddon.strFolder, OptionsScreen.CodeEnumLoadLevel.Machine, g_mapRadioToLoadSetting[nRadio])
	self:UpdateAddonLoadSetting(wndAddon)
end

function OptionsAddon:OnChangeAccountLoad(wndHandler, wndControl, eMouseButton)
	local wndAddon = wndHandler:GetParent():GetParent()
	local tAddon = GetAddonInfo(wndAddon:GetData())

	local nRadio = wndHandler:GetParent():GetRadioSel("AccountLoad")
	SetAddonLoadCondition(tAddon.strFolder, OptionsScreen.CodeEnumLoadLevel.Account, g_mapRadioToLoadSetting[nRadio])
	self:UpdateAddonLoadSetting(wndAddon)
end

function OptionsAddon:OnChangeRealmLoad(wndHandler, wndControl, eMouseButton)
	local wndAddon = wndHandler:GetParent():GetParent()
	local tAddon = GetAddonInfo(wndAddon:GetData())

	local nRadio = wndHandler:GetParent():GetRadioSel("RealmLoad")
	SetAddonLoadCondition(tAddon.strFolder, OptionsScreen.CodeEnumLoadLevel.Realm, g_mapRadioToLoadSetting[nRadio])
	self:UpdateAddonLoadSetting(wndAddon)
end

function OptionsAddon:OnChangeCharacterLoad(wndHandler, wndControl, eMouseButton)
	local wndAddon = wndHandler:GetParent():GetParent()
	local tAddon = GetAddonInfo(wndAddon:GetData())

	local nRadio = wndHandler:GetParent():GetRadioSel("CharacterLoad")
	SetAddonLoadCondition(tAddon.strFolder, OptionsScreen.CodeEnumLoadLevel.Character, g_mapRadioToLoadSetting[nRadio])
	self:UpdateAddonLoadSetting(wndAddon)
end

function OptionsAddon:OnEnableAddonCheck(wndHandler, wndControl, eMouseButton)
	local wndAddon = wndHandler:GetParent():GetParent()
	local tAddon = GetAddonInfo(wndAddon:GetData())
	self:UpdateAddonLoadSetting(wndAddon)
end

function OptionsAddon:OnAddonShowAdvancedToggle(wndHandler, wndControl)
	wndHandler:GetParent():FindChild("AdvancedAddonOptions"):Show(wndHandler:IsChecked())
end

function OptionsAddon:OnCloseAddonWindow(wndHandler, wndControl, eMouseButton)
	wndHandler:GetParent():Destroy()
end

function OptionsAddon:OnIgnoreVersionMismatchCheck(wndHandler, wndControl, eMouseButton)
	local bChecked = wndHandler:IsChecked()
	local wndAddon = wndHandler:GetParent():GetParent()
	local tAddon = GetAddonInfo(wndAddon:GetData())
	SetAddonIgnoreVersion(tAddon.strFolder, bChecked)
	self:UpdateAddonLoadSetting(wndAddon)
end

function OptionsAddon:OnSnapshot(wndHandler, wndControl, eMouseButton)

end

function OptionsAddon:OnChangeLoadSettings(wndHandler, wndControl, eMouseButton)
	if self.strSelectedAddon == nil then
		return
	end

	-- TEMPORARY SOLUTION FOR FX-68822
	if self.strSelectedAddon == "EscapeMenu" then
		return
	end

	local tAddon = GetAddonInfo(self.strSelectedAddon)
	self:InvokeAddonLoadOnStartDlg(tAddon)
end

function OptionsAddon:OnAddonSelChanged(wndHandler, wndControl, nRow, nCol)

	self.strSelectedAddon = wndControl:GetCellData(nRow, 2)
	-- TEMPORARY SOLUTION FOR FX-68822
	self.wndAddons:FindChild("LoadSettings"):Enable(self.strSelectedAddon ~= nil and self.strSelectedAddon ~= "EscapeMenu")

	bShowErrorsButton = false
	bShowConfigureButton = false
	if self.strSelectedAddon ~= nil then
		local tAddon = GetAddonInfo(self.strSelectedAddon)
		if tAddon ~= nil and #tAddon.arErrors > 0 then
			bShowErrorsButton = true
		end
		if tAddon ~= nil and tAddon.bHasConfigure and tAddon.eStatus >= OptionsScreen.CodeEnumAddonStatus.RunningWithError then
			bShowConfigureButton = true
		end
	end

	self.wndAddons:FindChild("ShowError"):Enable(bShowErrorsButton)
	self.wndAddons:FindChild("Configure"):Enable(bShowConfigureButton)
end

function OptionsAddon:OnAddonDoubleClick(wndHandler, wndControl, nRow, nCol)
	if nRow <= 0 then
		return
	end

	self.strSelectedAddon = wndControl:GetCellData(nRow, 2)
	local tAddon = GetAddonInfo(self.strSelectedAddon)
	if tAddon ~= nil then
		self:InvokeAddonLoadOnStartDlg(tAddon)
	end
end

function OptionsAddon:OnConfigure(wndHandler, wndControl, eMouseButton)
	CallConfigure(self.strSelectedAddon)
end

function OptionsAddon:OnConfigureAddon(wndHandler, wndControl, eMouseButton)
	CallConfigure(wndControl:GetData())
end

---------------------------------------------------------------------------------------------------
-- End Addons Management functions
---------------------------------------------------------------------------------------------------

function OptionsAddon:OnSystemKeyDown(iKey)
	if iKey == 27 then
		if not IsDemo() or GetDemoTimeRemaining() > 0 then
			self:OnOptionsClose()
		end
	end
	if iKey == 13 then
		--self:OnShowPassword()
	end
end

function OptionsAddon:OnOptionsClose()
	if self.nOptionsTimer ~= 0 then -- unsaved graphic change
		self:OnChangeCancelBtn()
	end

	self.wndTargeting:Show(false) -- TODO Hack for F&F: We hide the window to force a button click to bring it back up (as there's some state initialization there)
	self.OptionsDlg:FindChild("InnerFrame"):FindChild("TargetingBtn"):SetCheck(false)
	CloseOptions()
end

function OptionsAddon:OnExitGame()
	ExitGame()
end

function OptionsAddon:OnRequestCamp( wndHandler, wndControl, eMouseButton )
	RequestCamp()
end

function OptionsAddon:InitOptionsControls()

	self.wndVideoConfirm:Show(false)

	for idx, mapping in pairs(self.mapCB2CVs) do
		if mapping.wnd ~= nil then
			mapping.wnd:SetCheck(Apollo.GetConsoleVariable(mapping.consoleVar))
			mapping.wnd:SetData(mapping)
		end
	end

	for idx, mapping in pairs(self.mapSB2CVs) do
		if mapping.wnd ~= nil then
			mapping.wnd:SetValue(Apollo.GetConsoleVariable(mapping.consoleVar))
			mapping.wnd:SetData(mapping)
			if mapping.buddy ~= nil then
				if mapping.consoleVar == "ppp.gamma" then
					mapping.buddy:SetText(string.format("%.02f", Apollo.GetConsoleVariable(mapping.consoleVar)))
				else
					mapping.buddy:SetText(Apollo.GetConsoleVariable(mapping.consoleVar))
				end
			end
		end
	end

	for idx, parent in pairs(self.mapDDParents) do
		if parent.wnd ~= nil and parent.consoleVar ~= nil and parent.radio ~= nil then

			local arBtns = parent.wnd:FindChild("ChoiceContainer"):GetChildren()

			for idxBtn = 1, #arBtns do
				arBtns[idxBtn]:SetCheck(false)
			end

			if parent.consoleVar == "video.fullscreen" then
				if Apollo.GetConsoleVariable("video.fullscreen") == true then
					if Apollo.GetConsoleVariable("video.exclusive") == true then
						self.wndVideo:SetRadioSel(parent.radio, 3)
						arBtns[3]:SetCheck(true)
					else
						self.wndVideo:SetRadioSel(parent.radio, 2)
						arBtns[2]:SetCheck(true)
					end
				else
					self.wndVideo:SetRadioSel(parent.radio, 1)
					arBtns[1]:SetCheck(true)
				end
			elseif parent.consoleVar == "draw.shadows" then
				if Apollo.GetConsoleVariable("draw.shadows") == true then
					if Apollo.GetConsoleVariable("lod.shadowMapSize") == 4096 then
						self.wndVideo:SetRadioSel(parent.radio, 1)
						arBtns[1]:SetCheck(true)
					elseif Apollo.GetConsoleVariable("lod.shadowMapSize") == 2048 then
						self.wndVideo:SetRadioSel(parent.radio, 2)
						arBtns[2]:SetCheck(true)
					else
						self.wndVideo:SetRadioSel(parent.radio, 3)
						arBtns[3]:SetCheck(true)
					end
				else
					self.wndVideo:SetRadioSel(parent.radio, 4)
					arBtns[4]:SetCheck(true)
				end
			else
				self.wndVideo:SetRadioSel(parent.radio, Apollo.GetConsoleVariable(parent.consoleVar) + 1)
				if arBtns[Apollo.GetConsoleVariable(parent.consoleVar) + 1] ~= nil then
					arBtns[Apollo.GetConsoleVariable(parent.consoleVar) + 1]:SetCheck(true)
				end
			end

			local strLabel = Apollo.GetString("Options_Unspecified")
			for idxBtn = 1, #arBtns do
				if arBtns[idxBtn]:IsChecked() then
					strLabel = arBtns[idxBtn]:GetText()
				end
			end

			parent.wnd:SetText(strLabel)

		end

	end

	--custom options go here
	self.wndVideo:FindChild("EnableFXAA"):SetCheck(Apollo.GetConsoleVariable("fxaa.enable"))
	self.wndVideo:FindChild("FXAASlider"):Enable(Apollo.GetConsoleVariable("fxaa.enable"))
	self.wndVideo:FindChild("FXAABlocker"):Show(not Apollo.GetConsoleVariable("fxaa.enable"))

	self:FillConfigureList()
	self.OptionsDlg:FindChild("Camp"):Enable(IsInGame());
end

function OptionsAddon:OnInvokeOptionsScreen(nOption)
	self.wndAddCoins:Show(false)
	self.wndDemoGoodbye:Show(false, true)
	self.wndDemo:Show(false, true)
	if nOption == 1 then
		self.wndDemoGoodbye:Show(true)
		return
	elseif nOption == 2 then
		CloseOptions()
		Camp()
		return
	end

	self:InitOptionsControls()
	if IsDemo() then
		self.wndDemo:Show(true)
	end
end

function OptionsAddon:OnReturnToDemo(iOption)
	self.wndDemo:Show(false)
	self.wndDemoGoodbye:Show(false)
	CloseOptions()
end

function OptionsAddon:OnInvokeRestart(wndHandler, wndControl, eMouseButton)
	CloseOptions()
	Camp()
end

function OptionsAddon:OnDemoTimer()
	if IsDemo() then

		if GetDemoTimeRemaining() <= 0 then
			self.wndDemo:Show(false, true)
			self.wndDemoGoodbye:Show(true, true)
		end

		self.wndDemo:FindChild("ReturnToDemo"):Enable(GetDemoTimeRemaining() > 0)
		self.wndDemoGoodbye:FindChild("ReturnToDemo"):Enable(GetDemoTimeRemaining() > 0)
		--self.wndDemoGoodbye:FindChild("RestartClose"):Enable(GetDemoTimeRemaining() > 0)

		if self.wndDemoGoodbye:IsShown() then
			self.nDemoAutoTimeout = self.nDemoAutoTimeout + 1
		else
			self.nDemoAutoTimeout = 0
		end

		if self.nDemoAutoTimeout > 30 then
			self:OnInvokeRestart()
		end
	end
end

function OptionsAddon:OnToggleCoinBtn()
	self.wndAddCoins:Show(true)
	self.wndAddCoins:FindChild("InsertCoinPassword"):SetText("")
	self.wndAddCoins:FindChild("InsertCoinPassword"):SetFocus()
	self.wndAddCoins:FindChild("InsertCoin"):Enable(false)
	self.wndAddCoins:ToFront()
	--self.wndDemo:Show(false)
end

function OptionsAddon:OnHideAddCoin()
	self.wndAddCoins:Show(false)
end

function OptionsAddon:OnPasswordChanged(wndHandler, wndControl, strNew)
	self.wndAddCoins:FindChild("InsertCoin"):Enable(strNew == "g4ffer")
end

function OptionsAddon:OnInsertCoin()
	if self.wndAddCoins:FindChild("InsertCoinPassword"):GetText() == "g4ffer" then
		AddDemoTime(300)
	end
end

------------------------------------------------------------------------------------------
-- End Demo
------------------------------------------------------------------------------------------


------------------------------------------------------------------------------------------

function OptionsAddon:OnReloadUI()
	--[[
	if self.wndErrorDetail ~= nil then
		self.wndErrorDetail:Show(false)
		self.wndErrorDetail:Destroy()
		self.wndErrorDetail = nil
	end
	--]]

	self:HelperUncheckAllInnerFrame()
	ReloadUI()
end

------------------------------------------------------------------------------------------

function OptionsAddon:FillDisplayList()
	local exclusiveDisplayMode = Apollo.GetConsoleVariable("video.exclusiveDisplayMode")
	local arModes = EnumerateDisplayModes()
	local nSel = 0
	local nPos = self.wndVideo:FindChild("ResolutionParent"):FindChild("Resolution"):GetVScrollPos()
	self.wndVideo:FindChild("ResolutionParent"):FindChild("Resolution"):DeleteAll()
	for i, tMode in ipairs(arModes) do
		if tMode.vec.x == exclusiveDisplayMode.x and tMode.vec.y == exclusiveDisplayMode.y and tMode.vec.z == exclusiveDisplayMode.z then
			nSel = i
		end
		local str = ""
		if tMode.bCurrent then
			str = " >   "
			self.wndVideo:FindChild("DropToggleExclusive"):SetText(tMode.strDisplay)
			self.tPrevExcRes = tMode
		end
		str = str .. tMode.strDisplay
		self.wndVideo:FindChild("ResolutionParent"):FindChild("Resolution"):AddRow(str, "", tMode)
	end
	self.bValidResolution = (nSel > 0)
	self.wndVideo:FindChild("ResolutionParent"):FindChild("Resolution"):SetCurrentRow(nSel)
	self.wndVideo:FindChild("ResolutionParent"):FindChild("Resolution"):SetVScrollPos(nPos)
end

function OptionsAddon:OnMappedOptionsCheckbox(wndHandler, wndControl)
	Apollo.SetConsoleVariable(wndControl:GetData().consoleVar, wndControl:IsChecked())

	self:EnableVideoControls()
end

function OptionsAddon:OnOptionsSliderChanged(wndHandler, wndControl, fValue, fOldValue)
	local mapping = wndControl:GetData()
	Apollo.SetConsoleVariable(mapping.consoleVar, fValue)
	if mapping.buddy ~= nil then
		if mapping.consoleVar == "ppp.gamma" then
			mapping.buddy:SetText(string.format("%.02f", Apollo.GetConsoleVariable(mapping.consoleVar)))
		else
			mapping.buddy:SetText(Apollo.GetConsoleVariable(mapping.consoleVar))
		end
	end
end

function OptionsAddon:OnTextureFilteringRadio(wndHandler, wndControl)
	Apollo.SetConsoleVariable("lod.textureFilter", wndControl:GetParent():GetRadioSel("TextureFiltering") - 1)
	wndControl:GetParent():GetParent():SetText(wndControl:GetText())
	wndControl:GetParent():Close()
end

function OptionsAddon:OnClutterDensityRadio(wndHandler, wndControl)
	Apollo.SetConsoleVariable("lod.clutterDensity", wndControl:GetParent():GetRadioSel("ClutterDensity") - 1)
	wndControl:GetParent():GetParent():SetText(wndControl:GetText())
	wndControl:GetParent():Close()
end

function OptionsAddon:OnTextureResolutionRadio(wndHandler, wndControl)
	Apollo.SetConsoleVariable("lod.textureLodBias", wndControl:GetParent():GetRadioSel("TextureResolution") - 1)
	Apollo.SetConsoleVariable("lod.textureLodMin", wndControl:GetParent():GetRadioSel("TextureResolution") - 1)
	wndControl:GetParent():GetParent():SetText(wndControl:GetText())
	wndControl:GetParent():Close()
end

function OptionsAddon:OnShadowsRadio(wndHandler, wndControl)
	local ndx = wndControl:GetParent():GetRadioSel("ShadowSetting")
	if ndx == 1 then
		Apollo.SetConsoleVariable("draw.shadows", true)
		Apollo.SetConsoleVariable("lod.shadowMapSize", 4096)
	elseif ndx == 2 then
		Apollo.SetConsoleVariable("draw.shadows", true)
		Apollo.SetConsoleVariable("lod.shadowMapSize", 2048)
	elseif ndx == 3 then
		Apollo.SetConsoleVariable("draw.shadows", true)
		Apollo.SetConsoleVariable("lod.shadowMapSize", 1024)
	else -- off
		Apollo.SetConsoleVariable("draw.shadows", false)
	end

	wndControl:GetParent():GetParent():SetText(wndControl:GetText())
	wndControl:GetParent():Close()
end

function OptionsAddon:OnResolutionSelChanged(wndHandler, wndControl, nRow)
	local tMode = wndControl:GetCellData(nRow, 1)
	if tMode == nil then
		return
	end
	self.wndVideo:FindChild("ResolutionParent"):Show(false)
	self.wndVideo:FindChild("DropToggleExclusive"):SetText(tMode.strDisplay)
	Apollo.SetConsoleVariable("video.exclusiveDisplayMode", tMode.vec)

	if Apollo.GetConsoleVariable("video.fullscreen") == true and Apollo.GetConsoleVariable("video.exclusive") == true then
		Apollo.StartTimer("ResExChangedTimer")
		self.wndVideoConfirm:Show(true)
		self.wndVideoConfirm:SetData(2)
		self.wndVideoConfirm:FindChild("TextTimer"):SetText("15")
		self.nOptionsTimer = 0
	end
end

function OptionsAddon:OnResExChangedTimer()
	if self.nOptionsTimer < 15 then
		self.nOptionsTimer = self.nOptionsTimer + 1
		self.wndVideoConfirm:Show(true)
		self.wndVideoConfirm:FindChild("TextTimer"):SetText(15 - self.nOptionsTimer)
		Apollo.StartTimer("ResExChangedTimer", 1.000, false)
	else
		self.nOptionsTimer = 0
		self.wndVideoConfirm:Show(false)

		if self.tPrevExcRes ~= nil then
			self.wndVideo:FindChild("DropToggleExclusive"):SetText(self.tPrevExcRes.strDisplay)
			Apollo.SetConsoleVariable("video.exclusiveDisplayMode", self.tPrevExcRes.vec)
			self.tPrevExcRes = nil
		end
	end
end


function OptionsAddon:OnWindowModeToggle(wndHandler, wndControl)
	if wndHandler ~= wndControl then -- in case the window closing trips this
		return
	end
	wndControl:FindChild("ChoiceContainer"):Show(wndControl:IsChecked())
end

function OptionsAddon:OnWindowModeToggleRes(wndHandler, wndControl)
	self.wndVideo:FindChild("ResolutionParent"):Show(wndControl:IsChecked())
	self:FillDisplayList()
end

function OptionsAddon:OnCatcherDown()
end


--Resolution Settings (custom handlers)
function OptionsAddon:OnResWindowed(wndHandler, wndControl)
	self.tPrevResSettings = {Apollo.GetConsoleVariable("video.fullscreen"), Apollo.GetConsoleVariable("video.exclusive")}
	Apollo.SetConsoleVariable("video.fullscreen", false)
	Apollo.SetConsoleVariable("video.exclusive", false)
	self:EnableVideoControls()
	wndControl:GetParent():GetParent():SetText(wndControl:GetText())
	wndControl:GetParent():Close()
end

function OptionsAddon:OnResFullscreen(wndHandler, wndControl)
	self.tPrevResSettings = {Apollo.GetConsoleVariable("video.fullscreen"), Apollo.GetConsoleVariable("video.exclusive")}
	Apollo.SetConsoleVariable("video.fullscreen", true)
	Apollo.SetConsoleVariable("video.exclusive", false)
	self:EnableVideoControls()
	wndControl:GetParent():GetParent():SetText(wndControl:GetText())
	wndControl:GetParent():Close()
end

function OptionsAddon:OnResFullscreenEx(wndHandler, wndControl)
	self.tPrevResSettings = {Apollo.GetConsoleVariable("video.fullscreen"), Apollo.GetConsoleVariable("video.exclusive")}
	Apollo.SetConsoleVariable("video.fullscreen", true)
	Apollo.SetConsoleVariable("video.exclusive", true)
	self:EnableVideoControls()
	wndControl:GetParent():GetParent():SetText(wndControl:GetText())
	wndControl:GetParent():Close()

	self.wndVideoConfirm:Show(true)
	self.wndVideoConfirm:SetData(1)
	self.wndVideoConfirm:FindChild("TextTimer"):SetText("15")
	Apollo.StartTimer("ResChangedTimer")
	self.nOptionsTimer = 0
end

function OptionsAddon:OnResChangedTimer()
	if self.nOptionsTimer < 15 then
		self.nOptionsTimer = self.nOptionsTimer + 1
		self.wndVideoConfirm:Show(true)
		self.wndVideoConfirm:FindChild("TextTimer"):SetText(15 - self.nOptionsTimer)
		Apollo.StartTimer("ResChangedTimer")
	else
		self.nOptionsTimer = 0
		self.wndVideoConfirm:Show(false)

		if self.tPrevResSettings ~= nil then
			Apollo.SetConsoleVariable("video.fullscreen", self.tPrevResSettings[1])
			Apollo.SetConsoleVariable("video.exclusive", self.tPrevResSettings[2])
			self.tPrevResSettings = nil
			self:InitOptionsControls()
			self:EnableVideoControls()
		end
	end
end


function OptionsAddon:EnableVideoControls()
	self.wndVideo:FindChild("EnableFXAA"):SetCheck(Apollo.GetConsoleVariable("fxaa.enable"))
	self.wndVideo:FindChild("FXAASlider"):Enable(self.wndVideo:FindChild("EnableFXAA"):IsChecked())
	self.wndVideo:FindChild("FXAABlocker"):Show(not self.wndVideo:FindChild("EnableFXAA"):IsChecked())

	self:FillDisplayList()
end


function OptionsAddon:OnChangeConfirmBtn(wndHandler, wndControl)
	Apollo.StopTimer("ResExChangedTimer")
	Apollo.StopTimer("ResChangedTimer")
	self.wndVideoConfirm:Show(false)
	self.tPrevExcRes = nil
	self.tPrevResSettings = nil
end

function OptionsAddon:OnChangeCancelBtn(wndHandler, wndControl)
	Apollo.StopTimer("ResExChangedTimer")
	Apollo.StopTimer("ResChangedTimer")
	self.nOptionsTimer = 0
	self.wndVideoConfirm:Show(false)

	if self.wndVideoConfirm:GetData() == 1 then --res
		if self.tPrevResSettings ~= nil then
			Apollo.SetConsoleVariable("video.fullscreen", self.tPrevResSettings[1])
			Apollo.SetConsoleVariable("video.exclusive", self.tPrevResSettings[2])
			self.tPrevResSettings = nil
			self:InitOptionsControls()
			self:EnableVideoControls()
		end
	else -- res exc
		if self.tPrevExcRes ~= nil then
			self.wndVideo:FindChild("DropToggleExclusive"):SetText(self.tPrevExcRes.strDisplay)
			Apollo.SetConsoleVariable("video.exclusiveDisplayMode", self.tPrevExcRes.vec)
			self.tPrevExcRes = nil
		end
	end
end

-- Free form Targetting
function OptionsAddon:OnAlwaysFaceCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("Player.ignoreAlwaysFaceTarget", false)
	self.wndTargeting:FindChild("FacingLockBtn"):Enable(true)
	self.wndTargeting:FindChild("FacingLockBtn"):SetTextColor(CColor.new(1, 128/255, 0, 1))
end

function OptionsAddon:OnAlwaysFaceUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("Player.ignoreAlwaysFaceTarget", true)
	self.wndTargeting:FindChild("FacingLockBtn"):Enable(false)
	self.wndTargeting:FindChild("FacingLockBtn"):SetTextColor(CColor.new(85/255, 43/255, 0, 1))
end

function OptionsAddon:OnFacingLockCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("Player.disableFacingLock", false)
end

function OptionsAddon:OnFacingLockUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("Player.disableFacingLock", true)
end

function OptionsAddon:OnMoveToCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("Player.moveToTargetOnSelfAOE", true)
end

function OptionsAddon:OnMoveToUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("Player.moveToTargetOnSelfAOE", false)
end

function OptionsAddon:OnAutoSelfCastCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.autoSelectCharacter", true)
end

function OptionsAddon:OnAutoSelfCastUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.autoSelectCharacter", false)
end

function OptionsAddon:OnAutoPushTarget(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.disableAutoTargeting", wndControl:IsChecked())
end

-- Movement
function OptionsAddon:OnDashDoubleTapBtn(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("player.doubleTapToDash", wndControl:IsChecked())
	Apollo.SetConsoleVariable("player.showDoubleTapToDash", wndControl:IsChecked())
end

function OptionsAddon:OnDashDirectionalBtn(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("player.directionalDash", wndControl:IsChecked())
end

-- Abilities
function OptionsAddon:OnUseButtonDownBtn(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.useButtonDownForAbilities", wndControl:IsChecked())
end

function OptionsAddon:OnHoldToCastBtn(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.holdToContinueCasting", wndControl:IsChecked())
end

function OptionsAddon:OnAbilityQueueBtn(wndHandler, wndControl, eMouseButton)
	if wndControl:IsChecked() then
		Apollo.SetConsoleVariable("player.abilityQueueMax", 500)
	else
		Apollo.SetConsoleVariable("player.abilityQueueMax", 0)
	end
end

-- Telegraphs
function OptionsAddon:OnSelfTelegraphOpacityChanged(wndHandler, wndControl, fValue, fOldValue)
	Apollo.SetConsoleVariable("spell.selfTelegraphOpacity", fValue)
end

function OptionsAddon:OnAffectsSelfOpacityChanged(wndHandler, wndControl, fValue, fOldValue)
	Apollo.SetConsoleVariable("spell.enemyDetrimentalTelegraphOpacity", fValue)
end

function OptionsAddon:OnAffectsOthersOpacityChanged(wndHandler, wndControl, fValue, fOldValue)
	Apollo.SetConsoleVariable("spell.allyBeneficialTelegraphOpacity", fValue)
end

function OptionsAddon:OnAffectsOthersOpacityChanged(wndHandler, wndControl, fValue, fOldValue)
	Apollo.SetConsoleVariable("spell.allyBeneficialTelegraphOpacity", fValue)
end

function OptionsAddon:OnAdEhOpacityChanged(wndHandler, wndControl, fValue, fOldValue)
	Apollo.SetConsoleVariable("spell.enemyBeneficalAllyDetrimentalTelegraphOpacity", fValue)
end

function OptionsAddon:OnOutlineOpacityChanged(wndHandler, wndControl, fValue, fOldValue)
	Apollo.SetConsoleVariable("spell.selfTelegraphOutline", fValue)
	Apollo.SetConsoleVariable("spell.enemyDetrimentalTelegraphOutline", fValue)
	Apollo.SetConsoleVariable("spell.allyBeneficialTelegraphOutline", fValue)
	Apollo.SetConsoleVariable("spell.enemyBeneficalAllyDetrimentalTelegraphOutline", fValue)
end

function OptionsAddon:OnColorBlindNoneBtn(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("world.telegraphColorblindDisplay", 0)
end

function OptionsAddon:OnColorBlindDeuteranopialBtn(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("world.telegraphColorblindDisplay", 1)
end

function OptionsAddon:OnColorBlindProtanopiaBtn(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("world.telegraphColorblindDisplay", 2)
end

function OptionsAddon:OnColorBlindTratanopiaBtn(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("world.telegraphColorblindDisplay", 3)
end

function OptionsAddon:OnSelfTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.selfTelegraphDisplay", true)
end

function OptionsAddon:OnSelfTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.selfTelegraphDisplay", false)
end

function OptionsAddon:OnEnemyTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyTelegraphDisplay", true)
end

function OptionsAddon:OnEnemyTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyTelegraphDisplay", false)
end

function OptionsAddon:OnEnemyNPCTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyNPCTelegraphDisplay", true)
end

function OptionsAddon:OnEnemyNPCTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyNPCTelegraphDisplay", false)
end

function OptionsAddon:OnEnemyNPCBeneficialTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyNPCBeneficialTelegraphDisplay", true)
end

function OptionsAddon:OnEnemyNPCBeneficialTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyNPCBeneficialTelegraphDisplay", false)
end

function OptionsAddon:OnEnemyNPCDetrimentalTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyNPCDetrimentalTelegraphDisplay", true)
end

function OptionsAddon:OnEnemyNPCDetrimentalTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyNPCDetrimentalTelegraphDisplay", false)
end

function OptionsAddon:OnEnemyPlayerTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyPlayerTelegraphDisplay", true)
end

function OptionsAddon:OnEnemyPlayerTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyPlayerTelegraphDisplay", false)
end

function OptionsAddon:OnEnemyPlayerBeneficialTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyPlayerBeneficialTelegraphDisplay", true)
end

function OptionsAddon:OnEnemyPlayerBeneficialTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyPlayerBeneficialTelegraphDisplay", false)
end

function OptionsAddon:OnEnemyPlayerDetrimentalTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyPlayerDetrimentalTelegraphDisplay", true)
end

function OptionsAddon:OnEnemyPlayerDetrimentalTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.enemyPlayerDetrimentalTelegraphDisplay", false)
end

function OptionsAddon:OnAllyTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyTelegraphDisplay", true)
end

function OptionsAddon:OnAllyTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyTelegraphDisplay", false)
end

function OptionsAddon:OnPartyMemberAllyTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.partyMemberAllyTelegraphDisplay", true)
end

function OptionsAddon:OnPartyMemberAllyTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.partyMemberAllyTelegraphDisplay", false)
end

function OptionsAddon:OnAllyNPCTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyNPCTelegraphDisplay", true)
end

function OptionsAddon:OnAllyNPCTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyNPCTelegraphDisplay", false)
end

function OptionsAddon:OnAllyNPCBeneficialTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyNPCBeneficialTelegraphDisplay", true)
end

function OptionsAddon:OnAllyNPCBeneficialTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyNPCBeneficialTelegraphDisplay", false)
end

function OptionsAddon:OnAllyNPCDetrimentalTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyNPCDetrimentalTelegraphDisplay", true)
end

function OptionsAddon:OnAllyNPCDetrimentalTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyNPCDetrimentalTelegraphDisplay", false)
end

function OptionsAddon:OnAllyPlayerTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyPlayerTelegraphDisplay", true)
end

function OptionsAddon:OnAllyPlayerTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyPlayerTelegraphDisplay", false)
end

function OptionsAddon:OnAllyPlayerBeneficialTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyPlayerBeneficialTelegraphDisplay", true)
end

function OptionsAddon:OnAllyPlayerBeneficialTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyPlayerBeneficialTelegraphDisplay", false)
end

function OptionsAddon:OnAllyPlayerDetrimentalTelegraphDisplayCheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyPlayerDetrimentalTelegraphDisplay", true)
end

function OptionsAddon:OnAllyPlayerDetrimentalTelegraphDisplayUncheck(wndHandler, wndControl, eMouseButton)
	Apollo.SetConsoleVariable("spell.allyPlayerDetrimentalTelegraphDisplay", false)
end

function OptionsAddon:OnEnteredCombat()
	if not IsDemo() or GetDemoTimeRemaining() > 0 then
		self:OnOptionsClose()
	end
end

function OptionsAddon:OnRestoreDefaults()
	local tTables = {self.mapCB2CVs, self.mapSB2CVs, self.mapDDParents }

	for iTable,tTable in pairs(tTables) do
		for i,tVar in pairs(tTable) do
			if tVar.wnd:IsVisible() then
				Apollo.ResetConsoleVariable(tVar.consoleVar)
			end
		end
	end
	self:OnOptionsCheck()
end

function OptionsAddon:OnCheckCombatMusicFlair( wndHandler, wndControl, eMouseButton )
	Apollo.SetConsoleVariable("sound.intenseBattleMusic", true)
end

function OptionsAddon:OnUncheckCombatMusicFlair( wndHandler, wndControl, eMouseButton )
	Apollo.SetConsoleVariable("sound.intenseBattleMusic", false)
end

---------------------------------------------------------------------------------------------------
-- Options instance
---------------------------------------------------------------------------------------------------
local OptionsInst = OptionsAddon:new()
OptionsAddon:Init()
