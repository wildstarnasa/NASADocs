
---------------------------------------------------------------------------------------------------
-- TableUtil:Copy
---------------------------------------------------------------------------------------------------
TableUtil = {}
function TableUtil:Copy(t)
  local t2 = {}
  if type(t) ~= "table" then
    return t
  end
  for k,v in pairs(t) do
    t2[k] = TableUtil:Copy(v)
  end
  return t2
end

---------------------------------------------------------------------------------------------------
-- fifo queue implementation
---------------------------------------------------------------------------------------------------
Queue = {}

function Queue:new(o)
  	o = o or {tItems={}}
	setmetatable(o, self)
	self.__index = self
	return o
end
---------------------------------------------------------------------------------------------------
function Queue:Push( item )
    self.tItems[#self.tItems+1]=item
end
---------------------------------------------------------------------------------------------------
function Queue:Pop()
    if #(self.tItems) == 0 then
        return nil
    end
    
    local returnItem = self.tItems[1]
    table.remove( self.tItems, 1 )

    return returnItem
end

---------------------------------------------------------------------------------------------------
function Queue:Insert( iPos, item )
    table.insert( self.tItems, iPos, item )
end
---------------------------------------------------------------------------------------------------
function Queue:Remove( iPos )
    table.remove( self.tItems, iPos )
end
---------------------------------------------------------------------------------------------------
function Queue:GetItems()
    return self.tItems
end
---------------------------------------------------------------------------------------------------
function Queue:GetSize()
    return #self.tItems
end
---------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
local UtilLib = {}

function UtilLib:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self 

    -- initialize variables here

    return o
end

function UtilLib:Init()
	Apollo.RegisterAddon(self)
end
 

-----------------------------------------------------------------------------------------------
-- Rover OnLoad
-----------------------------------------------------------------------------------------------
function UtilLib:OnLoad()
end


-----------------------------------------------------------------------------------------------
-- Rover Instance
-----------------------------------------------------------------------------------------------
local UtilLibInst = UtilLib:new()
UtilLibInst:Init()
UtilLibInst = nil



