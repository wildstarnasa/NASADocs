-----------------------------------------------------------------------------------------------
-- Client Lua Script for InterfaceMenuList
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "GameLib"
require "Apollo"
require "MatchingGame"
require "MailSystemLib"
require "FriendshipLib"

local InterfaceMenuList = {}

local kBigNameToEventMapping =
{
	["CharacterBtn"]						= "ToggleCharacterWindow",
	["LASBtn"]								= "ToggleAbilitiesWindow",
	["SocialBtn"]							= "ToggleSocialWindow",
	["MailBtn"]								= "ToggleMailWindow",
	["GroupFinderBtn"]						= "ToggleGroupFinder",
	["InventoryBtn"]						= "InterfaceMenu_ToggleInventory",
	["LoreBtn"]								= "InterfaceMenu_ToggleLoreWindow",
	["ReportBugBtn"]						= "InterfaceMenu_ToggleReportBug",

	["InterfaceMenu_Character"]				= "ToggleCharacterWindow",
	["InterfaceMenu_Lore"]					= "InterfaceMenu_ToggleLoreWindow",
	["InterfaceMenu_AuctionListings"]		= "InterfaceMenu_ToggleMarketplaceListings",
	["InterfaceMenu_AbilityBuilder"]		= "ToggleAbilitiesWindow",
	["InterfaceMenu_Social"]				= "ToggleSocialWindow",
	["InterfaceMenu_GroupFinder"]			= "ToggleGroupFinder",
	["InterfaceMenu_Mail"]					= "ToggleMailWindow",
	["InterfaceMenu_QuestLog"]				= "ToggleQuestLog",
	["InterfaceMenu_PathLog"]				= "PlayerPathShow",
	["InterfaceMenu_ChallengeLog"]			= "ToggleChallengesWindow",
	["InterfaceMenu_AchievementLog"]		= "ToggleAchievementWindow",
	["InterfaceMenu_Tradeskills"]			= "ToggleTradeskills",
	["InterfaceMenu_FriendsList"]			= "InvokeFriendsList",
	["InterfaceMenu_Guild"]					= "EventGeneric_OpenGuildPanel",
	["InterfaceMenu_Inventory"]				= "InterfaceMenu_ToggleInventory",
	["InterfaceMenu_Keybindings"]			= "InterfaceMenu_Keybindings",
	["InterfaceMenu_LevelUpUnlocks"]		= "ToggleLevelUpUnlocks",
	["InterfaceMenu_Macro"]					= "InterfaceMenu_ToggleMacro",
	["InterfaceMenu_Map"]					= "ToggleZoneMap",
	["InterfaceMenu_MountCustomization"]	= "GenericEvent_OpenMountCustomize",
	["InterfaceMenu_NonCombatAbilities"]	= "GenericEvent_OpenNonCombatSpellbook",
	["InterfaceMenu_Neighbors"]				= "InvokeNeighborsList",
	["InterfaceMenu_ReportBug"]				= "InterfaceMenu_ToggleReportBug",
	["InterfaceMenu_Reputation"]			= "ToggleReputationInterface",
	["InterfaceMenu_SystemMenu"]			= "",
	["InterfaceMenu_SubmitTicket"]			= "TogglePlayerTicketWindow",
}

local tMenuData =
{
	["InterfaceMenu_AbilityBuilder"] 		= { "LimitedActionSetBuilder", 	"" }, --
	["InterfaceMenu_AuctionListings"] 		= { "", 						"" }, --
	["InterfaceMenu_Character"] 			= { "CharacterPanel", 			"" }, --
	["InterfaceMenu_QuestLog"] 				= { "QuestLog", 				"" }, --
	["InterfaceMenu_PathLog"] 				= { "Path", 					"" }, --
	["InterfaceMenu_ChallengeLog"] 			= { "Challenges", 				"" }, --
	["InterfaceMenu_AchievementLog"] 		= { "Achievements", 			"" }, --
	["InterfaceMenu_Tradeskills"] 			= { "Tradeskills", 				"" }, --
	["InterfaceMenu_FriendsList"] 			= { "", 						"" }, --
	["InterfaceMenu_GroupFinder"] 			= { "GroupFinder", 				"" }, --
	["InterfaceMenu_Guild"] 				= { "", 						"" }, --
	["InterfaceMenu_Inventory"] 			= { "Inventory", 				"" }, --
	["InterfaceMenu_Keybindings"] 			= { "",							"" }, --
	["InterfaceMenu_LevelUpUnlocks"] 		= { "",							"" }, --
	["InterfaceMenu_Lore"] 					= { "Lore", 					"" }, --
	["InterfaceMenu_Mail"] 					= { "Reputation", 				"" }, --
	["InterfaceMenu_Macro"] 				= { "", 						"" }, --
	["InterfaceMenu_Map"] 					= { "WorldMap", 				"" }, --
	["InterfaceMenu_MountCustomization"] 	= { "", 						"" }, --
	["InterfaceMenu_NonCombatAbilities"] 	= { "", 						"" }, --
	["InterfaceMenu_Neighbors"] 			= { "", 						"" }, --
	["InterfaceMenu_ReportBug"] 			= { "", 						"" }, --
	["InterfaceMenu_Reputation"] 			= { "Reputation", 				"" }, --
	["InterfaceMenu_Social"] 				= { "Social", 					"" }, --
	["InterfaceMenu_SubmitTicket"] 			= { "", 						"" }, --
	["InterfaceMenu_SystemMenu"] 			= { "Escape", 					"" }, --
}

function InterfaceMenuList:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function InterfaceMenuList:Init()
    Apollo.RegisterAddon(self)
end

function InterfaceMenuList:OnLoad()
	Apollo.RegisterEventHandler("UnitEnteredCombat", 					"OnEnteredCombat", self)
	Apollo.RegisterEventHandler("SubZoneChanged", 						"OnSubZoneChanged", self)

	Apollo.RegisterEventHandler("AlertMailInfo", 						"OnAlertMailInfo", self)
	Apollo.RegisterEventHandler("MailRead", 							"CalculateMailAlert", self)
	Apollo.RegisterEventHandler("FriendshipAccountInvitesRecieved",  	"OnAlertFriends", self)
	Apollo.RegisterEventHandler("EventGeneric_FriendInviteSeen", 		"OnAlertFriends", self)
    Apollo.RegisterEventHandler("FriendshipInvitesRecieved",  			"OnAlertFriends", self)
	Apollo.RegisterEventHandler("FriendshipAccountInviteRemoved",   	"CalculateSocialAlert", self)
    Apollo.RegisterEventHandler("FriendshipInviteRemoved",   			"CalculateSocialAlert", self)
	Apollo.RegisterEventHandler("MatchingJoinQueue", 					"CalculateGroupFinderAlert", self)
	Apollo.RegisterEventHandler("MatchingLeaveQueue", 					"CalculateGroupFinderAlert", self)
	Apollo.RegisterEventHandler("UpdateInventory", 						"CalculateInventoryAlert", self)

	Apollo.RegisterEventHandler("Tutorial_RequestUIAnchor", 			"OnTutorial_RequestUIAnchor", self)

    self.wndMain = Apollo.LoadForm("InterfaceMenuList.xml", "InterfaceMenuListForm", nil, self)
	self.wndHiddenBagWindow = self.wndMain:FindChild("HiddenBagWindow")
	self.wndMain:FindChild("OpenFullListBtn"):AttachWindow(self.wndMain:FindChild("FullListFrame"))
	self.bInCombat = false

	-- Check Alerts
	self:CalculateMailAlert()
	self:CalculateSocialAlert()
	self:CalculateInventoryAlert()
	self:CalculateGroupFinderAlert()
end

function InterfaceMenuList:OnSubZoneChanged()
	self:CalculateSocialAlert()
	self:CalculateInventoryAlert()
	self:CalculateGroupFinderAlert()
end

function InterfaceMenuList:FullListRedraw()
	local strUnbound = Apollo.GetString("CRB_Unbound")
	local wndParent = self.wndMain:FindChild("FullListScroll")
	local strQuery = string.lower(tostring(self.wndMain:FindChild("SearchEditBox"):GetText()) or "")

	for strWindowText, tData in pairs(tMenuData) do
		local bSearchResultMatch = string.find(string.lower(Apollo.GetString(strWindowText)), strQuery) ~= nil
		if strQuery == "" or bSearchResultMatch then
			local wndMenuItem = self:LoadByName("MenuListItem", wndParent, strWindowText)
			wndMenuItem:FindChild("MenuListItemName"):SetText(Apollo.GetString(strWindowText))

			if string.len(tData[1]) > 0 then
				local strKeyBindLetter = GameLib.GetKeyBinding(tData[1])
				wndMenuItem:FindChild("MenuListItemKeybind"):SetText(strKeyBindLetter == strUnbound and "" or string.format("(%s)", strKeyBindLetter))  -- LOCALIZE
			end
		elseif not bSearchResultMatch and wndParent:FindChild(strWindowText) then
			wndParent:FindChild(strWindowText):Destroy()
		end
	end
	wndParent:ArrangeChildrenVert(0, function (a,b) return a:GetName() < b:GetName() end)
end

-----------------------------------------------------------------------------------------------
-- Search
-----------------------------------------------------------------------------------------------

function InterfaceMenuList:OnSearchEditBoxChanged(wndHandler, wndControl)
	self.wndMain:FindChild("SearchClearBtn"):Show(string.len(wndHandler:GetText() or "") > 0)
	self:FullListRedraw()
end

function InterfaceMenuList:OnSearchClearBtn(wndHandler, wndControl)
	self.wndMain:FindChild("SearchFlash"):SetSprite("CRB_WindowAnimationSprites:sprWinAnim_BirthSmallTemp")
	self.wndMain:FindChild("SearchFlash"):SetFocus()
	self.wndMain:FindChild("SearchClearBtn"):Show(false)
	self.wndMain:FindChild("SearchEditBox"):SetText("")
	self:FullListRedraw()
end

function InterfaceMenuList:OnSearchCommitBtn(wndHandler, wndControl)
	self.wndMain:FindChild("SearchFlash"):SetSprite("CRB_WindowAnimationSprites:sprWinAnim_BirthSmallTemp")
	self.wndMain:FindChild("SearchFlash"):SetFocus()
	self:FullListRedraw()
end

-----------------------------------------------------------------------------------------------
-- Alerts
-----------------------------------------------------------------------------------------------

function InterfaceMenuList:DrawAlert(strWindowName)
	local wndTarget = self.wndMain:FindChild("ButtonList"):FindChild(strWindowName)
	if wndTarget then
		local wndIndicator = self:LoadByName("AlertIndicator", wndTarget, "AlertIndicator")
	end
end

function InterfaceMenuList:CalculateGroupFinderAlert()
	if MatchingGame.IsQueuedForMatching() then
		self:DrawAlert("GroupFinderBtn")
	end
end

function InterfaceMenuList:CalculateInventoryAlert()
	local nTotalSlots = self.wndHiddenBagWindow:GetTotalBagSlots()
	local nEmptySlots = self.wndHiddenBagWindow:GetTotalEmptyBagSlots()
	local strColor = "UI_TextHoloBodyHighlight"
	if nEmptySlots == 0 then
		strColor = "AddonError"
	elseif nEmptySlots <= 3 then
		strColor = "AddonWarning"
	end

	if nEmptySlots <= 3 then
		self:DrawAlert("InventoryBtn")
	elseif self.wndMain:FindChild("ButtonList"):FindChild("InventoryBtn"):FindChild("AlertIndicator") then
		self.wndMain:FindChild("ButtonList"):FindChild("InventoryBtn"):FindChild("AlertIndicator"):Destroy()
	end

	-- Now Text
	--local strCurrPiece = string.format("<T Font=\"CRB_Interface9_BO\" TextColor=\"%s\">%s</T>", strColor, nTotalSlots - nEmptySlots)
	--self.wndMain:FindChild("InventoryTextCount"):SetAML(string.format("<P Font=\"CRB_Interface9_BO\" TextColor=\"UI_TextHoloBodyHighlight\">%s/ %s</P>", strCurrPiece, nTotalSlots))
end

function InterfaceMenuList:OnAlertMailInfo()
	self:DrawAlert("MailBtn")
end

function InterfaceMenuList:CalculateMailAlert()
	if MailSystemLib.IsThereUnreadMail() then
		self:DrawAlert("MailBtn")
	elseif self.wndMain:FindChild("ButtonList"):FindChild("MailBtn"):FindChild("AlertIndicator") then
		self.wndMain:FindChild("ButtonList"):FindChild("MailBtn"):FindChild("AlertIndicator"):Destroy()
	end
end

function InterfaceMenuList:OnAlertFriends()
	self:CalculateSocialAlert()
end

function InterfaceMenuList:CalculateSocialAlert(nId)
	local nUnseenFriendInviteCount = 0
	for idx, tInvite in pairs(FriendshipLib.GetInviteList()) do
		if tInvite.bIsNew and tInvite.nId ~= nId then
			self:DrawAlert("SocialBtn")
			return
		end
	end

	for idx, tInvite in pairs(FriendshipLib.GetAccountInviteList()) do
		if tInvite.bIsNew and tInvite.nId ~= nId then
			self:DrawAlert("SocialBtn")
			return
		end
	end
end

-----------------------------------------------------------------------------------------------
-- Helpers and Errata
-----------------------------------------------------------------------------------------------

function InterfaceMenuList:OnMenuListItemClick(wndHandler, wndControl)
	if wndHandler ~= wndControl then return end
	local strMappingResult = kBigNameToEventMapping[wndHandler:GetName()] or ""
	if string.len(strMappingResult) > 0 then
		Event_FireGenericEvent(strMappingResult)
	elseif wndHandler:GetName() == "InterfaceMenu_SystemMenu" then
		InvokeOptionsScreen()
	end
	self.wndMain:FindChild("FullListFrame"):Show(false)
end

function InterfaceMenuList:OnListBtnClick(wndHandler, wndControl) -- These are the five always on icons on the top
	if wndHandler ~= wndControl then return end
	local strMappingResult = kBigNameToEventMapping[wndHandler:GetName()] or ""
	if string.len(strMappingResult) > 0 then
		Event_FireGenericEvent(strMappingResult)
	elseif wndHandler:GetName() == "InterfaceMenu_SystemMenu" then
		InvokeOptionsScreen()
	end

	if wndHandler:FindChild("AlertIndicator") and wndHandler:FindChild("AlertIndicator"):IsValid() then
		wndHandler:FindChild("AlertIndicator"):Destroy()
	end
end

function InterfaceMenuList:OnListBtnMouseEnter(wndHandler, wndControl)
	wndHandler:SetBGColor("ffffffff")
	if wndHandler ~= wndControl or self.wndMain:FindChild("FullListFrame"):IsVisible() then
		return
	end

	local tMapWindowNameToTextDescription =
	{
		["CharacterBtn"] 	= Apollo.GetString("InterfaceMenu_Character"),
		["LoreBtn"] 		= Apollo.GetString("InterfaceMenu_Lore"),
		["LASBtn"] 			= Apollo.GetString("InterfaceMenu_Abilities"),
		["SocialBtn"] 		= Apollo.GetString("InterfaceMenu_Social"),
		["GroupFinderBtn"] 	= Apollo.GetString("InterfaceMenu_GroupFinder"),
		["MailBtn"] 		= Apollo.GetString("InterfaceMenu_Mail"),
		["InventoryBtn"] 	= Apollo.GetString("InterfaceMenu_Inventory"),
		["OpenFullListBtn"] = Apollo.GetString("InterfaceMenu_SearchInterfaces"),
		["ReportBugBtn"] 	= Apollo.GetString("InterfaceMenu_ReportBug"),
	}

	self.wndMain:FindChild("TextDescription"):SetText(tMapWindowNameToTextDescription[wndHandler:GetName()] or "")
end

function InterfaceMenuList:OnListBtnMouseExit(wndHandler, wndControl) -- Also self.wndMain MouseExit and ButtonList MouseExit
	wndHandler:SetBGColor(self.bInCombat and "44ffffff" or "9dffffff")
	if wndHandler == wndControl and not self.wndMain:FindChild("ButtonList"):ContainsMouse() and not self.wndMain:FindChild("OpenFullListBtn"):ContainsMouse() then
		self.wndMain:FindChild("TextDescription"):SetText("")
	end
end

function InterfaceMenuList:OnOpenFullListCheck(wndHandler, wndControl)
	self.wndMain:FindChild("TextDescription"):SetText("")
	self.wndMain:FindChild("SearchEditBox"):SetFocus()
	self:FullListRedraw()
end

function InterfaceMenuList:OnMenuListItemMouseEnter(wndHandler, wndControl)
	wndHandler:FindChild("MenuListItemName"):SetTextColor("UI_BtnTextHoloFlyby")
end

function InterfaceMenuList:OnMenuListItemMouseExit(wndHandler, wndControl)
	wndHandler:FindChild("MenuListItemName"):SetTextColor("UI_BtnTextHoloNormal")
end

function InterfaceMenuList:OnEnteredCombat(unit, bInCombat)
	self.bInCombat = bInCombat
	if self.wndMain and self.wndMain:IsValid() and unit == GameLib.GetPlayerUnit() then
		for idx, wndCurr in pairs(self.wndMain:FindChild("ButtonList"):GetChildren()) do
			wndCurr:SetBGColor(bInCombat and "44ffffff" or "9dffffff")
		end
	end
end

function InterfaceMenuList:LoadByName(strForm, wndParent, strCustomName)
	local wndNew = wndParent:FindChild(strCustomName)
	if not wndNew then
		wndNew = Apollo.LoadForm("InterfaceMenuList.xml", strForm, wndParent, self)
		wndNew:SetName(strCustomName)
	end
	return wndNew
end

function InterfaceMenuList:OnTutorial_RequestUIAnchor(eAnchor, idTutorial, strPopupText)
	local arTutorialAnchorMapping =
	{
		[GameLib.CodeEnumTutorialAnchor.Abilities] 			= "LASBtn",
		[GameLib.CodeEnumTutorialAnchor.Character] 			= "CharacterBtn",
		[GameLib.CodeEnumTutorialAnchor.Mail] 				= "MailBtn",
		[GameLib.CodeEnumTutorialAnchor.GalacticArchive] 	= "LoreBtn",
		[GameLib.CodeEnumTutorialAnchor.Social] 			= "SocialBtn",
		[GameLib.CodeEnumTutorialAnchor.GroupFinder] 		= "GroupFinderBtn",
	}

	local strWindowName = arTutorialAnchorMapping[eAnchor] or false
	if not strWindowName then
		return
	end

	local tRect = {}
	tRect.l, tRect.t, tRect.r, tRect.b = self.wndMain:FindChild(strWindowName):GetRect()
	Event_FireGenericEvent("Tutorial_RequestUIAnchorResponse", eAnchor, idTutorial, strPopupText, tRect)
end

local InterfaceMenuListInst = InterfaceMenuList:new()
InterfaceMenuListInst:Init()
