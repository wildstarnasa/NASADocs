-----------------------------------------------------------------------------------------------
-- Client Lua Script for InstanceSettings
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"

local InstanceSettings = {}

function InstanceSettings:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function InstanceSettings:Init()
    Apollo.RegisterAddon(self)
end

function InstanceSettings:OnLoad()
	Apollo.RegisterEventHandler("ShowInstanceGameModeDialog", "OnShowDialog", self)
	Apollo.RegisterEventHandler("ShowInstanceWaitingDialog", "OnShowWaiting", self)
	Apollo.RegisterEventHandler("HideInstanceGameModeDialog", "OnCancel", self)
end

function InstanceSettings:OnShowWaiting()
	self:DestroyAll()
	self.wndWaiting = Apollo.LoadForm("InstanceSettings.xml", "InstanceSettingsWaitingForm", nil, self)
end

function InstanceSettings:OnShowDialog(tData)
	self:DestroyAll()

	self.wndMain = Apollo.LoadForm("InstanceSettings.xml", "InstanceSettingsForm", nil, self)
	self.wndMain:FindChild("DifficultyButton1"):Enable(tData.bDifficultyNormal)
	self.wndMain:FindChild("DifficultyButton2"):Enable(tData.bDifficultyVeteran)
	self.wndMain:SetRadioSel("InstanceSettings_LocalRadioGroup_Difficulty", 1)

	self.wndMain:FindChild("LevelScalingButton"):Show(tData.bFlagsScaling)
	self.wndMain:SetRadioSel("InstanceSettings_LocalRadioGroup_Rallying", 1)
end

function InstanceSettings:OnOK()
	local difficulty = nil
	if 2 == self.wndMain:GetRadioSel("InstanceSettings_LocalRadioGroup_Difficulty") then
		difficulty = GroupLib.Difficulty.Veteran
	else 
		difficulty = GroupLib.Difficulty.Normal
	end
	
	GameLib.SetInstanceSettings(difficulty, self.wndMain:GetRadioSel("InstanceSettings_LocalRadioGroup_Rallying"))
	self:DestroyAll()
end

function InstanceSettings:OnCancel()
	GameLib.OnClosedInstanceSettings() -- let the server know to remove us from the instance portal queue
	self:DestroyAll()
end

function InstanceSettings:DestroyAll()
	if self.wndMain and self.wndMain:IsValid() then
		self.wndMain:Destroy()
	end

	if self.wndWaiting and self.wndWaiting:IsValid() then
		self.wndWaiting:Destroy()
	end
end

local InstanceSettingsInst = InstanceSettings:new()
InstanceSettingsInst:Init()
