-----------------------------------------------------------------------------------------------
-- Client Lua Script for ClassResources
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"

local ClassResources = {}

local knWarriorOverdriveDuration = 8
local knEngineerPetGroupId = 298 -- TODO Hardcoded engineer pet grouping

local ktEngineerStanceToShortString =
{
	[0] = "",
	[1] = Apollo.GetString("EngineerResource_Aggro"),
	[2] = Apollo.GetString("EngineerResource_Defend"),
	[3] = Apollo.GetString("EngineerResource_Passive"),
	[4] = Apollo.GetString("EngineerResource_Assist"),
	[5] = Apollo.GetString("EngineerResource_Stay"),
}

function ClassResources:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function ClassResources:Init()
    Apollo.RegisterAddon(self)
end

function ClassResources:OnLoad()
	Apollo.RegisterEventHandler("CharacterCreated", "OnCharacterCreated", self)

	if GameLib:GetPlayerUnit() then
		self:OnCharacterCreated()
	end
end

function ClassResources:OnCharacterCreated()
	local unitPlayer = GameLib.GetPlayerUnit()
	if not unitPlayer then
		return
	end

	local eClassId =  unitPlayer:GetClassId()
	if eClassId == GameLib.CodeEnumClass.Engineer then
		self:OnCreateEngineer()
	elseif unitPlayer:GetClassId() == GameLib.CodeEnumClass.Warrior then
		--self:OnCreateWarrior()
	end
end

-----------------------------------------------------------------------------------------------
-- Warrior
-----------------------------------------------------------------------------------------------

function ClassResources:OnCreateWarrior()
	Apollo.RegisterEventHandler("VarChange_FrameCount", 				"OnWarriorUpdateTimer", self)
	Apollo.RegisterTimerHandler("WarriorResource_StartOverDriveTimer", 	"OnWarriorResource_StartOverDriveTimer", self)
	Apollo.CreateTimer("WarriorResource_StartOverDriveTimer", 0.01, false)

	self.wndMain = Apollo.LoadForm("ClassResources.xml", "WarriorResourceForm", "FixedHudStratum", self)
	self.wndMain:ToFront()

	self.wndWarrior1 = self.wndMain:FindChild("FuelCellLeft")
	self.wndWarrior2 = self.wndMain:FindChild("FuelCellMiddle")
	self.wndWarrior3 = self.wndMain:FindChild("FuelCellRight")
	self.wndWarrior4 = self.wndMain:FindChild("FuelCellMax")
end

function ClassResources:OnWarriorUpdateTimer()
	local unitPlayer = GameLib.GetPlayerUnit()
	local bOverdrive = GameLib.IsOverdriveActive()
	local nResourceCurr = unitPlayer:GetResource(1)
	local nResourceMax = unitPlayer:GetMaxResource(1)
	local nResourceMaxDiv4 = nResourceMax / 4

	for idx, wndCurr in pairs({ self.wndWarrior1, self.wndWarrior2, self.wndWarrior3, self.wndWarrior4 }) do
		local nPartialProgress = nResourceCurr - (nResourceMaxDiv4 * (idx - 1)) -- e.g. 250, 500, 750, 1000
		local bThisBubbleFilled = nPartialProgress >= nResourceMaxDiv4
		wndCurr:FindChild("FuelCellProgress"):SetMax(nResourceMaxDiv4)
		wndCurr:FindChild("FuelCellProgress"):SetProgress(nPartialProgress)
		wndCurr:FindChild("FuelCellProgress"):Show(not bOverdrive and not bThisBubbleFilled)
		wndCurr:FindChild("FuelCellCircleRed"):Show(bOverdrive or bThisBubbleFilled)

		if bOverdrive or bThisBubbleFilled then
			wndCurr:FindChild("FuelCellSkull"):SetSprite("CRB_WarriorSprites:sprWar_SmallSkullRed")
		elseif nPartialProgress > 0 then
			wndCurr:FindChild("FuelCellSkull"):SetSprite("CRB_WarriorSprites:sprWar_SmallSkullBlue")
		elseif nPartialProgress <= 0 then
			wndCurr:FindChild("FuelCellSkull"):SetSprite("")
		end
	end

	local bLastKnownOverdriveState = self.wndMain:FindChild("OverdriveProgressBar"):GetData()
	if bOverdrive and not bLastKnownOverdriveState then
		self.wndMain:FindChild("OverdriveProgressBar"):SetData(true)
		self.wndMain:FindChild("OverdriveProgressBar"):SetProgress(1)
		self.wndWarrior1:FindChild("FuelCellFlash"):SetSprite("CRB_WarriorSprites:sprWar_FuelFlash")
		self.wndWarrior2:FindChild("FuelCellFlash"):SetSprite("CRB_WarriorSprites:sprWar_FuelFlash")
		self.wndWarrior3:FindChild("FuelCellFlash"):SetSprite("CRB_WarriorSprites:sprWar_FuelFlash")
		self.wndWarrior4:FindChild("FuelCellFlash"):SetSprite("CRB_WarriorSprites:sprWar_FuelFlash")
		Apollo.StartTimer("WarriorResource_StartOverDriveTimer")
	elseif not bOverdrive and bLastKnownOverdriveState then
		self.wndMain:FindChild("OverdriveProgressBar"):SetData(false)
	end
end

function ClassResources:OnWarriorResource_StartOverDriveTimer()
	self.wndMain:FindChild("OverdriveProgressBar"):SetProgress(0, 1 / knWarriorOverdriveDuration) -- 2nd arg is rate for animation
end

-----------------------------------------------------------------------------------------------
-- Engineer
-----------------------------------------------------------------------------------------------

function ClassResources:OnCreateEngineer()
	Apollo.RegisterEventHandler("UnitEnteredCombat", 			"OnEnteredCombat", self)
	Apollo.RegisterEventHandler("VarChange_FrameCount", 		"OnEngineerUpdateTimer", self)
	Apollo.RegisterEventHandler("ShowActionBarShortcut", 		"OnShowActionBarShortcut", self)
	Apollo.RegisterTimerHandler("EngineerOutOfCombatFade", 		"OnOutOfCombatFade", self)
	Apollo.CreateTimer("EngineerOutOfCombatFade", 1.250, false)

    self.wndMain = Apollo.LoadForm("ClassResources.xml", "EngineerResourceForm", "FixedHudStratum", self)
	self.wndMain:FindChild("StanceMenuOpenerBtn"):AttachWindow(self.wndMain:FindChild("StanceMenuBG"))
	self.wndMain:FindChild("BaseProgressSliderText"):SetData(0)
	self.wndMain:ToFront()

	for idx = 1, 5 do
		self.wndMain:FindChild("Stance"..idx):SetData(idx)
	end

	local nSliderLeft, nSliderTop, nSliderRight, nSliderBottom = self.wndMain:FindChild("BaseProgressSlider"):GetAnchorOffsets()
	self.nSliderWidth = nSliderRight - nSliderLeft

	self.nHealthWarn = 0.4
	self.nHealthWarn2 = 0.6
	self.nFadeLevel = 0

	self:OnShowActionBarShortcut(1, IsActionBarSetVisible(1)) -- Show petbar if active from reloadui/load screen
end

function ClassResources:OnEngineerUpdateTimer()
	local unitPlayer = GameLib.GetPlayerUnit()
	local nResourceMax = unitPlayer:GetMaxResource(1)
	local nResourceCurrent = unitPlayer:GetResource(1)
	local nResourcePercent = nResourceCurrent / nResourceMax

	-- Slider
	local nFrameLeft, nFrameTop, nFrameRight, nFrameBottom = self.wndMain:FindChild("BaseProgressFrame"):GetAnchorOffsets()
	local nSliderLeft, nSliderTop, nSliderRight, nSliderBottom = self.wndMain:FindChild("BaseProgressSlider"):GetAnchorOffsets()
	local nUseableProgWidth = nFrameRight - nFrameLeft - (nSliderRight - nSliderLeft)

	local nOffset = nResourcePercent * nUseableProgWidth
	local nLeft, nTop, nRight, nBottom = self.wndMain:FindChild("BaseProgressSlider"):GetAnchorOffsets()
	self.wndMain:FindChild("BaseProgressSlider"):SetAnchorOffsets(nOffset, nTop, nOffset + self.nSliderWidth, nBottom)

	if not self.bInCombat and nResourceCurrent == 0 then
		self.wndMain:FindChild("BaseProgressSliderText"):SetData(0)
		self.wndMain:FindChild("BaseProgressSliderText"):SetText("")
	else
		self.wndMain:FindChild("BaseProgressSliderText"):SetData(nResourcePercent)
		self.wndMain:FindChild("BaseProgressSliderText"):SetText(String_GetWeaselString(Apollo.GetString("CRB_Percent"), nResourcePercent * 100))
		if self.bInCombat then
			self.wndMain:FindChild("BaseProgressSliderText"):SetTextColor(ApolloColor.new(1, 1, 1 - nResourcePercent, 1))
		end
	end

	-- Pets
	local bShowLeftPet = false
	local bShowRightPet = false
	local tPetData = GameLib.GetPlayerPets()
	local bHavePets = tPetData and #tPetData > 0

	local bFoundLeft = false
	local bFoundRight = false
	for idx, unitPet in pairs(tPetData) do
		if unitPet == self.unitLeftEngineerPet then
			bFoundLeft = true
		elseif unitPet == self.unitRightEngineerPet then
			bFoundRight = true
		end
	end

	if not bFoundLeft then
		self.unitLeftEngineerPet = nil
	end

	if not bFoundRight then
		self.unitRightEngineerPet = nil
	end

	if bHavePets then
		-- Find the left vs right pet (Note an existing right pet stays right until destroyed, to prevent sliding around)
		local ePetStance = nil
		for key, unitPet in pairs(tPetData) do
			if unitPet:GetUnitRaceId() == knEngineerPetGroupId then
				if (not self.unitLeftEngineerPet or not self.unitLeftEngineerPet:IsValid()) and unitPet ~= self.unitRightEngineerPet then
					self.unitLeftEngineerPet = unitPet
				elseif unitPet ~= self.unitLeftEngineerPet and (not self.unitRightEngineerPet or not self.unitRightEngineerPet:IsValid()) then
					self.unitRightEngineerPet = unitPet
				end
			end
		end

		local bHasValidPet = false

		local wndLeft = self.wndMain:FindChild("PetContainerL")
		if self.unitLeftEngineerPet and self.unitLeftEngineerPet:IsValid() then
			local eCurrStance = Pet_GetStance(self.unitLeftEngineerPet:GetId())
			if eCurrStance and eCurrStance > 0 then
				ePetStance = eCurrStance
			end

			wndLeft:FindChild("PetContainerMouseCatcher"):SetData(self.unitLeftEngineerPet)
			bShowLeftPet = self:DoEngineerPetHPAndShieldResizing(wndLeft:FindChild("PetVitals"), self.unitLeftEngineerPet)
			bHasValidPet = true
		end

		local wndRight = self.wndMain:FindChild("PetContainerR")
		if self.unitRightEngineerPet and self.unitRightEngineerPet:IsValid() then
			local eCurrStance = Pet_GetStance(self.unitRightEngineerPet:GetId())
			if eCurrStance and eCurrStance > 0 then
				ePetStance = eCurrStance
			end

			wndRight:FindChild("PetContainerMouseCatcher"):SetData(self.unitRightEngineerPet)
			bShowRightPet = self:DoEngineerPetHPAndShieldResizing(wndRight:FindChild("PetVitals"), self.unitRightEngineerPet)
			bHasValidPet = true
		end

		if bHasValidPet then
			self.wndMain:FindChild("StanceMenuOpenerText"):SetText(ktEngineerStanceToShortString[ePetStance or 0] or "")
		end
	end

	self.wndMain:FindChild("PetContainerL"):Show(bShowLeftPet)
	self.wndMain:FindChild("PetContainerR"):Show(bShowRightPet)

	-- TODO HACK: Resize
	local nLeft, nTop, nRight, nBottom = self.wndMain:FindChild("MainResourceFrame"):GetAnchorOffsets()
	self.wndMain:FindChild("MainResourceFrame"):SetAnchorOffsets(bHavePets and 157 or 0, nTop, nRight, nBottom)

	nLeft, nTop, nRight, nBottom = self.wndMain:FindChild("BaseProgressFrame"):GetAnchorOffsets()
	self.wndMain:FindChild("BaseProgressFrame"):SetAnchorOffsets(nLeft, nTop, self.wndMain:FindChild("MainResourceFrame"):GetWidth() - 6, nBottom)
end

function ClassResources:OnStanceBtn(wndHandler, wndControl)
	Pet_SetStance(0, tonumber(wndHandler:GetData())) -- First arg is for the pet ID, 0 means all engineer pets
	self.wndMain:FindChild("StanceMenuOpenerBtn"):SetCheck(false)
end

function ClassResources:OnShowActionBarShortcut(nWhichBar, bIsVisible, nNumShortcuts)
	if nWhichBar ~= 1 or not self.wndMain or not self.wndMain:IsValid() then -- 1 is hardcoded to be the engineer pet bar
		return
	end
	self.wndMain:FindChild("PetBarContainer"):Show(bIsVisible)
end

function ClassResources:OnPetContainerMouseUp(wndHandler, wndControl) -- PetContainerL and PetContainerR
	if wndHandler == wndControl then
		GameLib.SetTargetUnit(wndHandler:GetData())
	end
end

function ClassResources:OnPetContainerMouseEnter(wndHandler, wndControl) -- PetContainerL and PetContainerR
	wndHandler:FindChild("PetContainerDespawnBtn"):Show(true)
end

function ClassResources:OnPetContainerMouseExit(wndHandler, wndControl) -- PetContainerL and PetContainerR
	wndHandler:FindChild("PetContainerDespawnBtn"):Show(false)
end

-----------------------------------------------------------------------------------------------
-- Combat Fading
-----------------------------------------------------------------------------------------------

function ClassResources:OnEnteredCombat(unitPlayer, bInCombat)
	if unitPlayer ~= GameLib.GetPlayerUnit() or not self.wndMain or not self.wndMain:IsValid() then
		return
	end

	self.bInCombat = bInCombat

	if bInCombat then
		self.nFadeLevel = 0
		local nResourcePercent = self.wndMain:FindChild("BaseProgressSliderText"):GetData()
		self.wndMain:FindChild("BaseProgressSliderText"):SetTextColor(ApolloColor.new(1, 1, 1 - nResourcePercent, 1))
		Apollo.StopTimer("EngineerOutOfCombatFade")
	else
		Apollo.StartTimer("EngineerOutOfCombatFade")
	end
end

function ClassResources:OnOutOfCombatFade()
	if self.wndMain and self.wndMain:IsValid() then
		self.nFadeLevel = self.nFadeLevel + 1
		local nResourcePercent = self.wndMain:FindChild("BaseProgressSliderText"):GetData()
		self.wndMain:FindChild("BaseProgressSliderText"):SetTextColor(ApolloColor.new(1, 1, 1 - nResourcePercent, 1 - (0.25 * self.nFadeLevel)))
	end

	if self.nFadeLevel <= 3 then
		Apollo.CreateTimer("EngineerOutOfCombatFade", 1.25, false)
	end
end

-----------------------------------------------------------------------------------------------
-- Helpers
-----------------------------------------------------------------------------------------------

function ClassResources:DoEngineerPetHPAndShieldResizing(wndBtnParent, unitPet)
	local nHealthCurr = unitPet:GetHealth()
	local nHealthMax = unitPet:GetMaxHealth()
	local nShieldCurr = unitPet:GetShieldCapacity()
	local nShieldMax = unitPet:GetShieldCapacityMax()
	local nAbsorbCurr = 0
	local nAbsorbMax = unitPet:GetAbsorptionMax()
	if nAbsorbMax > 0 then
		nAbsorbCurr = unitPet:GetAbsorptionValue() -- Since it doesn'nFrameTop clear when the buff drops off
	end
	local nTotalMax = nHealthMax + nShieldMax + nAbsorbMax

	-- Bars
	wndBtnParent:FindChild("HealthBar"):Show(nHealthCurr > 0 and nHealthMax > 0)
	wndBtnParent:FindChild("MaxAbsorbBar"):Show(nHealthCurr > 0 and nAbsorbMax > 0)
	wndBtnParent:FindChild("MaxShieldBar"):Show(nHealthCurr > 0 and nShieldMax > 0)
	wndBtnParent:FindChild("CurrShieldBar"):Show(nHealthCurr > 0 and nShieldMax > 0)

	wndBtnParent:FindChild("CurrShieldBar"):SetMax(nShieldMax)
	wndBtnParent:FindChild("CurrShieldBar"):SetProgress(nShieldCurr)
	wndBtnParent:FindChild("CurrShieldBar"):EnableGlow((wndBtnParent:FindChild("CurrShieldBar"):GetWidth() * nShieldCurr/nShieldMax) > 4)
	wndBtnParent:FindChild("CurrAbsorbBar"):SetMax(nAbsorbMax)
	wndBtnParent:FindChild("CurrAbsorbBar"):SetProgress(nAbsorbCurr)
	wndBtnParent:FindChild("CurrAbsorbBar"):EnableGlow((wndBtnParent:FindChild("CurrAbsorbBar"):GetWidth() * nAbsorbCurr/nAbsorbMax) > 4)
	wndBtnParent:FindChild("HealthBarEdgeGlow"):Show(nShieldMax <= 0)

	-- Health Bar Color
	if (nHealthCurr / nHealthMax) < self.nHealthWarn then
		wndBtnParent:FindChild("HealthBar"):SetSprite("sprRaid_HealthProgBar_Red")
		wndBtnParent:FindChild("HealthBar"):FindChild("HealthBarEdgeGlow"):SetSprite("sprRaid_HealthEdgeGlow_Red")
	elseif (nHealthCurr / nHealthMax) < self.nHealthWarn2 then
		wndBtnParent:FindChild("HealthBar"):SetSprite("sprRaid_HealthProgBar_Orange")
		wndBtnParent:FindChild("HealthBar"):FindChild("HealthBarEdgeGlow"):SetSprite("sprRaid_HealthEdgeGlow_Orange")
	else
		wndBtnParent:FindChild("HealthBar"):SetSprite("sprRaid_HealthProgBar_Green")
		wndBtnParent:FindChild("HealthBar"):FindChild("HealthBarEdgeGlow"):SetSprite("sprRaid_HealthEdgeGlow_Green")
	end

	-- Scaling
	local nWidth = self.wndMain:FindChild("PetVitals"):GetWidth() - 2
	local nArtOffset = 2
	local nPointHealthRight = nWidth * (nHealthCurr / nTotalMax)
	local nPointShieldRight = nWidth * ((nHealthCurr + nShieldMax) / nTotalMax)
	local nPointAbsorbRight = nWidth * ((nHealthCurr + nShieldMax + nAbsorbMax) / nTotalMax)

	local nFrameLeft, nFrameTop, nFrameRight, nFrameBottom = wndBtnParent:FindChild("HealthBar"):GetAnchorOffsets()
	wndBtnParent:FindChild("HealthBar"):SetAnchorOffsets(nFrameLeft, nFrameTop, nPointHealthRight, nFrameBottom)
	wndBtnParent:FindChild("MaxShieldBar"):SetAnchorOffsets(nPointHealthRight - nArtOffset, nFrameTop, nPointShieldRight, nFrameBottom)
	wndBtnParent:FindChild("MaxAbsorbBar"):SetAnchorOffsets(nPointShieldRight - nArtOffset, nFrameTop, nPointAbsorbRight, nFrameBottom)

	-- Engineer UI only
	wndBtnParent:FindChild("PetHealthBarText"):SetText(math.max(1, math.floor((nHealthCurr + nShieldCurr + nAbsorbCurr) / nTotalMax * 100)).."%")
	wndBtnParent:SetTooltip(string.format("<P Font=\"CRB_InterfaceSmall\">%s %s/%s (%s)</P>", unitPet:GetName(), nHealthCurr, nHealthMax, nShieldCurr + nAbsorbCurr))

	return not unitPet:IsDead()
end

function ClassResources:OnGeneratePetCommandTooltip(wndControl, wndHandler, eType, arg1, arg2)
	local xml = nil
	if eType == Tooltip.TooltipGenerateType_PetCommand then
		xml = XmlDoc.new()
		xml:AddLine(arg2)
		wndControl:SetTooltipDoc(xml)
	elseif eType == Tooltip.TooltipGenerateType_Spell then
		xml = XmlDoc.new()
		if arg1 ~= nil then
			xml:AddLine(arg1:GetFlavor())
		end
		wndControl:SetTooltipDoc(xml)
	end
end

local ClassResourcesInst = ClassResources:new()
ClassResourcesInst:Init()
