require "Window"

local Prerequisites = {}

local kstrPrerequisitesFormFilename = "PrerequisitesForms.xml"

function Prerequisites:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	
	return o
end

function Prerequisites:Init()
	-- callbacks
	Apollo.RegisterAddon(self)
end

function Prerequisites:OnLoad()
	Apollo.RegisterEventHandler("DebugPrerequisite", "ShowDebugOutput", self)
end

----------------------------------------------------------------------------------------------------------
-- Debug Output
----------------------------------------------------------------------------------------------------------

function Prerequisites:ShowDebugOutput(description)
	if self.wndInfo == nil then
		self.wndInfo = Apollo.LoadForm(kstrPrerequisitesFormFilename, "DebugOutput", nil, self)
	end
	
	self.wndInfo:Show(true)	
    self.wndInfo:FindChild("DebugText"):SetVScrollInfo(0, 0, 0)
	self.wndInfo:FindChild("DebugText"):SetText(description)
end

function Prerequisites:OnCloseBtn()
	if self.wndInfo then
		self.wndInfo:Show(false)
	end
end

-- Global  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local PrerequisitesInstance = Prerequisites:new()
PrerequisitesInstance:Init()

