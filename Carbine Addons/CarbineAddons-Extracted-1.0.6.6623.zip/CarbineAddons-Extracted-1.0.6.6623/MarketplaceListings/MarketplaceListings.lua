-----------------------------------------------------------------------------------------------
-- Client Lua Script for MarketplaceListings
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "GameLib"
require "Money"
require "MarketplaceLib"
require "CommodityOrder"

local MarketplaceListings = {}

local ktTimeRemaining =
{
	[ItemAuction.CodeEnumAuctionRemaining.Expiring]		= Apollo.GetString("MarketplaceAuction_Expiring"),
	[ItemAuction.CodeEnumAuctionRemaining.LessThanHour]	= Apollo.GetString("MarketplaceAuction_LessThanHour"),
	[ItemAuction.CodeEnumAuctionRemaining.Short]		= Apollo.GetString("MarketplaceAuction_Short"),
	[ItemAuction.CodeEnumAuctionRemaining.Long]			= Apollo.GetString("MarketplaceAuction_Long"),
	[ItemAuction.CodeEnumAuctionRemaining.Very_Long]	= Apollo.GetString("MarketplaceAuction_VeryLong")
}

local knSaveVersion = 1

function MarketplaceListings:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function MarketplaceListings:Init()
    Apollo.RegisterAddon(self)
end

function MarketplaceListings:OnSave(eType)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Account then
		return
	end
	
	local tSaved = 
	{
		tOffsets = self.wndMain and {self.wndMain:GetAnchorOffsets()} or self.tSavedOffsets,
		nSaveVersion = knSaveVersion
	}
	
	return tSaved
end

function MarketplaceListings:OnRestore(eType, tSavedData)
	if not tSavedData or tSavedData.nSaveVersion ~= knSaveVersion then
		return
	end
	
	if tSavedData.tOffsets then
		self.tSavedOffsets = tSavedData.tOffsets
	end
end

function MarketplaceListings:OnLoad()
	Apollo.RegisterEventHandler("InterfaceMenu_ToggleMarketplaceListings", 	"OnToggle", self)
	Apollo.RegisterEventHandler("OwnedItemAuctions", 						"OnOwnedItemAuctions", self)
	Apollo.RegisterEventHandler("OwnedCommodityOrders", 					"OnOwnedCommodityOrders", self)
	Apollo.RegisterEventHandler("ItemCancelResult", 						"OnItemCancelResult", self)

	Apollo.RegisterEventHandler("CommodityAuctionRemoved", 					"OnCommodityAuctionRemoved", self) -- Essentially RequestData
	Apollo.RegisterEventHandler("PostCommodityOrderResult", 				"RequestData", self)
	Apollo.RegisterTimerHandler("MarketplaceListings_OneMinuteTimer", 		"OnOneMinuteTimer", self)

	Apollo.CreateTimer("MarketplaceUpdateTimer", 60, true)
	Apollo.StopTimer("MarketplaceUpdateTimer")

	self.xmlDoc = XmlDoc.CreateFromFile("MarketplaceListings.xml")
end

function MarketplaceListings:OnToggle()
	if self.wndMain and self.wndMain:IsValid() then
		self.tSavedOffsets = {self.wndMain:GetAnchorOffsets()}
		self.wndMain:Destroy()
	else
		self.bOneMinTimerActive = false

		self.wndMain = Apollo.LoadForm(self.xmlDoc, "MarketplaceListingsForm", nil, self)
		self.wndMain:SetSizingMinimum(400, 300)
		self.wndMain:Show(false, true)
		
		if self.tSavedOffsets then
			self.wndMain:SetAnchorOffsets(unpack(self.tSavedOffsets))
		end

		self.wndMain:FindChild("TitleBGText"):SetData(GameLib.GetPlayerUnit())
		self:RequestData()

		Apollo.StartTimer("MarketplaceUpdateTimer")
	end
end

function MarketplaceListings:OnDestroy()
	if self.wndMain and self.wndMain:IsValid() then
		self.tSavedOffsets = {self.wndMain:GetAnchorOffsets()}
		self.wndMain:Destroy()
		Apollo.StopTimer("MarketplaceUpdateTimer")
	end
end

function MarketplaceListings:OnOneMinuteTimer()
	self.bOneMinTimerActive = false
	self:RequestData()
end

function MarketplaceListings:RequestData()
	if not self.wndMain or not self.wndMain:IsValid() then
		return
	end

	self.wndMain:FindChild("MainScroll"):Show(false)
	self.wndMain:FindChild("WaitScreen"):Show(true)
	self.wndMain:FindChild("MainScroll"):DestroyChildren()

	MarketplaceLib.RequestOwnedCommodityOrders()
	MarketplaceLib.RequestOwnedItemAuctions()
end

function MarketplaceListings:OnOwnedItemAuctions(tAuctions)
	if not self.wndMain or not self.wndMain:IsValid() then
		return
	end

	for nIdx, aucCurrent in pairs(tAuctions) do
		if aucCurrent and ItemAuction.is(aucCurrent) then
			self:BuildAuctionOrder(nIdx, aucCurrent)
		end
	end

	self:SharedDrawMain()
end

function MarketplaceListings:OnOwnedCommodityOrders(tOrders)
	if not self.wndMain or not self.wndMain:IsValid() then
		return
	end

	for nIdx, tCurrOrder in pairs(tOrders) do
		self:BuildCommodityOrder(nIdx, tCurrOrder)
	end

	self:SharedDrawMain()
end

function MarketplaceListings:SharedDrawMain()
	local strPlayerName = self.wndMain:FindChild("TitleBGText"):GetData()
	local nNumChildren = #self.wndMain:FindChild("MainScroll"):GetChildren()

	self.wndMain:Show(true)
	self.wndMain:FindChild("MainScroll"):Show(true)
	self.wndMain:FindChild("WaitScreen"):Show(false)
	self.wndMain:FindChild("TitleBGText"):SetText(String_GetWeaselString(Apollo.GetString("MarketplaceListings_PlayerPrefixListings"), strPlayerName))
	self.wndMain:FindChild("MainScroll"):SetText(nNumChildren == 0 and Apollo.GetString("MarketplaceListings_NoActiveListings") or "")
	self.wndMain:FindChild("MainScroll"):ArrangeChildrenVert(0)

	if not self.bOneMinTimerActive then
		self.bOneMinTimerActive = true
		Apollo.CreateTimer("MarketplaceListings_OneMinuteTimer", 60, false)
		Apollo.StartTimer("MarketplaceListings_OneMinuteTimer")
	end
end

-----------------------------------------------------------------------------------------------
-- Item Drawing
-----------------------------------------------------------------------------------------------

function MarketplaceListings:BuildAuctionOrder(nIdx, aucCurrent)
	local tItem = aucCurrent:GetItem()
	local wndCurr = self:FactoryProduce(self.wndMain:FindChild("MainScroll"), "AuctionItem", aucCurrent)

	local bIsOwnAuction = aucCurrent:IsOwned()
	local nCount = aucCurrent:GetCount()
	local nBidAmount = aucCurrent:GetCurrentBid():GetAmount()
	local strPrefix = bIsOwnAuction and Apollo.GetString("MarketplaceListings_AuctionPrefix") or Apollo.GetString("MarketplaceListings_BiddingPrefix")

	if bIsOwnAuction then
		wndCurr:FindChild("AuctionTimeLeftText"):SetText(self:HelperFormatTimeString(aucCurrent:GetExpirationTime()))
	else
		wndCurr:FindChild("AuctionTimeLeftText"):SetTextRaw(ktTimeRemaining[aucCurrent:GetTimeRemainingEnum()]) -- Ending time will be obfuscated or 0'd for other players
	end

	wndCurr:FindChild("AuctionCancelBtn"):SetData(aucCurrent)
	wndCurr:FindChild("AuctionCancelBtn"):Enable(nBidAmount == 0)
	wndCurr:FindChild("AuctionCancelBtn"):Show(bIsOwnAuction)
	wndCurr:FindChild("AuctionCancelBtnTooltipHack"):Show(bIsOwnAuction and nBidAmount ~= 0)
	wndCurr:FindChild("AuctionPrice"):SetAmount(nBidAmount, true) -- 2nd arg is bInstant
	wndCurr:FindChild("AuctionBigIcon"):SetSprite(tItem:GetIcon())
	wndCurr:FindChild("AuctionIconAmountText"):SetText(nCount == 1 and "" or nCount)
	wndCurr:FindChild("AuctionItemName"):SetText(String_GetWeaselString(strPrefix, tItem:GetName()))
	Tooltip.GetItemTooltipForm(self, wndCurr:FindChild("AuctionBigIcon"), tItem, {bPrimary = true, bSelling = false, itemCompare = tItem:GetEquippedItemForItemType()})
end

function MarketplaceListings:BuildCommodityOrder(nIdx, aucCurrent)
	local tItem = aucCurrent:GetItem()
	local wndCurr = self:FactoryProduce(self.wndMain:FindChild("MainScroll"), "CommodityItem", aucCurrent)

	-- Tint a different color if Buy
	local strPrefix = Apollo.GetString("CRB_Sell")
	if aucCurrent:IsBuy() then
		strPrefix = Apollo.GetString("CRB_Buy")
		wndCurr:FindChild("CommodityItemName"):SetTextColor(ApolloColor.new("ff7fffb9"))
		wndCurr:FindChild("CommodityPPULabel"):SetTextColor(ApolloColor.new("ff7fffb9"))
		wndCurr:FindChild("CommodityBigIconContainer"):SetBGColor(ApolloColor.new("ffffff00"))
	end

	local nCount = aucCurrent:GetCount()
	wndCurr:FindChild("CommodityCancelBtn"):SetData(aucCurrent)
	wndCurr:FindChild("CommodityBuyBG"):Show(aucCurrent:IsBuy())
	wndCurr:FindChild("CommoditySellBG"):Show(not aucCurrent:IsBuy())
	wndCurr:FindChild("CommodityBigIcon"):SetSprite(tItem:GetIcon())
	wndCurr:FindChild("CommodityIconAmountText"):SetText(nCount == 1 and "" or nCount)
	wndCurr:FindChild("CommodityItemName"):SetText(String_GetWeaselString(Apollo.GetString("MarketplaceListings_AuctionLabel"), strPrefix, tItem:GetName()))
	wndCurr:FindChild("CommodityPrice"):SetAmount(aucCurrent:GetPricePerUnit():GetAmount(), true) -- 2nd arg is bInstant
	wndCurr:FindChild("CommodityTimeLeftText"):SetText(self:HelperFormatTimeString(aucCurrent:GetExpirationTime()))
	Tooltip.GetItemTooltipForm(self, wndCurr:FindChild("CommodityBigIcon"), tItem, {bPrimary = true, bSelling = false, itemCompare = tItem:GetEquippedItemForItemType()})
end

-----------------------------------------------------------------------------------------------
-- UI Interaction (mostly to cancel order)
-----------------------------------------------------------------------------------------------

function MarketplaceListings:OnAuctionCancelBtn(wndHandler, wndControl)
	local aucCurrent = wndHandler:GetData()
	if not aucCurrent then
		return
	end
	aucCurrent:Cancel() -- Will trigger CommodityAuctionRemoved soon
	self:RequestData() -- TODO REMOVE when CommodityAuctionRemoved works
	self.wndMain:FindChild("MainScroll"):Show(false)
end

function MarketplaceListings:OnCommodityCancelBtn(wndHandler, wndControl)
	local aucCurrent = wndHandler:GetData()
	if not aucCurrent or not aucCurrent:IsPosted() then
		return
	end
	aucCurrent:Cancel() -- Will trigger CommodityAuctionRemoved soon
	self.wndMain:FindChild("MainScroll"):Show(false)
end

function MarketplaceListings:OnCommodityAuctionRemoved(eAuctionEventType, oOrder)
	if not self.wndMain or not self.wndMain:IsValid() then
		return
	end

	-- TODO
	if eAuctionEventType == MarketplaceLib.AuctionEventType.Post then
	elseif eAuctionEventType == MarketplaceLib.AuctionEventType.Bid then
	elseif eAuctionEventType == MarketplaceLib.AuctionEventType.Fill then
	elseif eAuctionEventType == MarketplaceLib.AuctionEventType.Expire then
	elseif eAuctionEventType == MarketplaceLib.AuctionEventType.Cancel then
	end

	self:RequestData()
end

function MarketplaceListings:OnItemCancelResult(eAuctionEventType, oOrder)
	if not self.wndMain or not self.wndMain:IsValid() then
		return
	end

	if eAuctionEventType == MarketplaceLib.AuctionPostResult.AlreadyHasBid then
		Event_FireGenericEvent("GenericEvent_LootChannelMessage", Apollo.GetString("MarketplaceListings_CantCancelHasBid"))
	end

	self:RequestData()
end

function MarketplaceListings:OnCommodityItemSmallMouseEnter(wndHandler, wndControl)
	if wndHandler == wndControl and wndHandler:FindChild("CommodityCancelBtn") then
		wndHandler:FindChild("CommodityCancelBtn"):Show(true)
	end
end

function MarketplaceListings:OnCommodityItemSmallMouseExit(wndHandler, wndControl)
	if wndHandler == wndControl and wndHandler:FindChild("CommodityCancelBtn") then
		wndHandler:FindChild("CommodityCancelBtn"):Show(false)
	end
end

-----------------------------------------------------------------------------------------------
-- Helpers
-----------------------------------------------------------------------------------------------

function MarketplaceListings:HelperFormatTimeString(oExpirationTime)
	local strResult = ""
	local nInSeconds = math.floor(math.abs(Time.SecondsElapsed(oExpirationTime))) -- CLuaTime object
	local nHours = math.floor(nInSeconds / 3600)
	local nMins = math.floor(nInSeconds / 60 - (nHours * 60))

	if nHours > 0 then
		strResult = String_GetWeaselString(Apollo.GetString("MarketplaceListings_Hours"), nHours)
	elseif nMins > 0 then
		strResult = String_GetWeaselString(Apollo.GetString("MarketplaceListings_Minutes"), nMins)
	else
		strResult = Apollo.GetString("MarketplaceListings_LessThan1m")
	end
	return strResult
end

function MarketplaceListings:FactoryProduce(wndParent, strFormName, tObject) -- Using AuctionObjects
	local wnd = wndParent:FindChildByUserData(tObject)
	if not wnd then
		wnd = Apollo.LoadForm(self.xmlDoc, strFormName, wndParent, self)
		wnd:SetData(tObject)
	end
	return wnd
end

local MarketplaceListingsInst = MarketplaceListings:new()
MarketplaceListingsInst:Init()
