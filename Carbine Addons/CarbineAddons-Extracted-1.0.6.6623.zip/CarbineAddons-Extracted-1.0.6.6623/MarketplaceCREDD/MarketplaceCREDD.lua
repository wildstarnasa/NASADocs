-----------------------------------------------------------------------------------------------
-- Client Lua Script for MarketplaceCREDD
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------
 
require "Window"
require "CREDDExchangeLib"
require "CREDDExchangeOrder"
 
-----------------------------------------------------------------------------------------------
-- MarketplaceCREDD Module Definition
-----------------------------------------------------------------------------------------------
local MarketplaceCREDD = {} 
 
-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
local ktResultErrorCodeStrings =
{
	[CREDDExchangeLib.CodeEnumAccountOperationResult.GenericFail] = "Generic Failure.",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.DBError] = "Generic Failure.",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.MTXError] = "Generic Failure.",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.InvalidOffer] = "Invalid order.",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.InvalidPrice] = "Invalid order.",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.NotEnoughCurrency] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.NeedTransaction] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.InvalidAccountItem] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.InvalidPendingItem] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.InvalidInventoryItem] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.NoConnection] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.NoCharacter] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.AlreadyClaimed] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.MaxEntitlementCount] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.NoRegift] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.NoGifting] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.InvalidFriend] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.InvalidCoupon] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.CannotReturn] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.Prereq] = "",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.CREDDExchangeNotLoaded] = "C.R.E.D.D. is busy. Please try again.",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.NoCREDD] = "Not enough C.R.E.D.D. for order.",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.NoMatchingOrder] = "Could not find matching market order.",
	[CREDDExchangeLib.CodeEnumAccountOperationResult.InvalidCREDDOrder] = "Invalid C.R.E.D.D. order."
}

local knSaveVersion = 1
 
-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
function MarketplaceCREDD:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self 

    -- initialize variables here

    return o
end

function MarketplaceCREDD:Init()
    Apollo.RegisterAddon(self)
end

function MarketplaceCREDD:OnSave(eType)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Account then
		return
	end
	
	local tSaved = 
	{
		tOffsets = self.wndMain and {self.wndMain:GetAnchorOffsets()} or self.tSavedOffsets,
		nSaveVersion = knSaveVersion
	}
	
	return tSaved
end

function MarketplaceCREDD:OnRestore(eType, tSavedData)
	self.nSaveVersion = tSavedData.nSaveVersion
	if not tSavedData or tSavedData.nSaveVersion ~= knSaveVersion then
		return
	end
	
	if tSavedData.tOffsets then
		self.tSavedOffsets = tSavedData.tOffsets
	end
end
 

-----------------------------------------------------------------------------------------------
-- MarketplaceCREDD OnLoad
-----------------------------------------------------------------------------------------------
function MarketplaceCREDD:OnLoad()
	self.xmlDoc = XmlDoc.CreateFromFile("MarketplaceCREDD.xml")
end

-----------------------------------------------------------------------------------------------
-- MarketplaceCREDD GetAsyncLoadStatus
-----------------------------------------------------------------------------------------------
function MarketplaceCREDD:GetAsyncLoadStatus()
	if g_AddonsLoaded == nil then
		g_AddonsLoaded = {}
	end

	if self.xmlDoc ~= nil and self.xmlDoc:IsLoaded() then
	    self.wndMain = Apollo.LoadForm(self.xmlDoc, "MarketplaceCREDDForm", nil, self)
		self.wndOpenOrders = Apollo.LoadForm(self.xmlDoc, "MarketplaceListingsForm", nil, self)
		
		if self.wndMain == nil or self.wndOpenOrders == nil then
			Apollo.AddAddonErrorText(self, "Could not load the main window for some reason.")
			return Apollo.AddonLoadStatus.LoadingError
		end
		
	    self.wndMain:Show(false, true)
		self.wndOpenOrders:Show(false, true)
		
		if self.tSavedOffsets then
			self.wndMain:SetAnchorOffsets(unpack(self.tSavedOffsets))
		end
		
		Apollo.RegisterEventHandler("ToggleCREDDExchangeWindow", "OnToggleCREDDExchangeWindow", self)
		Apollo.RegisterEventHandler("CREDDExchangeWindowClose", "OnCREDDExchangeWindowClose", self)
		Apollo.RegisterEventHandler("CREDDExchangeInfoResults", "OnCREDDExchangeInfoResults", self)
		Apollo.RegisterEventHandler("AccountOperationResults", "OnCREDDExchangeOperationResults", self)
		
		-- Generic Events
		Apollo.RegisterEventHandler("PlayerCurrencyChanged", "RefreshCurrency", self)
		Apollo.RegisterEventHandler("AccountInventoryUpdate", "RefreshCurrency", self)
		
		self.wndPlayerCashWindow = self.wndMain:FindChild("BGFooter:PlayerCashContainer:PlayerCashWindow")
		self.wndPlayerCREDDWindow = self.wndMain:FindChild("BGFooter:PlayerCREDDContainer:PlayerCREDDWindow")
		self.wndHeaderBuyBtn = self.wndMain:FindChild("HeaderBuyBtn")
		self.wndHeaderSellBtn = self.wndMain:FindChild("HeaderSellBtn")
		self.wndRefreshMarketBtn = self.wndMain:FindChild("RefreshMarketBG:RefreshMarketBtn")
		self.wndListInputPrice = self.wndMain:FindChild("MainScrollContainer:SimpleListItem:ListInputPriceBG:ListInputPrice")
		self.wndCommonAlertMessages = self.wndMain:FindChild("CommonAlertMessages")
		self.wndWaitingScreen = self.wndMain:FindChild("CommonAlertMessages:WaitingScreen")
		self.wndCreateMarketSellOrderBtn = self.wndMain:FindChild("MainScrollContainer:SimpleListItem:CreateMarketSellOrderBtn")
		self.wndCreateSellOrderBtn = self.wndMain:FindChild("MainScrollContainer:SimpleListItem:CreateSellOrderBtn")
		self.wndCreateBuyOrderBtn = self.wndMain:FindChild("MainScrollContainer:SimpleListItem:CreateBuyOrderBtn")
		self.wndCreateMarketBuyOrderBtn = self.wndMain:FindChild("MainScrollContainer:SimpleListItem:CreateMarketBuyOrderBtn")
		self.wndPostResultNotificationSubText = self.wndMain:FindChild("CommonAlertMessages:PostResultNotification:PostResultNotificationBG:PostResultNotificationSubText")
		
		self.wndListingMainScroll = self.wndOpenOrders:FindChild("ListingMainScroll")
		
		self.wndHeaderBuyBtn:SetCheck(true)
		
		Apollo.RegisterSlashCommand("creddex", "OnToggleCREDDExchangeWindow", self)
		
		-- register our Addon so others can wait for it if they want
		g_AddonsLoaded["MarketplaceCREDD"] = true
		
		self:Refresh()
		
		return Apollo.AddonLoadStatus.Loaded
	end
	return Apollo.AddonLoadStatus.Loading 
end

function MarketplaceCREDD:OnToggleCREDDExchangeWindow()
	self.wndMain:Show(not self.wndMain:IsShown())
	if self.wndMain:IsShown() then
		self.wndMain:ToFront()
		CREDDExchangeLib.RequestExchangeInfo()
		self:Refresh()
	end
end

function MarketplaceCREDD:Refresh()
	self:RefreshCurrency()
end

function MarketplaceCREDD:RefreshCurrency()
	local nCreddAmount = AccountItemLib.GetAccountCurrency(AccountItemLib.CodeEnumAccountCurrency.CREDD)
	self.wndPlayerCREDDWindow:SetText(nCreddAmount)
	
	local nPlayerCash = GameLib.GetPlayerCurrency():GetAmount()
	self.wndPlayerCashWindow:SetAmount(nPlayerCash)
end

function MarketplaceCREDD:RefreshListings()
	self.wndListingMainScroll:DestroyChildren()
	for idx, oOrder in pairs(self.arOrders) do
		local wndMarketOrder = Apollo.LoadForm(self.xmlDoc, "MarketListingForm", self.wndListingMainScroll, self)
		wndMarketOrder:FindChild("CancelBtn"):SetData(oOrder)
		wndMarketOrder:FindChild("BuyBG"):Show(oOrder:IsBuy())
		wndMarketOrder:FindChild("SellBG"):Show(not oOrder:IsBuy())
		if oOrder:IsBuy() then
			wndMarketOrder:FindChild("ItemName"):SetText("Buy")
		else
			wndMarketOrder:FindChild("ItemName"):SetText("Sell")
		end
		wndMarketOrder:FindChild("Price"):SetAmount(oOrder:GetPrice())
		wndMarketOrder:FindChild("TimeLeftText"):SetText(self:HelperFormatTimeString(oOrder:GetExpirationTime()))
	end
	self.wndListingMainScroll:ArrangeChildrenVert(0)
end

function MarketplaceCREDD:OnCREDDExchangeOperationResults(eResult)
	self.wndWaitingScreen:Show(false)
	
	if eResult == CREDDExchangeLib.CodeEnumAccountOperationResult.Ok then
		self.wndCommonAlertMessages:Show(false)
		self:Refresh()
		wndMarketData:FindChild("Price"):SetAmount(tOrderData.monPrice, false)
	elseif ktResultErrorCodeStrings[eResult] ~= nil and ktResultErrorCodeStrings[eResult] ~= "" then
		self.wndPostResultNotificationSubText:SetText(ktResultErrorCodeStrings[eResult])
	end
end

function MarketplaceCREDD:OnCREDDExchangeInfoResults(arMarketStats, arOrders)
	self.wndRefreshMarketBtn:Enable(true)
	self.wndRefreshMarketBtn:SetCheck(false)

	self.arMarketStats = arMarketStats
	self.arOrders = arOrders
	
	if self.wndHeaderBuyBtn:IsChecked() then
		self:OnHeaderBuyCheck()
	end
	if self.wndHeaderSellBtn:IsChecked() then
		self:OnHeaderSellCheck()
	end
end

function MarketplaceCREDD:ShowWaitScreen()
	self.wndCommonAlertMessages:Show(true)
	self.wndWaitingScreen:Show(true)
end

function MarketplaceCREDD:OnDestroy(wndHandler, wndControl, eMouseButton)
	self.wndMain:Show(false)
end

function MarketplaceCREDD:OnHeaderBuyCheck(wndHandler, wndControl, eMouseButton)
	local wndMarketDataContainer = self.wndMain:FindChild("MarketDataContainer")
	wndMarketDataContainer:DestroyChildren()
	for idx, tOrderData in pairs(self.arMarketStats.arSellOrderPrices) do
		local wndMarketData = Apollo.LoadForm(self.xmlDoc, "MarketDataForm", wndMarketDataContainer, self)
		wndMarketData:FindChild("Label"):SetText("AVG for last "..tOrderData.nCount)
		wndMarketData:FindChild("Price"):SetAmount(tOrderData.monPrice, false)
	end
	wndMarketDataContainer:ArrangeChildrenVert(0)
	
	self.wndListInputPrice:SetAmount(1)
	
	self.wndCreateMarketSellOrderBtn:Show(false)
	self.wndCreateSellOrderBtn:Show(false)
	self.wndCreateBuyOrderBtn:Show(true)
	self.wndCreateMarketBuyOrderBtn:Show(true)
end

function MarketplaceCREDD:OnHeaderSellCheck(wndHandler, wndControl, eMouseButton)
	local wndMarketDataContainer = self.wndMain:FindChild("MarketDataContainer")
	wndMarketDataContainer:DestroyChildren()
	for idx, tOrderData in pairs(self.arMarketStats.arBuyOrderPrices) do
		local wndMarketData = Apollo.LoadForm(self.xmlDoc, "MarketDataForm", wndMarketDataContainer, self)
		wndMarketData:FindChild("Label"):SetText("Price for first "..tOrderData.nCount)
		wndMarketData:FindChild("Price"):SetAmount(tOrderData.monPrice, false)
	end
	wndMarketDataContainer:ArrangeChildrenVert(0)
	
	self.wndListInputPrice:SetAmount(1)
	
	self.wndCreateMarketSellOrderBtn:Show(true)
	self.wndCreateSellOrderBtn:Show(true)
	self.wndCreateBuyOrderBtn:Show(false)
	self.wndCreateMarketBuyOrderBtn:Show(false)
end

function MarketplaceCREDD:OnRefreshMarketBtn(wndHandler, wndControl, eMouseButton)
	self.wndRefreshMarketBtn:Enable(false)
	CREDDExchangeLib.RequestExchangeInfo()
end

function MarketplaceCREDD:OnCreateBuyOrderBtn(wndHandler, wndControl, eMouseButton)
	CREDDExchangeLib.BuyCREDD(self.wndListInputPrice:GetCurrency(), false)
	self:ShowWaitScreen()
end

function MarketplaceCREDD:OnCreateMarketBuyOrderBtn(wndHandler, wndControl, eMouseButton)
	CREDDExchangeLib.BuyCREDD(self.wndListInputPrice:GetCurrency(), true)
	self:ShowWaitScreen()
end

function MarketplaceCREDD:OnCreateSellOrderBtn(wndHandler, wndControl, eMouseButton)
	CREDDExchangeLib.SellCREDD(self.wndListInputPrice:GetCurrency(), false)
	self:ShowWaitScreen()
end

function MarketplaceCREDD:OnCreateMarketSellOrderBtn(wndHandler, wndControl, eMouseButton)
	CREDDExchangeLib.SellCREDD(self.wndListInputPrice:GetCurrency(), true)
	self:ShowWaitScreen()
end

function MarketplaceCREDD:OnOpenMarketListingsBtn(wndHandler, wndControl, eMouseButton)
	self.wndOpenOrders:Show(not self.wndOpenOrders:IsShown())
	if self.wndOpenOrders:IsShown() then
		self.wndOpenOrders:ToFront()
		self:RefreshListings()
	end
end

function MarketplaceCREDD:HelperFormatTimeString(oExpirationTime)
	local strResult = ""
	local nInSeconds = math.floor(math.abs(Time.SecondsElapsed(oExpirationTime))) -- CLuaTime object
	local nDays = math.floor(nInSeconds / 86400)
	local nHours = math.floor(nInSeconds / 3600)
	local nMins = math.floor(nInSeconds / 60 - (nHours * 60))

	if nDays > 0 then
		strResult = String_GetWeaselString(Apollo.GetString("MarketplaceListings_Hours"), nDays)
	elseif nHours > 0 then
		strResult = String_GetWeaselString(Apollo.GetString("MarketplaceListings_Hours"), nHours)
	elseif nMins > 0 then
		strResult = String_GetWeaselString(Apollo.GetString("MarketplaceListings_Minutes"), nMins)
	else
		strResult = Apollo.GetString("MarketplaceListings_LessThan1m")
	end
	return strResult
end

function MarketplaceCREDD:OnMarketOrderCancelBtn(wndHandler, wndControl, eMouseButton)
	CREDDExchangeLib.CancelOrder(wndControl:GetData())
end

function MarketplaceCREDD:OnCloseOrdersBtn(wndHandler, wndControl, eMouseButton)
	self.wndOpenOrders:Show(false)
end

-----------------------------------------------------------------------------------------------
-- MarketplaceCREDD Instance
-----------------------------------------------------------------------------------------------
local MarketplaceCREDDInst = MarketplaceCREDD:new()
MarketplaceCREDDInst:Init()
