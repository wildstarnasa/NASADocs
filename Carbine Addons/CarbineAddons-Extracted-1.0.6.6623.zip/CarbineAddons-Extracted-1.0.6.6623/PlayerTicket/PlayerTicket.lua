-- Client lua script
require "Window"

---------------------------------------------------------------------------------------------------
-- PlayerTicketDialog module definition
---------------------------------------------------------------------------------------------------
local PlayerTicketDialog = {}

---------------------------------------------------------------------------------------------------
-- local constants
---------------------------------------------------------------------------------------------------
local kstrCellNormal = "CRB_Basekit:kitBtn_HoloNormal"
local kstrCellNormalFocus = "CRB_Basekit:kitBtn_HoloFlyby"
local kstrCellSelected = "CRB_Basekit:kitBtn_HoloPressed"
local kstrCellSelectedFocus = "CRB_Basekit:kitBtn_HoloPressedFlyby"

local kstrEnterTicket = Apollo.GetString("PlayerTicket_ChooseCategory")

local knSaveVersion = 1

---------------------------------------------------------------------------------------------------
-- PlayerTicketDialog initialization
---------------------------------------------------------------------------------------------------
function PlayerTicketDialog:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	
	-- initialize our variables
	o.wnd = nil
	
	-- return our object
	return o
end

---------------------------------------------------------------------------------------------------
function PlayerTicketDialog:Init()
	Apollo.RegisterAddon(self)
end

function PlayerTicketDialog:OnSave(eType)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Account then
		return
	end
	
	local locWindowLocation = self.wndMain and self.wndMain:GetLocation() or self.locSavedWindowLoc
	
	local tSave =
	{
		tWindowLocation = locWindowLocation and locWindowLocation:ToTable() or nil,
		nSaveVersion = knSaveVersion,
	}
	
	return tSave
end

function PlayerTicketDialog:OnRestore(eType, tSavedData)
	if not tSavedData or tSavedData.nSaveVersion ~= knSaveVersion then
		return
	end
	
	if tSavedData.tWindowLocation then
		self.locSavedWindowLoc = WindowLocation.new(self.locSavedWindowLoc)
		
		if self.wndMain then
			self.wndMain:MoveToLocation(self.locSavedWindowLoc)
		end
	end
end

---------------------------------------------------------------------------------------------------
-- PlayerTicketDialog EventHandlers
---------------------------------------------------------------------------------------------------
function PlayerTicketDialog:OnLoad()
	Apollo.RegisterEventHandler("TogglePlayerTicketWindow", "ToggleWindow", self)
	Apollo.RegisterEventHandler("PlayerTicketSetSelection", "SelectPlayerTicketType", self)
	-- load our forms
	self.wndMain 				= Apollo.LoadForm("PlayerTicket.xml", "PlayerTicketDialog", nil, self)
	self.wndTextEntry 			= self.wndMain:FindChild("PlayerTicketTextEntry")
	self.wndCatList 			= self.wndMain:FindChild("Category")
	self.wndSubcatList 			= self.wndMain:FindChild("SubCategory")
	self.wndAcceptBtn 			= self.wndMain:FindChild("OkBtn")
	self.wndSubCategoryBlocker 	= self.wndMain:FindChild("SubCatBlocker")
	
	self.wndMain:Show(false)
end

function PlayerTicketDialog:ToggleWindow()
	if self.wndMain:IsVisible() then
		self.wndMain:Show(false)
	else
		self:PopulateTypePicker()
	end
end

function PlayerTicketDialog:PopulateTypePicker()
	local tListOfEntries = PlayerTicket_GetErrorTypeList()	
	self.wndCatList:DeleteAll()
	self.wndSubcatList:DeleteAll()	
	self.wndTextEntry:SetText(kstrEnterTicket)
	self.wndTextEntry:SetTextColor(ApolloColor.new("UI_TextHoloBodyCyan"))
	self.wndTextEntry:Enable(false)
	self.wndAcceptBtn:Enable(false)
	self.wndSubCategoryBlocker:Show(true)
	
	self.nMainRowCount = 0
	for idx, CurrentError in ipairs (tListOfEntries) do
		local iRow = self.wndCatList:AddRow(CurrentError.localizedText, "", CurrentError.index)
	end
	
	self.wndMain:Show(true)
end

function PlayerTicketDialog:PopulateSubtypeCombo()
	local iRow = self.wndCatList:GetCurrentRow()
	local index = self.wndCatList:GetCellData(iRow, 1)
	self.wndSubcatList:DeleteAll()		

	local nRows = 0
	local tListOfSubentries = PlayerTicket_GetSubtype(index)	
	for idx, CurrentSubError in ipairs (tListOfSubentries) do
		local wndNewRow = self.wndSubcatList:AddRow(CurrentSubError.localizedText, "", CurrentSubError.index)
		nRows = nRows + 1
	end
	
	if nRows > 0 then
		if self.wndTextEntry:GetText() == kstrEnterTicket then
			self.wndTextEntry:SetText("")
		end	
		
		self.wndSubcatList:SetCurrentRow(1)	
		self.wndTextEntry:SetTextColor(ApolloColor.new("UI_TextHoloBody"))
		self.wndTextEntry:Enable(true)
		self.wndSubCategoryBlocker:Show(false)
		self.wndAcceptBtn:Enable(self.wndTextEntry:GetText() ~= nil and self.wndTextEntry:GetText() ~= "")
		self.wndTextEntry:SetFocus()
		self.wndTextEntry:SetSel(0, -1)	
	else	
		self.wndTextEntry:SetText(kstrEnterTicket)
		self.wndTextEntry:SetTextColor(ApolloColor.new("UI_TextHoloBodyCyan"))
		self.wndTextEntry:Enable(false)	
		self.wndAcceptBtn:Enable(false)		
		self.wndSubCategoryBlocker:Show(true)
	end
end

function PlayerTicketDialog:OnSubcategoryChanged()
	self.wndTextEntry:SetFocus()
	self.wndTextEntry:SetSel(0, -1)		
end

---------------------------------------------------------------------------------------------------
function PlayerTicketDialog:OnOkBtn(wndHandler, wndControl)
	if wndHandler:GetId() ~= wndControl:GetId() then
		return
	end
	--PlayerTicketDialog_Report (self.PlayerTicketTypeCombo:GetSelectedData (), self.PlayerTicketSubType:GetSelectedData (), self.wndTextEntry:GetText())
	local nCategory = self.wndCatList:GetCellData(self.wndCatList:GetCurrentRow(), 1)
	local nSubCategory = self.wndSubcatList:GetCellData(self.wndSubcatList:GetCurrentRow(), 1)
	
	if nCategory ~= nil and nSubCategory ~= nil then
		PlayerTicketDialog_Report (nCategory, nSubCategory, self.wndTextEntry:GetText())
	end
	
	self.wndMain:Show(false)
end

---------------------------------------------------------------------------------------------------
function PlayerTicketDialog:OnCancelBtn(wndHandler, wndControl)
	if wndHandler:GetId() ~= wndControl:GetId() then
		return
	end
	self.wndMain:Show(false)
end

---------------------------------------------------------------------------------------------------
function PlayerTicketDialog:OnTextChanged()
	self.wndAcceptBtn:Enable(self.wndTextEntry:GetText() ~= nil and self.wndTextEntry:GetText() ~= "")
end



---------------------------------------------------------------------------------------------------
-- PlayerTicketDialog instance
---------------------------------------------------------------------------------------------------
local PlayerTicketDialogInst = PlayerTicketDialog:new()
PlayerTicketDialogInst:Init()
