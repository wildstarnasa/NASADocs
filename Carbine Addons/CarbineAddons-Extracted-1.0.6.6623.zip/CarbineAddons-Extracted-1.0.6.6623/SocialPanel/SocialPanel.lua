-----------------------------------------------------------------------------------------------
-- Client Lua Script for SocialPanel
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "FriendshipLib"

local SocialPanel = {}
local knMaxNumberOfCircles = 5
local knSaveVersion

function SocialPanel:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function SocialPanel:Init()
    Apollo.RegisterAddon(self)
end

function SocialPanel:OnSave(eType)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Account then
		return
	end
	
	local locWindowLocation = self.wndMain and self.wndMain:GetLocation() or self.locSavedWindowLoc
	
	local tSaved = 
	{
		tWindowLocation = locWindowLocation and locWindowLocation:ToTable() or nil,
		nSaveVersion = knSaveVersion,
	}
	
	return tSaved
end

function SocialPanel:OnRestore(eType, tSavedData)
	if not tSavedData or tSavedData.nSaveVersion ~= knSaveVersion then
		return
	end
	
	if tSavedData.tWindowLocation then
		self.locSavedWindowLoc = WindowLocation.new(tSavedData.tWindowLocation)
	end
end

function SocialPanel:OnLoad()
	self.xmlDoc = XmlDoc.CreateFromFile("SocialPanel.xml")
	self.xmlDoc:RegisterCallback("OnDocumentReady", self) 
end

function SocialPanel:OnDocumentReady()
	if  self.xmlDoc == nil then
		return
	end
	
	Apollo.RegisterEventHandler("InterfaceMenuListHasLoaded", "OnInterfaceMenuListHasLoaded", self)
	
	Apollo.RegisterEventHandler("ToggleSocialWindow", 			"OnToggleSocialWindow", self)
	Apollo.RegisterEventHandler("EventGeneric_OpenSocialPanel", "OnEventGeneric_OpenSocialPanel", self)

	Apollo.RegisterEventHandler("GuildMemberChange", 			"OnGuildMemberChange", self)  -- this is for when member counts change.
	Apollo.RegisterEventHandler("GuildChange", 					"OnGuildChange", self)  -- notification that a guild was added / removed.
	Apollo.RegisterEventHandler("GuildName", 					"OnGuildChange", self) -- notification that the guild name has changed.

	Apollo.RegisterEventHandler("HousingBasicsUpdated",			"OnHousingBasicsUpdated", self)
	
	-- Friend Events
	Apollo.RegisterEventHandler("FriendshipAccountInvitesRecieved",  	"OnFriendshipInviteChange", self)
    Apollo.RegisterEventHandler("FriendshipAccountInviteRemoved",   	"OnFriendshipInviteChange", self)
	Apollo.RegisterEventHandler("FriendshipInvitesRecieved",  			"OnFriendshipInviteChange", self)
    Apollo.RegisterEventHandler("FriendshipInviteRemoved",   			"OnFriendshipInviteChange", self)
	Apollo.RegisterEventHandler("EventGeneric_FriendInviteSeen", 		"OnFriendshipInviteChange", self)
	
	-- Timers
	Apollo.RegisterTimerHandler("RetryLoadingSocialPanel", 		"FullyDrawSplashScreen", self)
	
    self.wndMain = nil

	self.arWndOnlineMemberCount = {}
end

function SocialPanel:OnInterfaceMenuListHasLoaded()
	Event_FireGenericEvent("InterfaceMenuList_NewAddOn", Apollo.GetString("InterfaceMenu_Social"), {"ToggleSocialWindow", "Social", "spr_HUD_MenuIcons_Social"})
	
	self:CalcFriendInvites()
end


function SocialPanel:OnToggleSocialWindow()
	if self.wndMain and self.wndMain:IsValid() and self.wndMain:IsShown() then
		self.wndMain:Close()
	else
		self:FullyDrawSplashScreen()
		self.wndMain:ToFront()
	end
end

function SocialPanel:OnCloseBtn(wndHandler, wndControl)
	if wndHandler == wndControl then
		Apollo.StopTimer("RetryLoadingSocialPanel")
		Event_FireGenericEvent("SocialWindowHasBeenClosed")
		self.wndMain:Close()
	end
end

function SocialPanel:OnEventGeneric_OpenSocialPanel(tPos)
	self:FullyDrawSplashScreen()
	self.wndMain:ToFront()
end

function SocialPanel:OnGuildMemberChange(guildUpdated)
	if self.wndMain and self.wndMain:IsShown() then
		if guildUpdated:GetType() == GuildLib.GuildType_Guild or guildUpdated:GetType() == GuildLib.GuildType_Circle then
			local strGuildName = guildUpdated:GetName()
			if self.arWndOnlineMemberCount[strGuildName] then
				self.arWndOnlineMemberCount[strGuildName]:SetText(String_GetWeaselString(Apollo.GetString("SocialPanel_MembersOnline"), guildUpdated:GetOnlineMemberCount()))
			end
		end
	end
end

function SocialPanel:OnGuildChange(guildUpdated)
	if self.wndMain and self.wndMain:IsShown() then
		self:FullyDrawSplashScreen()
	end
end

function SocialPanel:OnFriendshipInviteChange(tInvite)
	if self.wndMain and self.wndMain:IsShown() then
		self:FullyDrawSplashScreen()
	end
end

function SocialPanel:OnHousingBasicsUpdated()
	if self.wndMain and self.wndMain:IsShown() then
		self:FullyDrawSplashScreen()
	end
end

function SocialPanel:CalcFriendInvites()
	local nUnseenFriendInviteCount = 0
	for idx, tInvite in pairs(FriendshipLib.GetInviteList()) do
		if tInvite.bIsNew then
			nUnseenFriendInviteCount = nUnseenFriendInviteCount + 1
		end
	end
	for idx, tInvite in pairs(FriendshipLib.GetAccountInviteList()) do
		if tInvite.bIsNew then
			nUnseenFriendInviteCount = nUnseenFriendInviteCount + 1
		end
	end
	
	Event_FireGenericEvent("InterfaceMenuList_AlertAddOn", Apollo.GetString("InterfaceMenu_Social"), {nUnseenFriendInviteCount > 0})
	Event_FireGenericEvent("InterfaceMenuList_AlertAddOn", Apollo.GetString("InterfaceMenu_FriendsList"), {nUnseenFriendInviteCount > 0})
	
	return nUnseenFriendInviteCount
end

function SocialPanel:FullyDrawSplashScreen(bHide)
	if not self.wndMain or not self.wndMain:IsValid() then
		self.wndMain = Apollo.LoadForm(self.xmlDoc, "SocialPanelForm", nil, self) 
		self.wndMain:FindChild("SplashFriendsBtnAlert"):Show(false, true)
		
		if self.locSavedWindowLoc then
			self.wndMain:MoveToLocation(self.locSavedWindowLoc)
		end
	end

	Apollo.StopTimer("RetryLoadingSocialPanel")
	Event_ShowTutorial(GameLib.CodeEnumTutorial.General_Social)

	-------- Start Friends
	self.wndMain:FindChild("SplashFriendsBtnAlert"):Show(self:CalcFriendInvites() > 0)
	self.wndMain:FindChild("SplashFriendsBtnItemCount"):SetText(self:CalcFriendInvites())
	
	
	-------- Start Guilds
	local guildShown = nil
	self.arWndOnlineMemberCount = {}
	for idx, guildCurr in pairs(GuildLib.GetGuilds()) do
		if guildCurr:GetType() == GuildLib.GuildType_Guild then
			guildShown = guildCurr
			self.wndMain:FindChild("SplashGuildBtn"):SetData(guildShown)
			self.wndMain:FindChild("SplashGuildText"):SetText(guildShown:GetName())

			local strGuildName = guildCurr:GetName()
			self.arWndOnlineMemberCount[strGuildName] = self.wndMain:FindChild("SplashGuildSubtext")
			self.arWndOnlineMemberCount[strGuildName]:SetText(String_GetWeaselString(Apollo.GetString("SocialPanel_MembersOnline"), guildShown:GetOnlineMemberCount()))
		end
	end

	self.wndMain:FindChild("SplashGuildBtn"):Show(guildShown)
	self.wndMain:FindChild("SplashGuildDisabledBtn"):Show(not guildShown)

	if not guildShown then
		self.wndMain:FindChild("SplashGuildsLabel"):SetText(Apollo.GetString("SocialPanel_GuildLabel"))
	end

	-------- Start Circles
	self.wndMain:FindChild("SplashCircleItemContainer"):DestroyChildren() -- TODO: See if we can remove this

	local nNumberOfCircles = 0
	local arGuilds = GuildLib.GetGuilds()
	table.sort(arGuilds, function(a,b) return (self:HelperSortCirclesChannelOrder(a,b)) end)
	for key, guildCurr in pairs(arGuilds) do
		if guildCurr:GetType() == GuildLib.GuildType_Circle then
			nNumberOfCircles = nNumberOfCircles + 1

			local wndCurr = Apollo.LoadForm(self.xmlDoc, "SplashCirclesPickerItem", self.wndMain:FindChild("SplashCircleItemContainer"), self)
			wndCurr:FindChild("SplashCirclesPickerBtn"):SetData(guildCurr)
			wndCurr:FindChild("SplashCirclesPickerText"):SetText(guildCurr:GetName())

			self.arWndOnlineMemberCount[guildCurr:GetName()] = wndCurr:FindChild("SplashCirclesPickerSubtext")
			self.arWndOnlineMemberCount[guildCurr:GetName()]:SetText(String_GetWeaselString(Apollo.GetString("SocialPanel_MembersOnline"), guildCurr:GetOnlineMemberCount()))
		end
	end
	self.wndMain:FindChild("SplashCircleItemContainer"):ArrangeChildrenVert(0) 

	if nNumberOfCircles < knMaxNumberOfCircles then
		Apollo.LoadForm(self.xmlDoc, "SplashCirclesAddItem", self.wndMain:FindChild("SplashCircleItemContainer"), self)
		nNumberOfCircles = nNumberOfCircles + 1
	end

	for idx = nNumberOfCircles + 1, knMaxNumberOfCircles do -- Fill in the rest with blanks
		Apollo.LoadForm(self.xmlDoc, "SplashCirclesUnusedItem", self.wndMain:FindChild("SplashCircleItemContainer"), self)
	end

	self.wndMain:FindChild("SplashCircleItemContainer"):ArrangeChildrenVert(0)

	-------- Neighbors
	local bIsResidenceOwner = HousingLib.IsResidenceOwner()
	self.wndMain:FindChild("SplashNeighborsBtn"):Show(bIsResidenceOwner)
	self.wndMain:FindChild("SplashNeighborsDisabledBtn"):Show(not bIsResidenceOwner)

	-- Retry, in case Guild Lib is still loading
	if nNumberOfCircles > 0 and GuildLib:IsLoading() and self.wndMain:IsShown() then
		Apollo.CreateTimer("RetryLoadingSocialPanel", 1.0, false)
		Apollo.StartTimer("RetryLoadingSocialPanel")
	end

	self.wndMain:Show(true)
end

function SocialPanel:OnSplashBtn(wndHandler, wndControl)
	local nLeft, nTop, nRight, nBottom = self.wndMain:GetAnchorOffsets()
	local strBtnName = wndHandler:GetName()
	local strEvent = nil
	local guildData = nil

	if strBtnName == "SplashFriendsBtn" then
		strEvent = "EventGeneric_OpenFriendsList"
	elseif strBtnName == "SplashNeighborsBtn" then
		strEvent = "EventGeneric_OpenNeighborsList"
	elseif strBtnName == "SplashCirclesPickerBtn" and wndHandler:GetData() then
		strEvent = "EventGeneric_OpenCirclesPanel"
		guildData = wndHandler:GetData()
	elseif strBtnName == "SplashGuildBtn" and wndHandler:GetData() then
		strEvent = "EventGeneric_OpenGuildPanel"
		guildData = wndHandler:GetData()
	end

	Event_FireGenericEvent(strEvent, {["x"] = nLeft, ["y"] = nTop}, guildData)

	self.wndMain:Close()
end

function SocialPanel:OnSplashCirclesAddBtn(wndHandler, wndControl)
	Event_FireGenericEvent("EventGeneric_OpenCircleRegistrationPanel", self.wndMain)
end

function SocialPanel:HelperSortCirclesChannelOrder(guildLhs, guildRhs)
	local chanLhs = guildLhs and guildLhs:GetChannel()
	local chanRhs = guildRhs and guildRhs:GetChannel()
	local strCommandLhs = chanLhs and chanLhs:GetCommand() or ""
	local strCommandRhs = chanRhs and chanRhs:GetCommand() or ""
	
	return strCommandLhs < strCommandRhs
end

local SocialPanelInst = SocialPanel:new()
SocialPanelInst:Init()
