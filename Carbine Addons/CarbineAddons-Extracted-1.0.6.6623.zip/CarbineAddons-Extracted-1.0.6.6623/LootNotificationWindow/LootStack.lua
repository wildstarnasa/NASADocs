-----------------------------------------------------------------------------------------------
-- Client Lua Script for LootStack
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "Sound"
require "GameLib"

local LootStack = {}

local knMaxEntryData = 3 -- Previously 3
local kfMaxItemTime = 7	-- item display time (seconds)
local kfTimeBetweenItems = 2 -- Previously .3			-- delay between items; also determines clearing time (seconds)

local knType_Invalid = 0
local knType_Item = 1

local kfCashDisplayDuration = 5.0 		-- cash display timer (s)

local karQualitySquareSprite =
{
	[Item.CodeEnumItemQuality.Inferior] 		= "CRB_Tooltips:sprTooltip_Header_Silver",
	[Item.CodeEnumItemQuality.Average] 			= "CRB_Tooltips:sprTooltip_Header_White",
	[Item.CodeEnumItemQuality.Good] 			= "CRB_Tooltips:sprTooltip_Header_Green",
	[Item.CodeEnumItemQuality.Excellent] 		= "CRB_Tooltips:sprTooltip_Header_Blue",
	[Item.CodeEnumItemQuality.Superb] 			= "CRB_Tooltips:sprTooltip_Header_Purple",
	[Item.CodeEnumItemQuality.Legendary] 		= "CRB_Tooltips:sprTooltip_Header_Orange",
	[Item.CodeEnumItemQuality.Artifact]		 	= "CRB_Tooltips:sprTooltip_Header_Pink",
}

local karEvalColors =
{
	[Item.CodeEnumItemQuality.Inferior] 		= "ItemQuality_Inferior",
	[Item.CodeEnumItemQuality.Average] 			= "ItemQuality_Average",
	[Item.CodeEnumItemQuality.Good] 			= "ItemQuality_Good",
	[Item.CodeEnumItemQuality.Excellent] 		= "ItemQuality_Excellent",
	[Item.CodeEnumItemQuality.Superb] 			= "ItemQuality_Superb",
	[Item.CodeEnumItemQuality.Legendary] 		= "ItemQuality_Legendary",
	[Item.CodeEnumItemQuality.Artifact]		 	= "ItemQuality_Artifact",
}

function LootStack:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
	o.arEntries = {}
	o.tEntryData = {}
	o.tQueuedEntryData = {}
	o.fLastTimeAdded = 0
    return o
end

function LootStack:Init()
    Apollo.RegisterAddon(self)
end

function LootStack:OnSave(eType)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Character then
		return
	end
	local tSavedData = {}
	tSavedData.tAnchorOffsets = {self.wndLootStack:GetAnchorOffsets()}
	return tSavedData
end

function LootStack:OnRestore(eType, tSavedData)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Character then
		return
	end
	if tSavedData.tAnchorOffsets then
		--self.wndLootStack:SetAnchorOffsets(unpack(tSavedData.tAnchorOffsets))
	end
end

function LootStack:OnLoad()
	Apollo.RegisterEventHandler("LootedItem", 			"OnLootedItem", self)
	Apollo.RegisterEventHandler("LootedMoney", 			"OnLootedMoney", self)

	-- Stun Events
	Apollo.RegisterEventHandler("ActivateCCStateStun", 	"OnActivateCCStateStun", self)
	Apollo.RegisterEventHandler("RemoveCCStateStun", 	"OnRemoveCCStateStun", self)

	Apollo.RegisterTimerHandler("LootStackUpdate",		"OnLootStackUpdate", self)
	Apollo.RegisterTimerHandler("CashTimer", 			"OnCashTimer", self)

	Apollo.CreateTimer("LootStackUpdate", 0.1, true)

	Apollo.CreateTimer("CashTimer", kfCashDisplayDuration, false)
	Apollo.StartTimer("CashTimer")

	self.wndLootStack = Apollo.LoadForm("LootStack.xml", "LootStackForm", "InWorldHudStratum", self)
	self.wndLootStack:Show(false)
	self.wndCashComplex = self.wndLootStack:FindChild("CashComplex")
	self.wndCashComplex:Show(false)
	self.wndCashDisplay = self.wndCashComplex:FindChild("CashDisplay")

	for idx = 1, knMaxEntryData do
		local wndEntry = self.wndLootStack:FindChild("LootedItem_"..idx)
		self.arEntries[idx] = wndEntry
	end

	self:UpdateDisplay()
end

-----------------------------------------------------------------------------------------------
-- Hide if stunned
-----------------------------------------------------------------------------------------------

function LootStack:OnActivateCCStateStun()
	self.wndLootStack:Show(false)
end

function LootStack:OnRemoveCCStateStun()
	self.wndLootStack:Show(true)
end

-----------------------------------------------------------------------------------------------
-- CASH FUNCTIONS
-----------------------------------------------------------------------------------------------

function LootStack:OnLootedMoney(monLooted)
	local eCurrencyType = monLooted:GetMoneyType()
	if eCurrencyType ~= Money.CodeEnumCurrencyType.Credits then
		return
	end

	self.wndCashDisplay:SetAmount(self.wndCashDisplay:GetAmount() + monLooted:GetAmount())
	self.wndCashComplex:Show(true)

	Apollo.StopTimer("CashTimer")
	Apollo.StartTimer("CashTimer")
end

function LootStack:OnCashTimer()
	self.wndCashComplex:Show(false)
	self.wndCashDisplay:SetAmount(0)
end

-----------------------------------------------------------------------------------------------
-- ITEM FUNCTIONS
-----------------------------------------------------------------------------------------------

function LootStack:OnLootStackUpdate(strVar, nValue)
	if self.wndLootStack == nil then
		return
	end

	local fCurrTime = GameLib.GetGameTime()

	-- remove any old items
	for idx, tEntryData in ipairs(self.tEntryData) do   --TODO: time the remove to delay
		if fCurrTime - tEntryData.fTimeAdded >= kfMaxItemTime then
			self:RemoveItem(idx)
		end
	end

	-- add a new item if its time
	if #self.tQueuedEntryData > 0 then
		if fCurrTime - self.fLastTimeAdded >= kfTimeBetweenItems then
			self:AddQueuedItem()
		end
	end

	-- update all the items
	self:UpdateDisplay()
end

function LootStack:OnLootedItem(itemInstance, nCount)
	-- add this item to the queue to be popped during OnFrameUpdate
	self.tQueuedEntryData[#self.tQueuedEntryData + 1] =
	{
		eType = knType_Item,
		itemInstance = itemInstance,
		nCount = nCount,
		money = nil,
		fTimeAdded = GameLib.GetGameTime()
	}
	self.fLastTimeAdded = GameLib.GetGameTime()
end

function LootStack:AddQueuedItem()
	-- gather our entryData we need
	local tQueuedData = self.tQueuedEntryData[1]
	table.remove(self.tQueuedEntryData, 1)
	if tQueuedData == nil then
		return
	end

	if tQueuedData.eType == knType_Item and tQueuedData.nCount == 0 then
		return
	end

	-- ensure there's room
	while #self.tEntryData >= knMaxEntryData do
		if not self:RemoveItem(1) then
			break
		end
	end

	-- push this item on the end of the table
	local fCurrTime = GameLib.GetGameTime()
	local nBtnIdx = #self.tEntryData + 1
	self.tEntryData[nBtnIdx] = tQueuedData
	self.tEntryData[nBtnIdx].fTimeAdded = fCurrTime -- adds a delay for vaccuum looting by switching logged to "shown" time

	self.fLastTimeAdded = fCurrTime

	-- animate the entry down
	--self.arEntries[btnIdx]:PlayAnim(0)
end

function LootStack:RemoveItem(idx)
	-- validate our inputs
	if idx < 1 or idx > #self.tEntryData then
		return false
	end

	-- remove that item and alert inventory
	local tEntryData = self.tEntryData[idx]
	table.remove(self.tEntryData, idx)
	return true
end

function LootStack:UpdateDisplay()
	-- iterate over our entry data updating all the buttons
	for idx, wndEntry in ipairs(self.arEntries) do
		local tCurrEntryData = self.tEntryData[idx]
		local tCurrItem = tCurrEntryData and tCurrEntryData.itemInstance or false

		wndEntry:Show(tCurrEntryData)

		if tCurrEntryData and tCurrItem and tCurrEntryData.nButton ~= idx then
			local bGivenQuest = tCurrItem:GetGivenQuest()
			local eItemQuality = tCurrItem and tCurrItem:GetItemQuality() or 1
			wndEntry:FindChild("Text"):SetTextColor(bGivenQuest and "white" or karEvalColors[eItemQuality])
			wndEntry:FindChild("LootIcon"):SetSprite(bGivenQuest and "sprMM_QuestGiver" or tCurrItem:GetIcon())
			wndEntry:FindChild("RarityBracket"):SetSprite(bGivenQuest and "sprTooltip_Header_White" or karQualitySquareSprite[eItemQuality])

			if tCurrEntryData.nCount == 1 then
				wndEntry:FindChild("Text"):SetText(tCurrItem:GetName())
			else
				wndEntry:FindChild("Text"):SetText(String_GetWeaselString(Apollo.GetString("CombatLog_MultiItem"), tCurrEntryData.nCount, tCurrItem:GetName()))
			end
			tCurrEntryData.nButton = idx
		end
	end

	self.wndLootStack:ArrangeChildrenVert(0)
end

local LootStackInst = LootStack:new()
LootStackInst:Init()
