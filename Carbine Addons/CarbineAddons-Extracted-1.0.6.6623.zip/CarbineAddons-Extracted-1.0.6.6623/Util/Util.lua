-- Util.lua
-- Carbine Studios, LLC


function FixXMLString(str)
	str = str:gsub("&", "&amp;")	-- must do this first!
	str = str:gsub("<", "&lt;")
	str = str:gsub(">", "&gt;")
	str = str:gsub("'", "&apos;")
	str = str:gsub('"', "&quot;")
	return str
end


---------------------------------------------------------------------------------------------------
-- TableUtil:Copy
---------------------------------------------------------------------------------------------------
TableUtil = {}
function TableUtil:Copy(t)
  local t2 = {}
  if type(t) ~= "table" then
    return t
  end
  for k,v in pairs(t) do
    t2[k] = TableUtil:Copy(v)
  end
  return t2
end

---------------------------------------------------------------------------------------------------
-- fifo queue implementation
---------------------------------------------------------------------------------------------------
Queue = {}

function Queue:new(o)
  	o = o or {tItems={}}
	setmetatable(o, self)
	self.__index = self
	o.iFirst = 1
	o.iLast = 0
	return o
end
---------------------------------------------------------------------------------------------------
function Queue:Push( oValue )
    local iNewIndex = self.iLast + 1
	self.iLast = iNewIndex
	self.tItems[iNewIndex] = oValue
end
---------------------------------------------------------------------------------------------------
function Queue:Pop()
	local iNewFront = self.iFirst
	if iNewFront > self.iLast then
		return
	end
	
	local oValue = self.tItems[iNewFront]
	self.tItems[iNewFront] = nil
	self.iFirst = iNewFront + 1
	
	return oValue
end

---------------------------------------------------------------------------------------------------
function Queue:Insert( iPos, item )
    table.insert( self.tItems, self.iFirst + iPos, item )
	self.iLast = self.iLast + 1
end
---------------------------------------------------------------------------------------------------
function Queue:Remove( iPos )
    table.remove( self.tItems,  self.iFirst + iPos )
	self.iLast = self.iLast - 1
end
---------------------------------------------------------------------------------------------------
function Queue:GetItems()
    return self.tItems
end
---------------------------------------------------------------------------------------------------
function Queue:GetSize()
	local nItems = 0
	
	for idx, value in pairs(self.tItems) do
		nItems = nItems + 1
	end
	
    return nItems
end
---------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
local UtilLib = {}

function UtilLib:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self 

    -- initialize variables here

    return o
end

function UtilLib:Init()
	Apollo.RegisterAddon(self)
end
 

-----------------------------------------------------------------------------------------------
-- Rover OnLoad
-----------------------------------------------------------------------------------------------
function UtilLib:OnLoad()
end


-----------------------------------------------------------------------------------------------
-- Rover Instance
-----------------------------------------------------------------------------------------------
local UtilLibInst = UtilLib:new()
UtilLibInst:Init()
UtilLibInst = nil



