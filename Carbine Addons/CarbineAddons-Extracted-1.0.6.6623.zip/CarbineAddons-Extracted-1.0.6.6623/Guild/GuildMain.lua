-----------------------------------------------------------------------------------------------
-- Client Lua Script for GuildMain
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------

require "Window"
require "GameLib"

local Guild = {}

local knSaveVersion = 1

function Guild:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function Guild:Init()
    Apollo.RegisterAddon(self)
end

function Guild:OnSave(eType)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Account then
		return
	end
	
	local locWindowLocation = g_wndGuild and g_wndGuild:GetLocation() or self.locSavedWindowLoc
	
	local tSaved = 
	{
		tWindowLocation = locWindowLocation and locWindowLocation:ToTable() or nil,
		nSavedVersion = knSaveVersion,
	}
	return tSaved
end

function Guild:OnRestore(eType, tSavedData)
	if not tSavedData or tSavedData.nSavedVersion ~= knSaveVersion then
		return
	end
	
	if tSavedData.tWindowLocation then
		self.locSavedWindowLoc = WindowLocation.new(tSavedData.tWindowLocation)
	end
end

function Guild:OnLoad()
	self.xmlDoc = XmlDoc.CreateFromFile("GuildMain.xml")
	self.xmlDoc:RegisterCallback("OnDocumentReady", self) 
end

function Guild:OnDocumentReady()
	if  self.xmlDoc == nil then
		return
	end
    g_wndGuild = Apollo.LoadForm(self.xmlDoc, "GuildMainForm", nil, self)
    self.wndOptions = g_wndGuild:FindChild("TopTabContainer")

    Apollo.RegisterSlashCommand("guildpanel", 					"OnGuildOn", self) -- Note: dont register "guild" as the slash command.  guild chat channel tries to bind to /g and /guild for chat.  If it detects that is already taken it binds to /g1 and /guild1.  
    Apollo.RegisterEventHandler("EventGeneric_OpenGuildPanel", 	"OnGuildOn", self)
	Apollo.RegisterEventHandler("EventGeneric_CloseGuildPanel", "OnClose", self)
	Apollo.RegisterEventHandler("ToggleGuild", "OnToggleGuild", self)

    Apollo.RegisterEventHandler("GuildChange", 					"OnGuildChange", self) -- notification that a guild was added / removed.
	Apollo.RegisterEventHandler("GuildInvite", 					"OnGuildInvite", self) -- notification you got a guild/circle invite
	Apollo.RegisterEventHandler("GuildResult", 					"OnGuildResult", self) -- notification about an action that occured with the guild (Likely from self)

    Apollo.RegisterTimerHandler("RetryLoadingGuilds", 			"RetryLoadingGuilds", self)

	self.tContent = {}
	for idx = 1, 3 do
		self.tContent[idx] = g_wndGuild:FindChild("ContentWnd_" .. idx)
		self.tContent[idx]:Show(false)
	end

	Event_FireGenericEvent("GuildMainLoaded")
	self.nLastSelection = -1
	g_wndGuild:Show(false)
	if self.locSavedWindowLoc then
		g_wndGuild:MoveToLocation(self.locSavedWindowLoc)
	end
end

function Guild:OnGuildOn()
	if g_wndGuild:IsShown() then
		g_wndGuild:Show(false)
		Event_FireGenericEvent("GuildWindowHasBeenClosed")
	else
		g_wndGuild:ToFront()
	
		local bGuildTableIsEmpty = true
		for key, tGuild in pairs(GuildLib.GetGuilds()) do
			if tGuild:GetType() == GuildLib.GuildType_Guild then
				bGuildTableIsEmpty = false
				g_wndGuild:SetData(tGuild)
			end
		end

		if bGuildTableIsEmpty or GuildLib:IsLoading() then
			g_wndGuild:FindChild("JoinContainer"):Show(true)
			g_wndGuild:FindChild("GuildOption1"):Enable(false)
			g_wndGuild:FindChild("GuildOption2"):Enable(false)
			g_wndGuild:FindChild("GuildOption3"):Enable(false)
			g_wndGuild:Show(true)

			Apollo.CreateTimer("RetryLoadingGuilds", 1.0, false)
			Apollo.StartTimer("RetryLoadingGuilds")
			return
		end

		g_wndGuild:FindChild("JoinContainer"):Show(false)
		g_wndGuild:FindChild("GuildOption1"):Enable(true)
		g_wndGuild:FindChild("GuildOption2"):Enable(true)
		g_wndGuild:FindChild("GuildOption3"):Enable(true)

		if self.nLastSelection == nil or self.nLastSelection == 1 then self:ToggleInfo()
		elseif self.nLastSelection == 2 then self:ToggleRoster()
		elseif self.nLastSelection == 3 then self:TogglePerks()
		else self:ToggleInfo() end
	end
end

function Guild:RetryLoadingGuilds()
	Apollo.StopTimer("RetryLoadingGuilds")
	g_wndGuild:Show(false)
	self:OnGuildOn()
end

function Guild:OnClose(wndHandler, wndControl)
	if wndHandler == wndControl then
		g_wndGuild:Show(false)
		Apollo.StopTimer("RetryLoadingGuilds")
		Event_FireGenericEvent("GuildWindowHasBeenClosed")
	end
end

function Guild:OnToggleGuild()
	if g_wndGuild:IsShown() then
		self:OnClose()
	else
		self:OnGuildOn()
	end
end

function Guild:ToggleInfo()
	if g_wndGuild:IsShown() and self.nLastSelection == 1 then
		g_wndGuild:Show(false)
		Event_FireGenericEvent("GuildWindowHasBeenClosed")
	else
		g_wndGuild:Show(true)
		g_wndGuild:ToFront()
		self.wndOptions:SetRadioSel("GuildOptions", 1)
		self:OnGuildOptionCheck(nil, nil, false)
	end
end

function Guild:ToggleRoster()
	if g_wndGuild:IsShown() and self.nLastSelection == 2 then
		g_wndGuild:Show(false)
		Event_FireGenericEvent("GuildWindowHasBeenClosed")
	else
		g_wndGuild:Show(true)
		g_wndGuild:ToFront()
		self.wndOptions:SetRadioSel("GuildOptions", 2)
		self:OnGuildOptionCheck(nil, nil, false)
	end
end

function Guild:TogglePerks()
	if g_wndGuild:IsShown() and self.nLastSelection == 3 then
		g_wndGuild:Show(false)
		Event_FireGenericEvent("GuildWindowHasBeenClosed")
	else
		g_wndGuild:Show(true)
		g_wndGuild:ToFront()
		self.wndOptions:SetRadioSel("GuildOptions", 3)
		self:OnGuildOptionCheck(nil, nil, false)
	end
end

function Guild:OnGuildOptionCheck(wndHandler, wndControl, bToggledFromCall, tUserData)
	local nGuildOption = self.wndOptions:GetRadioSel("GuildOptions")
	if nGuildOption ~= 1 then -- the player's switched to anything but Info (which auto-selects)
		Event_FireGenericEvent("Guild_TabChanged") -- stops anything going on in the window
	end

	for idx = 1, 3 do
		self.tContent[idx]:Show(false)
	end

	if nGuildOption == 1 then
		Event_FireGenericEvent("Guild_ToggleInfo")
	elseif nGuildOption == 2 then
		Event_FireGenericEvent("Guild_ToggleRoster")
	elseif nGuildOption == 3 then
		Event_FireGenericEvent("Guild_TogglePerks")
	end

	self.nLastSelection = nGuildOption -- Save last selection
	self.tContent[nGuildOption]:Show(true)

	if not g_wndGuild:IsVisible() then -- in case it's responding to a key or Datachron toggle
		g_wndGuild:Show(true)
		g_wndGuild:ToFront()
	end
end

-----------------------------------------------------------------------------------------------
-- Guild Invite Window
-----------------------------------------------------------------------------------------------

function Guild:OnGuildInvite( strGuildName, strInvitorName, guildType, tFlags )
	if guildType ~= GuildLib.GuildType_Guild then return end

	if self.wndGuildInvite ~= nil then
		self.wndGuildInvite:Destroy()
	end

	self.wndGuildInvite = Apollo.LoadForm(self.xmlDoc, "GuildInviteConfirmation", nil, self)
	self.wndGuildInvite:FindChild("GuildInviteLabel"):SetText(String_GetWeaselString(Apollo.GetString("Guild_IncomingInvite"), strGuildName, strInvitorName))
	self.wndGuildInvite:FindChild("GuildInviteTaxes"):Show( tFlags.bTax )
	self.wndGuildInvite:ToFront()
end

function Guild:OnGuildInviteAccept(wndHandler, wndControl)
	GuildLib.Accept()
	if self.wndGuildInvite then
		self.wndGuildInvite:Destroy()
	end
end

function Guild:OnGuildInviteDecline() -- This can come from a variety of sources
	GuildLib.Decline()
	if self.wndGuildInvite then
		self.wndGuildInvite:Destroy()
	end
end

-----------------------------------------------------------------------------------------------
-- OnGuildResult
-----------------------------------------------------------------------------------------------

function Guild:OnGuildResult(guildCurr, strName, nRank, eResult)
	if eResult == GuildLib.GuildResult_PendingInviteExpired and self.wndGuildInvite ~= nil then
		self.wndGuildInvite:Destroy()
	end
end

-- Feedback Messages
-----------------------------------------------------------------------------------------------
function Guild:OnGuildChange()
	-- a guild was added or removed.
	for idx = 1, 3 do
		self.tContent[idx]:Show(false)
	end
	
	if g_wndGuild:IsShown() then
		g_wndGuild:Show(false)
		Event_FireGenericEvent("GuildWindowHasBeenClosed")
		self:OnGuildOn()
	end
end

local GuildInst = Guild:new()
GuildInst:Init()
