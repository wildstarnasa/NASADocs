----------------------------------------------------------------------------------------------- 
-- Client Lua Script for Keybinding 
-- Copyright (c) NCsoft. All rights reserved 
----------------------------------------------------------------------------------------------- 

require "Window"
require "GameLib"
require "Apollo"


-----------------------------------------------------------------------------------------------
-- Keybinding module definition
-----------------------------------------------------------------------------------------------
local Keybinding = {}

----------------------------------------------------------------------------------------------- 
--  Constants
----------------------------------------------------------------------------------------------- 

local LuaEnumKeybindingState =
{
    Idle 					= 0,
    AcceptingInput 			= 1,
    SelectingSet 			= 2,
    ConfirmUnbindDuplicate 	= 3,
    SelectCopySet 			= 4,
	AcceptingModfierInput 	= 5,
}

local knSavedVersion = 1

---------------------------------------------------------------------------------------------------
-- Keybinding Initializing
---------------------------------------------------------------------------------------------------
function Keybinding:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	-- initialize our variables
	o.tItems = {}
	o.tCollapsedCategories = {}
	o.nCollapsedCount = 0
	o.bCollapseAll = false
	return o
end

---------------------------------------------------------------------------------------------------
-- Keybinding Event Handlers
---------------------------------------------------------------------------------------------------
function Keybinding:Init()
	Apollo.RegisterAddon(self, true, Apollo.GetString("CRB_Keybindings"))
end

function Keybinding:OnSave(eType)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Account then
		return
	end
	
	local tSaved = 
	{
		tOffsets = {self.wndKeybindingForm:GetAnchorOffsets()},
		nSavedVersion = knSaveVersion
	}
	return tSaved
end

function Keybinding:OnRestore(eType, tSavedData)
	if not tSavedData or tSavedData.nSavedVersion ~= knSaveVersion then
		return
	end
	
	if tSavedData.tOffsets then
		self.wndKeybindingForm:SetAnchorOffsets(unpack(tSavedData.tOffsets))
	end
end

---------------------------------------------------------------------------------------------------
function Keybinding:OnLoad()
	Apollo.RegisterEventHandler("InterfaceMenu_Keybindings", 	"OnShow", self)
	Apollo.RegisterEventHandler("KeyDown", 						"OnKeyDown", self)
	Apollo.RegisterEventHandler("KeyBindingUpdated", 			"RefreshKeybindList", self) -- reload keybind list
	Apollo.RegisterEventHandler("KeyBindingReceived", 			"UpdateCopySet", self) -- received the copy set from db	
	Apollo.RegisterSlashCommand("keybind", 						"OnShow", self)

-- Setting up the main keybind interface forms
	self.wndKeybindingForm 	= Apollo.LoadForm("KeybindingForms.xml", "KeybindingForm", nil, self) --this is the main form
	self.wndKeybindList 	= self.wndKeybindingForm:FindChild("KeybindList") --this is the empty list keybinds load into
	self.wndFeedback 		= self.wndKeybindingForm:FindChild("FeedbackText")
	self.wndDuplicateMsg 		= self.wndKeybindingForm:FindChild("DuplicateMsg")
	self.wndListBlocker 	= self.wndKeybindingForm:FindChild("KeybindListBlocker")
	
	self.wndSetSelectionBtn	= self.wndKeybindingForm:FindChild("SetSelection")
	self.wndSetSave 		= self.wndKeybindingForm:FindChild("SaveSetButton")
	self.wndSetCancel 		= self.wndKeybindingForm:FindChild("CancelSetButton")
	self.wndBindUnbind 		= self.wndKeybindingForm:FindChild("UnbindButton")
	self.wndBindCancel 		= self.wndKeybindingForm:FindChild("CancelButton")
	self.wndUndoUnbindDuplicate = self.wndKeybindingForm:FindChild("UndoBindButton")
	
	self.wndVerifyYes 		= self.wndKeybindingForm:FindChild("ConfirmBindButton")
	self.wndVerifyNo 		= self.wndKeybindingForm:FindChild("CancelBindButton")	

	self.wndOkForm 			= self.wndKeybindingForm:FindChild("OkForm")	--this form is for displaying message
	self.wndOkForm:Show(false)
	
	self.tItems = {}
	
-- setting up modifier selection stuffs for sprint
	self.wndModifierSelection 	= self.wndKeybindingForm:FindChild("SelectModifier")
	self.nReservedModifier 		= 0 -- for preventing user binding other keys with the chosen modifier for sprint
	self.wndModifierDropdown 	= nil -- for getting the position of the selection window
	
-- Setting up the Set Selection interface form	
    self.wndSetSelection 		= self.wndKeybindingForm:FindChild("SetSelectionWindow") --shortcut sets are selected from this list
	self.arKeySetBtns = 
	{
		[GameLib.CodeEnumInputSets.Account] 	= self.wndSetSelection:FindChild("AccountCustom"),
		[GameLib.CodeEnumInputSets.Character] 	= self.wndSetSelection:FindChild("CharacterCustom")
	}
    self.arKeySetNames = 
	{
		[GameLib.CodeEnumInputSets.Account] 	= self.arKeySetBtns[GameLib.CodeEnumInputSets.Account]:GetText(),
		[GameLib.CodeEnumInputSets.Character] 	= self.arKeySetBtns[GameLib.CodeEnumInputSets.Character]:GetText()
	}

    self.arKeySetBtns[GameLib.CodeEnumInputSets.Account]:SetData(GameLib.CodeEnumInputSets.Account)
    self.arKeySetBtns[GameLib.CodeEnumInputSets.Character]:SetData(GameLib.CodeEnumInputSets.Character)
    self.wndSetSelection:Show(false)
-- Setting up the Copy Set Confirmation interface form	
	self.wndYesNoForm = self.wndKeybindingForm:FindChild("YesNoForm")	--this form is used to confirm duplicating a set
	self.wndYesNoForm:Show(false)
        
	self.wndKeybindingForm:Show(false)

end	

function Keybinding:OnConfigure()
	self:OnShow()
end

---------------------------------------------------------------------------------------------------
-- Interface
---------------------------------------------------------------------------------------------------	
function Keybinding:OnShow()
	if IsDemo() then
		return
	end

    GameLib.PauseGameActionInput(true)

	self.wndKeybindingForm:Show(true)
	self.wndKeybindingForm:ToFront()
    
    -- get current key set
    self.eCurrKeySet = GameLib.GetCurrInputKeySet()
    self.eOriginalKeySet = self.eCurrKeySet

	for idx, wndButton in pairs(self.arKeySetBtns) do 
		wndButton:SetCheck(false)
	end
	
    self.arKeySetBtns[self.eCurrKeySet]:SetCheck(true)
    self.wndSetSelectionBtn:SetText(self.arKeySetNames[self.eCurrKeySet])
    
    self.wndSetSelection:Show(false)    
    self.wndYesNoForm:Show(false)
    
    self:InitializeVariables()
	self.arKeyBindings = GameLib.GetKeyBindings()
	self:PopulateKeybindList()
	
	self:ShowUndoUnbindDuplicateMessage(false)
    
end	

function Keybinding:InitializeVariables()

    self:SetState(LuaEnumKeybindingState.Idle)
	
	-- for keeping track of the current selections before confirming binding
    self.wndCurrBind = nil
	self.wndCurrModifierBind = nil
    
    -- keep track if there's any unsaved data
    self.bNeedSave = false
    self.bNeedSaveSet = false
    self.bShowingYesNoDialog = false
    
end

function Keybinding:RefreshKeybindList()
    self.arKeyBindings = GameLib.GetKeyBindings()
    self:PopulateKeybindList()
end
	
function Keybinding:AddCategory(tCategory)
    -- add new binding into the form
    local wndBindingItem = Apollo.LoadForm( "KeybindingForms.xml", "KeybindCategoryItem", self.wndKeybindList, self )
	wndBindingItem:SetText( "-- " .. tCategory.strName .. " --" )
	wndBindingItem:SetData(tCategory.nCategoryId) 
end

function Keybinding:IsSprintAction( tBinding )
	if tBinding.strAction == "SprintModifier" then return true end
	return false
end

function Keybinding:IsModifierKeyName( strName )
	if strName == 'Alt' then return true end
	if strName == 'Shift' then return true end
	if strName == 'Ctrl' then return true end
	return false
end

function Keybinding:ClearSprintIfModifier( iKeyBinding )
	if self.arKeyBindings[iKeyBinding].strAction == "SprintModifier" then
		if self:IsModifierKeyName(GameLib.GetInputKeyNameText(self.arKeyBindings[iKeyBinding].arInputs[1])) or self:IsModifierKeyName(GameLib.GetInputKeyNameText(self.arKeyBindings[iKeyBinding].arInputs[2])) then
	        local tCurrInput = {} 
			tCurrInput.eDevice = GameLib.CodeEnumInputDevice.None
	        tCurrInput.nCode = 0
	        tCurrInput.eModifier = 0

		    self.arKeyBindings[iKeyBinding].arInputs[1] = TableUtil:Copy(tCurrInput)
		    self.arKeyBindings[iKeyBinding].arInputs[2] = TableUtil:Copy(tCurrInput)

			self.nReservedModifier = 0
			
			if self.wndModifierDropdown then
				self.wndModifierDropdown:SetText( Apollo.GetString("Keybinding_Unbound") )
			end
		end
	end
end

function Keybinding:AddKeyBinding(iKeyBinding, tBinding)
    -- add new binding into the form
	local wndBindingItem
	if self:IsSprintAction(tBinding) then
		wndBindingItem = Apollo.LoadForm("KeybindingForms.xml", "KeybindModifierOptKeyItem", self.wndKeybindList, self)
		wndBindingItem:FindChild("KbList_Text"):SetText(tBinding.strActionLocalized)
		
		if self:IsModifierKeyName(GameLib.GetInputKeyNameText(tBinding.arInputs[1])) then
			wndBindingItem:FindChild("DropdownButton"):SetText( GameLib.GetInputKeyNameText(tBinding.arInputs[1]) )
			wndBindingItem:FindChild("BindButton1"):SetText(Apollo.GetString("Keybinding_Unbound"))
		else	
			wndBindingItem:FindChild("DropdownButton"):SetText( Apollo.GetString("Keybinding_Unbound") )
			wndBindingItem:FindChild("BindButton1"):SetText(GameLib.GetInputKeyNameText(tBinding.arInputs[1]))
		end
		wndBindingItem:FindChild("BindButton1"):SetData(1)
		self.wndModifierDropdown = wndBindingItem:FindChild("DropdownButton") 
		self.nReservedModifier = tBinding.arInputs[1].nCode 
	else
	    wndBindingItem = Apollo.LoadForm("KeybindingForms.xml", "KeybindListItem", self.wndKeybindList, self)
		wndBindingItem:FindChild("KbList_Text"):SetText(tBinding.strActionLocalized)
		wndBindingItem:FindChild("BindButton1"):SetText(GameLib.GetInputKeyNameText(tBinding.arInputs[1]))
		wndBindingItem:FindChild("BindButton2"):SetText(GameLib.GetInputKeyNameText(tBinding.arInputs[2]))
		wndBindingItem:FindChild("BindButton1"):SetData(1)
		wndBindingItem:FindChild("BindButton2"):SetData(2)
	end
	self.tItems[tBinding.idAction] = wndBindingItem
	wndBindingItem:SetData(iKeyBinding)
end

function Keybinding:PopulateKeybindList()
    -- go thru all the key bindings and display the key binding items in the keybind list
	self.tItems = {}
	self.wndKeybindList:DestroyChildren()
	
	self:SetState(LuaEnumKeybindingState.Idle)
	
	local arActionCategories = GameLib.GetInputActionCategories()
	table.sort(arActionCategories, function(a,b) return a.strName < b.strName end)
	self.nCategoryCount = #arActionCategories

	table.sort(self.arKeyBindings, function(a,b) 
		if a.nDisplayIndex == b.nDisplayIndex then return a.idAction < b.idAction end
		return a.nDisplayIndex < b.nDisplayIndex
	end)
    
	for iCategory = 1, self.nCategoryCount do	    
		self:AddCategory(arActionCategories[iCategory])
		if not self.tCollapsedCategories[arActionCategories[iCategory].nCategoryId] then
			for idx = 1,#self.arKeyBindings do
				if self.arKeyBindings[idx].idCategory == arActionCategories[iCategory].nCategoryId then
					local bSkip = false

					if self.arKeyBindings[idx].arInputs[1].eDevice == GameLib.CodeEnumInputDevice.Mouse and 
					   (self.arKeyBindings[idx].arInputs[1].nCode == 0 or self.arKeyBindings[idx].arInputs[1].nCode == 1) then
						bSkip = true 
					end
					if not bSkip then
						self:AddKeyBinding(idx, self.arKeyBindings[idx])
					end
				end
			end
		end
	end
	
	-- align the items vertically
	self.wndKeybindList:ArrangeChildrenVert()
end

---------------------------------------------------------------------------------------------------
-- message dialog
---------------------------------------------------------------------------------------------------	
function Keybinding:ShowMessage(strMessage)
	self:EnableBindingButtons(false)
	self:EnableSetButtons(false)
	self.wndOkForm:FindChild("MessageText"):SetText(strMessage)
	self.wndOkForm:Show(true)
end

function Keybinding:OnOkFormOk(wndHandler, wndControl, eMouseButton)
	self:EnableBindingButtons(true)
	self:EnableSetButtons(true)
	self.wndOkForm:Show(false)
end
---------------------------------------------------------------------------------------------------
-- Yes no dialog
---------------------------------------------------------------------------------------------------	
function Keybinding:ShowYesNoDialog(strMsg, fnContinue, oContinue, fnYes, oYes, fnNo, oNo)
    self.oContinue = oContinue
    self.fnContinue = fnContinue
    self.oContinue = oContinue
    self.fnYes = fnYes
    self.oYes = oYes
    self.fnNo = fnNo
    self.oNo = oNo
    self.bShowingYesNoDialog = true
    self.wndYesNoForm:Show(true)
    self.wndYesNoForm:FindChild("QuestionText"):SetText(strMsg)
	self:ShowBindingInterface(false)
    self:EnableBindingButtons(false)
    self:EnableSetButtons(false)
    self.wndSetSave:Enable(false)
	self.wndSetCancel:Enable(false)
	self:ShowUndoUnbindDuplicateMessage(false)
end
function Keybinding:ExitYesNoDialog(bYesNo)
    self.bShowingYesNoDialog = false
    if bYesNo == true then
        if self.fnYes ~= nil then
            self:fnYes(self.oYes)
        end
    else
        if self.fnNo ~= nil then
            self:fcnNo(self.oNo)
        end
    end
    if self.fnContinue ~= nil then 
        self:fnContinue(self.oContinue)
    end
    self:SetState(self.eState) -- update enable/disable windows
    self.wndYesNoForm:Show(false)
    self.wndBeforeYesNoDialog = nil
    self.fnContinue = nil
    self.fnYes = nil
    self.fnNo = nil
    self.wndSetSave:Enable(true)
	self.wndSetCancel:Enable(true)
end
function Keybinding:OnEscapeYesNoDialog()
    self:ExitYesNoDialog(false)
end
function Keybinding:OnYesNoFormYes() 
    if self.bShowingYesNoDialog then
        self:ExitYesNoDialog(true)
        return
    end
end
function Keybinding:OnYesNoFormNo()
    if self.bShowingYesNoDialog then
        self:ExitYesNoDialog(false)
        return
    end
    self.wndYesNoForm:Show(false)
end

---------------------------------------------------------------------------------------------------
-- Select set
---------------------------------------------------------------------------------------------------	

function Keybinding:OnToggleSetSelect() --this opens the set-selection dialog
	self:ShowUndoUnbindDuplicateMessage(false)
	if self.wndSetSelection:IsVisible() then
		self:SetState(LuaEnumKeybindingState.Idle)
		self.wndSetSelection:Show(false)
	else
	    self:SetState(LuaEnumKeybindingState.SelectingSet)
	    self.wndSetSelection:Show(true)
	    self.wndSetSelectionBtn:Enable(true)
	end	
end

function Keybinding:OnSetSelected(wndHandler, wndControl) --this function covers the buttons used in picking a set(ShortcutSet radio group)

    if wndHandler ~= wndControl then
        return
    end

	self:ShowUndoUnbindDuplicateMessage(false)
	
    self:OnToggleSetSelect()
    
    if self.bNeedSave then
        self:ShowYesNoDialog(Apollo.GetString("CRB_Would_you_like_to_save_the_current_s"), self.ContinueSetSelected, wndControl, self.Save)
    else
        self:ContinueSetSelected(wndControl)
    end
end	

function Keybinding:ContinueSetSelected(wndControl)

    local eCurrKeySet = wndControl:GetData()

    if self.eCurrKeySet ~= eCurrKeySet then
        self.eCurrKeySet = eCurrKeySet
        local bCompleted = GameLib.SetCurrInputKeySet(self.eCurrKeySet) -- SetCurrInputKeySet return FALSE if still need to wait for server to send client the keybindings
                                                                          -- when client received the keybinding from server, it will trigger the KeyBindingUpdated event
        self.wndSetSelectionBtn:SetText(self.arKeySetNames[self.eCurrKeySet])
        
        self:InitializeVariables()
        self.bNeedSaveSet = true
	    if bCompleted then -- if not completed, then delay refresh until receiving a KeyBindingUpdated event
	        self.arKeyBindings = GameLib.GetKeyBindings()
            self:PopulateKeybindList() -- refresh list
        end
    end    
end

function Keybinding:OnEscapeSetSelect()
    self:SetState(LuaEnumKeybindingState.Idle)
end

---------------------------------------------------------------------------------------------------
-- Helper functions
---------------------------------------------------------------------------------------------------	

-- enable all set select/save/cancel/copy buttons
function Keybinding:EnableSetButtons(bEnable) 
	self.wndSetSelectionBtn:Enable(bEnable)
end	

-- enable binding buttons
function Keybinding:EnableBindingButtons(bEnable)
    self.wndKeybindList:Enable(bEnable)
    self.wndListBlocker:Show(not bEnable)
end	

-- enable save/cancel buttons
function Keybinding:EnableSaveCancelButtons(bEnable)
   self.wndSetSave:Enable(bEnable)
   self.wndSetCancel:Enable(bEnable)
end	

-- set state and show/hide buttons according to the state
function Keybinding:SetState(eState)
	
    self.eState = eState
    
    if eState ~= LuaEnumKeybindingState.AcceptingInput and self.wndCurrBind ~= nil then
        -- make sure the selected key button is unchecked
        self.wndCurrBind:SetCheck(false)
		self.wndCurrBind = nil
		self.wndCurrModifierBind = nil
    end

	if eState ~= LuaEnumKeybindingState.AcceptingModifierInput and self.wndCurrModifierBind ~= nil then
        -- make sure the select modifier dropdown is unchecked
        self.wndCurrModifierBind:SetCheck(false)
    end
    
	if eState == LuaEnumKeybindingState.Idle then
        self:ShowBindingInterface(false)
        self:EnableBindingButtons(true)
        self:EnableSetButtons(true)
		self:EnableSaveCancelButtons(true)
    elseif eState == LuaEnumKeybindingState.AcceptingInput or eState == LuaEnumKeybindingState.AcceptingModifierInput then
		self:EnableBindingButtons(true)
        self:ShowBindingInterface(true)
        self:EnableSetButtons(true)
		self:EnableSaveCancelButtons(true)
    elseif eState == LuaEnumKeybindingState.SelectingSet then
        self:ShowBindingInterface(false)
        self:EnableBindingButtons(false)
        self:EnableSetButtons(false)
		self:EnableSaveCancelButtons(true)
	else
        Print( Apollo.GetString("CRB_ERROR_KeybindSetState__unhandled_sta") )
    end
    
end

---------------------------------------------------------------------------------------------------
-- Binding Interface
---------------------------------------------------------------------------------------------------	

function Keybinding:IsBindingModifierKey(iBinding)
	return self.wndCurrBind ~= nil and self.arKeyBindings[iBinding].strAction == "SprintModifier"
end

function Keybinding:IsCurrBindingModifierKey()
	return self.eState == LuaEnumKeybindingState.AcceptingModifierInput
end

-- show binding interface - buttons to unbind/cancel
function Keybinding:ShowBindingInterface(bShow)
	local bShowSelectModifier = bShow
	local bShowSelectBinding = bShow
	
	if bShow then
		bShowSelectModifier = self:IsCurrBindingModifierKey()
		bShowSelectBinding = not bShowSelectModifier
		self:ShowUndoUnbindDuplicateMessage(false)
	end
	
	if bShowSelectModifier then 
		-- reset the buttons to be unchecked for the select modifier window
		self.wndModifierSelection:FindChild("Shift"):SetCheck(false)
		self.wndModifierSelection:FindChild("Ctrl"):SetCheck(false)
		self.wndModifierSelection:FindChild("Alt"):SetCheck(false)
		
		-- set the position of the modifier selection window to be below the modifier dropdown button
		local nLeft, nTop, nRight, nBottom = self.wndModifierDropdown:GetRect()
		local nLeftP1, nTopP1, nRightP1, nBottomP1 = self.wndModifierDropdown:GetParent():GetRect()
		local nLeftP2, nTopP2, nRightP2, nBottomP2 = self.wndModifierDropdown:GetParent():GetParent():GetRect()
		local nLeftSelect, nTopSelect, nRightSelect, nBottomSelect = self.wndModifierSelection:GetRect()
		local nWidthSelect = nRightSelect - nLeftSelect
		local nHeightSelect = nBottomSelect - nTopSelect
	
		-- get the rect of dropdown button relative to the parent of the select window
		nLeft = nLeft + nLeftP1 + nLeftP2
		nTop = nTop + nTopP1 + nTopP2
		nRight = nRight + nLeftP1 + nLeftP2
		nBottom = nBottom + nTopP1 + nTopP2
		
		-- move the selection window to be right below the dropdown button
		self.wndModifierSelection:Move( nLeft + ((nRight - nLeft-nWidthSelect) / 2), nBottom + 2, nWidthSelect, nHeightSelect )
		

	end
	self.wndModifierSelection:Show(bShowSelectModifier)
	self.wndKeybindList:Enable(not bShowSelectModifier) -- disable keybind list if picking modifier
	self.wndBindUnbind:Show(bShowSelectBinding)
	self.wndBindCancel:Show(bShowSelectBinding)
	if bShowSelectBinding then
	    self.wndFeedback:SetText(String_GetWeaselString(Apollo.GetString("Keybinding_PickKey"), self.arKeyBindings[self.wndCurrBind:GetParent():GetData()].strActionLocalized ))
	else
	    self.wndFeedback:SetText("")
	end

end

function Keybinding:OnRestoreDefaults( wndHandler, wndControl, eMouseButton )
	self:ShowYesNoDialog(Apollo.GetString("CRB_This_will_replace_all_keybinds"), nil, nil, self.RestoreDefaults, nil, nil)
end

function Keybinding:RestoreDefaults()
	self:ShowUndoUnbindDuplicateMessage(false)

	-- overwrite the key set
	self.arKeyBindings = GameLib.GetInputKeySet(GameLib.CodeEnumInputSets.Default1)

	self:PopulateKeybindList() -- refresh list
   	self:InitializeVariables() 
	self.bNeedSave = true

end

---------------------------------------------------------------------------------------------------
-- Keybinding Functions
---------------------------------------------------------------------------------------------------
function Keybinding:ShowUndoUnbindDuplicateMessage(bShow)

	if not bShow or self.iUndoUnbindKeybinding == nil or self.iUndoKeybinding == nil then
		self.wndDuplicateMsg:Show(false)
		self.wndUndoUnbindDuplicate:Show(false)
		self.iUndoUnbindKeybinding = nil
		self.iUndoKeybinding = nil
		return
	end
	
	self.wndDuplicateMsg:SetText(String_GetWeaselString(Apollo.GetString("Keybinding_UnmappedDuplicate"), self.arKeyBindings[self.iUndoUnbindKeybinding].strActionLocalized ))
	self.wndDuplicateMsg:Show(true)
	self.wndUndoUnbindDuplicate:Show(true)
end

function Keybinding:OnUndoUnbindDuplicate( wndHandler, wndControl, eMouseButton )
	
	-- undo the keybind
	-- assign the key back to the unmapped key
	self.arKeyBindings[self.iUndoUnbindKeybinding].arInputs[self.iUndoUnbindSlot] = TableUtil:Copy( self.arKeyBindings[self.iUndoKeybinding].arInputs[self.iUndoSlot] )
	local wndUpdate = self.tItems[ self.arKeyBindings[self.iUndoUnbindKeybinding].idAction ]
	local tNewInput = self.arKeyBindings[self.iUndoUnbindKeybinding].arInputs[self.iUndoUnbindSlot] 
	if wndUpdate then
		local wndBindButton = wndUpdate:FindChild("BindButton".. self.iUndoUnbindSlot)
		wndBindButton :SetText( GameLib.GetInputKeyNameText(tNewInput) )
	end
			
	-- assign the old key back to the newly mapped key
	self.arKeyBindings[self.iUndoKeybinding].arInputs[self.iUndoSlot] = TableUtil:Copy( self.tUndoInput )
	wndUpdate  = self.tItems[ self.arKeyBindings[self.iUndoKeybinding].idAction ]
	tNewInput = self.tUndoInput
	if wndUpdate then
		local wndBindButton = wndUpdate:FindChild("BindButton".. self.iUndoSlot)
		wndBindButton :SetText( GameLib.GetInputKeyNameText(tNewInput) )
	end
	
	self:ShowUndoUnbindDuplicateMessage(false)
		
end

function Keybinding:OverwriteDuplicates(iKeybinding, tInput)
	self.iUndoUnbindKeybinding = nil -- the keybind that's being overwritten/unbound
	self.iUndoUnbindSlot = nil -- the slot of the keybind that being unbound
    for idx = 1,#self.arKeyBindings do
        if idx ~= iKeybinding then
			for iBinding = 1, 2 do	
                if self.arKeyBindings[idx].arInputs[iBinding].nCode == tInput.nCode and 
				   self.arKeyBindings[idx].arInputs[iBinding].eDevice == tInput.eDevice and 
				   self.arKeyBindings[idx].arInputs[iBinding].eModifier == tInput.eModifier
                then
					-- keep track of what is unmapped so that user can undo
					self.iUndoUnbindKeybinding = idx
					self.iUndoUnbindSlot = iBinding
					
					-- unmap the duplicate
					local wndDuplicate = self.tItems[self.arKeyBindings[idx].idAction]
					if wndDuplicate then
						local wndBindButton = wndDuplicate:FindChild("BindButton"..iBinding)
						if wndBindButton then
							wndBindButton:SetText(GameLib.GetInputKeyNameText({eDevice = GameLib.CodeEnumInputDevice.None}))
						end
					end
					self.arKeyBindings[idx].arInputs[iBinding] = {eDevice = GameLib.CodeEnumInputDevice.None} 
					self:ShowUndoUnbindDuplicateMessage(true)
                end    
            end
        end
    end
end

function Keybinding:OnCancelBind()
    -- back to idle state
	self:SetState(LuaEnumKeybindingState.Idle)
	return true
end

function Keybinding:GetModifierFlag(nModifierScancode)
	if nModifierScancode == GameLib.CodeEnumInputModifierScancode.LeftShift then
		return GameLib.CodeEnumInputModifier.Shift
	elseif nModifierScancode == GameLib.CodeEnumInputModifierScancode.LeftCtrl then
		return GameLib.CodeEnumInputModifier.Control
	elseif nModifierScancode == GameLib.CodeEnumInputModifierScancode.LeftAlt then
		return GameLib.CodeEnumInputModifier.Alt
	else
		return 0 
	end
end

function Keybinding:GetModifierString(nModifierScancode)
	if nModifierScancode == GameLib.CodeEnumInputModifierScancode.LeftShift then
		return Apollo.GetString("Keybinding_ShiftMod")
	elseif nModifierScancode == GameLib.CodeEnumInputModifierScancode.LeftCtrl then
		return Apollo.GetString("Keybinding_CtrlMod")
	elseif nModifierScancode == GameLib.CodeEnumInputModifierScancode.LeftAlt then
		return Apollo.GetString("Keybinding_AltMod")
	else
		return ""
	end
end

function Keybinding:OnKeyDown(wndHandler, wndControl, strKeyName, nCode, eModifier)
    
    if wndHandler ~= wndControl then
		return false
	end
	
	-- ignore shift ctrl and alt because they are used as modifiers
	if not GameLib.IsKeyBindable(nCode) then
		return false
	end
	
	if not self.wndCurrBind then
		return false
	end
	
	-- ignore if it's the same as its sibling input
	local iSiblingInput = 1
	if self.wndCurrBind:GetData() == 1 then
	    iSiblingInput = 2
	end
	local iKeybinding = self.wndCurrBind:GetParent():GetData();
	if self.arKeyBindings[iKeybinding].arInputs[iSiblingInput].nCode == nCode and self.arKeyBindings[iKeybinding].arInputs[iSiblingInput].eModifier == eModifier then
	    return false
    end

    if self.eState == LuaEnumKeybindingState.AcceptingInput then
        
		-- error out if using the modifier that is assigned to sprint
		local nModifierFlag = self:GetModifierFlag(self.nReservedModifier)
		if bit32.band(eModifier, nModifierFlag) > 0 then -- player is trying to bind a key with the reserved modifier flag
			self:ShowMessage(String_GetWeaselString(Apollo.GetString("Keybinding_ReservedForSprint"), self:GetModifierString(self.nReservedModifier)))
			return false
		end		

		self:ClearSprintIfModifier(iKeybinding, self.wndCurrBind:GetData(), iSiblingInput)	
		
        -- set the currently selected input binding
        local tCurrInput = {} 
		tCurrInput.eDevice = GameLib.CodeEnumInputDevice.Keyboard
        tCurrInput.nCode = nCode
		if not self:IsSprintAction(self.arKeyBindings[iKeybinding]) then
	        tCurrInput.eModifier = eModifier
		else
			tCurrInput.eModifier = 0
		end
        
	    -- set the binding
	    self:AcceptCurrInput(iKeybinding, tCurrInput)
	   
	    self:SetState(LuaEnumKeybindingState.Idle)
		
		return true;
    end
end

function Keybinding:OnMouseWheel(wndHandler, wndControl, nX, nY, nDelta, eModifier)
    -- only process the wheel signal when accepting input
    if self.eState == LuaEnumKeybindingState.AcceptingInput then
        local nCode = GameLib.CodeEnumInputMouse.WheelUp
        if  nDelta < 0 then
            nCode = GameLib.CodeEnumInputMouse.WheelDown
        end
		
		-- error out if using the modifier that is assigned to sprint
		local nModifierFlag = self:GetModifierFlag(self.nReservedModifier)
		if bit32.band(eModifier, nModifierFlag) > 0 then -- player is trying to bind a key with the reserved modifier flag
			self:ShowMessage(String_GetWeaselString(Apollo.GetString("Keybinding_ReservedForSprint"), self:GetModifierString(self.nReservedModifier)))
			return false
		end
		
        -- ignore if it's the same as its sibling input
        local iSiblingInput = 1
        if self.wndCurrBind:GetData() == 1 then
            iSiblingInput = 2
        end
		
        local iKeybinding = self.wndCurrBind:GetParent():GetData();
        if self.arKeyBindings[iKeybinding].arInputs[iSiblingInput].nCode == nCode and 
           self.arKeyBindings[iKeybinding].arInputs[iSiblingInput].eDevice == GameLib.CodeEnumInputDevice.Mouse and 
		   self.arKeyBindings[iKeybinding].arInputs[iSiblingInput].eModifier == eModifier then
           return true
        end
        
        -- assign the new binding
		local tCurrInput = {}
        tCurrInput.eDevice = GameLib.CodeEnumInputDevice.Mouse
        tCurrInput.nCode = nCode
        tCurrInput.eModifier = eModifier

		self:ClearSprintIfModifier(iKeybinding)
	   
	    -- set the binding
	    self:AcceptCurrInput(iKeybinding, tCurrInput)
	   
	    self:SetState(LuaEnumKeybindingState.Idle)
		
		return true;
    end
    
    return false
end

function Keybinding:AcceptCurrInput(iKeybinding, tCurrInput)
	
	self.iUndoKeybinding = iKeybinding -- keep track of the keybind just got changed (in case of undoing unmapping due to duplicate)
	self.tUndoInput = TableUtil:Copy(self.arKeyBindings[iKeybinding].arInputs[self.wndCurrBind:GetData()]) -- undo input = input before changes
	self.iUndoSlot = self.wndCurrBind:GetData() -- the slot being changed
	
	-- if there are any duplicates, save over them
	self:OverwriteDuplicates(iKeybinding, tCurrInput)

	self.bNeedSave = true
    self.wndCurrBind:SetCheck(false)
    self.arKeyBindings[iKeybinding].arInputs[self.wndCurrBind:GetData()] = TableUtil:Copy(tCurrInput)
    self.wndCurrBind:SetText(GameLib.GetInputKeyNameText(tCurrInput))
end

function Keybinding:OnClick( wndHandler, wndControl )
    if self.bShowingYesNoDialog then
        return -- ignore everything
    end
    if self.eState == LuaEnumKeybindingState.AcceptingInput or self.eState == LuaEnumKeybindingState.AcceptingModifierInput then
		self:SetState(LuaEnumKeybindingState.Idle)
    elseif self.eState == LuaEnumKeybindingState.SelectingSet then
        self:OnToggleSetSelect() --cancel set select 
    end
end

function Keybinding:OnBindButton(wndHandler, wndControl, eMouseButton)

	if wndHandler ~= wndControl then
		return false
	end
	
	-- if current key set is the preset default set, then disable editing
    if not GameLib.CanEditKeySet(self.eCurrKeySet) then
        self.wndFeedback:SetText(Apollo.GetString("CRB_Default_key_sets_cannot_be_edited"))
        return false
    end

	if self.eState == LuaEnumKeybindingState.Idle and eMouseButton ~= GameLib.CodeEnumInputMouse.Left then
	    -- selecting mode - only accept left mouse click
        return false
	end
	
	-- capturing mouse input change
	if self.eState == LuaEnumKeybindingState.AcceptingInput and self.wndCurrBind == wndControl then
	    if eMouseButton == GameLib.CodeEnumInputMouse.Left or eMouseButton == GameLib.CodeEnumInputMouse.Right then
            -- left mouse and right mouse cannot be selected
             return false
        end
		
		-- error out if using the modifier that is assigned to sprint
		local nModifierFlag = self:GetModifierFlag(self.nReservedModifier)
		local eModifier = Apollo.GetMetaKeysDown()
		if bit32.band(eModifier, nModifierFlag) > 0 then -- player is trying to bind a key with the reserved modifier flag
			self:ShowMessage(String_GetWeaselString(Apollo.GetString("Keybinding_ReservedForSprint"), self:GetModifierString(self.nReservedModifier)))
			return false
		end
		
        -- ignore if it's the same as its sibling input
        local iSiblingInput = 1
        if self.wndCurrBind:GetData() == 1 then
            iSiblingInput = 2
        end
        local iKeybinding = self.wndCurrBind:GetParent():GetData()
        if self.arKeyBindings[iKeybinding].arInputs[iSiblingInput].nCode == nCode and 
		   self.arKeyBindings[iKeybinding].arInputs[iSiblingInput].eDevice == GameLib.CodeEnumInputDevice.Mouse and
		   self.arKeyBindings[iKeybinding].arInputs[iSiblingInput].eModifier == eModifier then
		return false
        end

		self:ClearSprintIfModifier(iKeybinding, self.wndCurrBind:GetData(), iSiblingInput)	

        -- this button is already selected -- accepting mouse input
        -- set the currently selected input binding
        local tCurrInput = {}
		tCurrInput.eDevice = GameLib.CodeEnumInputDevice.Mouse
        tCurrInput.nCode = eMouseButton
        tCurrInput.eModifier = eModifier
	    -- set the binding
	    self:AcceptCurrInput(iKeybinding, tCurrInput)
	    self:SetState(LuaEnumKeybindingState.Idle)
		return true;
	end
	
	-- set up for binding for the selected 
	if self.wndCurrBind ~= nil then
		self.wndCurrBind:SetCheck(false)
	end
	
	self.wndCurrBind = wndControl
	self.wndCurrBind:SetCheck(true)
	
	self:SetState(LuaEnumKeybindingState.AcceptingInput)
	
	wndControl:SetFocus()
	
end
		
function Keybinding:OnUnbindButton()
    if self.eState == LuaEnumKeybindingState.AcceptingInput then		
        -- set the currently selected input binding
        local tCurrInput = {} 
		tCurrInput.eDevice = GameLib.CodeEnumInputDevice.None
        tCurrInput.nCode = 0
        tCurrInput.eModifier = 0
        
	    -- set the binding
	    self:AcceptCurrInput(self.wndCurrBind:GetParent():GetData(), tCurrInput)
	   
	    self:SetState(LuaEnumKeybindingState.Idle)
	end
end

---------------------------------------------------------------------------------------------------
-- Applying Changes
---------------------------------------------------------------------------------------------------
function Keybinding:Save()   
    GameLib.SetKeyBindings(self.arKeyBindings) -- save the key bindings, will do nothing if it's default settings

	self.eOriginalKeySet = self.eCurrKeySet
	self.bNeedSaveSet = false
	self.bNeedSave = false
end

function Keybinding:OnSaveBtn() --the bottom "Save" button
    self:Save()
	self:OnClose()
end 

function Keybinding:OnCancelBtn() --the bottom "Cancel" button

    if self.bShowingYesNoDialog then
        return
    end
    
    if self.bNeedSave or self.bNeedSaveSet then
       self:ShowYesNoDialog(Apollo.GetString("CRB_Would_you_like_to_save_the_current_s_1"), self.OnClose, nil, self.Save)
    else
       self:OnClose()
    end
	
end 

function Keybinding:OnClose()
    GameLib.PauseGameActionInput(false)
    self.wndCurrBind = nil
	self.wndCurrModifierBind = nil
    self.eState = LuaEnumKeybindingState.Idle
    self.wndKeybindingForm:Show(false)

	self.tItems = {}
	self.wndKeybindList:DestroyChildren()
	
    self.arKeyBindings = {}
    
    if self.eOriginalKeySet ~= self.eCurrKeySet then
        GameLib.SetCurrInputKeySet(self.eOriginalKeySet) -- revert back to original key set
    end
    
	Event_FireGenericEvent("KeybindInterfaceClosed") --The Options UI should listen for this and re-enable.
end

---------------------------------------------------------------------------------------------------
-- KeybindModifierKeyItem Functions
---------------------------------------------------------------------------------------------------

function Keybinding:OnModifierSelected(wndHandler, wndControl, eMouseButton)
	
	if wndHandler ~= wndControl then
		return false
	end	
	
	if eMouseButton ~= GameLib.CodeEnumInputMouse.Left then
		return true
	end
	
	-- if nothing changed, then just return
	local nOldCode = self.nReservedModifier
	local nNewCode = wndControl:GetContentId()
	if nOldCode == nNewCode then
		self:SetState(LuaEnumKeybindingState.Idle)
		self.wndCurrModifierBind = nil
		return true
	end

	local tCurrInput = {}
	tCurrInput.eDevice = GameLib.CodeEnumInputDevice.Keyboard
    tCurrInput.nCode = nNewCode
    tCurrInput.eModifier = 0
	
	local tModifierSelectedState = {}
	tModifierSelectedState.tCurrInput = tCurrInput
	tModifierSelectedState.nOldCode = nOldCode
	tModifierSelectedState.nNewCode = nNewCode
	
	if self:IsModifierInUse(nNewCode) then
		if self:GetModifierFlag(nOldCode) == 0 then
			local strYesNoMsg = String_GetWeaselString(Apollo.GetString("Keybinding_ModifierCleared"), self:GetModifierString(nNewCode))
			self:ShowYesNoDialog(strYesNoMsg, nil, nil, self.FinalizeModifierSelected, tModifierSelectedState, nil, nil)
		else
			self:ShowMessage(String_GetWeaselString(Apollo.GetString("Keybinding_ModifierUpdated"), self:GetModifierString(nNewCode), self:GetModifierString(nOldCode)))
			self:FinalizeModifierSelected(tModifierSelectedState)
		end
	else
		self:FinalizeModifierSelected(tModifierSelectedState)
	end
end

function Keybinding:FinalizeModifierSelected(tModifierSelectedState)
	local tCurrInput = tModifierSelectedState.tCurrInput

	self.nReservedModifier = tModifierSelectedState.nNewCode
        
    self.bNeedSave = true
       
	-- update keybinding
	self.arKeyBindings[self.wndCurrModifierBind:GetParent():GetData()].arInputs[1] = TableUtil:Copy(tCurrInput)
	-- update keybinding2 to right shift/ctrl/alt
	if tCurrInput.nCode == GameLib.CodeEnumInputModifierScancode.LeftShift then
		tCurrInput.nCode = GameLib.CodeEnumInputModifierScancode.RightShift
	elseif tCurrInput.nCode == GameLib.CodeEnumInputModifierScancode.LeftCtrl then
		tCurrInput.nCode = GameLib.CodeEnumInputModifierScancode.RightCtrl
	elseif tCurrInput.nCode == GameLib.CodeEnumInputModifierScancode.LeftAlt then
		tCurrInput.nCode = GameLib.CodeEnumInputModifierScancode.RightAlt
	else -- error - unknown modifier chosen
		tCurrInput = {eDevice = GameLib.CodeEnumInputDevice.None}
	end
	self.arKeyBindings[self.wndCurrModifierBind:GetParent():GetData()].arInputs[2] = TableUtil:Copy(tCurrInput)

	self.wndCurrModifierBind:GetParent():FindChild("BindButton1"):SetText(Apollo.GetString("Keybinding_Unbound"))
	
    -- update display
    self.wndCurrModifierBind:SetText(GameLib.GetInputKeyNameText(tCurrInput))

	-- go thru all the keybinds and convert any keybinding that use the new modifier as a modifier key to use the old modifier instead
	local nOldModifierFlag = self:GetModifierFlag(tModifierSelectedState.nOldCode)
	local nNewModifierFlag = self:GetModifierFlag(tModifierSelectedState.nNewCode)
	for idx = 1,#self.arKeyBindings do
    	for iBinding = 1, 2 do
    		if self.arKeyBindings[idx].arInputs[iBinding].eDevice ~= GameLib.CodeEnumInputDevice.None and -- if new modifer is used
    			bit32.band(self.arKeyBindings[idx].arInputs[iBinding].eModifier, nNewModifierFlag) > 0
   			then -- change it to use old modifer instead
				local eModifier = self.arKeyBindings[idx].arInputs[iBinding].eModifier
	            -- remove the new modifier
				eModifier = bit32.band( eModifier, bit32.bnot(nNewModifierFlag))
			   	-- add the old modifier 
				eModifier = bit32.bor(eModifier, nOldModifierFlag)
				-- assign & update the UI
				
				if eModifier == 0 then
					self.arKeyBindings[idx].arInputs[iBinding].eDevice = GameLib.CodeEnumInputDevice.None
					self.arKeyBindings[idx].arInputs[iBinding].nCode = 0
					self.arKeyBindings[idx].arInputs[iBinding].eModifier = 0
				else				
					self.arKeyBindings[idx].arInputs[iBinding].eModifier = eModifier
				end

				local wndCurrBinding = self.tItems[self.arKeyBindings[idx].idAction]
				if wndCurrBinding then
					wndCurrBinding:FindChild("BindButton" .. iBinding):SetText(GameLib.GetInputKeyNameText(self.arKeyBindings[idx].arInputs[iBinding]))
				end
			end
		end
	end
	
	self:SetState(LuaEnumKeybindingState.Idle)
	self.wndCurrModifierBind:SetCheck(false)
	self.wndCurrModifierBind = nil
	
	return true
end

function Keybinding:IsModifierInUse(newCode)
	
	local nNewModifierFlag = self:GetModifierFlag(newCode)

	for idx = 1,#self.arKeyBindings do
    	for iBinding = 1, 2 do
    		if self.arKeyBindings[idx].arInputs[iBinding].eDevice ~= GameLib.CodeEnumInputDevice.None and
    			bit32.band(self.arKeyBindings[idx].arInputs[iBinding].eModifier, nNewModifierFlag) > 0
   			then
				return true
			end
		end
	end
		
	return false
end

function Keybinding:OnModifierDropdownToggle(wndHandler, wndControl, eMouseButton)

	if wndHandler ~= wndControl or eMouseButton ~= GameLib.CodeEnumInputMouse.Left then
		return false
	end
	
	self.wndCurrModifierBind = wndControl
	self.wndCurrModifierBind:SetCheck(true)
	
	self:SetState(LuaEnumKeybindingState.AcceptingModifierInput)
	
	wndControl:SetFocus()
	return true
	
end

---------------------------------------------------------------------------------------------------
-- KeyboardCategoryItem Functions
---------------------------------------------------------------------------------------------------

function Keybinding:OnCategoryClick(wndHandler, wndControl)
	if self.bCollapseAll then
		self.wndKeybindingForm:FindChild("ToggleCategory"):SetText(Apollo.GetString("CRB_Collapse_All"))
		self.bCollapseAll = false
	end

	local id = wndHandler:GetData()
	if self.tCollapsedCategories[id] then
		self.tCollapsedCategories[id] = nil
		self.nCollapsedCount = self.nCollapsedCount - 1
	else
		self.tCollapsedCategories[id] = true
		self.nCollapsedCount = self.nCollapsedCount + 1
	end
	
	if self.nCollapsedCount == self.nCategoryCount then
		self.wndKeybindingForm:FindChild("ToggleCategory"):SetText(Apollo.GetString("CRB_Expand_All"))
		self.bCollapseAll = true	
	end
	
	self:PopulateKeybindList()
end

function Keybinding:OnToggleCategories(wndHandler, wndControl)
	if self.bCollapseAll then
		self.wndKeybindingForm:FindChild("ToggleCategory"):SetText(Apollo.GetString("CRB_Collapse_All"))
		self.tCollapsedCategories = {}
		self.nCollapsedCount = 0
	else
		self.wndKeybindingForm:FindChild("ToggleCategory"):SetText(Apollo.GetString("CRB_Expand_All"))

		local arActionCategories = GameLib.GetInputActionCategories()
		for iCategory = 1, self.nCategoryCount do	
			self.tCollapsedCategories[arActionCategories[iCategory].nCategoryId] = true
		end
		
		self.nCollapsedCount = self.nCategoryCount
	end
	
	self.bCollapseAll = not self.bCollapseAll
	self:PopulateKeybindList()
end


---------------------------------------------------------------------------------------------------
-- Keybinding instance
---------------------------------------------------------------------------------------------------
local KeybindingInst = Keybinding:new()
KeybindingInst:Init()
	
		

